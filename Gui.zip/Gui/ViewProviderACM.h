#pragma once

#include <Gui/ViewProviderDocumentObject.h>
#include <Base/Placement.h>
#include "CollisionObject.h"
//#include "../App/fcl/FCLMethodWrapper.h"

namespace WirCoreGui
{

class WirCoreGuiExport ViewProviderACM : public Gui::ViewProviderDocumentObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderACM);

public:   
    ViewProviderACM();
    ~ViewProviderACM();

    //fclwrapper::FclSceneObjects getFclEnvSceneObject();
    //fclwrapper::FclSceneObjects getFclRobotSceneObject();

    void initCollisionCheck();
    void collisionCheck();
    void updateACM();

    void initFCLCollisionCheck();
    void fclCollisionCheck();
    void deleteScene();

    //  Gui::Document::signalNewObject;
    virtual bool showInTree() const { return false; }
    void changeColor(std::string name);    
    int getIntersectionCount() const { return intersectionCount; }


    SoIntersectionDetectionAction* pCollisionDetectAction = nullptr;
    SoGroup* pRootScene = nullptr;
    std::map<Gui::ViewProvider*, App::Color> vps; // color change
    //fclwrapper::FCLMethodWrapper* fclCollision = nullptr;

protected:
    void slotNewObject(const Gui::ViewProviderDocumentObject& doc); //slot for new viewprovider document object    
    static SbBool intersectionFilter (void *userData, const SoPath *p1, const SoPath *p2);
    static SoIntersectionDetectionAction::Resp onIntersection(void *userData,
                                                              const SoIntersectingPrimitive *primitive1,
                                                              const SoIntersectingPrimitive *primitive2);
    bool allowedCollision(std::string name1, std::string name2);
    void addCollisionObj(CollisionObject* obj);
    bool createScene();   
    void updateACMObject();

    std::map<std::string, CollisionObject*> collisionObjMap;
    int intersectionCount = 0;
};

} //namespace WirCoreGui
