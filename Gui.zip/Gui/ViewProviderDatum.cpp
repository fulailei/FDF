#include "PreCompiled.h"

#ifndef _PreComp_
# include <QMessageBox>
# include <QAction>
# include <QMenu>
# include <Inventor/actions/SoGetBoundingBoxAction.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/nodes/SoPickStyle.h>
# include <Inventor/nodes/SoShapeHints.h>
# include <Inventor/nodes/SoMaterial.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoTransparencyType.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoMarkerSet.h>
# include <Inventor/nodes/SoVertexProperty.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/details/SoLineDetail.h>
# include <Inventor/details/SoFaceDetail.h>
# include <Inventor/details/SoPointDetail.h>
# include <TopoDS_Vertex.hxx>
# include <TopoDS.hxx>
# include <BRep_Tool.hxx>
# include <gp_Pnt.hxx>
# include <Precision.hxx>
# include <Geom_Plane.hxx>
# include <Geom_Line.hxx>
# include <GeomAPI_IntCS.hxx>
#endif

#include <App/DocumentObjectGroup.h>
#include <App/GeoFeatureGroupExtension.h>
#include <Gui/Control.h>
#include <Gui/Command.h>
#include <Gui/Application.h>
#include <Gui/MDIView.h>
#include <Gui/ViewProviderOrigin.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>

#include "ViewProviderDatum.h"
#include <../App/DatumCS.h>

using namespace Gui;
using namespace WirCoreGui;

PROPERTY_SOURCE(WirCoreGui::ViewProviderDatum,Gui::ViewProviderGeometryObject)

// static data
const double ViewProviderDatum::defaultSize = Gui::ViewProviderOrigin::defaultSize ();
double ViewProviderDatum::size = 0.1;
ViewProviderDatum::ViewProviderDatum()
{
    pShapeSep = new SoSeparator();
    pShapeSep->ref();
    pPickStyle = new SoPickStyle();
    pPickStyle->ref();

    DisplayMode.setStatus(App::Property::Hidden, true);

    // set default color for datums (golden yellow with 60% transparency)
    ParameterGrp::handle hGrp = App::GetApplication().GetParameterGroupByPath (
            "User parameter:BaseApp/Preferences/Mod/PartDesign");// ?????????????
    unsigned long shcol = hGrp->GetUnsigned ( "DefaultDatumColor", 0xFFD70099 );

    App::Color col ( (uint32_t) shcol );
    ShapeColor.setValue ( col );

    Transparency.setValue (col.a * 100);

    oldTip = NULL;
}

ViewProviderDatum::~ViewProviderDatum()
{
    pShapeSep->unref();
    pPickStyle->unref();
}

void ViewProviderDatum::attach(App::DocumentObject *obj)
{
    ViewProviderGeometryObject::attach ( obj );

    // only this
    App::DocumentObject* o = getObject();
    if (o->getTypeId() == WirCore::CoordinateSystem::getClassTypeId())
    {
        datumType = QString::fromLatin1("CoordinateSystem");
        datumText = QObject::tr("Coordinate System");
    }

    SoShapeHints* hints = new SoShapeHints();
    hints->shapeType.setValue(SoShapeHints::UNKNOWN_SHAPE_TYPE);
    hints->vertexOrdering.setValue(SoShapeHints::COUNTERCLOCKWISE);
    SoDrawStyle* fstyle = new SoDrawStyle();
    fstyle->style = SoDrawStyle::FILLED;
    fstyle->lineWidth = 3;
    fstyle->pointSize = 5;
    pPickStyle->style = SoPickStyle::SHAPE;
    SoMaterialBinding* matBinding = new SoMaterialBinding;
    matBinding->value = SoMaterialBinding::OVERALL;

    SoSeparator* sep = new SoSeparator();
    sep->addChild(hints);
    sep->addChild(fstyle);
    sep->addChild(pPickStyle);
    sep->addChild(matBinding);
    sep->addChild(pcShapeMaterial);
    sep->addChild(pShapeSep);

    addDisplayMaskMode(sep, "Base");
}

bool ViewProviderDatum::onDelete(const std::vector<std::string> &)
{
    // TODO: Ask user what to do about dependent objects, e.g. Sketches that have this feature as their support
    // 1. Delete
    // 2. Suppress
    // 3. Re-route

    return true;
}

std::vector<std::string> ViewProviderDatum::getDisplayModes(void) const
{
    return { "Base" };
}

void ViewProviderDatum::setDisplayMode(const char* ModeName)
{
    if (strcmp(ModeName, "Base") == 0)
        setDisplayMaskMode("Base");
    ViewProviderGeometryObject::setDisplayMode(ModeName);
}

std::string ViewProviderDatum::getElement(const SoDetail* detail) const
{
    if (detail)
    {
        int element = 1;

        if (detail->getTypeId() == SoLineDetail::getClassTypeId())
        {
            const SoLineDetail* line_detail = static_cast<const SoLineDetail*>(detail);
            element = line_detail->getLineIndex();
        }
        else if (detail->getTypeId() == SoFaceDetail::getClassTypeId())
        {
            const SoFaceDetail* face_detail = static_cast<const SoFaceDetail*>(detail);
            element = face_detail->getFaceIndex();
        }
        else if (detail->getTypeId() == SoPointDetail::getClassTypeId())
        {
            const SoPointDetail* point_detail = static_cast<const SoPointDetail*>(detail);
            element = point_detail->getCoordinateIndex();
        }

        if (element == 0)
            return datumType.toStdString();
    }

    return std::string("");
}

SoDetail* ViewProviderDatum::getDetail(const char* subelement) const
{
    QString subelem = QString::fromLatin1(subelement);

    if (subelem == QObject::tr("Line"))
    {
         SoLineDetail* detail = new SoLineDetail();
         detail->setPartIndex(0);
         return detail;
    }
    else if (subelem == QObject::tr("Plane"))
    {
        SoFaceDetail* detail = new SoFaceDetail();
        detail->setPartIndex(0);
        return detail;
    }
    else if (subelem == QObject::tr("Point"))
    {
        SoPointDetail* detail = new SoPointDetail();
        detail->setCoordinateIndex(0);
        return detail;
    }

    return NULL;
}

bool ViewProviderDatum::isSelectable(void) const
{
    return true;
}

void ViewProviderDatum::setupContextMenu(QMenu* menu, QObject* receiver, const char* member)
{
    Gui::ViewProviderGeometryObject::setupContextMenu(menu, receiver, member); // need this(has Position)
}

bool ViewProviderDatum::setEdit(int ModNum)
{
    if (!ViewProvider::setEdit(ModNum))
        return false;

    if (ModNum == ViewProvider::Default )
    {
        return true;
    }
    else
    {
        // return ViewProvider::setEdit(ModNum);
        return Gui::ViewProviderGeometryObject::setEdit(ModNum); // modify
    }
}

bool ViewProviderDatum::doubleClicked(void)
{
    return true;
}

void ViewProviderDatum::unsetEdit(int ModNum)
{
    if (ModNum == ViewProvider::Default)
    {
    }
    else
    {
        Gui::ViewProviderGeometryObject::unsetEdit(ModNum);
    }
}

void ViewProviderDatum::updateExtents ()
{
    setExtents ( getRelevantBoundBox () );
}

void ViewProviderDatum::setExtents (const SbBox3f &bbox)
{
    const SbVec3f & min = bbox.getMin ();
    const SbVec3f & max = bbox.getMax ();
    setExtents ( Base::BoundBox3d ( min.getValue()[0], min.getValue()[1], min.getValue()[2],
                                    max.getValue()[0], max.getValue()[1], max.getValue()[2] ) );
}

SbBox3f ViewProviderDatum::getRelevantBoundBox () const
{
    std::vector<App::DocumentObject *> objs;

    // Probe if we belongs to some group
    App::DocumentObject* group =  App::DocumentObjectGroup::getGroupOfObject ( this->getObject () );

    if(group)
    {
        auto* ext = group->getExtensionByType<App::GroupExtension>();
        if(ext)
            objs = ext->getObjects ();
    }
    else
    {
        // Fallback to whole document
        objs = this->getObject ()->getDocument ()->getObjects ();
    }

    Gui::View3DInventor* view = dynamic_cast<Gui::View3DInventor*>(this->getActiveView());
    if(view)
    {
       Gui::View3DInventorViewer* viewer = view->getViewer();
       SoGetBoundingBoxAction bboxAction(viewer->getSoRenderManager()->getViewportRegion());
       SbBox3f bbox = getRelevantBoundBox (bboxAction, objs);
       return bbox;
    }
    else
    {
       return defaultBoundBox();
    }
}

SbBox3f ViewProviderDatum::getRelevantBoundBox (
        SoGetBoundingBoxAction &bboxAction, const std::vector <App::DocumentObject *> &objs )
{
    SbBox3f bbox = defaultBoundBox();

    // Adds the bbox of given feature to the output
    for (auto obj :objs)
    {
        ViewProvider *vp = Gui::Application::Instance->getViewProvider(obj);
        if (!vp) { continue; }
        if (!vp->isVisible()) { continue; }

        if (obj->isDerivedFrom(Part::Datum::getClassTypeId()))
        {
            // Treat datums only as their basepoint
            // I hope it's ok to take FreeCAD's point here
            Base::Vector3d basePoint = static_cast<Part::Datum *>(obj)->getBasePoint();
            bbox.extendBy(SbVec3f(basePoint.x, basePoint.y, basePoint.z));
        }
        else
        {
            bboxAction.apply(vp->getRoot());
            SbBox3f obj_bbox =  bboxAction.getBoundingBox();

            if (obj_bbox.getVolume() < Precision::Infinite())
            {
                bbox.extendBy(obj_bbox);
            }
        }
    }

    // TODO: shrink bbox when all other elements are too small
    return bbox;
}

SbBox3f ViewProviderDatum::defaultBoundBox ()
{
    return SbBox3f ( -defaultSize, -defaultSize, -defaultSize,
            defaultSize, defaultSize, defaultSize );
}

bool ViewProviderDatum::isPickable()
{
    return bool(pPickStyle->style.getValue() == SoPickStyle::SHAPE);
}

void ViewProviderDatum::setPickable(bool val)
{
    if(val)
        pPickStyle->style = SoPickStyle::SHAPE;
    else
        pPickStyle->style = SoPickStyle::UNPICKABLE;
}
