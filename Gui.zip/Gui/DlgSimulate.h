
#ifndef WIROLP_DLGSIMULATE_H
#define WIROLP_DLGSIMULATE_H

#include <Gui/TaskView/TaskDialog.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

#include "RobotOptions.h"
#include "RobotSim.h"

namespace WirCoreGui {


/// simulation dialog for the TaskView
class DlgSimulate : public Gui::TaskView::TaskDialog
{
    Q_OBJECT

public:
    DlgSimulate(WirCore::RobotObject *pcRobotObject,
                WirCore::TrajectoryObject *pcTrajectoryObject);

    ~DlgSimulate();

public:
    /// is called the TaskView when the dialog is opened
    virtual void open();
    /// is called by the framework if an button is clicked which has no accept or rject role
    virtual void clicked(int);
    /// is called by the framework if the dialog is accepted (Ok)
    virtual bool accept();
    /// is called by the framework if the dialog is rejected (Cancel)
    virtual bool reject();
    /// is called by the framework if the user press the help button
    virtual void helpRequested();

    /// returns for Close and Help button
    virtual QDialogButtonBox::StandardButtons getStandardButtons(void) const
    { return QDialogButtonBox::Close|QDialogButtonBox::Help; }

protected:
    RobotOptions    *rob;
    RobotSim        *trac;

};



} //namespace RobotGui

#endif // ROBOTGUI_TASKDLGSIMULATE_H
