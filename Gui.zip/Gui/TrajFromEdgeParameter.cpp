#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include <QString>
#include <QSlider>
#include "ui_TrajFromEdgeParameter.h"
#include "TrajFromEdgeParameter.h"
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/BitmapFactory.h>
#include <Gui/ViewProvider.h>
#include <Gui/WaitCursor.h>
#include <Base/Console.h>
#include <Gui/Selection.h>


using namespace WirCoreGui;
using namespace Gui;


TrajFromEdgeParameter::TrajFromEdgeParameter(QWidget *parent)
    : TaskBox(Gui::BitmapFactory().pixmap("WirCore_TrajectoryFromEdge"),
              tr("TrajFromEdgeParameter"),
              true,
              parent)
{
    faceFilter =  "SELECT Part::Feature SUBELEMENT Face COUNT 1";
    edgeFilter =  "SELECT Part::Feature SUBELEMENT Edge COUNT 1";

    proxy = new QWidget(this);
    ui = new Ui_TrajFromEdgeParameter();
    ui->setupUi(proxy);
    QMetaObject::connectSlotsByName(this);

    ui->listWidget_edge->installEventFilter(this);
    ui->listWidget_face->installEventFilter(this);

  //  Qt::ClickFocus(true);

    this->groupLayout()->addWidget(proxy);
    Gui::Selection().Attach(this);

    QObject::connect(ui->doubleSpinBoxSizing, SIGNAL(valueChanged(double)), this, SLOT(sizingValueChanged(double)));

    m_selEdgeObject = nullptr;
    m_selFaceObject = nullptr;
    m_sel = 0;
}

void TrajFromEdgeParameter::sizingValueChanged(double size) {
    (void)size;
}

TrajFromEdgeParameter::~TrajFromEdgeParameter()
{
    delete ui;
    Gui::Selection().Detach(this);
}


bool TrajFromEdgeParameter::eventFilter(QObject* watched, QEvent* event)
{
    if (event->type()==QEvent::FocusIn)
    {
        QPalette palette(QApplication::palette());
        Gui::Selection().clearSelection();
        if (watched == ui->listWidget_edge) {

            palette.setBrush(QPalette::Base,QColor(255,0,0));
            ui->listWidget_edge->setPalette(palette);
            // set the gate for the filter
            Gui::Selection().addSelectionGate(new SelectionFilterGate(edgeFilter.c_str()));
            m_sel = 1;
        }
        else if (watched == ui->listWidget_face) {
            palette.setBrush(QPalette::Base,QColor(255,0,0));
            ui->listWidget_face->setPalette(palette);
            Gui::Selection().addSelectionGate(new SelectionFilterGate(faceFilter.c_str()));
            m_sel = 2;
        }
    }

    return false;
}

void TrajFromEdgeParameter::setSelection2Buffer(void)
{
    std::vector<Gui::SelectionObject> temp = Gui::Selection().getSelectionEx();
    assert(temp.size() >= 1);
    if (m_sel == 1) {
        m_selEdgeObject = temp[0].getObject();
        edgeSubname = temp[0].getSubNames();
    }
    else if (m_sel == 2) {
        m_selFaceObject = temp[0].getObject();
        faceSubname = temp[0].getSubNames()[0];
    }
}

void TrajFromEdgeParameter::OnChange(Gui::SelectionSingleton::SubjectType &rCaller,
                                      Gui::SelectionSingleton::MessageType Reason)
{
    Q_UNUSED(rCaller);
    if (Reason.Type == SelectionChanges::AddSelection ||
        Reason.Type == SelectionChanges::RmvSelection ||
        Reason.Type == SelectionChanges::SetSelection ||
        Reason.Type == SelectionChanges::ClrSelection) {
            std::vector<Gui::SelectionSingleton::SelObj> sel = Gui::Selection().getSelection();
            for (std::vector<Gui::SelectionSingleton::SelObj>::const_iterator it=sel.begin();it!=sel.end();++it)
            {
                std::string temp;
                temp += it->FeatName;
                if (strcmp(it->SubName, "") != 0){
                    temp += "::";
                    temp += it->SubName;
                }
                if (m_sel == 2)
                {
                    ui->listWidget_face->clear();
                    new QListWidgetItem(QString::fromLatin1(temp.c_str()), ui->listWidget_face);
                }
                else if (m_sel == 1)
                {
                    ui->listWidget_edge->clear();
                    new QListWidgetItem(QString::fromLatin1(temp.c_str()), ui->listWidget_edge);
                }
                setSelection2Buffer();
            }
    }
}
/// @endcond
///
#include "moc_TrajFromEdgeParameter.cpp"
