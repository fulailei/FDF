#ifndef WIRCORE_WORKBENCH_H
#define WIRCORE_WORKBENCH_H

#include <Gui/Workbench.h>
#include <Gui/TaskView/TaskWatcher.h>

class QMenu;
class QAction;
class QComboBox;

namespace tt
{
    class Page;
    class Group;
    class TabToolbar;
}

namespace WirCoreGui {

class Workbench : public Gui::BlankWorkbench
{
    TYPESYSTEM_HEADER();

public:
    Workbench();
    virtual ~Workbench();

    virtual void setupContextMenu(const char* recipient, Gui::MenuItem*) const;
    virtual void activated();
    virtual void deactivated();

    void retranslate() const;

protected:
    virtual Gui::MenuItem* setupMenuBar() const;
    virtual Gui::ToolBarItem* setupToolBars() const;
    virtual Gui::ToolBarItem* setupCommandBars() const;
    virtual Gui::DockWindowItems* setupDockWindows() const;

    void addACMObject();
    std::vector<Gui::TaskView::TaskWatcher*> Watcher;

private:
    // start model simulate
    // Start
    //      "File"
    //      "Edit"
    //      "Create Workstation"
    //      "Trajectory programming"
    //      "Setting"
    //      "Freehand"
    //      "Graphics Tools"

    // Model
    //      Part
    //      PointCloud

    // Simulation
    //      Collision
    //      Simulate Trajectory

    // View

    tt::Page* createStartPage() const;
        tt::Group* createFreeHandGroup(tt::Page* , QList<QAction*>/*, std::function<QAction*(const QList<QAction*>& actions, const char* name)>*/) const;
        tt::Group* createrGraphicsToolsGroup(tt::Page*) const;

    tt::Page* createModelPage() const;
    tt::Page* createSimulatePage() const;
    tt::Page* createViewPage() const;
    tt::Page* createMachiningPage() const;

    QAction* findAction(const QList<QAction*>& actions, std::string& name) const;
    QAction* setupAction(const QList<QAction*>& actions, const char* name) const;



    // need translate

    mutable tt::TabToolbar* m_pTabToolbar = nullptr;

    mutable tt::Page* m_pPage_Start;
        mutable tt::Group* m_pGroup_File;
        mutable tt::Group* m_pGroup_Edit;
        mutable tt::Group* m_pGroup_CreateWorkstation;
        mutable tt::Group* m_pGroup_TrajectoryProgramming;
        mutable tt::Group* m_pGroup_Setting;
            mutable QWidget* m_pActiveObj;
        mutable tt::Group* m_pGroup_Freehand;
            mutable QComboBox* m_pComCS = nullptr;
        mutable tt::Group* m_pGroup_GraphicsTools;
            mutable QAction* m_pActShowHide = nullptr;
            mutable QAction* m_PActFrameSize = nullptr;

    mutable tt::Page* m_pPage_Model;
        mutable tt::Group* m_pGroup_Part;
        mutable tt::Group* m_pGroup_PointCloud;
        mutable tt::Group* m_pGroup_Measure;


    mutable tt::Page* m_pPage_Simulation;
        mutable tt::Group* m_pGroup_Collision;
        mutable tt::Group* m_pGroup_SimulateTrajectory;

    mutable tt::Page* m_pPage_View;
    mutable tt::Page* m_pPage_Machining;
};

} // namespace WirCoreGui

#endif // WirCore_WORKBENCH_H
