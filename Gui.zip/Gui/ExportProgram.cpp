#include "PreCompiled.h"

#ifndef _PreComp_
#include <Inventor/nodes/SoSeparator.h>
#endif

#include <Mod/WirCore/App/robot_prog/ABBProgGenerator.h>
#include "ExportProgram.h"
#include <Gui/Application.h>
#include <Gui/Document.h>

using namespace WirCoreGui;
using namespace Gui;

ExportProgram::ExportProgram(WirCore::RobotObject *pcRobotObject, WirCore::TrajectoryObject *pcTrajectoryObject)
{
    robot = pcRobotObject;
    traj = pcTrajectoryObject;
    mw = new TextEdit();
}
ExportProgram::~ExportProgram()
{
    if(mw){
        delete mw;
    }
}

void ExportProgram::generateRobotProgram()
{
    Base::Console().Message("generate robot program clicked\n");
    //TODO: generate robot program here

    std::string rname = robot->getNameInDocument();
    if(rname.find("Abb") != std::string::npos) {
        WirCore::ABBProgGenerator AbbGen("AbbProgram");
        //std::vector<std::shared_ptr<WirCore::Instruction>> internalInsts;

        std::string prog = AbbGen.generateProg(traj);

        mw->updateContent(prog);
        mw->show();

        Base::Console().Message(prog.c_str());
        Base::Console().Message("Program generation finished\n");
    }
}
