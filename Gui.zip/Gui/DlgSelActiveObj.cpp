#include "PreCompiled.h"
#ifndef _PreComp_
# include <algorithm>
# include <sstream>
# include <QListWidgetItem>
# include <QMessageBox>
#endif

#include <Gui/Application.h>
#include <Gui/Document.h>
#include <App/Document.h>

#include <Mod/WirCore/App/ActiveStationObject.h>

#include "DlgSelActiveObj.h"
#include "ui_DlgSelActiveObj.h"


using namespace WirCoreGui;

DlgSelActiveObj::DlgSelActiveObj(QWidget* parent)
 : QWidget(parent), ui(new Ui_DlgSelActiveObj)
{
    ui->setupUi(this);

    QObject::connect(ui->comboBox, SIGNAL(activated(int)), this, SLOT(onChangeActiveStation(int)));
    QObject::connect(ui->comboBox_2, SIGNAL(activated(int)), this, SLOT(onChangeActiveWobj(int)));
    QObject::connect(ui->comboBox_3, SIGNAL(activated(int)), this, SLOT(onChangeActiveTool(int)));
}

DlgSelActiveObj::~DlgSelActiveObj()
{
    delete ui;
}
void DlgSelActiveObj::onChangeActiveStation(int Value)
{
    QString tname = ui->comboBox->currentText();
    App::Document* doc = App::GetApplication().getActiveDocument();

    auto _object = dynamic_cast<WirCore::WorkStationGroup*>(doc->getObject(tname.toLatin1().data()));
    if (_object == nullptr)
    {
        return;
    }


    auto _active = dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station"));
    if (_active == nullptr)
    {
        return;
    }

    _active->Object.setValue(_object);


    UpdateStationCombo(_object);
}

void DlgSelActiveObj::onChangeActiveWobj(int Value)
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    QString tname = ui->comboBox_2->currentText();
    auto _active = dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station"));
    if (_active == nullptr)
    {
        return;
    }

    auto _station = dynamic_cast<WirCore::WorkStationGroup*>(_active ->Object.getValue());
    if (_station == nullptr)
    {
        return;
    }

    _station->activeWobjObjectName.setValue(tname.toLatin1().data());

}


void DlgSelActiveObj::onChangeActiveTool(int Value)
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    QString tname = ui->comboBox_3->currentText();
    auto _active = dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station"));
    if (_active == nullptr)
    {
        return;
    }

    auto _station = dynamic_cast<WirCore::WorkStationGroup*>(_active ->Object.getValue());
    if (_station == nullptr)
    {
        return;
    }

    _station->activeToolObjectName.setValue(tname.toLatin1().data());

}


void DlgSelActiveObj::UpdateStationCombo(WirCore::WorkStationGroup* obj)
{
    if (obj == nullptr)
    {
        return;
    }

    auto _station = obj;

    ui->comboBox_3->clear();
    ui->comboBox_2->clear();

    auto _wobjs = _station->getAllWobjsInStation();
    for(auto obj : _wobjs) {
        std::string name = obj->getNameInDocument();
        ui->comboBox_2->addItem(QString::fromStdString(name));
    }
    ui->comboBox_2->setCurrentText(QString::fromStdString(_station->activeWobjObjectName.getValue()));


    auto _tools = _station->getAllToolsInStation();
    for(auto obj : _tools) {
        std::string name = obj->getNameInDocument();
        ui->comboBox_3->addItem(QString::fromStdString(name));
    }
    ui->comboBox_3->setCurrentText(QString::fromStdString(_station->activeToolObjectName.getValue()));
}


void DlgSelActiveObj::UpdateStationCombo()
{
    App::Document* doc = App::GetApplication().getActiveDocument();

    ui->comboBox->clear();

    std::vector<WirCore::WorkStationGroup*> _objs = doc->getObjectsOfType<WirCore::WorkStationGroup>();

    if (_objs.size() < 1)
    {
        return;
    }

    for(auto obj : _objs) {
        std::string name = obj->getNameInDocument();
        ui->comboBox->addItem(QString::fromStdString(name));
    }

    auto _active = dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station"));
    if (_active == nullptr)
    {
        return;
    }

    auto _station = dynamic_cast<WirCore::WorkStationGroup*>(_active ->Object.getValue());
    if (_station == nullptr)
    {
        return;
    }
    ui->comboBox->setCurrentText(QString::fromStdString(_station->getNameInDocument()));

    UpdateStationCombo(_station);
}

void DlgSelActiveObj::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange)
        ui->retranslateUi(this);
    QWidget::changeEvent(e);
}

#include "moc_DlgSelActiveObj.cpp"
