#ifndef WIRCORE_VIEWPROVIDEROPERATION_H
#define WIRCORE_VIEWPROVIDEROPERATION_H

#include <Gui/ViewProviderDocumentObject.h>
#include <Mod/WirCore/App/OperationObject.h>
#include <Gui/SoAxisCrossKit.h>
#include <Gui/SoFCSelection.h>

class SoCoordinate3;
class SoDrawStyle;
class SoLineSet;


namespace WirCoreGui
{

class ViewProviderOperationObject : public Gui::ViewProviderDocumentObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderOperationObject);

public:
    ViewProviderOperationObject();
    ~ViewProviderOperationObject();

    void attach(App::DocumentObject* pcObject);
    void setDisplayMode(const char* modeName);
    std::vector<std::string> getDisplayModes() const;

    void updateData(const App::Property*);
    void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);
    std::vector<App::DocumentObject*> claimChildren() const;

protected:
    Gui::SoFCSelection *pcOperationRoot;
    SoCoordinate3 *pcCoords;
    SoDrawStyle *pcDrawStyle;
    SoLineSet *pcLines;

    SoGroup* axisGroup;

};




}



#endif
