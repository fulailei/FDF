#pragma once

#include <Mod/Part/Gui/ViewProvider.h>
#include <Mod/WirCore/App/AllowedCollisionMatrix.h>
#include <Gui/ViewProvider.h>
#include <Mod/Part/Gui/SoBrepFaceSet.h>
#include <Inventor/VRMLnodes/SoVRMLShape.h>
#include <Mod/WirCore/Gui/ViewProviderRobotObject.h>
#include <Gui/ViewProvider.h>
#include <Inventor/collision/SoIntersectionDetectionAction.h>
//#include "../App/fcl/FCLMethodWrapper.h"

namespace WirCoreGui
{

class CollisionObject
{ 
    // TYPESYSTEM_HEADER();
public:
    CollisionObject() {};
    ~CollisionObject() {};
    CollisionObject(Gui::ViewProvider* vp); // WirOlp::AllowedCollisionMatrix& acm,ViewProviderRobotObject* robObj);
    std::string getName() const { return name; }
    void setName(std::string n) { name = n; }
    SoSeparator* getRoot() { return vp->getRoot(); }
    SoGroup* getChildRoot() { return vp->getChildRoot(); }
    WirCore::AllowedCollisionMatrix& getACM() { return acm; }
    //bool selfCollisionCheck();
    Gui::ViewProvider* getProvider() { return vp; }
    virtual void buildFclSceneObjects();
    //fclwrapper::FclSceneObjects getFclSceneObjects() { return sceneObjects; }

protected:
    WirCore::AllowedCollisionMatrix acm;
    Gui::ViewProvider* vp;
    std::vector<PartGui::SoBrepFaceSet*> shapes;
    //fclwrapper::FclSceneObjects sceneObjects;
    void getShapes();

    std::string name;

    PartGui::ViewProviderPart* partObj;
    // Gui::ViewProviderPart * partObj;
};

class RobotCollisionObj : public CollisionObject
{
    //    TYPESYSTEM_HEADER();

public:
    RobotCollisionObj(Gui::ViewProvider* robObj);
    bool selfCollisionCheck();
    const WirCore::AllowedCollisionMatrix& getACM(){return acm;}
    void buildFclSceneObjects() override;

private:
    //    WirOlp::AllowedCollisionMatrix acm;
    int intersectionCount;

protected:
    ViewProviderRobotObject* robObj;
    void getShape(std::string TName,std::vector<SoVRMLShape*>& shapes,std::string name);
    void getShape(Gui::ViewProvider* vp, std::string name);
    void createDefaultACM(std::vector<std::string>& entry_names);

    static  SbBool intersectionFilter (void *closure, const SoPath *p1, const SoPath *p2);
    static SoIntersectionDetectionAction::Resp
    onIntersection(void *userData,
                   const SoIntersectingPrimitive *primitive1,
                   const SoIntersectingPrimitive *primitive2);
};

} // namespace WirCoreGui
