#include "PreCompiled.h"
#ifndef _PreComp_
#include <QMessageBox>
#include <QFileDialog>
#include <QCoreApplication>
#endif

# include <Gui/Action.h>
# include <Gui/BitmapFactory.h>
# include <Gui/MainWindow.h>
#include <Base/Console.h>
#include <Base/Placement.h>
#include <App/Document.h>
#include <App/Part.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Document.h>
#include <Gui/MainWindow.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/Control.h>
#include <Gui/FileDialog.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Gui/ViewProvider.h>
#include <Mod/Part/App/PartFeature.h>
#include <App/Application.h>
#include <App/Document.h>
#include <App/GeoFeature.h>
#include <App/DocumentObjectGroup.h>
#include <App/MeasureDistance.h>
#include <App/DocumentObject.h>

#include <ViewProviderDatum.h>
#include <ViewProviderDatumCS.h>
#include <Mod/WirCore/App/DatumCS.h>
#include <Mod/WirCore/App/WorkObjectReferenceFrame.h>
#include <Mod/WirCore/Gui/ViewProviderReferenceFrame.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

using namespace std;
using namespace Gui;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//===========================================================================
// CmdWirCoreGraphToolsShowHide
//===========================================================================
class CmdWirCoreGraphToolsShowHide : public Gui::Command
{
public:
    CmdWirCoreGraphToolsShowHide();
    virtual ~CmdWirCoreGraphToolsShowHide(){}
    virtual void languageChange();
    virtual const char* className() const {return "CmdWirCoreGraphToolsShowHide";}
    //void updateIcon(const Gui::MDIView* view);
protected:
    virtual void activated(int iMsg);
    virtual bool isActive(void);
    virtual Gui::Action * createAction(void);
};

CmdWirCoreGraphToolsShowHide::CmdWirCoreGraphToolsShowHide()
  : Command("WirCore_GraphToolsShowHide")
{
    sGroup        = QT_TR_NOOP("GraphTools");
    sMenuText     = QT_TR_NOOP("Show/Hide");
    //sToolTipText  = QT_TR_NOOP("Show/Hide");
    //sStatusTip    = QT_TR_NOOP("Show/Hide");
    sPixmap       = "WirCore_GraphToolsShowHide";
    //eType         = Alter3DView;
    //this->getGuiApplication()->signalActivateView.connect(boost::bind(&CmdWirCoreGraphToolsShowHide::updateIcon, this, _1));
}

Gui::Action * CmdWirCoreGraphToolsShowHide::createAction(void)
{
    Gui::ActionGroup* pcAction = new Gui::ActionGroup(this, Gui::getMainWindow());
    pcAction->setExclusive(false);
    pcAction->setDropDownMenu(false); // this can make a style like workbench. fuck!!!
    applyCommandData(this->className(), pcAction);

    auto addAction = [&](QString name)
    {
        QAction* act = pcAction->addAction(/*QString()*/name);
        act->setText(name);
        act->setToolTip(name);
        act->setCheckable(true);
        act->setChecked(true);
        act->setObjectName(name);
        //act->setIcon(BitmapFactory().iconFromTheme(""));
        //act->setShortcut(QKeySequence(QString::fromUtf8("V,1")));
    };

//    addAction(QString::fromLocal8Bit("TargetNames"));
//    addAction(QString::fromLocal8Bit("FrameNames"));
//    addAction(QString::fromLocal8Bit("PathNames"));
    addAction(QString::fromLatin1(QT_TR_NOOP("AllGeometries")));
    addAction(QString::fromLatin1(QT_TR_NOOP("AllPaths")));
    addAction(QString::fromLatin1(QT_TR_NOOP("AllTargets")));
    addAction(QString::fromLatin1(QT_TR_NOOP("AllFrames")));

    //pcAction->setIcon(a0->icon());
    _pcAction = pcAction;
    languageChange();
    return pcAction;
}

void CmdWirCoreGraphToolsShowHide::activated(int iMsg)
{
    auto show = [](const Base::Type& typeId, bool isShow)
    {
        // go through active document
        Gui::Document* doc = Application::Instance->activeDocument();
        App::Document* app = doc->getDocument();
        const std::vector<App::DocumentObject*> obj = app->getObjectsOfType
            (typeId/*App::DocumentObject::getClassTypeId()*/);
        for (std::vector<App::DocumentObject*>::const_iterator it=obj.begin();it!=obj.end();++it)
        {
            if (isShow)
            {
                doCommand(Gui,"Gui.getDocument(\"%s\").getObject(\"%s\").Visibility=True"
                         , app->getName(), (*it)->getNameInDocument());
            }
            else
            {
                doCommand(Gui,"Gui.getDocument(\"%s\").getObject(\"%s\").Visibility=False"
                         , app->getName(), (*it)->getNameInDocument());
            }
        }
    };


    Gui::ActionGroup* pcAction = dynamic_cast<Gui::ActionGroup*>(_pcAction);
    auto actions = pcAction->actions();
    switch (iMsg)
    {
//    case 0:
//    case 1:
//    case 2:
    case 0/*3*/:
        show(App::DocumentObject::getClassTypeId(), actions[iMsg]->isChecked());
        break;
    case 1/*4*/:
        show(WirCore::TrajectoryObject::getClassTypeId(), actions[iMsg]->isChecked());
        break;
    case 2/*5*/:
        show(WirCore::CoordinateSystem::getClassTypeId(), actions[iMsg]->isChecked());
        break;
    case 3/*6*/:
        show(WirCore::CoordinateSystem::getClassTypeId(), actions[iMsg]->isChecked());
        show(WirCore::WorkObjectReferenceFrame::getClassTypeId(), actions[iMsg]->isChecked());
        show(WirCore::ToolObjectReferenceFrame::getClassTypeId(), actions[iMsg]->isChecked());
        break;
    default:
        break;
    }
}

bool CmdWirCoreGraphToolsShowHide::isActive(void)
{
    return Gui::Application::Instance->activeDocument();
}

void CmdWirCoreGraphToolsShowHide::languageChange()
{
    Command::languageChange();

    if (!_pcAction)
        return;
    ActionGroup* pcAction = qobject_cast<ActionGroup*>(_pcAction);
    QList<QAction*> acts = pcAction->actions();

    acts[0]->setText(QCoreApplication::translate(this->className(), "AllGeometries"));
    acts[1]->setText(QCoreApplication::translate(this->className(), "AllPaths"));
    acts[2]->setText(QCoreApplication::translate(this->className(), "AllTargets"));
    acts[3]->setText(QCoreApplication::translate(this->className(), "AllFrames"));
}

//===========================================================================
// CmdWirCoreGraphToolsFrameSize
//===========================================================================
class CmdWirCoreGraphToolsFrameSize : public Gui::Command
{
public:
    CmdWirCoreGraphToolsFrameSize();
    virtual ~CmdWirCoreGraphToolsFrameSize(){}
    virtual void languageChange();
    virtual const char* className() const {return "CmdWirCoreGraphToolsFrameSize";}
    //void updateIcon(const Gui::MDIView* view);
protected:
    virtual void activated(int iMsg);
    virtual bool isActive(void);
    virtual Gui::Action * createAction(void);
};

CmdWirCoreGraphToolsFrameSize::CmdWirCoreGraphToolsFrameSize()
  : Command("WirCore_GraphToolsFrameSize")
{
    sGroup        = QT_TR_NOOP("GraphTools");
    sMenuText     = QT_TR_NOOP("FrameSize");
    //sToolTipText  = QT_TR_NOOP("FrameSize");
    //sStatusTip    = QT_TR_NOOP("FrameSize");
    sPixmap       = "WirCore_GraphToolsFrameSize";
    //eType         = Alter3DView;
    //this->getGuiApplication()->signalActivateView.connect(boost::bind(&CmdWirCoreGraphToolsShowHide::updateIcon, this, _1));
}

Gui::Action * CmdWirCoreGraphToolsFrameSize::createAction(void)
{
    Gui::ActionGroup* pcAction = new Gui::ActionGroup(this, Gui::getMainWindow());
    pcAction->setExclusive(true);
    pcAction->setDropDownMenu(false); // this can make a style like workbench. fuck!!!
    applyCommandData(this->className(), pcAction);

    auto addAction = [&](QString name)
    {
        QAction* act = pcAction->addAction(/*QString()*/name);
        act->setText(name);
        act->setToolTip(name);
        act->setCheckable(true);
        act->setChecked(false);
        act->setObjectName(name);
        //act->setIcon(BitmapFactory().iconFromTheme("WirCore_GraphToolsFrameSize"));
        //act->setShortcut(QKeySequence(QString::fromUtf8("V,1")));
    };
    addAction(/*QCoreApplication::translate(this->className(), "Large")*/QString::fromLatin1(QT_TR_NOOP("Large")));
    addAction(/*QCoreApplication::translate(this->className(), "Medium")*/QString::fromLatin1(QT_TR_NOOP("Medium")));
    addAction(/*QCoreApplication::translate(this->className(), "Small")*/QString::fromLatin1(QT_TR_NOOP("Small")));
           // QString::fromLatin1(QT_TR_NOOP("Small"))
    pcAction->setCheckedAction(2);

    //pcAction->setIcon(a0->icon());
    _pcAction = pcAction;
    languageChange();
    return pcAction;
}

void CmdWirCoreGraphToolsFrameSize::activated(int iMsg)
{
    switch (iMsg)
    {
    case 2:
        WirCoreGui::ViewProviderDatum::size = -0.9;
        WirCoreGui::ViewProviderReferenceFrame::s_scaleFactor = -0.7;
        break;
    case 1:
        WirCoreGui::ViewProviderDatum::size = -0.5;
        WirCoreGui::ViewProviderReferenceFrame::s_scaleFactor = -0.5;
        break;
    case 0:
        WirCoreGui::ViewProviderDatum::size = 0.1;
        WirCoreGui::ViewProviderReferenceFrame::s_scaleFactor = 1.5;
        break;
    default:
        WirCoreGui::ViewProviderDatum::size = 0.1;
        WirCoreGui::ViewProviderReferenceFrame::s_scaleFactor = 1.0;
        break;
    }

    // go through active document
    Gui::Document* doc = Application::Instance->activeDocument();
    App::Document* app = doc->getDocument();
    std::vector<App::DocumentObject*> obj = app->getObjectsOfType(WirCore::CoordinateSystem::getClassTypeId());
    for (std::vector<App::DocumentObject*>::iterator it=obj.begin();it!=obj.end();++it)
    {
        Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(*it);
        if (vp)
        {
            WirCoreGui::ViewProviderDatumCoordinateSystem* cs = dynamic_cast<WirCoreGui::ViewProviderDatumCoordinateSystem*>(vp);
            if (cs)
                cs->updateView();
        }
    }


    obj.clear();
    obj = app->getObjectsOfType(WirCore::WorkObjectReferenceFrame::getClassTypeId());
    for (std::vector<App::DocumentObject*>::iterator it=obj.begin();it!=obj.end();++it)
    {
        Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(*it);
        if (vp)
        {
            WirCoreGui::ViewProviderReferenceFrame* cs = dynamic_cast<WirCoreGui::ViewProviderReferenceFrame*>(vp);
            if (cs)
                cs->updateView();
        }
    }
}

bool CmdWirCoreGraphToolsFrameSize::isActive(void)
{
    return Gui::Application::Instance->activeDocument();
}

void CmdWirCoreGraphToolsFrameSize::languageChange()
{
    Command::languageChange();

    if (!_pcAction)
        return;
    ActionGroup* pcAction = qobject_cast<ActionGroup*>(_pcAction);
    QList<QAction*> acts = pcAction->actions();

    acts[0]->setText(QCoreApplication::translate(this->className(), "Large"));
    acts[1]->setText(QCoreApplication::translate(this->className(), "Medium"));
    acts[2]->setText(QCoreApplication::translate(this->className(), "Small"));
//    int index=1;
//    for (QList<QAction*>::ConstIterator it = acts.begin()+5; it != acts.end(); ++it, index++)
//    {
//        if ((*it)->isVisible()) {
//            QString viewnr = QString(QObject::tr("Restore view &%1")).arg(index);
//            (*it)->setText(viewnr);
//        }
//    }
}

void CreateWirCoreCommandGraphicsTools(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();
    rcCmdMgr.addCommand(new CmdWirCoreGraphToolsShowHide());
    rcCmdMgr.addCommand(new CmdWirCoreGraphToolsFrameSize());
}
