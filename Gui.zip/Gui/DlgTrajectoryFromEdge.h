#ifndef WIRCORE_DLGTRAJECTORYFROMEDGE_H
#define WIRCORE_DLGTRAJECTORYFROMEDGE_H

#include <Gui/TaskView/TaskDialog.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/PointObject.h>

#include "TrajFromEdgeParameter.h"

namespace Gui {
    namespace TaskView {
        class TaskSelectLinkProperty;
    }
}

namespace WirCoreGui {
class DlgTrajectoryFromEdge : public Gui::TaskView::TaskDialog
{
    Q_OBJECT

public:
    DlgTrajectoryFromEdge(WirCore::TrajectoryObject* traj, WirCore::WorkFrameObject* wobj);
    ~DlgTrajectoryFromEdge();

public:
    virtual bool accept();
    virtual bool reject();
    virtual void helpRequested();
    bool generateTrajectory();
    WirCore::TrajectoryObject* traj;
    WirCore::WorkFrameObject* wobj;

    /// return the list of sub elements starts with a special string
    std::vector<std::string> getSubValuesStartsWith(std::vector<std::string>SubList, const char*) const;

    virtual QDialogButtonBox::StandardButtons getStandardButtons(void) const
    { return QDialogButtonBox::Ok | QDialogButtonBox::Cancel; }


     void modifyStandardButtons(QDialogButtonBox*);
protected:
    TrajFromEdgeParameter* param;
};

}


#endif
