#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include <Base/Console.h>
#include <Base/UnitsApi.h>
#include <QString>
#include <qpalette.h>
#include <QSlider>
#include "ui_RobotOptions.h"
#include "RobotOptions.h"

#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/BitmapFactory.h>
#include <Gui/ViewProvider.h>
#include <Gui/WaitCursor.h>
#include <Gui/Selection.h>
#include <Gui/Placement.h>

using namespace WirCoreGui;
using namespace Gui;

RobotOptions::RobotOptions(WirCore::RobotObject *pcRobotObject, QWidget *parent)
    : TaskBox(Gui::BitmapFactory().pixmap("Robot_CreateRobot"), tr("RobotOptions"), true, parent),
     pcRobot(pcRobotObject), Rob()
{
    proxy = new QWidget(this);
    ui = new Ui_RobotOptions();
    ui->setupUi(proxy);

    QMetaObject::connectSlotsByName(this);

    this->groupLayout()->addWidget(proxy);
    QObject::connect(ui->horizontalSlider, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA1(int)));
    QObject::connect(ui->horizontalSlider_2, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA2(int)));
    QObject::connect(ui->horizontalSlider_3, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA3(int)));
    QObject::connect(ui->horizontalSlider_4, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA4(int)));
    QObject::connect(ui->horizontalSlider_5, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA5(int)));
    QObject::connect(ui->horizontalSlider_6, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA6(int)));

    if(pcRobotObject)
        setRobot(pcRobotObject);
}

RobotOptions::~RobotOptions() {
    delete ui;
}

void RobotOptions::setRobot(WirCore::RobotObject *pcRobotObject) {
    pcRobot = pcRobotObject;
    std::cout << "SetRobot begin" << std::endl;
    if(!pcRobotObject) {
        std::cout << "Robot Object is null" << std::endl;
        delete Rob;
        return;
    }
    std::cout << "SetRobot success" << std::endl;

    Rob = new WirCore::Robot6Axis(pcRobot->getRobot());
    ui->horizontalSlider->setMaximum((int)Rob->getMaxAngle(0));
    ui->horizontalSlider->setMinimum((int)Rob->getMinAngle(0));

    ui->horizontalSlider_2->setMaximum((int)Rob->getMaxAngle(1));
    ui->horizontalSlider_2->setMinimum((int)Rob->getMinAngle(1));

    ui->horizontalSlider_3->setMaximum((int)Rob->getMaxAngle(2));
    ui->horizontalSlider_3->setMinimum((int)Rob->getMinAngle(2));

    ui->horizontalSlider_4->setMaximum((int)Rob->getMaxAngle(3));
    ui->horizontalSlider_4->setMinimum((int)Rob->getMinAngle(3));

    ui->horizontalSlider_5->setMaximum((int)Rob->getMaxAngle(4));
    ui->horizontalSlider_5->setMinimum((int)Rob->getMinAngle(4));

    ui->horizontalSlider_6->setMaximum((int)Rob->getMaxAngle(5));
    ui->horizontalSlider_6->setMinimum((int)Rob->getMinAngle(5));

    setAxis(pcRobot->Axis1.getValue(),
            pcRobot->Axis2.getValue(),
            pcRobot->Axis3.getValue(),
            pcRobot->Axis4.getValue(),
            pcRobot->Axis5.getValue(),
            pcRobot->Axis6.getValue(),
            pcRobot->Tcp.getValue());

    viewTool(pcRobot->Tool.getValue());
}

void RobotOptions::createPlacementDlg(void) {
    Gui::Dialog::Placement plc;
    plc.setPlacement(pcRobot->Tool.getValue());
    if(plc.exec() == QDialog::Accepted)
        pcRobot->Tool.setValue(plc.getPlacement());
    viewTool(pcRobot->Tool.getValue());
}

void RobotOptions::viewTcp(const Base::Placement pos)
{
    double A,B,C;
    pos.getRotation().getYawPitchRoll(A,B,C);

    QString result = QString::fromLatin1("TCP:( %1, %2, %3, %4, %5, %6 )")
        .arg(pos.getPosition().x,0,'f',1)
        .arg(pos.getPosition().y,0,'f',1)
        .arg(pos.getPosition().z,0,'f',1)
        .arg(A,0,'f',1)
        .arg(B,0,'f',1)
        .arg(C,0,'f',1);

    ui->label_TCP->setText(result);
}

void RobotOptions::viewTool(const Base::Placement pos) {
    double A,B,C;
    pos.getRotation().getYawPitchRoll(A, B, C);

    QString result = QString::fromLatin1("Tool:(%1, %2, %3, %4, %5, %6)")
        .arg(pos.getPosition().x, 0, 'f', 1)
        .arg(pos.getPosition().y, 0, 'f',1)
        .arg(pos.getPosition().z, 0, 'f', 1)
        .arg(A, 0, 'f', 1)
        .arg(B,0,'f',1)
        .arg(C, 0, 'f', 1);

    ui->label_Tool->setText(result);
}

void RobotOptions::changeSliderA1(int value) {
    std::cout << "Slider1 value: " << value << std::endl;
    pcRobot->Axis1.setValue(float(value));
    viewTcp(pcRobot->Tcp.getValue());
    ui->lineEdit->setText(QString::fromUtf8("%1\xc2\xb0").arg((float)value, 0, 'f', 1));
    setColor(0, float(value), *(ui->lineEdit));
}

void RobotOptions::changeSliderA2(int value) {
    pcRobot->Axis2.setValue(float (value));
    viewTcp(pcRobot->Tcp.getValue());
    ui->lineEdit_2->setText(QString::fromUtf8("%1\xc2\xb0").arg((float)value,0,'f',1));
    setColor(1,float (value),*(ui->lineEdit_2));
}

void RobotOptions::changeSliderA3(int value) {
    pcRobot->Axis3.setValue(float (value));
    viewTcp(pcRobot->Tcp.getValue());
    ui->lineEdit_3->setText(QString::fromUtf8("%1\xc2\xb0").arg((float)value,0,'f',1));
    setColor(2,float (value),*(ui->lineEdit_3));
}

void RobotOptions::changeSliderA4(int value) {
    pcRobot->Axis4.setValue(float (value));
    viewTcp(pcRobot->Tcp.getValue());
    ui->lineEdit_4->setText(QString::fromUtf8("%1\xc2\xb0").arg((float)value,0,'f',1));
    setColor(3,float (value),*(ui->lineEdit_4));
}

void RobotOptions::changeSliderA5(int value) {
    pcRobot->Axis5.setValue(float (value));
    viewTcp(pcRobot->Tcp.getValue());
    ui->lineEdit_5->setText(QString::fromUtf8("%1\xc2\xb0").arg((float)value,0,'f',1));
    setColor(4,float (value),*(ui->lineEdit_5));
}

void RobotOptions::changeSliderA6(int value) {
    pcRobot->Axis6.setValue(float(value));
    viewTcp(pcRobot->Tcp.getValue());
    ui->lineEdit_6->setText(QString::fromUtf8("%1\xc2\xb0").arg((float)value,0,'f',1));
    setColor(5,float (value),*(ui->lineEdit_6));
}

void RobotOptions::setColor(int i, float angle, QLineEdit &lineEdit) {
    if( angle > Rob->getMaxAngle(i) || angle < Rob->getMinAngle(i)){
        QPalette p = lineEdit.palette();
        p.setColor(QPalette::Base, QColor(255,220,220));//green color
        lineEdit.setPalette(p);
    }else{
        QPalette p = lineEdit.palette();
        p.setColor(QPalette::Base, QColor(220,255,220));//green color
        lineEdit.setPalette(p);
    }
}

void RobotOptions::setAxis(float A1, float A2, float A3, float A4, float A5, float A6, const Base::Placement& Tcp)
{
    ui->horizontalSlider->setSliderPosition((int)A1);
    ui->lineEdit->setText(QString::fromLatin1("%1°").arg(A1, 0, 'f', 1));
    setColor(0, A1, *(ui->lineEdit));

    ui->horizontalSlider_2->setSliderPosition((int)A2);
    ui->lineEdit_2->setText(QString::fromLatin1("%1°").arg(A2, 0, 'f', 1));
    setColor(1, A2, *(ui->lineEdit_2));

    ui->horizontalSlider_3->setSliderPosition((int)A3);
    ui->lineEdit_3->setText(QString::fromLatin1("%1°").arg(A3, 0, 'f', 1));
    setColor(2, A3, *(ui->lineEdit_3));

    ui->horizontalSlider_4->setSliderPosition((int)A4);
    ui->lineEdit_4->setText(QString::fromLatin1("%1°").arg(A4, 0, 'f', 1));
    setColor(3, A4, *(ui->lineEdit_4));

    ui->horizontalSlider_5->setSliderPosition((int)A5);
    ui->lineEdit_5->setText(QString::fromLatin1("%1°").arg(A5, 0, 'f', 1));
    setColor(4, A5, *(ui->lineEdit_5));

    ui->horizontalSlider_6->setSliderPosition((int)A6);
    ui->lineEdit_6->setText(QString::fromLatin1("%1°").arg(A6, 0, 'f', 1));
    setColor(5, A6, *(ui->lineEdit_6));

    viewTcp(Tcp);
}


#include "moc_RobotOptions.cpp"



