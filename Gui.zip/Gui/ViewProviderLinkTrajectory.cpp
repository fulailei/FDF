#include "PreCompiled.h"

#ifndef _PreComp_

#endif

#include "ViewProviderLinkTrajectory.h"

using namespace Gui;
using namespace WirCoreGui;


PROPERTY_SOURCE(WirCoreGui::ViewProviderLinkTrajectory, Gui::ViewProviderDocumentObject)

ViewProviderLinkTrajectory::ViewProviderLinkTrajectory()
{
    sPixmap = "WirCore_LinkTrajectory";

    refLinkTrajectoryRoot = new Gui::SoFCSelection();
    refLinkTrajectoryRoot->ref();
}


ViewProviderLinkTrajectory::~ViewProviderLinkTrajectory()
{
    refLinkTrajectoryRoot->unref();
}

void ViewProviderLinkTrajectory::attach(App::DocumentObject *pcObj)
{
    Gui::ViewProviderDocumentObject::attach(pcObj);

    addDisplayMaskMode(refLinkTrajectoryRoot, "LinkTrajectory");
    refLinkTrajectoryRoot->objectName = pcObj->getNameInDocument();
    refLinkTrajectoryRoot->subElementName = "Main";
}

void ViewProviderLinkTrajectory::setDisplayMode(const char *ModeName)
{
    if(strcmp("LinkTrajectory", ModeName) == 0)
        setDisplayMaskMode("LinkTrajectory");
    Gui::ViewProviderDocumentObject::setDisplayMode(ModeName);
}


std::vector<std::string> ViewProviderLinkTrajectory::getDisplayModes(void) const
{
    std::vector<std::string> StrList;
    StrList.push_back("LinkTrajectory");
    return StrList;
}


bool ViewProviderLinkTrajectory::canDropObjects() const
{
     return true;
}


bool ViewProviderLinkTrajectory::canDropObject(App::DocumentObject* obj) const
{
    if (obj->isDerivedFrom(WirCore::TrajectoryOperationObject::getClassTypeId()))
    {
        return true;
    }

    return false;
}

bool ViewProviderLinkTrajectory::canDragObjects() const
{
     return true;
}


void ViewProviderLinkTrajectory::dropObject(App::DocumentObject* obj)
{
    //删除原位置结点
    auto group = WirCore::TrajectoryObject::getInlistTrajectory(obj);
    auto src_TrajectoryObject = group[0];
    std::vector<App::DocumentObject*> src_pointGroup = src_TrajectoryObject->WayPointList.getValues();
    std::vector<App::DocumentObject*>::iterator
                   result = find(src_pointGroup.begin( ), src_pointGroup.end( ), obj);
    src_pointGroup.erase(result);
    src_TrajectoryObject->WayPointList.setValues(src_pointGroup);

    //找到要插入的位置
    group = WirCore::TrajectoryObject::getInlistTrajectory(pcObject);
    auto fix_TrajectoryObject = group[0];
    std::vector<App::DocumentObject*> fix_pointGroup = fix_TrajectoryObject->WayPointList.getValues();
    result = find(fix_pointGroup.begin( ), fix_pointGroup.end( ), this->pcObject);
    fix_pointGroup.insert(result, obj);
    fix_TrajectoryObject->WayPointList.setValues(fix_pointGroup);
}




