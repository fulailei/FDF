
#include "PreCompiled.h"

#ifndef _PreComp_
#include <QPixmap>
#endif

#include "RobotWatcher.h"

using namespace WirCoreGui;

RobotWatcher::RobotWatcher()
    : Gui::TaskView::TaskWatcher("SELECT WirCore::RobotObject COUNT 1")
{
    rob = new RobotOptions(0);

    Content.push_back(rob);
}

RobotWatcher::~RobotWatcher()
{

}

bool RobotWatcher::shouldShow()
{
    if(match()) {
        rob->setRobot((WirCore::RobotObject *)Result[0][0].getObject());
        return true;
    }
    return false;
}

#include "moc_RobotWatcher.cpp"
