#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
# include <QMenu>
# include <QAction>
# include <QActionGroup>
# include <QObject>
#endif

#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Action.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/Document.h>
#include <Gui/ViewProviderOriginGroup.h>

#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/PointObject.h>
#include <Mod/WirCore/Gui/DlgFindRobot.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/ActiveStationObject.h>

#include "WircoreAction.h"

using namespace std;
using namespace WirCoreGui;

DEF_STD_CMD_A(CmdWirCoreInsertPoint);

CmdWirCoreInsertPoint::CmdWirCoreInsertPoint()
    :Command("WirCore_InsertPoint")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("InsertPoint");
    sToolTipText    = QT_TR_NOOP("Insert a point into the specify workobject.");
    sWhatsThis      = "WirCore_InsertPoint";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_InsertPoint";
}

void CmdWirCoreInsertPoint::activated(int)
{
    App::Document* doc = App::GetApplication().getActiveDocument();

    Gui::SelectionFilter WobjFilter("SELECT WirCore::WorkFrameObject COUNT 1");
    WirCore::WorkFrameObject *Wobj;
    if(WobjFilter.match()) {
        Wobj = static_cast<WirCore::WorkFrameObject*>(WobjFilter.Result[0][0].getObject());
    }
    else {
        QMessageBox::warning(Gui::getMainWindow(), QObject::tr("Wrong Selection"),
            QObject::tr("Select one Work Frame"));
        return;
    }

    openCommand("Insert Ponit");
    WirCore::PointObject* _PointObject = new WirCore::PointObject();
    std::string n = "Target";
    _PointObject->Label.setValue(n);
    doc->addObject(_PointObject, n.c_str());

    std::vector<App::DocumentObject*> pointList;
    Wobj->addObject(_PointObject);

    updateActive();
    commitCommand();
}

bool CmdWirCoreInsertPoint::isActive(void)
{
    return hasActiveDocument();
}

//==========================================
// WirCore_CreateWorkObjectInsertRobotTcp
//==========================================

DEF_STD_CMD_A(CmdWirCoreInsertRobotTcp);

CmdWirCoreInsertRobotTcp::CmdWirCoreInsertRobotTcp()
    :Command("WirCore_InsertTcpPoint")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("InsertTcpPoint");
    sToolTipText    = QT_TR_NOOP("Insert a robot Tcp point into the specify workobject.");
    sWhatsThis      = "WirCore_InsertRobotTcp";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_InsertRobotTcp";
}

void CmdWirCoreInsertRobotTcp::activated(int)
{
    App::Document* doc = App::GetApplication().getActiveDocument();

    Gui::SelectionFilter WobjFilter("SELECT WirCore::WorkFrameObject COUNT 1");
    WirCore::WorkFrameObject *Wobj;
    if(WobjFilter.match()) {
        Wobj = static_cast<WirCore::WorkFrameObject*>(WobjFilter.Result[0][0].getObject());
    }
    else {
        QMessageBox::warning(Gui::getMainWindow(), QObject::tr("Wrong Selection"),
            QObject::tr("Select one Work Frame"));
        return;
    }

    WirCore::RobotObject* _robotobject;

    std::vector<WirCore::RobotObject*> vec_robotobj = doc->getObjectsOfType<WirCore::RobotObject>();
    if (vec_robotobj.size() == 1)
    {
        _robotobject = vec_robotobj[0];
    }
    else
    {
        QStringList link;
        link << QLatin1String(doc->getName());
        link << QLatin1String(Wobj->getNameInDocument());
        link << QLatin1String("");
        link << QLatin1String("");

        WirCoreGui::DlgFindRobot dlg(link);
        if (dlg.exec() == QDialog::Accepted)
        {
            QString _str = dlg.propertyLink();

            if (_str == QLatin1String(""))
            {
                return;
            }
            _robotobject = dynamic_cast<WirCore::RobotObject*>(doc->getObject(_str.toStdString().c_str()));
        }
    }

    openCommand("Insert Ponit");

    WirCore::PointObject* _PointObject = new WirCore::PointObject();
    std::string n = "Target";
    _PointObject->Label.setValue(n);
    _PointObject->Placement.setValue(_robotobject->Tcp.getValue());
    doc->addObject(_PointObject, n.c_str());

    Wobj->addObject(_PointObject);

    updateActive();
    commitCommand();
}

bool CmdWirCoreInsertRobotTcp::isActive(void)
{
    if (!hasActiveDocument())
    {
        return false;
    }
    App::Document* doc = App::GetApplication().getActiveDocument();
    std::vector<WirCore::RobotObject*> robotobj = doc->getObjectsOfType<WirCore::RobotObject>();

    return (robotobj.size() > 0);
}



//==========================================
// WirCore_CmdWirCoreCopyPoint
//==========================================

DEF_STD_CMD_AC(CmdWirCoreCopyPoint)

CmdWirCoreCopyPoint::CmdWirCoreCopyPoint()
    :Command("WirCore_CopyPoint")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Copy to");
    sToolTipText    = QT_TR_NOOP("Copy Point");
    sWhatsThis      = "WirCore_CopyPoint";
    sStatusTip      = sToolTipText;
}

Gui::Action * CmdWirCoreCopyPoint::createAction(void)
{
    ObjectListAction* pcAction = new ObjectListAction
            (this, WirCore::WorkFrameObject::getClassTypeId(),Gui::getMainWindow());
    pcAction->setObjectName(QLatin1String("WorkObjectList"));
    pcAction->setDropDownMenu(true);
    applyCommandData(this->className(), pcAction);

    return pcAction;
}

void CmdWirCoreCopyPoint::activated(int iMsg)
{
    Gui::ActionGroup* pcAction = dynamic_cast<Gui::ActionGroup*>(_pcAction);
    auto actions = pcAction->actions();

    QString str = actions[iMsg]->text();

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::WorkFrameObject* _WorkFrameObject = dynamic_cast<WirCore::WorkFrameObject*>(doc->getObject(str.toStdString().c_str()));

    vector<App::DocumentObject*>  vec_selpoint;
    vec_selpoint = Gui::Selection().getObjectsOfType(WirCore::PointObject::getClassTypeId(), doc->getName());

    openCommand("Copy point");

    for (std::vector<App::DocumentObject*>::iterator it = vec_selpoint.begin(); it != vec_selpoint.end(); ++it)
    {
        WirCore::PointObject*  new_point = new  WirCore::PointObject();
        WirCore::PointObject*  src_point = dynamic_cast<WirCore::PointObject*>(*it);

        new_point->copyFrom(src_point);
        doc->addObject(new_point, src_point->Label.getValue());
        _WorkFrameObject->addObject(new_point);
    }

    updateActive();
    commitCommand();
}

bool CmdWirCoreCopyPoint::isActive(void)
{
    return hasActiveDocument();
}


//==========================================
// WirCore_CmdWirCoreAddtoTrajtory
//==========================================

DEF_STD_CMD_AC(CmdWirCoreAddtoTrajtory)

CmdWirCoreAddtoTrajtory::CmdWirCoreAddtoTrajtory()
    :Command("WirCore_AddtoTrajtory")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("add to Trajectory");
    sToolTipText    = QT_TR_NOOP("add to Trajectory");
    sWhatsThis      = "WirCore_AddtoTrajtory";
    sStatusTip      = sToolTipText;
}

Gui::Action * CmdWirCoreAddtoTrajtory::createAction(void)
{
    ObjectListAction* pcAction = new ObjectListAction
            (this, WirCore::TrajectoryObject::getClassTypeId() ,Gui::getMainWindow());
    pcAction->setObjectName(QLatin1String("add2Trajectory_TrajertoryList"));
    pcAction->setDropDownMenu(true);
    applyCommandData(this->className(), pcAction);

    return pcAction;
}

void CmdWirCoreAddtoTrajtory::activated(int iMsg)
{
    Gui::ActionGroup* pcAction = dynamic_cast<Gui::ActionGroup*>(_pcAction);
    auto actions = pcAction->actions();

    QString str = actions[iMsg]->text();

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* _Trajectory = dynamic_cast<WirCore::TrajectoryObject*>(doc->getObject(str.toStdString().c_str()));
    std::vector<App::DocumentObject*> pointGroup;
    pointGroup = _Trajectory->WayPointList.getValues();

    vector<App::DocumentObject*>  vec_selpoint;
    vec_selpoint = Gui::Selection().getObjectsOfType(WirCore::PointObject::getClassTypeId(), doc->getName());

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());


    openCommand("add to Trajectory");

    for (std::vector<App::DocumentObject*>::iterator it = vec_selpoint.begin(); it != vec_selpoint.end(); ++it)
    {
        WirCore::PointObject*  point = dynamic_cast<WirCore::PointObject*>(*it);

        WirCore::WaypointObject*  waypoint = new  WirCore::WaypointObject();
        waypoint->linkPoint.setValue(point);
        waypoint->waypointType.setValue("MoveL");

        std::string n = "MoveL_" + std::string(point->Label.getValue()) + "_";
        waypoint->Label.setValue(n);
        waypoint->linkTool.setValue(_station->GetActiveToolObject());
        doc->addObject(waypoint, n.c_str());
        pointGroup.push_back(waypoint);
    }
    _Trajectory->WayPointList.setValues(pointGroup);

    updateActive();
    commitCommand();
}

bool CmdWirCoreAddtoTrajtory::isActive(void)
{
    return hasActiveDocument();
}



// #####################################################################################################

// #####################################################################################################
void CreateWirCoreCommandPointOperate(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();

    rcCmdMgr.addCommand(new CmdWirCoreInsertPoint());
    rcCmdMgr.addCommand(new CmdWirCoreInsertRobotTcp());
    rcCmdMgr.addCommand(new CmdWirCoreCopyPoint());
    rcCmdMgr.addCommand(new CmdWirCoreAddtoTrajtory());
}
