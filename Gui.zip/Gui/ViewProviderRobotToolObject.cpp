#include "PreCompiled.h"

#ifndef _PreComp_

# include <QApplication>
# include <QFileDialog>
# include <QLabel>


#endif

# include <Inventor/nodes/SoSeparator.h>


#include <Base/FileInfo.h>
#include <Base/Tools.h>

#include <App/Application.h>
#include <App/Document.h>
#include <Gui/Application.h>
#include <Gui/Control.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/Document.h>

#include "ViewProviderRobotToolObject.h"
#include <Mod/WirCore/App/RobotToolObject.h>

using namespace Gui;
using namespace WirCoreGui;
using namespace std;

PROPERTY_SOURCE(WirCoreGui::ViewProviderRobotToolObject, Gui::ViewProviderGeometryObject)


ViewProviderRobotToolObject::ViewProviderRobotToolObject()
{
    sPixmap = "WirCore_ToolObject";

    Gui::ViewProviderOriginGroupExtension::initExtension(this);
    //toolobject = NULL;
}

ViewProviderRobotToolObject::~ViewProviderRobotToolObject()
{
}

void ViewProviderRobotToolObject::onChanged(const App::Property* prop)
{
    ViewProviderGeometryObject::onChanged(prop);
}

std::vector<App::DocumentObject*> ViewProviderRobotToolObject::claimChildren(void) const {

    WirCore::RobotToolObject* robToolObj = static_cast<WirCore::RobotToolObject*>(pcObject);

    std::vector<App::DocumentObject*> children;

    if (robToolObj->ToolShape.getValue() != NULL)
    {
        children.push_back(robToolObj->ToolShape.getValue());
    }
    return children;
}

std::vector< App::DocumentObject* > ViewProviderRobotToolObject::claimChildren3D(void) const {
    return claimChildren();
}

bool ViewProviderRobotToolObject::canDragObject(App::DocumentObject* obj) const
{
    return false;
}

bool ViewProviderRobotToolObject::canDragObjects() const
{
    return false;
}

bool ViewProviderRobotToolObject::canDropObjects() const
{
     return false;
}

bool ViewProviderRobotToolObject::canDropObject(App::DocumentObject* obj) const
{
     return false;
}

