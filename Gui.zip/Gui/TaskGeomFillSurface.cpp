#include "PreCompiled.h"
#ifndef _PreComp_
# include <Inventor/nodes/SoSeparator.h>
# include <TopoDS_Face.hxx>
# include <TopExp.hxx>
# include <TopExp_Explorer.hxx>
# include <BRepProj_Projection.hxx>
# include <TopoDS_Builder.hxx>
# include <TopoDS_Edge.hxx>
# include <ShapeAnalysis.hxx>
# include <ShapeAnalysis_FreeBounds.hxx>
# include <ShapeFix_Wire.hxx>
# include <BRep_Tool.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Geom_TrimmedCurve.hxx>
# include <GeomProjLib.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include "ShapeFix_Edge.hxx"
# include <BRepBuilderAPI_MakeFace.hxx>
# include <ShapeFix_Face.hxx>
# include <BRepCheck_Analyzer.hxx>
# include <ShapeFix_Wireframe.hxx>
# include <BRepPrimAPI_MakePrism.hxx>
# include <gp_Ax1.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_Transform.hxx>
# include <QAction>
# include <QMenu>
# include <QMessageBox>
# include <QTimer>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
# include <cfloat>
# include <QFuture>
# include <QFutureWatcher>
# include <QKeyEvent>
# include <QtConcurrentMap>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/actions/SoSearchAction.h>
# include <Inventor/details/SoLineDetail.h>
#endif

#include "TaskGeomFillSurface.h"
#include "ui_TaskGeomFillSurface.h"
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/Command.h>
#include <Gui/SelectionObject.h>
#include <Base/Console.h>
#include <Gui/Control.h>
#include <Gui/BitmapFactory.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>
#include <Mod/Part/Gui/CrossSections.h>
#include "Gui/MainWindow.h"
#include "Gui/MDIView.h"
#include "Gui/View3DInventor.h"
#include "Gui/View3DInventorViewer.h"
#include "Inventor/SbVec3d.h"
#include "Mod/Part/Gui/ViewProviderExt.h"
#include "ViewProviderGeometryObject.h"
#include "Mod/Part/App/PropertyTopoShape.h"

#include "Mod/Part/Gui/SoBrepFaceSet.h"
#include "Mod/Part/Gui/SoBrepEdgeSet.h"
#include "Gui/SoFCUnifiedSelection.h"

using namespace WirCoreGui;
namespace WirCoreGui
{
class ProjectCurve : public Part::Feature
{
public:
    enum ProjectLineType { Line, Splin, Polyline };
    ProjectCurve()
    {
        createLineShape();
        createSplinShape();
        createPolylinShape();
    }

    ~ProjectCurve()
    {
    }

    /// returns the type name of the ViewProvider
    const char* getViewProviderName(void) const
    {
        return "WirCoreGui::ViewProviderProjectCurve";
    }

    std::vector<TopoDS_Shape> getShapes(int i)
    {
        assert(i == Line || i == Splin || i == Polyline);
        switch(i)
        {
        case Line:
            return m_dataLine;
        case Splin:
            return m_dataSplin;
        case Polyline:
            return m_dataPolylin;
        }
        return std::vector<TopoDS_Shape>();
    }

    void setShapes(int i)
    {
        auto comShape = [](std::vector<TopoDS_Shape>& v)->TopoDS_Shape
        {
            TopoDS_Compound aCompound;
            TopoDS_Builder aBuilder;
            aBuilder.MakeCompound(aCompound);
            for (auto it2 : v)
                aBuilder.Add(aCompound, it2);
            return aCompound;
        };

        assert(i == Line || i == Splin || i == Polyline);
        switch(i)
        {
        case Line:
            this->Shape.setValue(comShape(m_dataLine));
            break;
        case Splin:
            this->Shape.setValue(comShape(m_dataSplin));
            break;
        case Polyline:
            this->Shape.setValue(comShape(m_dataPolylin));
            break;
        }
    }

private:
    void createSegLine(const gp_Pnt& p1, const gp_Pnt& p2, std::vector<TopoDS_Shape>& vShapes)
    {
        auto line = GC_MakeSegment(p1, p2);
        auto edge = BRepBuilderAPI_MakeEdge(line.Value());
        vShapes.push_back(edge);
    }

    void createLineShape()
    {
        m_dataLine.clear();
        createSegLine(gp_Pnt(0, 0, 0), gp_Pnt(0, 5, 0), m_dataLine);
        createSegLine(gp_Pnt(5, 0, 0), gp_Pnt(5, 5, 0), m_dataLine);
        createSegLine(gp_Pnt(10, 0, 0), gp_Pnt(10, 5, 0), m_dataLine);
        createSegLine(gp_Pnt(15, 0, 0), gp_Pnt(15, 5, 0), m_dataLine);
    }

    void createSplinShape()
    {
        m_dataSplin.clear();
        const std::vector<gp_Pnt> p{gp_Pnt(0,0,0), gp_Pnt(5,5,0), gp_Pnt(10,0,0), gp_Pnt(15,5,0), gp_Pnt(20,0,0)};
        const std::vector<gp_Vec> t{gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0)};
        auto spline = new Part::GeomBSplineCurve;
        spline->interpolate(p,t);
        m_dataSplin.push_back(spline->toShape());
    }

    void createPolylinShape()
    {
        m_dataPolylin.clear();
        createSegLine(gp_Pnt(0, 0, 0), gp_Pnt(5, 5, 0), m_dataPolylin);
        createSegLine(gp_Pnt(5, 5, 0), gp_Pnt(10, 0, 0), m_dataPolylin);
        createSegLine(gp_Pnt(10, 0, 0), gp_Pnt(15, 5, 0), m_dataPolylin);
        createSegLine(gp_Pnt(15, 5, 0), gp_Pnt(20, 0, 0), m_dataPolylin);
    }
    //ProjectLineType curType;
    std::vector<TopoDS_Shape> m_dataLine;
    std::vector<TopoDS_Shape> m_dataSplin;
    std::vector<TopoDS_Shape> m_dataPolylin;
};

class ViewProviderProjectCurve : public PartGui::ViewProviderPartExt
{
public:
    ViewProviderProjectCurve()
    {
    }
    ~ViewProviderProjectCurve()
    {
    }
};


// ----------------------------------------------------------------------------
class GeomFillSurface::EdgeSelection : public Gui::SelectionFilterGate
{
public:
    EdgeSelection(bool appendEdges)
        : Gui::SelectionFilterGate(static_cast<Gui::SelectionFilter*>(nullptr))
        , appendEdges(appendEdges)
    {
    }
    /**
      * Allow the user to pick only edges.
      */
    bool allow(App::Document* pDoc, App::DocumentObject* pObj, const char* sSubName);

private:
    bool appendEdges;
};

bool GeomFillSurface::EdgeSelection::allow(App::Document* , App::DocumentObject* pObj, const char* sSubName)
{
    // don't allow references to itself
    //        if (pObj == editedObject)
    //            return false;
    if (!pObj->isDerivedFrom(Part::Feature::getClassTypeId()))
        return false;

    if (!sSubName || sSubName[0] == '\0')
        return false;

    std::string element(sSubName);
    if (element.substr(0,4) == "Face" || element.substr(0,4) == "Edge")
        return true;

    //        auto links = editedObject->BoundaryList.getSubListValues();
    //        for (auto it : links) {
    //            if (it.first == pObj) {
    //                for (auto jt : it.second) {
    //                    if (jt == sSubName)
    //                        return !appendEdges;
    //                }
    //            }
    //        }

    return /*appendEdges*/false;
}

// ----------------------------------------------------------------------------

GeomFillSurface::GeomFillSurface()
{
    //this->setObjectName(QString::fromLatin1("WirCore_GeomFillSurface"));
    ui = new Ui_GeomFillSurface();
    ui->setupUi(this);
    selectionMode = None;
    checkCommand = true;

    // Create context menu
    QAction* removeFace = new QAction(tr("Remove"), this);
    removeFace->setShortcut(QString::fromLatin1("Del"));
    ui->listWidget->addAction(removeFace);
    connect(removeFace, SIGNAL(triggered()), this, SLOT(onDeleteFace()));

    QAction* removeEdge = new QAction(tr("Remove"), this);
    removeEdge->setShortcut(QString::fromLatin1("Del"));
    ui->edgeList->addAction(removeEdge);
    connect(removeEdge, SIGNAL(triggered()), this, SLOT(onDeleteEdge()));

    connect(ui->edgeList, SIGNAL(itemSelectionChanged()), this, SLOT(onWidgetEdgeSelectionChanged()));



    ui->listWidget->setContextMenuPolicy(Qt::ActionsContextMenu);
    ui->edgeList->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->stackedWidget->setCurrentIndex(0);
    //connect(ui->comboBox, SIGNAL(currentIndexChanged(int)),ui->stackedWidget, SLOT(setCurrentIndex(int)));
    connect(ui->comboBox, SIGNAL(currentIndexChanged(int)),this, SLOT(changePage(int)));


    on_checkBox_clicked(true);

    auto m_partDocument = App::GetApplication().getActiveDocument();
    if (!m_partDocument)
    {
        throw Base::ValueError(QString(tr("Have no active document!!!")).toUtf8());
    }
    //this->attachDocument(m_partDocument);


    m_geometryObject = dynamic_cast<Part::Feature*>(m_partDocument->addObject("WirCore::GeometryObject", "Geometry"));
    if (!m_geometryObject)
    {
        throw Base::ValueError(QString(tr("Can not create a geometry object!!!")).toUtf8());
    }
    m_geometryObject->Label.setValue(std::string("Geometry"));


    vp = new ViewProviderProjectCurve();
    spline = new ProjectCurve();
    vp->attach(spline);
    Gui::Document* doc = Gui::Application::Instance->activeDocument();
    view = (Gui::View3DInventor*)(doc->getActiveView());
    if (view) {
        view->getViewer()->addViewProvider(vp);
        //view->getViewer()->update();
    }
    m_partDocument->recompute();

    //on_radioLine_clicked();
    projectLineType = ProjectCurve::Line;
    spline->setShapes(ProjectCurve::Line);


//    Base::BoundBox3d bbox;
//    m_intersectDlg = new WirCoreGui::DlgCrossSections(bbox, this);
//    auto layout = new QHBoxLayout();
//    layout->addWidget(m_intersectDlg);
//    ui->intersection->setLayout(layout);
}

/*
 *  Destroys the object and frees any allocated resources
 */
GeomFillSurface::~GeomFillSurface()
{
    // no need to delete child widgets, Qt does it all for us
    if (view) {
        view->getViewer()->removeViewProvider(vp);
    }
    delete vp;

    // no need to delete child widgets, Qt does it all for us
    delete ui;
}

void GeomFillSurface::on_pushButton_showline_clicked(bool checked)
{
    std::vector<TopoDS_Shape> faces;
    for(auto obj : m_vFaces)
    {
        // collect face
        auto aPart = dynamic_cast<Part::Feature*>(obj.getObject());
        if (aPart)
        {
            auto inputShape = aPart->Shape.getShape().getShape();
            if (obj.getSubNames().size() )
            {
                for (auto itName = obj.getSubNames().begin(); itName != obj.getSubNames().end(); ++itName)
                {
                    auto currentShape =  aPart->Shape.getShape().getSubShape(itName->c_str());
                    faces.push_back(currentShape);
                }
            }
            else
                faces.push_back(inputShape);
        }
    }
    auto aPart = dynamic_cast<Part::Feature*>(m_vFaces.front().getObject());

    auto bigShape = aPart->Shape.getShape().getShape();

    Gui::Document* doc = Gui::Application::Instance->activeDocument();
    //doc->getDocument()->get
    //TopTools_ListOfShape profiles;
    TopoDS_Compound aCompound;
    TopoDS_Builder aBuilder;
    aBuilder.MakeCompound(aCompound);

    for(auto f : faces)
    {
       if (f.ShapeType() == TopAbs_FACE)
       {
           TopTools_IndexedMapOfShape edges;
           TopExp::MapShapes(bigShape, TopAbs_EDGE, edges);

           TopTools_IndexedMapOfShape fedges;
           TopExp::MapShapes(f, TopAbs_EDGE, fedges);
           for (int i = 1; i <= fedges.Extent(); i++)
           {
               auto index = edges.FindIndex(fedges.FindKey(i));
               QListWidgetItem* item = new QListWidgetItem(ui->edgeList);
               item->setIcon(Gui::BitmapFactory().pixmap("view-rotate-right"));
               ui->edgeList->addItem(item);

               QString text = QString::fromLatin1("(Edge)-%1").arg(QString::fromLocal8Bit(m_vFaces.front().getObject()->Label.getValue()));
               item->setText(text);

               QList<QVariant> data;
               data << QByteArray(m_vFaces.front().getDocName());
               data << QByteArray(m_vFaces.front().getFeatName());
               data << QByteArray(m_vFaces.front().getObject()->Label.getValue());
               data << index;
               item->setData(Qt::UserRole, data);

               aBuilder.Add(aCompound, fedges.FindKey(i));
           }
       }
    }

    if (!aCompound.IsNull())
        m_geometryObject->Shape.setValue(aCompound);
}

void GeomFillSurface::changePage(int index)
{
    switch(index)
    {
    case 0:
        break;
    case 1:
        break;
    case 2:
    {
//        if (m_intersectDlg)
//        {
//            std::set<std::string> objs;
//            for(auto o : m_vFaces)
//                objs.insert(o.getFeatName());

//            Base::BoundBox3d bbox;
//            for(auto o : objs)
//            {
//                App::Document* doc = App::GetApplication().getActiveDocument();
//                App::DocumentObject* obj = doc->getObject(o.c_str());
//                bbox.Add(static_cast<Part::Feature*>(obj)->Shape.getBoundingBox());
//            }
//            m_intersectDlg->setBoundBox3d(bbox);
//        }
        break;
    }
    case 3:
    {


        break;
    }
    }

    ui->stackedWidget->setCurrentIndex(index);
}

void GeomFillSurface::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange) {
        ui->retranslateUi(this);
    }
    else {
        QWidget::changeEvent(e);
    }
}

void GeomFillSurface::open()
{
    checkOpenCommand();
    //this->vp->highlightReferences(true);
    Gui::Selection().clearSelection();
}

void GeomFillSurface::clearSelection()
{
    Gui::Selection().clearSelection();
}

void GeomFillSurface::checkOpenCommand()
{
    if (checkCommand && !Gui::Command::hasPendingCommand()) {
        std::string Msg("Edit ");
        //Msg += editedObject->Label.getValue();
        Gui::Command::openCommand(Msg.c_str());
        checkCommand = false;
    }
}

void GeomFillSurface::slotUndoDocument(const Gui::Document&)
{
    checkCommand = true;
}

void GeomFillSurface::slotRedoDocument(const Gui::Document&)
{
    checkCommand = true;
}

void GeomFillSurface::slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj)
{
    // If this view provider is being deleted then reset the colors of
    // referenced part objects. The dialog will be deleted later.
    //if (this->vp == &Obj) {
    //    this->vp->highlightReferences(false);
    //}
}

bool GeomFillSurface::accept()
{   
    selectionMode = None;
    //Gui::Selection().rmvSelectionGate();

    //    int count = ui->listWidget->count();
    //    if (count > 4) {
    //        QMessageBox::warning(this,
    //            tr("Too many edges"),
    //            tr("The tool requires two, three or four edges"));
    //        return false;
    //    }
    //    else if (count < 2) {
    //        QMessageBox::warning(this,
    //            tr("Too less edges"),
    //            tr("The tool requires two, three or four edges"));
    //        return false;
    //    }

    //    if (editedObject->mustExecute())
    //        editedObject->recomputeFeature();
    //    if (!editedObject->isValid()) {
    //        QMessageBox::warning(this, tr("Invalid object"),
    //            QString::fromLatin1(editedObject->getStatusString()));
    //        return false;
    //    }

    //this->vp->highlightReferences(false);

    Gui::Command::commitCommand();
    //Gui::Command::doCommand(Gui::Command::Gui,"Gui.ActiveDocument.resetEdit()");

    //
    switch (ui->comboBox->currentIndex())
    {
    case 0:
    {
        // runCommand(Command::Doc,cmd.toUtf8());
        //Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();
        //auto cmd = mgr.getCommandByName("Part_projectionOnSurface");
        //cmd->invoke(0);
        //        std::string names(name);
        //        QAction* action = findAction(actions, names);
        //        if(!action)
        //        {
        //            if (mgr.addTo(name, m_pTabToolbar))
        //            {
        //                action = m_pTabToolbar->actions().last();
        //                m_pTabToolbar->removeAction(action);//mgr.addTo will also add action to toolbar, remove it to avoid duplication
        //            }
        //            if (action)
        //                action->setData(QString::fromStdString(names));
        //        }


        //            Gui::Command::runCommand(Gui::Command::Gui, "Part_projectionOnSurface");





        //        std::stringstream stream;
        //        std::vector<Base::Vector3d> EditCurve{Base::Vector3d(0, 0, 0), Base::Vector3d(1, 1, 0), Base::Vector3d(2, 0, 0)};

        //        for (std::vector<Base::Vector3d>::const_iterator it = EditCurve.begin(); it != EditCurve.end(); ++it)
        //        {
        //            stream << "App.Vector(" << (*it).x << "," << (*it).y << "," << (*it).z << "),";
        //        }

        //        std::string controlpoints = stream.str();
        //        // remove last comma and add brackets
        //        int index = controlpoints.rfind(',');
        //        controlpoints.resize(index);

        //        controlpoints.insert(0,1,'[');
        //        controlpoints.append(1,']');

        //        //int currentgeoid = getHighestCurveIndex();
        //        Gui::Command::doCommand(Gui::Command::Doc,
        //                                "App.ActiveDocument.%s.addGeometry(Part.BSplineCurve"
        //                                "(%s,None,None,%s,3,None,False),"
        //                                "%s)",
        //                                "Cube",
        //                                controlpoints.c_str(),
        //                                "True", /*ConstrMethod == 0 ?"False":*/
        //                                "True"); // /*geometryCreationMode==Construction?"True":*/



        //        poles = [[0, 0, 0], [1, 1, 0], [2, 0, 0]]
        //        self.spline = Part.BSplineCurve()
        //        self.spline.buildFromPoles(poles)

        break;
    }
    case 1:
    {
        Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();
        auto cmd = mgr.getCommandByName("IsoCurve");
        cmd->invoke(0);

        //            doCommand(Doc,"FreeCAD.getDocument(\"%s\").addObject(\"Part::Feature\",\"%s\")"
        //                         ,doc->getName()
        //                         ,name.c_str());
        //Gui::Command::runCommand(Gui::Command::Gui, "FreeCAD.ActiveDocument.getObject(\"IsoCurve\").NumberU = 6");

        //            std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::DocumentObject::getClassTypeId(), "IsoCurve");
        ////            if (sel.empty())
        ////            {
        ////                App::Document* doc = App::GetApplication().getDocument(DocName);
        ////                sel = doc->getObjectsOfType(App::DocumentObject::getClassTypeId());
        ////            }
        //            std::stringstream str;
        //            std::set<App::DocumentObject*> unique_objs;
        //            str << "__objs__=[]" << std::endl;
        //            for (std::vector<App::DocumentObject*>::iterator it = sel.begin(); it != sel.end(); ++it) {
        //                if (unique_objs.insert(*it).second) {
        //                    str << "__objs__.append(FreeCAD.getDocument(\"" << DocName << "\").getObject(\""
        //                        << (*it)->getNameInDocument() << "\"))" << std::endl;
        //                }
        //            }

        break;
    }
    case 2:
    {

        break;
    }
    }

    Gui::Command::updateActive();
    return true;
}

void GeomFillSurface::onWidgetEdgeSelectionChanged()
{
    auto aPart = dynamic_cast<Part::Feature*>(m_vFaces.front().getObject());
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(aPart);


    SoSearchAction searchAction;
    searchAction.setType(PartGui::SoBrepEdgeSet::getClassTypeId());
    searchAction.setInterest(SoSearchAction::FIRST);
    searchAction.apply(vp->getRoot());
    SoPath* selectionPath = searchAction.getPath();
    if (selectionPath) {
        ParameterGrp::handle hGrp = Gui::WindowParameter::getDefaultParameter()->GetGroup("View");
        SbColor selectionColor(0.1f, 0.8f, 0.1f);
        unsigned long selection = (unsigned long)(selectionColor.getPackedValue());
        selection = hGrp->GetUnsigned("SelectionColor", selection);
        float transparency;
        selectionColor.setPackedValue((uint32_t)selection, transparency);

        // clear the selection first
        Gui::SoSelectionElementAction clear(Gui::SoSelectionElementAction::None);
        clear.apply(selectionPath);

        Gui::SoSelectionElementAction action(Gui::SoSelectionElementAction::Append);
        action.setColor(selectionColor);
        action.apply(selectionPath);

        int row = ui->edgeList->currentRow();
        QListWidgetItem* item = ui->edgeList->item(row);
        QString text = item->text();

        QList<QVariant> data;
        data = item->data(Qt::UserRole).toList();
        int edgeIndex = data[3].toInt();
        //int idx1 = text.lastIndexOf(QLatin1String("."));
        //int idx2 = text.indexOf(QLatin1String("("));
        //QString mid = text.mid(idx1+4+1, idx2-idx1-5);
        //int edgeIndex = mid.toInt();


        //QAbstractItemModel* model = ui->treeView->model();
        SoLineDetail detail;
        action.setElement(&detail);
        detail.setLineIndex(edgeIndex-1);
        action.apply(selectionPath);
        /*
        for (int i=0; i<model->rowCount(); ++i) {
            QVariant value = model->index(i,0).data(Qt::CheckStateRole);
            Qt::CheckState checkState = static_cast<Qt::CheckState>(value.toInt());

            // is item checked
            if (checkState & Qt::Checked) {
                // the index value of the edge
                //TODO: get the edge index here
                int id = model->index(i,0).data(Qt::UserRole).toInt();
                detail.setLineIndex(id-1);
                action.apply(selectionPath);
            }
        }*/
    }

    /*
    int row = ui->edgeList->currentRow();
    QListWidgetItem* item = ui->edgeList->item(row);
    if(item) {
        checkOpenCommand();
        QList<QVariant> data;
        data = item->data(Qt::UserRole).toList();

        //App::Document* doc = App::GetApplication().getDocument(data[0].toByteArray());
        //App::DocumentObject* obj = doc ? doc->getObject(data[1].toByteArray()) : nullptr;
        //std::string sub = data[2].toByteArray().constData();


        App::DocumentObject* obj = sel.getObject();

        Gui::Document* doc = Gui::Application::Instance->activeDocument();
        //doc->getViewProviderByName()
        //auto selvp = doc->getViewProvider(obj);
        Part::Feature* base = dynamic_cast<Part::Feature*>(obj);
        if (base) {
            PartGui::ViewProviderPartExt* svp = dynamic_cast<PartGui::ViewProviderPartExt*>(
                        Gui::Application::Instance->getViewProvider(base));
            if (svp) {
                if (true) {
                    std::vector<App::Color> colors;
                    TopTools_IndexedMapOfShape eMap;
                    TopExp::MapShapes(base->Shape.getValue(), TopAbs_EDGE, eMap);
                    colors.resize(eMap.Extent(), svp->LineColor.getValue());

                    for (int idx = 0; idx < eMap.Extent(); idx++) {
                        colors[idx] = App::Color(1.0,0.0,1.0); // magenta
                    }

                    svp->setHighlightedEdges(colors);
                }
                else {
                    svp->unsetHighlightedEdges();
                }
            }
        }

    }
    */
}


void GeomFillSurface::on_pushButtonGetCurrentCamDir_clicked()
{
    get_camera_direction();
}

void GeomFillSurface::set_xyz_dir_spinbox(QDoubleSpinBox* icurrentSpinBox)
{
    auto currentVal = icurrentSpinBox->value();
    auto newVal = 0.0;
    if (currentVal != 1.0 && currentVal != -1.0)
    {
        newVal = -1;
    }
    else if (currentVal == 1.0)
    {
        newVal = -1;
    }
    else if (currentVal == -1.0)
    {
        newVal = 1;
    }
    ui->doubleSpinBoxDirX->setValue(0);
    ui->doubleSpinBoxDirY->setValue(0);
    ui->doubleSpinBoxDirZ->setValue(0);
    icurrentSpinBox->setValue(newVal);
}

void GeomFillSurface::on_pushButtonDirX_clicked()
{
    set_xyz_dir_spinbox(ui->doubleSpinBoxDirX);
}

void GeomFillSurface::on_pushButtonDirY_clicked()
{
    set_xyz_dir_spinbox(ui->doubleSpinBoxDirY);
}

void GeomFillSurface::on_pushButtonDirZ_clicked()
{
    set_xyz_dir_spinbox(ui->doubleSpinBoxDirZ);
}

void GeomFillSurface::get_camera_direction(void)
{
    auto mainWindow = Gui::getMainWindow();

    auto mdiObject = dynamic_cast<Gui::View3DInventor*>(mainWindow->activeWindow());
    if (!mdiObject) return;
    auto camerRotation = mdiObject->getViewer()->getCameraOrientation();

    SbVec3f lookAt(0, 0, -1);
    camerRotation.multVec(lookAt, lookAt);

    float valX, valY, valZ;
    lookAt.getValue(valX, valY, valZ);

    ui->doubleSpinBoxDirX->setValue(valX);
    ui->doubleSpinBoxDirY->setValue(valY);
    ui->doubleSpinBoxDirZ->setValue(valZ);
}

void GeomFillSurface::create_projection_wire1()
{
    for(auto obj : m_vFaces)
    {
        // collect face
        auto aPart = dynamic_cast<Part::Feature*>(obj.getObject());
        if (aPart)
        {
            auto inputShape = aPart->Shape.getShape().getShape();
            if (obj.getSubNames().size() )
            {
                for (auto itName = obj.getSubNames().begin(); itName != obj.getSubNames().end(); ++itName)
                {
                    auto currentShape =  aPart->Shape.getShape().getSubShape(itName->c_str());
                    m_inputShapeVec.push_back(currentShape);
                }
            }
            else
                m_inputShapeVec.push_back(inputShape);
        }
    }

    auto valX =  ui->doubleSpinBoxDirX->value();
    auto valY = ui->doubleSpinBoxDirY->value();
    auto valZ = ui->doubleSpinBoxDirZ->value();
    auto dir = gp_Dir(valX, valY, valZ);


    m_wireShapeVec.clear();
    auto lines = spline->getShapes(projectLineType);
    for (int j = 0; j < m_inputShapeVec.size(); j ++ )
    {
        for (int i = 0; i < lines.size(); i ++)
        {
            BRepProj_Projection aProjection(lines[i], m_inputShapeVec[j], dir);
            auto currentProjection = aProjection.Shape();
            for (TopExp_Explorer aExplorer(currentProjection, TopAbs_EDGE); aExplorer.More(); aExplorer.Next())
            {
                m_wireShapeVec.push_back(TopoDS::Edge(aExplorer.Current()));
            }
        }
    }

}

void GeomFillSurface::on_pushButton_clicked()
{
    create_projection_wire1();
    show_projected_shapes();
}

void GeomFillSurface::show_projected_shapes()
{
    if (!m_geometryObject) return;

    TopoDS_Compound aCompound;
    TopoDS_Builder aBuilder;
    aBuilder.MakeCompound(aCompound);
    for (auto it : m_wireShapeVec)
        aBuilder.Add(aCompound, it);

    if (aCompound.IsNull())
    {
        // if (!m_partDocument) return;
        m_geometryObject->Shape.setValue(TopoDS_Shape());
        return;
    }

    auto currentPlacement = m_geometryObject->Placement.getValue();
    m_geometryObject->Shape.setValue(aCompound);
    m_geometryObject->Placement.setValue(currentPlacement);

    //set color
    PartGui::ViewProviderPartExt* vp1 = dynamic_cast<PartGui::ViewProviderPartExt*>(Gui::Application::Instance->getViewProvider(m_geometryObject));
    if (vp1)
    {
        vp1->LineColor.setValue(0x8ae23400);
        vp1->ShapeColor.setValue(0x8ae23400);
        vp1->PointColor.setValue(0x8ae23400);
    }
}

void GeomFillSurface::on_radioLine_clicked()
{
    projectLineType = ProjectCurve::Line;
    spline->setShapes(ProjectCurve::Line);
    vp->setActiveMode();
    vp->updateView();
}

void GeomFillSurface::on_radioSplin_clicked()
{
    projectLineType = ProjectCurve::Splin;
    spline->setShapes(ProjectCurve::Splin);
    vp->setActiveMode();
    vp->updateView();
}

void GeomFillSurface::on_radioPolylin_clicked()
{
    projectLineType = ProjectCurve::Polyline;
    spline->setShapes(ProjectCurve::Polyline);
    vp->setActiveMode();
    vp->updateView();
}

bool GeomFillSurface::reject()
{
    //this->vp->highlightReferences(false);
    selectionMode = None;
    Gui::Selection().rmvSelectionGate();

    //Gui::Command::abortCommand();
    //Gui::Command::doCommand(Gui::Command::Gui,"Gui.ActiveDocument.resetEdit()");
    Gui::Command::updateActive();
    return true;
}

void GeomFillSurface::on_checkBox_clicked(bool checked)
{
    if (checked)
    {
        selectionMode = Append;
        Gui::Selection().addSelectionGate(new EdgeSelection(true/*, editedObject*/));
    }
    else
    {
        selectionMode = None;
        Gui::Selection().addSelectionGate(new EdgeSelection(false/*, editedObject*/));
    }

    ui->stackedWidget->setDisabled(checked);
}

void GeomFillSurface::onSelectionChanged(const Gui::SelectionChanges& msg)
{
    if (selectionMode == None)
        return;

    if (msg.Type == Gui::SelectionChanges::AddSelection)
    {
        checkOpenCommand();
        if (selectionMode == Append)
        {
            QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
            item->setIcon(Gui::BitmapFactory().pixmap("view-rotate-right"));
            ui->listWidget->addItem(item);

            Gui::SelectionObject sel(msg);
            QString text = QString::fromLatin1("%1.%2")
                    .arg(QString::fromUtf8(sel.getObject()->Label.getValue()))
                    .arg(QString::fromLatin1(msg.pSubName));
            item->setText(text);

            QList<QVariant> data;
            data << QByteArray(msg.pDocName);
            data << QByteArray(msg.pObjectName);
            data << QByteArray(msg.pSubName);
            item->setData(Qt::UserRole, data);

            m_vFaces.push_back(sel);

            //            auto objects = editedObject->BoundaryList.getValues();
            //            objects.push_back(sel.getObject());
            //            auto element = editedObject->BoundaryList.getSubValues();
            //            element.push_back(msg.pSubName);
            //            editedObject->BoundaryList.setValues(objects, element);
            //            auto booleans = editedObject->ReversedList.getValues();
            //            booleans.push_back(false);
            //            editedObject->ReversedList.setValues(booleans);
            //this->vp->highlightReferences(true);
        }
        else
        {
            Gui::SelectionObject sel(msg);
            QList<QVariant> data;
            int row = 0;
            data << QByteArray(msg.pDocName);
            data << QByteArray(msg.pObjectName);
            data << QByteArray(msg.pSubName);
            for (int i=0; i<ui->listWidget->count(); i++)
            {
                QListWidgetItem* item = ui->listWidget->item(i);
                if (item && item->data(Qt::UserRole) == data)
                {
                    row = i;
                    ui->listWidget->takeItem(i);
                    delete item;
                }
            }

            //this->vp->highlightReferences(false);

            //std::string sub = msg.pSubName;
            //            auto objects = editedObject->BoundaryList.getValues();
            //            auto element = editedObject->BoundaryList.getSubValues();
            //            auto it = objects.begin();
            //            auto jt = element.begin();

            //            // remove the element of the bitset at position 'row'
            //            const boost::dynamic_bitset<>& old_booleans = editedObject->ReversedList.getValues();
            //            boost::dynamic_bitset<> new_booleans = old_booleans >> 1;
            //            new_booleans.resize(objects.size()-1);

            //            // double-check in case 'old_booleans' is out of sync
            //            if (new_booleans.size() < old_booleans.size()) {
            //                for (int i=0; i<row; i++)
            //                    new_booleans[i] = old_booleans[i];
            //            }

            //            for (; it != objects.end() && jt != element.end(); ++it, ++jt) {
            //                if (*it == obj && *jt == sub) {
            //                    objects.erase(it);
            //                    element.erase(jt);
            //                    editedObject->BoundaryList.setValues(objects, element);
            //                    editedObject->ReversedList.setValues(new_booleans);
            //                    break;
            //                }
            //            }
            //            //this->vp->highlightReferences(true);
        }

        //        editedObject->recomputeFeature();
        QTimer::singleShot(50, this, SLOT(clearSelection()));
    }
}
void GeomFillSurface::onDeleteEdge()
{
    int row = ui->edgeList->currentRow();
    QListWidgetItem* item = ui->edgeList->item(row);
    if(item) {
        checkOpenCommand();
        QList<QVariant> data;
        data = item->data(Qt::UserRole).toList();
        ui->edgeList->takeItem(row);
        delete item;
    }

    //update the data saved in the geometry document object
    //from the index, get the compound shape
    //for now only consider a single face
    //TODO: consider the situation where multiple faces are selected
    auto aPart = dynamic_cast<Part::Feature*>(m_vFaces.front().getObject());
    auto bigShape = aPart->Shape.getShape().getShape();
    TopoDS_Compound newCompound;
    TopoDS_Builder newBuilder;
    newBuilder.MakeCompound(newCompound);

    TopTools_IndexedMapOfShape edges;
    TopExp::MapShapes(bigShape, TopAbs_EDGE, edges);

    for(int i = 0; i < ui->edgeList->count(); i++) {
       QListWidgetItem* item = ui->edgeList->item(i);
       QList<QVariant> data;
       data = item->data(Qt::UserRole).toList();
       int edgeIndex = data[3].toInt();
       newBuilder.Add(newCompound, edges.FindKey(edgeIndex));
    }

    if(!newCompound.IsNull())
        m_geometryObject->Shape.setValue(newCompound);


}

void GeomFillSurface::onDeleteFace()
{
    int row = ui->listWidget->currentRow();
    QListWidgetItem* item = ui->listWidget->item(row);
    if (item) {
        checkOpenCommand();
        QList<QVariant> data;
        data = item->data(Qt::UserRole).toList();
        ui->listWidget->takeItem(row);
        delete item;

        App::Document* doc = App::GetApplication().getDocument(data[0].toByteArray());
        App::DocumentObject* obj = doc ? doc->getObject(data[1].toByteArray()) : nullptr;
        std::string sub = data[2].toByteArray().constData();
        //auto objects = editedObject->BoundaryList.getValues();
        //        auto element = editedObject->BoundaryList.getSubValues();
        //        auto it = objects.begin();
        //        auto jt = element.begin();
        //        //this->vp->highlightReferences(false);

        //        // remove the element of the bitset at position 'row'
        //        const boost::dynamic_bitset<>& old_booleans = editedObject->ReversedList.getValues();
        //        boost::dynamic_bitset<> new_booleans = old_booleans >> 1;
        //        new_booleans.resize(objects.size()-1);

        //        // double-check in case 'old_booleans' is out of sync
        //        if (new_booleans.size() < old_booleans.size()) {
        //            for (int i=0; i<row; i++)
        //                new_booleans[i] = old_booleans[i];
        //        }

        //        for (; it != objects.end() && jt != element.end(); ++it, ++jt) {
        //            if (*it == obj && *jt == sub) {
        //                objects.erase(it);
        //                element.erase(jt);
        //                editedObject->BoundaryList.setValues(objects, element);
        //                editedObject->ReversedList.setValues(new_booleans);
        //                break;
        //            }
        //        }
        //        //this->vp->highlightReferences(true);
    }
}


// ----------------------------------------------------------------------------
TaskGeomFillSurface::TaskGeomFillSurface()
{
    this->setButtonPosition(TaskGeomFillSurface::South);
    widget = new GeomFillSurface();
    widget->setWindowTitle(QObject::tr("CreateGeometry"));
    taskbox = new Gui::TaskView::TaskBox(
                Gui::BitmapFactory().pixmap("BezSurf"),
                widget->windowTitle(), true, 0);
    taskbox->groupLayout()->addWidget(widget);
    Content.push_back(taskbox);
}

TaskGeomFillSurface::~TaskGeomFillSurface()
{
    // automatically deleted in the sub-class
}

void TaskGeomFillSurface::modifyStandardButtons(QDialogButtonBox* button)
{
    taskbox->groupLayout()->addWidget(button);
}

void TaskGeomFillSurface::open()
{
    widget->open();
}

bool TaskGeomFillSurface::accept()
{
    return widget->accept();
}

bool TaskGeomFillSurface::reject()
{
    return widget->reject();
}

}

#include "moc_TaskGeomFillSurface.cpp"
