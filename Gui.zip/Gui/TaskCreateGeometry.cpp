#include "PreCompiled.h"
#ifndef _PreComp_
# include <Inventor/nodes/SoSeparator.h>
# include <TopoDS_Face.hxx>
# include <TopExp.hxx>
# include <TopExp_Explorer.hxx>
# include <BRepProj_Projection.hxx>
# include <TopoDS_Builder.hxx>
# include <TopoDS_Edge.hxx>
# include <ShapeAnalysis.hxx>
# include <ShapeAnalysis_FreeBounds.hxx>
# include <ShapeFix_Wire.hxx>
# include <BRep_Tool.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Geom_TrimmedCurve.hxx>
# include <GeomProjLib.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include "ShapeFix_Edge.hxx"
# include <BRepBuilderAPI_MakeFace.hxx>
# include <ShapeFix_Face.hxx>
# include <BRepCheck_Analyzer.hxx>
# include <ShapeFix_Wireframe.hxx>
# include <BRepPrimAPI_MakePrism.hxx>
# include <gp_Ax1.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_Transform.hxx>
# include <QAction>
# include <QMenu>
# include <QDoubleSpinBox>
# include <QPushButton>
# include <QMessageBox>
# include <QTimer>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
# include <cfloat>
# include <QFuture>
# include <QFutureWatcher>
# include <QToolButton>
# include <QKeyEvent>
# include <QtConcurrentMap>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
#endif

#include "TaskCreateGeometry.h"
#include "ui_TaskCreateGeometry.h"
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/Command.h>
#include <Gui/SelectionObject.h>
#include <Base/Console.h>
#include <Gui/Control.h>
#include <Gui/BitmapFactory.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>
#include <Mod/Part/Gui/CrossSections.h>
#include <Mod/WirCore/Gui/DlgCreateGeometry/DlgCrossSections.h>
#include "Gui/MainWindow.h"
#include "Gui/MDIView.h"
#include "Gui/View3DInventor.h"
#include "Gui/View3DInventorViewer.h"
#include "Inventor/SbVec3d.h"
#include "Mod/Part/Gui/ViewProviderExt.h"
#include "ViewProviderGeometryObject.h"
#include "Mod/Part/App/PropertyTopoShape.h"
#include "Mod/WirCore/App/WorkObjectReferenceFrame.h"
#include "Mod/Part/App/PropertyTopoShape.h"
#include "Mod/WirCore/Gui/DlgCreateGeometry/DlgSpecifyArea.h"
#include "Mod/WirCore/Gui/DlgCreateGeometry/DlgSpecifyEdge.h"
#include "Mod/WirCore/Gui/DlgCreateGeometry/BaseDialog.h"
#include "Mod/WirCore/Gui/DlgCreateGeometry/DlgProjection.h"
#include "Mod/WirCore/Gui/DlgCreateGeometry/DlgUVCurve.h"
#include "Mod/WirCore/App/GeometryObject.h"

using namespace WirCore;
using namespace WirCoreGui;

namespace WirCoreGui
{
// ----------------------------------------------------------------------------
DlgCreateGeometry::DlgCreateGeometry()
{
    ui = new Ui_DlgCreateGeometry();
    ui->setupUi(this);

    auto curDoc = App::GetApplication().getActiveDocument();

    // 投影方向即选择当前摄像机的视角方向，暂时不开启预览功能
    ui->toolButtonPreViewProVector->setDisabled(true);

    // 命名功能若按照系统方法，则需要先生成结果物体，暂时按照数量向后累加命名

    auto docGeometryObjs = curDoc->getObjectsOfType(WirCore::GeometryObject::getClassTypeId());
    QString s;
    s.setNum(docGeometryObjs.size());
    m_StrGeoName = QString::fromLocal8Bit("Geometry_") + s;
    ui->lineEditName->setText(m_StrGeoName);

    // 工件坐标系选择功能
    auto docWorkObjObjs = curDoc->getObjectsOfType(WirCore::WorkObjectReferenceFrame::getClassTypeId());
    for (auto it : docWorkObjObjs)
    {
        ui->comboBoxWorkObj->addItem(QString::fromStdString(it->Label.getValue()));
    }
    if (docWorkObjObjs.empty())
        ui->comboBoxWorkObj->addItem(QString::fromLocal8Bit("No"));

    // 切换Type的选项时，切换当前的对话框
    ui->comboBoxType->removeItem(3); // 暂时不显示UVCurve
    ui->stackedWidget_Type->setCurrentIndex(0);
    QObject::connect(ui->comboBoxType, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this, [&](int index)
    {
        ui->stackedWidget_Type->setCurrentIndex(index);
        m_curType = (TypeGeo)index;
        switch (index)
        {
        case 0:
            m_curDlg = m_pDlgSpecifyEdge;
            break;
        case 1:
            m_curDlg = m_pDlgIntersectGeo;
            break;
        case 2:
            m_curDlg = m_pDlgProjectionGeo;
            break;
        case 3:
            m_curDlg = m_pDlgDlgUVCurve;
            break;
        }
    });

    // preview功能,该功能需要在该类中新建ViewProviderGeometry对象，用来做预览功能
    m_pVpGeo = new ViewProviderGeometryObject();
    App::Color c(1.0, 0, 1.0);
    m_pVpGeo->LineColor.setValue(c);
    m_pVpGeo->LineWidth.setValue(50);

    m_pGeo = new GeometryObject();
    m_pVpGeo->attach(m_pGeo);
    Gui::Document* doc = Gui::Application::Instance->activeDocument();
    view = qobject_cast<Gui::View3DInventor*>(doc->getActiveView());
    if (view)
        view->getViewer()->addViewProvider(m_pVpGeo);
}

/*
 *  Destroys the object and frees any allocated resources
 */
DlgCreateGeometry::~DlgCreateGeometry()
{
    if (view)
    {
        view->getViewer()->removeViewProvider(m_pVpGeo);
    }
    delete m_pVpGeo;
    delete m_pGeo;

    // no need to delete child widgets, Qt does it all for us
    delete ui;
}

void DlgCreateGeometry::preview()
{
    switch (m_curType)
    {
    case 0:
        m_curDlg = m_pDlgSpecifyEdge;
        break;
    case 1:
        m_curDlg = m_pDlgIntersectGeo;
        break;
    case 2:
        m_curDlg = m_pDlgProjectionGeo;
        break;
    case 3:
        m_curDlg = m_pDlgDlgUVCurve;
        break;
    }
    if (m_curDlg)
    {
        static bool ok = false;
        TopoDS_Shape Shape= m_curDlg->getShape();

        m_pGeo->Shape.setValue(m_curDlg->getShape());

        // the two line is very good
        m_pVpGeo->setActiveMode();
        m_pVpGeo->updateView();
        m_pVpGeo->setVisible(ok = !ok);
    }
}

void DlgCreateGeometry::addToAssistWidget(BaseDialog* w)
{
    ui->stackedWidget->insertWidget(1, w);
    ui->stackedWidget->setCurrentIndex(1);

    Q_EMIT sigSpecifyAreaClicked();
}

void DlgCreateGeometry::on_toolButtonSpecifyArea_clicked()
{
    if (!m_pDlgSpecifyArea)
    {
        m_pDlgSpecifyArea = new DlgSpecifyArea(App::GetApplication().getActiveDocument(), ui->page_2);

        // 点击对应的拾取界面的cancel或ok按钮，切回
        QObject::connect(m_pDlgSpecifyArea, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigOK), this, [&]()
        {
            slotCloseSpecifyAreaPage();
            Q_EMIT sigSpecifyAreaClose();
        });
        QObject::connect(m_pDlgSpecifyArea, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigCancel), this, [&]()
        {
            slotCloseSpecifyAreaPage();
            Q_EMIT sigSpecifyAreaClose();
        });

    }
    addToAssistWidget(m_pDlgSpecifyArea);
    m_pDlgSpecifyArea->show();
}

void DlgCreateGeometry::slotCloseSpecifyAreaPage()
{
    auto w = ui->stackedWidget->widget(1);
    if (w)
    {
        ui->stackedWidget->removeWidget(w);
        ui->stackedWidget->setCurrentIndex(0);
    }
}

void DlgCreateGeometry::on_toolButtonPreViewArea_clicked(bool checked)
{
    static bool flag = false;
    if (m_pDlgSpecifyArea)
        m_pDlgSpecifyArea->preview(flag = !flag);
}


// Edge Curve
void DlgCreateGeometry::on_toolButtonSpecifyEdge_clicked()
{
    if (m_pDlgSpecifyArea != nullptr)
    {
        auto fs = m_pDlgSpecifyArea->getSelectedFaces();
        if (!m_pDlgSpecifyEdge)
        {
            m_pDlgSpecifyEdge = new DlgSpecifyEdge(App::GetApplication().getActiveDocument(), ui->page_2);

            // 点击对应的拾取界面的cancel或ok按钮，切回
            QObject::connect(m_pDlgSpecifyEdge, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigOK), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
            QObject::connect(m_pDlgSpecifyEdge, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigCancel), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });

        }
        m_pDlgSpecifyEdge->setSelectedFaces(fs);
        addToAssistWidget(m_pDlgSpecifyEdge);
        m_pDlgSpecifyEdge->show();
    }
}

void DlgCreateGeometry::on_toolButtonPreViewEdge_clicked(bool checked)
{
    static bool flag = true;
    if (m_pDlgSpecifyEdge)
        m_pDlgSpecifyEdge->preview(flag = !flag);
}

// Intersect Geo
void DlgCreateGeometry::on_toolButtonSpecifyPlane_clicked()
{
    Base::BoundBox3d bbox;
    if (m_pDlgSpecifyArea != nullptr)
    {
        if (!m_pDlgIntersectGeo)
        {
            m_pDlgIntersectGeo = new DlgCrossSections(bbox, ui->page_2);

            // 点击对应的拾取界面的cancel或ok按钮，切回
            QObject::connect(m_pDlgIntersectGeo, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigOK), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
            QObject::connect(m_pDlgIntersectGeo, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigCancel), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
        }
        auto fs = m_pDlgSpecifyArea->getSelectedFaces();
        for (auto i : fs)
        {
            auto obj = static_cast<Part::Feature*>(i.first);

            Part::PropertyPartShape propShape;
            WirCoreGui::BaseDialog::makeGlobalPropShape(&obj->Shape, obj->globalPlacement(), propShape);
            bbox.Add(propShape.getBoundingBox());
        }
        m_pDlgIntersectGeo->setBoundBox3d(bbox);
        m_pDlgIntersectGeo->setSelectedFaces(fs);

        addToAssistWidget(m_pDlgIntersectGeo);

        m_pDlgIntersectGeo->show();
    }
}

void DlgCreateGeometry::on_toolButtonPreViewPlane_clicked()
{
    if (m_pDlgIntersectGeo)
    {
        static bool ok = false;
        m_pDlgIntersectGeo->preView(ok = !ok);
    }
}

// Project Geo
void DlgCreateGeometry::on_toolButtonSpecifyProCurve_clicked()
{
    if (m_pDlgSpecifyArea != nullptr )
    {
        if (!m_pDlgProjectionGeo)
        {
            m_pDlgProjectionGeo = new DlgProjection(App::GetApplication().getActiveDocument(), ui->page_2);

            // 点击对应的拾取界面的cancel或ok按钮，切回
            QObject::connect(m_pDlgProjectionGeo, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigOK), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
            QObject::connect(m_pDlgProjectionGeo, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigCancel), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });

        }
        auto fs = m_pDlgSpecifyArea->getSelectedFaces();
        m_pDlgProjectionGeo->setSelectedFaces(fs);
        m_pDlgProjectionGeo->showCurve();
        addToAssistWidget(m_pDlgProjectionGeo);
    }
}

void DlgCreateGeometry::on_toolButtonSpecifyProVector_clicked()
{
    if (m_pDlgSpecifyArea != nullptr )
    {
        if (!m_pDlgProjectionGeo)
        {
            m_pDlgProjectionGeo = new DlgProjection(App::GetApplication().getActiveDocument(), ui->page_2);

            // 点击对应的拾取界面的cancel或ok按钮，切回
            QObject::connect(m_pDlgProjectionGeo, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigOK), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
            QObject::connect(m_pDlgProjectionGeo, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigCancel), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
        }
        auto fs = m_pDlgSpecifyArea->getSelectedFaces();
        m_pDlgProjectionGeo->setSelectedFaces(fs);
        m_pDlgProjectionGeo->showDirection();
        addToAssistWidget(m_pDlgProjectionGeo);
    }
}

void DlgCreateGeometry::on_toolButtonPreViewProCurve_clicked()
{
    if (m_pDlgProjectionGeo != nullptr )
    {
        static bool ok = false;
        m_pDlgProjectionGeo->previewCurve(ok = !ok);
    }
}

void DlgCreateGeometry::on_toolButtonPreViewProVector_clicked()
{
    if (m_pDlgProjectionGeo != nullptr )
    {
        static bool ok = false;
        m_pDlgProjectionGeo->previewDirection(ok = !ok);
    }
}


// UV Curve
void DlgCreateGeometry::on_toolButtonSpecifyUVParam_clicked()
{
    if (m_pDlgSpecifyArea != nullptr )
    {
        if (!m_pDlgDlgUVCurve)
        {
            m_pDlgDlgUVCurve = new DlgUVCurve(App::GetApplication().getActiveDocument(), ui->page_2);

            // 点击对应的拾取界面的cancel或ok按钮，切回
            QObject::connect(m_pDlgDlgUVCurve, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigOK), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });
            QObject::connect(m_pDlgDlgUVCurve, static_cast<void(BaseDialog::*)()>(&BaseDialog::sigCancel), this, [&]()
            {
                slotCloseSpecifyAreaPage();
                Q_EMIT sigSpecifyAreaClose();
            });

        }
        auto fs = m_pDlgSpecifyArea->getSelectedFaces();
    }
}

void DlgCreateGeometry::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange) {
        ui->retranslateUi(this);
    }
    else {
        QWidget::changeEvent(e);
    }
}

void DlgCreateGeometry::open()
{
    checkOpenCommand();
    //this->vp->highlightReferences(true);
    Gui::Selection().clearSelection();
}

//void DlgCreateGeometry::clearSelection()
//{
//    Gui::Selection().clearSelection();
//}

void DlgCreateGeometry::checkOpenCommand()
{
    if (checkCommand && !Gui::Command::hasPendingCommand()) {
        std::string Msg("Edit ");
        //Msg += editedObject->Label.getValue();
        Gui::Command::openCommand(Msg.c_str());
        checkCommand = false;
    }
}

//void DlgCreateGeometry::slotUndoDocument(const Gui::Document&)
//{
//    checkCommand = true;
//}

//void DlgCreateGeometry::slotRedoDocument(const Gui::Document&)
//{
//    checkCommand = true;
//}

//void DlgCreateGeometry::slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj)
//{
//    // If this view provider is being deleted then reset the colors of
//    // referenced part objects. The dialog will be deleted later.
//    //if (this->vp == &Obj) {
//    //    this->vp->highlightReferences(false);
//    //}
//}

bool DlgCreateGeometry::accept()
{
    Gui::Command::commitCommand();
    //Gui::Command::doCommand(Gui::Command::Gui,"Gui.ActiveDocument.resetEdit()");

    auto doc = App::GetApplication().getActiveDocument();
    switch (ui->comboBoxType->currentIndex())
    {
    case 0: // Edge Curve
    {
        m_pDlgSpecifyEdge->getShape();
        auto obj_child = dynamic_cast<WirCore::GeometryObject*>(doc->addObject("WirCore::GeometryObject", ui->lineEditName->text().toStdString().c_str()));
        obj_child->obj_group.assign(m_pDlgSpecifyEdge->obj_group.begin(),m_pDlgSpecifyEdge->obj_group.end());
        auto obj=dynamic_cast<Part::Feature*>(obj_child);
        if (!obj)
        {
            throw Base::ValueError(QString(tr("Can not create a projection object!!!")).toUtf8());
        }
        if (m_pDlgSpecifyEdge)
        {
            auto shape = m_pDlgSpecifyEdge->getShape();
            obj->Shape.setValue(shape);
        }
        break;
    }
    case 1: // Intersect Curve
    {
        auto obj = dynamic_cast<Part::Feature*>(doc->addObject("WirCore::GeometryObject", ui->lineEditName->text().toStdString().c_str()));
        if (!obj)
        {
            throw Base::ValueError(QString(tr("Can not create a projection object!!!")).toUtf8());
        }
        if (m_pDlgIntersectGeo)
        {
            auto shape = m_pDlgIntersectGeo->getShape();
            obj->Shape.setValue(shape);
        }
        break;
    }

    case 2: // Project Geo
    {
        auto obj = dynamic_cast<Part::Feature*>(doc->addObject("WirCore::GeometryObject", ui->lineEditName->text().toStdString().c_str()));
        if (!obj)
        {
            throw Base::ValueError(QString(tr("Can not create a projection object!!!")).toUtf8());
        }
        if (m_pDlgProjectionGeo)
        {
            auto shape = m_pDlgProjectionGeo->getShape();
            obj->Shape.setValue(shape);
        }
        break;
    }
    case 3: //UV Curve
    {
        Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();
        auto cmd = mgr.getCommandByName("IsoCurve");
        cmd->invoke(0);

        //            doCommand(Doc,"FreeCAD.getDocument(\"%s\").addObject(\"Part::Feature\",\"%s\")"
        //                         ,doc->getName()
        //                         ,name.c_str());
        //Gui::Command::runCommand(Gui::Command::Gui, "FreeCAD.ActiveDocument.getObject(\"IsoCurve\").NumberU = 6");

        //            std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::DocumentObject::getClassTypeId(), "IsoCurve");
        ////            if (sel.empty())
        ////            {
        ////                App::Document* doc = App::GetApplication().getDocument(DocName);
        ////                sel = doc->getObjectsOfType(App::DocumentObject::getClassTypeId());
        ////            }
        //            std::stringstream str;
        //            std::set<App::DocumentObject*> unique_objs;
        //            str << "__objs__=[]" << std::endl;
        //            for (std::vector<App::DocumentObject*>::iterator it = sel.begin(); it != sel.end(); ++it) {
        //                if (unique_objs.insert(*it).second) {
        //                    str << "__objs__.append(FreeCAD.getDocument(\"" << DocName << "\").getObject(\""
        //                        << (*it)->getNameInDocument() << "\"))" << std::endl;
        //                }
        //            }

        break;
    }
        //    case 2:
        //    {
        // runCommand(Command::Doc,cmd.toUtf8());
        //Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();
        //auto cmd = mgr.getCommandByName("Part_projectionOnSurface");
        //cmd->invoke(0);
        //        std::string names(name);
        //        QAction* action = findAction(actions, names);
        //        if(!action)
        //        {
        //            if (mgr.addTo(name, m_pTabToolbar))
        //            {
        //                action = m_pTabToolbar->actions().last();
        //                m_pTabToolbar->removeAction(action);//mgr.addTo will also add action to toolbar, remove it to avoid duplication
        //            }
        //            if (action)
        //                action->setData(QString::fromStdString(names));
        //        }


        //            Gui::Command::runCommand(Gui::Command::Gui, "Part_projectionOnSurface");





        //        std::stringstream stream;
        //        std::vector<Base::Vector3d> EditCurve{Base::Vector3d(0, 0, 0), Base::Vector3d(1, 1, 0), Base::Vector3d(2, 0, 0)};

        //        for (std::vector<Base::Vector3d>::const_iterator it = EditCurve.begin(); it != EditCurve.end(); ++it)
        //        {
        //            stream << "App.Vector(" << (*it).x << "," << (*it).y << "," << (*it).z << "),";
        //        }

        //        std::string controlpoints = stream.str();
        //        // remove last comma and add brackets
        //        int index = controlpoints.rfind(',');
        //        controlpoints.resize(index);

        //        controlpoints.insert(0,1,'[');
        //        controlpoints.append(1,']');

        //        //int currentgeoid = getHighestCurveIndex();
        //        Gui::Command::doCommand(Gui::Command::Doc,
        //                                "App.ActiveDocument.%s.addGeometry(Part.BSplineCurve"
        //                                "(%s,None,None,%s,3,None,False),"
        //                                "%s)",
        //                                "Cube",
        //                                controlpoints.c_str(),
        //                                "True", /*ConstrMethod == 0 ?"False":*/
        //                                "True"); // /*geometryCreationMode==Construction?"True":*/



        //        poles = [[0, 0, 0], [1, 1, 0], [2, 0, 0]]
        //        self.spline = Part.BSplineCurve()
        //        self.spline.buildFromPoles(poles)
        //        break;
        //    }
    }

    Gui::Command::updateActive();
    return true;
}

bool DlgCreateGeometry::reject()
{
    selectionMode = None;
    Gui::Selection().rmvSelectionGate();

    //Gui::Command::abortCommand();
    //Gui::Command::doCommand(Gui::Command::Gui,"Gui.ActiveDocument.resetEdit()");
    Gui::Command::updateActive();
    return true;
}

// ----------------------------------------------------------------------------
TaskCreateGeometry::TaskCreateGeometry()
{
    this->setButtonPosition(TaskCreateGeometry::South);
    widget = new DlgCreateGeometry();
    widget->setWindowTitle(QObject::tr("CreateGeometry"));
    taskbox = new Gui::TaskView::TaskBox(
                Gui::BitmapFactory().pixmap("BezSurf"),
                widget->windowTitle(), true, 0);
    taskbox->groupLayout()->addWidget(widget);
    Content.push_back(taskbox);
}

TaskCreateGeometry::~TaskCreateGeometry()
{
    // automatically deleted in the sub-class
}

void TaskCreateGeometry::modifyStandardButtons(QDialogButtonBox* button)
{
    btnsBox = new QWidget(taskbox);
    QHBoxLayout* layout = new QHBoxLayout(btnsBox);

    m_btnPreview = new QToolButton(btnsBox);
    m_btnPreview->setText(QString::fromLocal8Bit("Preview"));
    layout->addWidget(m_btnPreview);
    layout->addWidget(button);
    btnsBox->setLayout(layout);
    taskbox->groupLayout()->addWidget(btnsBox);

    QObject::connect(widget, static_cast<void(DlgCreateGeometry::*)()>(&DlgCreateGeometry::sigSpecifyAreaClicked), this, [&]()
    {
        btnsBox->hide();
    });
    QObject::connect(widget, static_cast<void(DlgCreateGeometry::*)()>(&DlgCreateGeometry::sigSpecifyAreaClose), this, [&]()
    {
        btnsBox->show();
    });

    QObject::connect(m_btnPreview, static_cast<void(QToolButton::*)(bool)>(&QToolButton::clicked), this, [&](bool)
    {
        widget->preview();
    });
}

void TaskCreateGeometry::open()
{
    widget->open();
}

bool TaskCreateGeometry::accept()
{
    return widget->accept();
}

bool TaskCreateGeometry::reject()
{
    return widget->reject();
}

}

#include "moc_TaskCreateGeometry.cpp"
