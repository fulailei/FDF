#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include "WircoreAction.h"

using namespace WirCoreGui;

ObjectListAction::ObjectListAction(Gui::Command* pcCmd,  Base::Type _ObjectType, QObject * parent)
           : Gui::ActionGroup( pcCmd, parent ), ObjectType(_ObjectType)
{
    setObjectList();
}

ObjectListAction::~ObjectListAction()
{
}


void ObjectListAction::setObjectList()
{
    QList<QAction*> ObjectList = _group->actions();
    for (int index = 0; index < ObjectList.size(); index++) {
         _group->removeAction(ObjectList[index]);
    }

    auto addAction = [&](QString name)
    {
        QAction* act = _group->addAction(/*QString()*/name);
        act->setText(name);
        act->setToolTip(name);
        act->setCheckable(true);
        act->setObjectName(name);
    };

    App::Document* doc = App::GetApplication().getActiveDocument();

    std::vector<App::DocumentObject*> vecObject = doc->getObjectsOfType(ObjectType);

    for (std::vector<App::DocumentObject*>::iterator it = vecObject.begin(); it != vecObject.end(); ++it)
    {
        QString label = QString::fromUtf8((*it)->Label.getValue());
        addAction(label);
    }

}


void ObjectListAction::removeSpecifyObject(App::DocumentObject* i_Object)
{
    QString t_name =  QString::fromUtf8(i_Object->Label.getValue());
    QList<QAction*> ObjectList = _group->actions();
    for (int index = 0; index < ObjectList.size(); index++)
    {
        QString t_str = ObjectList[index]->text();
        if (t_str.compare(t_name) == 0)
        {
            _group->removeAction(ObjectList[index]);
        }
    }
}



#include "moc_WircoreAction.cpp"
