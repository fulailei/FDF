#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include <QString>
#include <QTimer>
#include "DlgRobotSimulate.h"
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/BitmapFactory.h>
#include <Gui/ViewProvider.h>
#include <Gui/WaitCursor.h>
#include <Base/Console.h>
#include <Gui/Selection.h>
#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>
#include <Gui/ViewProvider.h>
#include <Gui/SoFCSelection.h>
#include <Gui/ViewProviderPart.h>
#include <Base/Console.h>
#include <Gui/View3DInventor.h>
#include "Gui/View3DInventorViewer.h"
#include "Gui/MainWindow.h"
#include <Mod/WirCore/App/AllowedCollisionMatrix.h>
#include <Mod/WirCore/Gui/ViewProviderACM.h>
#include "Mod/WirCore/App/kdl_cp/chain.hpp"
#include "Mod/WirCore/App/kdl_cp/path_line.hpp"
#include "Mod/WirCore/App/kdl_cp/path_roundedcomposite.hpp"
#include "Mod/WirCore/App/kdl_cp/trajectory_composite.hpp"
#include "Mod/WirCore/App/kdl_cp/rotational_interpolation_sa.hpp"
#include "Mod/WirCore/App/kdl_cp/velocityprofile_trap.hpp"
#include "Mod/WirCore/App/kdl_cp/trajectory_segment.hpp"
#include "Mod/WirCore/App/kdl_cp/path_roundedcomposite.hpp"
#include "Mod/WirCore/App/kdl_cp/utilities/error.h"

using namespace WirCoreGui;
using namespace Gui;

DlgRobotSimulate::DlgRobotSimulate(WirCore::RobotObject *pRobotObject,
                                   WirCore::TrajectoryObject *pTrajectoryObject,
                                   QWidget *parent)
    : QDialog( parent),
      sim(pRobotObject ,pTrajectoryObject),
      pcRobot(pRobotObject),
      trace(pTrajectoryObject),
      Run(false),
      block(false),
      timePos(0.0)
{
    this->setupUi(this);
    QMetaObject::connectSlotsByName(this);

    // sim.Tool = pcRobotObject->Tool.getValue();
    sim.Base = pRobotObject->Placement.getValue();
    duration = sim.getDuration();

    initSimControlBar();
    initTrajectoryTable();
    initWayPointStates();

    // set up timer
    timer = new QTimer( this );
    timer->setInterval(100);
    connect(timer             ,SIGNAL(timeout ())           ,this ,SLOT(timerDone()));
    connect(timeSpinBox       ,SIGNAL(valueChanged(double)) ,this , SLOT(valueChanged(double)) );
    connect(timeSlider        ,SIGNAL(valueChanged(int)   ) ,this , SLOT(valueChanged(int)) );

    // get the view provider
    auto provider = Gui::Application::Instance->activeDocument()->getViewProvider(pRobotObject);
    ViewProv = static_cast<ViewProviderRobotObject*>(provider);

    setTo();
}

void  DlgRobotSimulate::onTarBarValueChanged(int value)
{
    if (pcRobot->isLimitPos  == true)
    {
        targetStateBar->setStyleSheet(QString::fromLocal8Bit("QProgressBar::chunk { background-color: rgb(0, 255, 0) }"));
    }
    else
    {
        targetStateBar->setStyleSheet(QString::fromLocal8Bit("QProgressBar::chunk { background-color: rgb(255, 0, 0) }"));
    }
}

void  DlgRobotSimulate::onCollisionBarValueChanged(int value)
{
    ViewProviderACM* vACM = nullptr;
    App::DocumentObject* obj =  App::GetApplication().getActiveDocument()->getObject(WirCore::AllowedCollisionMatrix::uniqueName.c_str());
    if (obj /*&& obj->getTypeId()==WirCore::AllowedCollisionMatrix::getClassTypeId()*/)
    {
        WirCore::AllowedCollisionMatrix* acm = static_cast<WirCore::AllowedCollisionMatrix*>(obj);
        Gui::Document* document = Application::Instance->activeDocument();
        if (document)
        {
            Gui::ViewProvider* vp = document->getViewProvider(obj);
            if (acm->getIsCheckInSim() && vp && vp->getTypeId() == ViewProviderACM::getClassTypeId())
            {
                vACM = static_cast<ViewProviderACM*>(vp);
                //vACM->updateACM();
                vACM->collisionCheck();
            }
            else
            {
                //Base::Console().Message("ViewProviderACM object is not found\n");
                return;
            }
        }
    }


    QColor c(255,255,0);
    if (vACM && vACM->getIntersectionCount() != 0)
    {
        if (isCollisionStop)
            this->stop();

        collisionBar->setStyleSheet(QString::fromLocal8Bit("QProgressBar::chunk { background-color: rgb(255, 255, 0) }"));
    }
    else
    {
        collisionBar->setStyleSheet(QString::fromLocal8Bit("QProgressBar::chunk { background-color: rgb(255, 0, 0) }"));
    }
}

DlgRobotSimulate::~DlgRobotSimulate()
{
}

void DlgRobotSimulate::setTo()
{
    sim.setToTime(timePos, checkWayPoint(timePos));
    axisChanged(sim.Axis[0],sim.Axis[1],sim.Axis[2],sim.Axis[3],sim.Axis[4],sim.Axis[5], pcRobot->Tcp.getValue());

    collisonCheck();
}

void DlgRobotSimulate::start(void)
{
    pointIndex = 0;

    stop();

    timePos = 0.0f;
    timeSpinBox->setValue(timePos);
    timeSlider->setValue(int((timePos/duration)*1000));
    setTo();

    setTargetValue(0);
    ButtonCollisionStop->setDisabled(false);
}

void DlgRobotSimulate::stop(void)
{
    timer->stop();
    Run = false;
}

void DlgRobotSimulate::run(void)
{
    timer->start();
    Run = true;

    ButtonCollisionStop->setDisabled(true);
}

void DlgRobotSimulate::back(void)
{
}

void DlgRobotSimulate::forward(void)
{
}

void DlgRobotSimulate::end(void)
{
    timePos = duration;
    timeSpinBox->setValue(timePos);
    timeSlider->setValue(int((timePos/duration)*1000));
    setTo();
}

void DlgRobotSimulate::collisionStop(void)
{
    if (isCollisionStop)
    {
        isCollisionStop = false;
        ButtonCollisionStop->setIcon(QIcon(Gui::BitmapFactory().pixmap("WirCore_Sim_CollisionStop_On.svg")));
    }
    else
    {
        isCollisionStop = true;
        this->ButtonCollisionStop->setIcon(QIcon(Gui::BitmapFactory().pixmap("WirCore_Sim_CollisionStop_Off.svg")));
    }
}

void DlgRobotSimulate::timerDone(void)
{
    if(timePos < duration)
    {
        timePos += .1f;
        timeSpinBox->setValue(timePos);
        timeSlider->setValue(int((timePos/duration)*1000));
        setTo();
        timer->start();
        int index = checkWayPoint(timePos);
        if (index > 0)
        {
            setTargetValue(index);
        }
    }
    else
    {
        timer->stop();
        Run = false;

        auto trac = trace->getAllPointsInTrajectory();
        auto size = trac.size();
        setTargetValue(size);
    }
}

void DlgRobotSimulate::valueChanged (int value)
{
    if (!block)
    {
        timePos = duration*(value/1000.0);
        block=true;
        timeSpinBox->setValue(timePos);
        block=false;
        setTo();
        int index = checkWayPoint(timePos);
        if (index > 0)
        {
            setTargetValue(index);
        }
    }
}

void DlgRobotSimulate::valueChanged ( double value )
{
    if(!block)
    {
        timePos = value;
        block=true;
        timeSlider->setValue(int((timePos/duration)*1000));
        block=false;
        setTo();
    }
}

void DlgRobotSimulate::valueChangedSpeed (int d)
{
    timer->setInterval(10*d);
}

void DlgRobotSimulate::speed(int v)
{
    timer->setInterval(1000*v/5);
}

void DlgRobotSimulate::initTrajectoryTable()
{
    trajectoryTable->setSortingEnabled(false);

    auto trac = trace->getAllPointsInTrajectory();
    auto size = trac.size();
    trajectoryTable->setRowCount(size);
    for (unsigned int i = 0; i < size; i++)
    {
        auto pt = dynamic_cast<WirCore::WaypointObject*>(trac[i]);
        if (pt->waypointType.getEnum() == "MoveJ")
        {
            trajectoryTable->setItem(i, 0, new QTableWidgetItem(QString::fromLatin1("MoveJ")));
        }
        else if (pt->waypointType.getEnum() == "MoveL")
        {
            trajectoryTable->setItem(i, 0, new QTableWidgetItem(QString::fromLatin1("MoveL")));
        }
        trajectoryTable->setItem(i, 1, new QTableWidgetItem(QString::fromUtf8(pt->Label.getName())));
        //        if(pt->)
        //            trajectoryTable->setItem(i, 2, new QTableWidgetItem(QString::fromLatin1("|")));
        //        else
        //            trajectoryTable->setItem(i, 2, new QTableWidgetItem(QString::fromLatin1("-")));

        trajectoryTable->setItem(i, 2, new QTableWidgetItem(QString::number(pt->getCurTime(), 10, 4)));

        trajectoryTable->setItem(i, 3, new QTableWidgetItem(QString::number(pt->Velocity.getValue())));
        trajectoryTable->setItem(i, 4, new QTableWidgetItem(QString::number(pt->Accelaration.getValue())));
    }
}

void DlgRobotSimulate::initWayPointStates()
{
    auto trac = trace->getAllPointsInTrajectory();
    auto size = trac.size();
    targetLabel->setText(QString::fromLocal8Bit("0/") + QString::number(size) + QString::fromLocal8Bit(":"));

    targetSlider->setMaximum(size);
    targetSlider->setMinimum(0);

    targetStateBar->setMaximum(size);
    targetStateBar->setMinimum(0);

    collisionBar->setMaximum(size);
    collisionBar->setMinimum(0);

    connect(targetSlider, SIGNAL(valueChanged(int)), targetStateBar, SLOT(setValue(int)));
    connect(targetSlider, SIGNAL(valueChanged(int)), collisionBar, SLOT(setValue(int)));
    connect(targetStateBar, SIGNAL(valueChanged(int)), this, SLOT(onTarBarValueChanged(int)));
    connect(collisionBar, SIGNAL(valueChanged(int)), this, SLOT(onCollisionBarValueChanged(int)));
}

void DlgRobotSimulate::initSimControlBar()
{
    ButtonStepForward->hide();
    ButtonStepBack->hide();
    ButtonStepEnd->hide();

    ButtonCollisionStop->setIcon(QIcon(Gui::BitmapFactory().pixmap("WirCore_Sim_CollisionStop_On.svg")));
    timeSpinBox->setMaximum(duration);

    connect(ButtonStepStart      ,SIGNAL(clicked())      ,this,SLOT(start()));
    connect(ButtonStepStop       ,SIGNAL(clicked())      ,this,SLOT(stop()));
    connect(ButtonStepRun        ,SIGNAL(clicked())      ,this,SLOT(run()));
    connect(ButtonStepBack       ,SIGNAL(clicked())      ,this,SLOT(back()));
    connect(ButtonStepForward    ,SIGNAL(clicked())      ,this,SLOT(forward()));
    connect(ButtonStepEnd        ,SIGNAL(clicked())      ,this,SLOT(end()));
    connect(ButtonCollisionStop  ,SIGNAL(clicked())      ,this,SLOT(collisionStop()));
    connect(ButtonClose          ,SIGNAL(clicked())      ,this,SLOT(close()));
    connect(ComboBoxSpeed        ,SIGNAL(activated(int)) ,this,SLOT(speed(int)));
    connect(Override          ,SIGNAL(valueChanged(int)   ) ,this , SLOT(valueChangedSpeed(int)) );
}

void DlgRobotSimulate::collisonCheck()
{
    auto obj =  App::GetApplication().getActiveDocument()->getObject(WirCore::AllowedCollisionMatrix::uniqueName.c_str());
    if (obj)
    {
        auto acm = static_cast<WirCore::AllowedCollisionMatrix*>(obj);
        auto document = Application::Instance->activeDocument();
        if (document)
        {
            auto vp = document->getViewProvider(obj);
            if (acm->getIsCheckInSim() && vp && vp->getTypeId() == ViewProviderACM::getClassTypeId())
            {
                auto vACM = static_cast<ViewProviderACM*>(vp);
                //vACM->updateACM();
                vACM->collisionCheck();
            }
            else
            {
                //Base::Console().Message("ViewProviderACM object is not found\n");
                return;
            }
        }
    }
}

void DlgRobotSimulate::setTargetValue(int index)
{
    if (targetSlider)
    {
        targetSlider->setValue(index);
        targetLabel->setText(QString::number(index) + QString::fromLocal8Bit("/") +
                             QString::number(targetSlider->maximum()) + QString::fromLocal8Bit(":"));
    }
}

int  DlgRobotSimulate::checkWayPoint(float time)
{
    auto trac = trace->getAllPointsInTrajectory();
    auto size = trac.size();
    for (unsigned int i = 0; i < size; i++)
    {
        auto pt = dynamic_cast<WirCore::WaypointObject*>(trac[i]);
        if (abs(time - pt->getCurTime()) < 0.1)
            //setTargetValue(i);
            return i;
    }
    return 0;
}


#include "moc_DlgRobotSimulate.cpp"
