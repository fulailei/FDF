#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include "CollisionObject.h"
#include <Inventor/actions/SoSearchAction.h>
#include <Inventor/actions/SoSearchAction.h>
#include <Base/Console.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/Part/Gui/SoBrepEdgeSet.h>
#include <Mod/Part/Gui/SoBrepPointSet.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include <Mod/Part/Gui/ViewProviderExt.h>
//#include <Mod/Part/Gui/ViewProviderPart.h>

using namespace WirCoreGui;
using namespace WirCore;
using namespace Gui;
using namespace PartGui;

CollisionObject::CollisionObject(Gui::ViewProvider* vp)
{
    // this->vp=NULL;
    // if (vp->isDerivedFrom(PartGui::ViewProviderPart::getClassTypeId()))
    this->vp = vp;
    // else return;
    partObj = static_cast<PartGui::ViewProviderPart*>(vp);
    name = (const char*)partObj->getObject()->getNameInDocument();
    getShapes();
    // Base::Console().Message("Enter Here 11!\n");
    acm.addEntry(name);
    // Base::Console().Message("Enter Here 12s!\n");
}

void CollisionObject::buildFclSceneObjects()
{
//    //worldObj = dynamic_cast<PartGui::ViewProviderPart*>(*it);
//    if (partObj && !partObj->getObject()->getTypeId().isDerivedFrom(Mesh::Feature::getClassTypeId()))
//    {
//        // exclude meshes
//        std::map<std::string, App::Property*> Map;
//        partObj->getObject()->getPropertyMap(Map);
//        Mesh::MeshObject mesh;
//        for (std::map<std::string, App::Property*>::iterator jt = Map.begin(); jt != Map.end(); ++jt)
//        {
//            if (jt->first == "Shape" && jt->second->getTypeId().isDerivedFrom(App::PropertyComplexGeoData::getClassTypeId()))
//            {
//                std::vector<Base::Vector3d> aPoints;
//                std::vector<Data::ComplexGeoData::Facet> aTopo;
//                const Data::ComplexGeoData* data = static_cast<App::PropertyComplexGeoData*>(jt->second)->getComplexData();
//                if (data)
//                {
//                    data->getFaces(aPoints, aTopo, 0.1); // QObject::tr("Enter tolerance for meshing geometry:"), 0.1, 0.01,10.0,2,&ok);
//                    //mesh.setFacets(aTopo, aPoints);
//                    fclwrapper::FclSceneObject sobj;
//                    sobj.name = this->name;
//                    for (auto point : aPoints)
//                        sobj.vertices.push_back(fcl::Vector3d(point.x, point.y, point.z));
//                    for(auto tri : aTopo)
//                        sobj.triangles.push_back(fcl::Triangle(tri.I1, tri.I2, tri.I3));
//                    sceneObjects.push_back(sobj);
//                }
//            }
//        }
//    }
}

void CollisionObject::getShapes()
{
    if (!partObj)
        return;

    SoSearchAction searchAction;
    SoPath* path;
    searchAction.setType(SoShape::getClassTypeId(), TRUE);
    searchAction.setInterest(SoSearchAction::ALL);
    searchAction.setSearchingAll(false);

    searchAction.apply((SoNode*)partObj->getRoot());
    SoPathList pathList = searchAction.getPaths();
    // Base::Console().Message("Enter here, the length of the pathlist is %d\n",pathList.getLength());
    for (int i = 0; i < pathList.getLength(); i++)
    {
        path = pathList[i];
        SoNode* node = path->getTail();
        // Base::Console().Message("the type of the node is %s\n",node->getTypeId().getName().getString());
        std::string str1 ("SoBrepFaceSet");
        std::string str2 ("SoBrepPointSet");
        std::string str3 ("SoBrepEdgeSet");
        if (str1.compare(node->getTypeId().getName().getString()) == 0)
        {
            SoBrepFaceSet* shape = static_cast<SoBrepFaceSet *>(node);
            // Base::Console().Message("the name of the object is %s\n",name.c_str());
            SbName sname(name.c_str());
            shape->setName(sname);
            shapes.push_back(shape);
        }
        if (str2.compare(node->getTypeId().getName().getString()) == 0)
        {
            SoBrepPointSet* shape = static_cast<SoBrepPointSet *>(node);
            // Base::Console().Message("the name of the object is %s\n",name.c_str());
            SbName sname(name.c_str());
            shape->setName(sname);
            // shapes.push_back(shape);
        }
        if (str3.compare(node->getTypeId().getName().getString()) == 0)
        {
            SoBrepEdgeSet* shape = static_cast<SoBrepEdgeSet *>(node);
            // Base::Console().Message("the name of the object is %s\n",name.c_str());
            SbName sname(name.c_str());
            shape->setName(sname);
            // shapes.push_back(shape);
        }
    }
}

RobotCollisionObj::RobotCollisionObj(ViewProvider* vp)
{
    // acm
    if (!vp || vp->getTypeId() != ViewProviderRobotObject::getClassTypeId())
        return;

    this->vp = vp;
    robObj = (ViewProviderRobotObject*)(vp);
    name = static_cast<const char*>(robObj->getObject()->getNameInDocument());


    WirCore::RobotObject* robObj1 = dynamic_cast<WirCore::RobotObject*>(robObj->getObject());
    std::vector<App::DocumentObject*> partGroup = robObj1->LinkList.getValues();
    std::vector<std::string> entry_names;
    for (auto part : partGroup)
        entry_names.push_back(part->Label.getValue());

    if(robObj1)
    {
        for (auto obj : robObj1->LinkList.getValues())
        {
            auto document = Gui::Application::Instance->activeDocument();
            auto vp = document->getViewProvider(obj);
            if (vp)
            {
                getShape(vp, obj->Label.getValue());
            }
        }
    }




    createDefaultACM(entry_names);
}

void RobotCollisionObj::createDefaultACM(std::vector<std::string>& entry_names)
{
    acm.setEntryNames(entry_names);
    for (int i = 0;i < entry_names.size(); i++)
    {
        for (int j = i; j < entry_names.size(); j++)
        {
            if (i == j || j == i+1)
                acm.setEntry(j,i,1);
            else
                acm.setEntry(j,i,0);
        }
    }
}

void RobotCollisionObj::getShape(std::string TName,std::vector<SoVRMLShape*>& shapes,std::string name)
{
    if (!robObj)
        return;

    //    SoSearchAction searchAction;
    //    SoPath * path;
    //    SoPathList* pathList;
    //    SbName TransformName(TName.c_str());
    //    searchAction.setName(TransformName);
    //    searchAction.setInterest(SoSearchAction::FIRST);
    //    searchAction.setSearchingAll(false);
    //    searchAction.apply((SoNode*)robObj->getRoot());
    //    path = searchAction.getPath();
    //    if (path)
    //    {
    //        SoNode* fNode = path->getTail();
    //        // Base::Console().Warning("The type of the father is '%s' \n",(const char*)fNode->getTypeId().getName());
    //        searchAction.reset();
    //        searchAction.setInterest(SoSearchAction::ALL);
    //        searchAction.setType(SoVRMLShape::getClassTypeId(),FALSE);
    //        searchAction.setSearchingAll(false);
    //        searchAction.apply(fNode);
    //        pathList = &searchAction.getPaths();
    //        for (int i = 0; i < pathList->getLength(); i++)
    //        {
    //            path = (*pathList)[i];
    //            SoNode* node = path->getTail();
    //            if (node->getTypeId() == SoVRMLShape::getClassTypeId())
    //            {
    //                // Base::Console().Warning("SoVRMLIndexedFaceSet found\n");
    //                SoVRMLShape* shape = static_cast<SoVRMLShape *>(node);
    //                SbName sname(name.c_str());
    //                shape->setName(sname);
    //                shapes.push_back(static_cast<SoVRMLShape *>(node));
    //            }
    //        }
    //    }
}

void RobotCollisionObj::buildFclSceneObjects()
{
//    if (robObj)
//    {
//        WirCore::RobotObject* robObj1 = dynamic_cast<WirCore::RobotObject*>(robObj->getObject());
//        for (auto obj : robObj1->LinkList.getValues())
//        {
//            Mesh::Feature* mesh = dynamic_cast<Mesh::Feature*>(obj);
//            if (mesh)
//            {
//                std::vector<Base::Vector3d> aPoints;
//                std::vector<Data::ComplexGeoData::Facet> aTopo;
//                const Data::ComplexGeoData* data = mesh->getPropertyOfGeometry()->getComplexData();
//                if (data)
//                {
//                    data->getFaces(aPoints, aTopo, 0.1); // QObject::tr("Enter tolerance for meshing geometry:"), 0.1, 0.01,10.0,2,&ok);
//                    //mesh.setFacets(aTopo, aPoints);
//                    fclwrapper::FclSceneObject sobj;
//                    sobj.name = this->name;
//                    for (auto point : aPoints)
//                        sobj.vertices.push_back(fcl::Vector3d(point.x, point.y, point.z));
//                    for(auto tri : aTopo)
//                        sobj.triangles.push_back(fcl::Triangle(tri.I1, tri.I2, tri.I3));
//                    sceneObjects.push_back(sobj);
//                }
//            }
//        }
//    }
}

void RobotCollisionObj::getShape(Gui::ViewProvider* vp, std::string name)
{
    if (!vp) return;

    SoSearchAction searchAction;
    SoPath* path;
    searchAction.setType(SoShape::getClassTypeId(), TRUE);
    searchAction.setInterest(SoSearchAction::ALL);
    searchAction.setSearchingAll(false);

    //WirCore::RobotObject* robObj1 = dynamic_cast<WirCore::RobotObject*>(robObj->getObject());
    //std::vector<App::DocumentObject*> partGroup = robObj1->LinkList.getValues();
    //for (int i = 0; i < partGroup.)
    searchAction.apply((SoNode*)vp->getRoot());
    SoPathList pathList = searchAction.getPaths();
    // Base::Console().Message("Enter here, the length of the pathlist is %d\n",pathList.getLength());
    for (int i = 0; i < pathList.getLength(); i++)
    {
        path = pathList[i];
        SoNode* node = path->getTail();
        // Base::Console().Message("the type of the node is %s\n",node->getTypeId().getName().getString());
        std::string str1 ("SoFCIndexedFaceSet");
        std::string str2 ("SoBrepPointSet");
        std::string str3 ("SoBrepEdgeSet");
        if (str1.compare(node->getTypeId().getName().getString()) == 0)
        {
            //SoFCIndexedFaceSet* shape = static_cast<SoFCIndexedFaceSet *>(node);
            // Base::Console().Message("the name of the object is %s\n",name.c_str());
            SbName sname(name.c_str());
            node->setName(sname);
            //shapes.push_back(shape);
        }
        //        if (str2.compare(node->getTypeId().getName().getString()) == 0)
        //        {
        //            SoBrepPointSet* shape = static_cast<SoBrepPointSet *>(node);
        //            // Base::Console().Message("the name of the object is %s\n",name.c_str());
        //            SbName sname(name.c_str());
        //            shape->setName(sname);
        //            // shapes.push_back(shape);
        //        }
        //        if (str3.compare(node->getTypeId().getName().getString()) == 0)
        //        {
        //            SoBrepEdgeSet* shape = static_cast<SoBrepEdgeSet *>(node);
        //            // Base::Console().Message("the name of the object is %s\n",name.c_str());
        //            SbName sname(name.c_str());
        //            shape->setName(sname);
        //            // shapes.push_back(shape);
        //        }
    }

}

SbBool RobotCollisionObj::intersectionFilter(void *userData, const SoPath *p1, const SoPath *p2)
{
    RobotCollisionObj* data;
    if (userData != NULL)
        data=(RobotCollisionObj*)userData;
    SoNode* node1 = p1->getTail();
    SoNode* node2 = p2->getTail();
    int bAllowed = data->acm.getEntry(node1->getName().getString(), node2->getName().getString());
    // Base::Console().Message("the status of the acm is %d, name 1 is %s, name 2 is %s \n",
    //                        bAllowed,node1->getName().getString(),node2->getName().getString());
    return (bAllowed==1) ? FALSE : TRUE;
}

SoIntersectionDetectionAction::Resp
RobotCollisionObj::onIntersection(void *userData,
                                  const SoIntersectingPrimitive *primitive1,
                                  const SoIntersectingPrimitive *primitive2)
{
    RobotCollisionObj* data;
    if (userData != NULL)
        data = (RobotCollisionObj*) userData;
    Base::Console().Message("RobotCollisionObj self collision check: Collision %d: %s (%s) *** %s (%s)\n",
                            //           RobotCollisionObj::intersectionCount,
                            data->intersectionCount,
                            (char *)primitive1->path->getTail()->getName().getString(),
                            (char *)primitive1->path->getTail()->getTypeId().getName().getString(),
                            (char *)primitive2->path->getTail()->getName().getString(),
                            (char *)primitive2->path->getTail()->getTypeId().getName().getString());

    //    RobotCollisionObj::intersectionCount++;

    // This callback will be called for the two next colliding shapes
    return SoIntersectionDetectionAction::NEXT_SHAPE;
}

bool RobotCollisionObj::selfCollisionCheck()
{
    if (!robObj)
        return false;
    intersectionCount = 1;
    SoIntersectionDetectionAction action;
    action.setFilterCallback(RobotCollisionObj::intersectionFilter,this);
    action.addIntersectionCallback(RobotCollisionObj::onIntersection,this);
    action.apply((SoNode*)robObj->getRoot()/*>getRobotRoot()*/);
    //    Base::Console().Message("Create the Scene Found");
}

