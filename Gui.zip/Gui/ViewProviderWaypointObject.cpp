#include "PreCompiled.h"

#ifndef _PreComp_
#include <QMenu>
#include <QAction>
#include <QActionGroup>
#include <QObject>
#endif

#include <Gui/ActionFunction.h>

#include <App/Document.h>
#include "ViewProviderWaypointObject.h"
#include <Mod/WirCore/App/WaypointObject.h>
#include "DlgLinkConfig.h"



using namespace Gui;
using namespace WirCoreGui;


PROPERTY_SOURCE(WirCoreGui::ViewProviderWaypointObject, Gui::ViewProviderDocumentObject)

ViewProviderWaypointObject::ViewProviderWaypointObject()
{
    sPixmap = "WirCore_WaypointObject";

    refWaypointRoot = new Gui::SoFCSelection();
    refWaypointRoot->ref();

}


ViewProviderWaypointObject::~ViewProviderWaypointObject()
{
    refWaypointRoot->unref();
}


void ViewProviderWaypointObject::attach(App::DocumentObject *pcObj)
{
    Gui::ViewProviderDocumentObject::attach(pcObj);

    addDisplayMaskMode(refWaypointRoot, "WaypointObject");
    refWaypointRoot->objectName = pcObj->getNameInDocument();
    refWaypointRoot->subElementName = "Main";

}

void ViewProviderWaypointObject::setDisplayMode(const char *ModeName)
{
    if(strcmp("WaypointObject", ModeName) == 0)
        setDisplayMaskMode("WaypointObject");
    Gui::ViewProviderDocumentObject::setDisplayMode(ModeName);
}

std::vector<std::string> ViewProviderWaypointObject::getDisplayModes(void) const
{
    std::vector<std::string> StrList;
    StrList.push_back("WaypointObject");
    return StrList;
}

void ViewProviderWaypointObject::updateData(const App::Property *prop)
{
    auto pcWayPointObj = static_cast<WirCore::WaypointObject*>(pcObject);

    if(prop == &pcWayPointObj->waypointType) {
        auto _obj = pcWayPointObj->linkPoint.getValue();
        if (_obj == nullptr)
        {
            return;
        }
        std::string n = pcWayPointObj->linkPoint.getValue()->Label.getValue();
        std::string t_str = pcWayPointObj->waypointType.getValueAsString();
        t_str += "_" + n + "_";
        pcWayPointObj->Label.setValue(t_str);

    }
}

void ViewProviderWaypointObject::SetRobotConfig()
{
    auto pcWayPointObj = static_cast<WirCore::WaypointObject*>(pcObject);
    std::vector<bool> _LinkConfig;
    _LinkConfig.push_back(pcWayPointObj->ConfigFront.getValue());
    _LinkConfig.push_back(pcWayPointObj->ConfigUp.getValue());
    _LinkConfig.push_back(pcWayPointObj->ConfigFlip.getValue());

    WirCoreGui::DlgLinkConfig dlg(_LinkConfig);

    if (dlg.exec() == QDialog::Accepted)
    {
       pcWayPointObj->setLinkConfig(dlg.getLinkConfig());
    }
}

void ViewProviderWaypointObject::setupContextMenu(QMenu* menu, QObject* receiver, const char* member)
{
    Gui::ActionFunction* func = new Gui::ActionFunction(menu);
    QAction* act = menu->addAction(QObject::tr("Set Robot Config"), receiver, member);

    func->trigger(act, boost::bind(&ViewProviderWaypointObject::SetRobotConfig, this));

    ViewProviderDocumentObject::setupContextMenu(menu, receiver, member); // need this(has Position)
}


bool ViewProviderWaypointObject::canDropObjects() const
{
     return true;
}


bool ViewProviderWaypointObject::canDropObject(App::DocumentObject* obj) const
{
    if (obj->isDerivedFrom(WirCore::TrajectoryOperationObject::getClassTypeId()))
    {
        return true;
    }

    return false;
}

bool ViewProviderWaypointObject::canDragObjects() const
{
     return true;
}


void ViewProviderWaypointObject::dropObject(App::DocumentObject* obj)
{
    //删除原位置结点
    WirCore::TrajectoryObject* src_TrajectoryObject = findTrajtoryContainPoint(obj);
    std::vector<App::DocumentObject*> src_pointGroup = src_TrajectoryObject->WayPointList.getValues();
    std::vector<App::DocumentObject*>::iterator
                   result = find(src_pointGroup.begin( ), src_pointGroup.end( ), obj);
    src_pointGroup.erase(result);
    src_TrajectoryObject->WayPointList.setValues(src_pointGroup);

    //找到要插入的位置
    WirCore::TrajectoryObject* fix_TrajectoryObject = findTrajtoryContainPoint(this->pcObject);
    std::vector<App::DocumentObject*> fix_pointGroup = fix_TrajectoryObject->WayPointList.getValues();
    result = find(fix_pointGroup.begin( ), fix_pointGroup.end( ), this->pcObject);
    fix_pointGroup.insert(result, obj);
    fix_TrajectoryObject->WayPointList.setValues(fix_pointGroup);
}



WirCore::TrajectoryObject* ViewProviderWaypointObject::findTrajtoryContainPoint(App::DocumentObject* obj)
{
    std::vector<App::DocumentObject*> t_vec = obj->getInList();
    WirCore::TrajectoryObject* src_Trajectory;
    for (std::vector<App::DocumentObject*>::iterator it = t_vec.begin();it != t_vec.end(); ++it)
    {
        if ((*it)->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
        {
            src_Trajectory = dynamic_cast<WirCore::TrajectoryObject*>(*it);
            break;
        }
    }

    return  src_Trajectory;
}





















