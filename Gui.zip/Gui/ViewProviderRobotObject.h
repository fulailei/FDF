/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#ifndef WIRCORE_VIEWPROVIDERROBOTOBJECT_H
#define WIRCORE_VIEWPROVIDERROBOTOBJECT_H

#include <Inventor/VRMLnodes/SoVRMLTransform.h>
#include <Gui/ViewProviderGeometryObject.h>
#include <Gui/ViewProviderOriginGroup.h>

#include <Gui/SoFCSelection.h>
#include <Base/Placement.h>
#include <QMenu>
#include <Gui/Command.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/TopoShape.h>

#include <Mod/Mesh/App/Mesh.h>
#include <Mod/Mesh/App/MeshFeature.h>
#include <XCAFDoc_ColorTool.hxx>


class SoFCCSysDragger;
class Property;

namespace WirCoreGui
{

class ViewProviderRobotObject : public Gui::ViewProviderGeometryObject,
                                public Gui::ViewProviderOriginGroupExtension
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderRobotObject);

public:
    /// constructor.
    ViewProviderRobotObject();

    /// destructor.
    ~ViewProviderRobotObject();

    App::PropertyBool Manipulator;

    bool canDragObjects() const;
    bool canDragObject(App::DocumentObject*) const;
    bool canDropObjects() const;
    bool canDropObject(App::DocumentObject*) const;

    bool extensionOnDelete(const std::vector<std::string> &);

    void updateData(const App::Property*);

    virtual void onChanged(const App::Property* prop);

    void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);

    /// for simulation without changing the document:
    void setAxisTo(float A1,float A2,float A3,float A4,float A5,float A6);
    void SetRobotHome();

    void addTool();
//    std::vector<App::DocumentObject*> claimChildren(void) const;
//    std::vector<App::DocumentObject*> claimChildren3D(void) const;

    static Gui::SoFCCSysDragger* jogLinearDragger;
    bool doubleClicked(void) override;
protected:
    Gui::SoFCSelection    * pcRobotRoot;

    void loadMesh(Mesh::Feature *pcFeature, const char* filename);

private:
    bool setEdit(int ModNum) override;
    void unsetEdit(int ModNum) override;
    bool mouseMove(const SbVec2s &cursorPos, Gui::View3DInventorViewer* viewer) override;
    bool mouseButtonPressed(int button, bool pressed, const SbVec2s &cursorPos,
                            const Gui::View3DInventorViewer* viewer) override;

    static void sDraggerMotionCallback(void *data, SoDragger *dragger);
    void DraggerMotionCallback(SoDragger *dragger);
    void setDragger(void);
    void resetDragger(void);

    void SetRobotConfig();

    bool m_isLeftBtnPressed = false;
    double m_prePressedPos[2] = { 0 };
    //double m_len = 0;
    int axisIndex = 0;
};
}

#endif // WIROLP_VIEWPROVIDERROBOTOBJECT_H
