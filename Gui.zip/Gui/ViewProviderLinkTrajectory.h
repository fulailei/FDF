#ifndef WIRCORE_VIEWPROVIDERLINKTRAJECTORY_H
#define WIRCORE_VIEWPROVIDERLINKTRAJECTORY_H


#include <App/DocumentObject.h>
#include <Gui/ViewProviderDocumentObject.h>
#include <Gui/SoFCSelection.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

namespace WirCoreGui
{

class ViewProviderLinkTrajectory : public Gui::ViewProviderDocumentObject
{
     PROPERTY_HEADER(WirCoreGui::ViewProviderLinkTrajectory);
public:
    ViewProviderLinkTrajectory();
    ~ViewProviderLinkTrajectory();
    void setDisplayMode(const char* ModeName);
    void attach(App::DocumentObject *pcObject);
    std::vector<std::string> getDisplayModes() const;

    bool canDropObjects() const;
    bool canDragObjects() const;
    bool canDropObject(App::DocumentObject* obj) const;
    void dropObject(App::DocumentObject* obj);

    bool showInTree() const
    {
      return false;
    }

protected:
   Gui::SoFCSelection* refLinkTrajectoryRoot;

};

}
#endif // VIEWPROVIDERLINKTRAJECTORY_H
