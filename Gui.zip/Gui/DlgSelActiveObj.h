#ifndef WIRCORE_DIALOG_SELACTIVEOBJ_H
#define WIRCORE_DIALOG_SELACTIVEOBJ_H


#include <QWidget>
#include <QComboBox>

#include <Mod/WirCore/App/WorkStationGroup.h>

namespace WirCoreGui {


class Ui_DlgSelActiveObj;
class DlgSelActiveObj : public QWidget
{
    Q_OBJECT

public:
    DlgSelActiveObj(QWidget *parent = 0);

    ~DlgSelActiveObj();

    void UpdateStationCombo();
    void UpdateStationCombo(WirCore::WorkStationGroup* obj);

protected:
    void changeEvent(QEvent *e) override;

    Ui_DlgSelActiveObj* ui;

protected Q_SLOTS:
    void onChangeActiveStation(int Value);
    void onChangeActiveWobj(int Value);
    void onChangeActiveTool(int Value);

};

}


#endif // WIRCORE_DIALOG_SELACTIVEOBJ_H
