#include "PreCompiled.h"
#ifndef _PreComp_
# include <BRepAdaptor_Curve.hxx>
# include <BRepAdaptor_Surface.hxx>
# include <GeomAbs_CurveType.hxx>
# include <GeomAbs_SurfaceType.hxx>
# include <Geom_BezierCurve.hxx>
# include <Geom_BSplineCurve.hxx>
# include <Geom_BezierSurface.hxx>
# include <Geom_BSplineSurface.hxx>
# include <gp_Pnt.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Edge.hxx>
# include <TopoDS_Wire.hxx>
# include <TopoDS_Face.hxx>
# include <TopoDS_Shape.hxx>
# include <TopoDS_Shell.hxx>
# include <TopExp_Explorer.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Python.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/nodes/SoSwitch.h>
# include <QAction>
# include <QMenu>
# include <Inventor/SoDB.h>
# include <Inventor/SoInput.h>
# include <Inventor/SbVec3f.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/nodes/SoTransform.h>
# include <Inventor/nodes/SoSphere.h>
# include <Inventor/nodes/SoRotation.h>
# include <Inventor/actions/SoSearchAction.h>
# include <Inventor/draggers/SoJackDragger.h>
# include <Inventor/VRMLnodes/SoVRMLTransform.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoMarkerSet.h>
# include <Inventor/nodes/SoShapeHints.h>
# include <QFile>
# include <QAction>
# include <QMenu>
#endif

#include <boost/bind.hpp>
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>
#include "Mod/Part/Gui/SoFCShapeObject.h"
#include "ViewProviderGeometryObject.h"


using namespace WirCoreGui;
using namespace PartGui;
using namespace Gui;

PROPERTY_SOURCE(WirCoreGui::ViewProviderGeometryObject, PartGui::ViewProviderPartExt)

WirCoreGui::ViewProviderGeometryObject::ViewProviderGeometryObject()
{
}

WirCoreGui::ViewProviderGeometryObject::~ViewProviderGeometryObject()
{
}

//namespace WirCoreGui
//{
//class ProjectCurve1 : public Part::Feature
//{
//public:
//    ProjectCurve1()
//    {
//        const std::vector<gp_Pnt> p{gp_Pnt(0,0,0), gp_Pnt(5,5,0), gp_Pnt(10,0,0), gp_Pnt(15,5,0), gp_Pnt(20,0,0)};
//        const std::vector<gp_Vec> t{gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0)};
//        spline = new Part::GeomBSplineCurve;
//        spline->interpolate(p,t);
//        this->Shape.setValue(spline->toShape());
//    }

//    ~ProjectCurve1()
//    {
//        if (spline)
//        {
//            delete spline;
//            spline = nullptr;
//        }
//    }

//    /// returns the type name of the ViewProvider
//    const char* getViewProviderName(void) const
//    {
//        return "WirCoreGui::ViewProviderProjectCurve";
//    }

//private:
//    //Part::PropertyPartShape Shape;
//    Part::GeomBSplineCurve* spline;
//};

//class ViewProviderProjectCurve1 : public PartGui::ViewProviderPartExt
//{
//public:
//    ViewProviderProjectCurve1()
//    {
//    }
//    ~ViewProviderProjectCurve1()
//    {
//    }
//};
