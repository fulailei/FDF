#ifndef WIRCORE_VIEWPROVIDERWORKSTATIONGROUP_H
#define WIRCORE_VIEWPROVIDERWORKSTATIONGROUP_H

#include <App/DocumentObject.h>
#include <Gui/ViewProviderDocumentObjectGroup.h>

namespace WirCoreGui
{


class ViewProviderWorkStationGroup : public Gui::ViewProviderDocumentObjectGroup
{

    PROPERTY_HEADER_WITH_EXTENSIONS(WirCoreGui::ViewProviderWorkStationGroup);
public:
    ViewProviderWorkStationGroup();
     ~ViewProviderWorkStationGroup();

    void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);

    void SetActiveTool();
    void SetActiveWobj();
    void UpdateActiveView();

    std::vector<App::DocumentObject*> claimChildren(void) const;
    void updateData(const App::Property*);

    bool showInTree() const
    {
      return false;
    }
};

}

#endif // VIEWPROVIDERWORKSTATIONGROUP_H
