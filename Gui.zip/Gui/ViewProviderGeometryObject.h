#ifndef WIRCOREGUI_VIEWPROVIDERGEOMETRYOBJECT_H
#define WIRCOREGUI_VIEWPROVIDERGEOMETRYOBJECT_H

#include "Mod/Part/Gui/ViewProviderExt.h"
#include <Gui/SoFCSelection.h>

class SoCoordinate3;
class SoDrawStyle;
class SoLineSet;

namespace WirCoreGui
{


class ViewProviderGeometryObject : public PartGui::ViewProviderPartExt
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderGeometryObject);

public:
    /// constructor
    ViewProviderGeometryObject();
    /// destructor
    virtual ~ViewProviderGeometryObject();
};

//class ViewProviderProjectCurve1;
//class ProjectCurve1;

//class ViewProviderGeometry : public PartGui::ViewProviderPartExt
//{
//    PROPERTY_HEADER(WirCoreGui::ViewProviderGeometry);

//public:
//    /// constructor
//    ViewProviderGeometry();
//    /// destructor
//    virtual ~ViewProviderGeometry();

//    // Display properties
//    App::PropertyBool ControlPoints;

//    //void updateData(const App::Property* prop);
//    void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);

//protected:
//    void onChanged(const App::Property* prop);
//    void toggleControlPoints(bool);
//    void showControlPoints(bool, const App::Property* prop);
//    void showControlPointsOfEdge(const TopoDS_Edge&);
//    void showControlPointsOfFace(const TopoDS_Face&);
//    void showProjectLine();

//    SoSwitch     *pcControlPoints;

//    Gui::SoFCSelection    * pcTrajectoryRoot;
//    SoCoordinate3         * pcCoords;
//    SoDrawStyle           * pcDrawStyle;
//    SoLineSet             * pcLines;
//    ViewProviderProjectCurve1* vp;
//    ProjectCurve1* spline;
//};

} //namespace WirCoreGui


#endif // WIRCOREGUI_VIEWPROVIDERPARTSPLINE_H

