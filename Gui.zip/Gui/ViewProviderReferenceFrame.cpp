#include "PreCompiled.h"

#ifndef _PreComp_
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoGroup.h>

#endif

#include "ViewProviderReferenceFrame.h"
#include <Mod/WirCore/App/ReferenceFrame.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <QAction>
#include <Gui/SoFCBoundingBox.h>
#include <App/Document.h>

using namespace Gui;
using namespace WirCoreGui;

PROPERTY_SOURCE(WirCoreGui::ViewProviderReferenceFrame, Gui::ViewProviderGeometryObject)

double ViewProviderReferenceFrame::s_scaleFactor = 1.0;
ViewProviderReferenceFrame::ViewProviderReferenceFrame()
{
    sPixmap = "WirCore_CreateReferenceFrame";

    refFrameRoot = new Gui::SoFCSelection();
    refFrameRoot->ref();

    axisCross = new Gui::SoShapeScale();
    axisCross->ref();

    axisGroup = new Gui::SoSkipBoundingGroup;
    axisGroup->ref();

    axisTrans = new SoTransform();
    axisTrans->ref();

    Gui::SoAxisCrossKit* axisKit = new Gui::SoAxisCrossKit();
    axisKit->set("xAxis.appearance.drawStyle", "lineWidth 2");
    axisKit->set("yAxis.appearance.drawStyle", "lineWidth 2");
    axisKit->set("zAxis.appearance.drawStyle", "lineWidth 2");
    axisCross->setPart("shape", axisKit);
    axisCross->scaleFactor = s_scaleFactor/*1.0f*/;

    axisGroup->addChild(axisTrans);
    axisGroup->addChild(axisCross);
    refFrameRoot->addChild(axisGroup);
}

ViewProviderReferenceFrame::~ViewProviderReferenceFrame()
{
    if(refFrameRoot) refFrameRoot->unref();
    if(axisGroup) axisGroup->unref();
    if(axisCross) axisCross->unref();
    if(axisTrans) axisTrans->unref();
}

void ViewProviderReferenceFrame::attach(App::DocumentObject *pcObj)
{
    WirCore::ReferenceFrame* refFrame = static_cast<WirCore::ReferenceFrame*>(pcObj);
    Gui::ViewProviderGeometryObject::attach(pcObj);

    /*
    SbMatrix mat;
    Base::Placement p = refFrame->Placement.getValue();
    mat.setTransform(SbVec3f(p.getPosition().x,p.getPosition().y,p.getPosition().z),
                   SbRotation(p.getRotation()[0],p.getRotation()[1],p.getRotation()[2],p.getRotation()[3]),
                   SbVec3f(1.0,1.0,1.0)
                   );
    axisTrans->setMatrix(mat);
    */
    addDisplayMaskMode(refFrameRoot, "ReferenceFrame");
    refFrameRoot->objectName = pcObj->getNameInDocument();
    refFrameRoot->documentName = pcObj->getDocument()->getName();
    refFrameRoot->subElementName = "Main";
}

void ViewProviderReferenceFrame::setupContextMenu(QMenu* menu, QObject* receiver, const char* member)
{
//    //QAction* act = menu->addAction(QObject::tr("Transform"), receiver, member);
//    //act->setData(QVariant((int)ViewProvider::Transform));
//    QAction* act = menu->addAction(QObject::tr("RF Visible"), receiver, member);
//    act->setData(QVariant((int)ViewProvider::Transform));
}


void ViewProviderReferenceFrame::setDisplayMode(const char *ModeName)
{
    if(strcmp("ReferenceFrame", ModeName) == 0)
        setDisplayMaskMode("ReferenceFrame");
    Gui::ViewProviderGeometryObject::setDisplayMode(ModeName);
}

std::vector<std::string> ViewProviderReferenceFrame::getDisplayModes(void) const
{
    std::vector<std::string> StrList;
    StrList.push_back("ReferenceFrame");
    return StrList;
}

void ViewProviderReferenceFrame::updateData(const App::Property *prop)
{
    axisCross->scaleFactor = s_scaleFactor/*1.0f*/;

    WirCore::ReferenceFrame* pcRefObj = static_cast<WirCore::ReferenceFrame*>(pcObject);
    auto updateObjectPlacement = [&](){
        const std::vector<App::DocumentObject*>& objs = pcRefObj->Objects.getValues();
        for(auto obj : objs){
            if(obj && obj->isDerivedFrom(App::GeoFeature::getClassTypeId())) {
                App::GeoFeature* geo = static_cast<App::GeoFeature*>(obj);
                geo->Placement.setValue(pcRefObj->Placement.getValue());
            }
        }
        /*
        App::DocumentObject* docObj = pcRefObj->Object.getValue();
        if(docObj && docObj->isDerivedFrom(App::GeoFeature::getClassTypeId())){
            App::GeoFeature* geo = static_cast<App::GeoFeature*>(docObj);
            geo->Placement.setValue(pcRefObj->Frame.getValue());
        }*/
    };

    if(prop == &pcRefObj->Placement) {
        /*
        SbMatrix mat;
        //setTransformation(pcRefObj->Placement.getValue().toMatrix());

        Base::Placement p = pcRefObj->Placement.getValue();

        //p = p * Base::Placement();

        mat.setTransform(SbVec3f(p.getPosition().x,p.getPosition().y,p.getPosition().z),
                       SbRotation(p.getRotation()[0],p.getRotation()[1],p.getRotation()[2],p.getRotation()[3]),
                       SbVec3f(1.0,1.0,1.0)
                       );

        axisTrans->setMatrix(mat);
        */
        updateObjectPlacement();
    }
    else if(prop == &pcRefObj->Objects) {
        updateObjectPlacement();
    }
    ViewProviderGeometryObject::updateData(prop);
}


void ViewProviderReferenceFrame::onChanged(const App::Property *prop)
{
    ViewProviderGeometryObject::onChanged(prop);
}

std::vector<App::DocumentObject*> ViewProviderReferenceFrame::claimChildren(void) const {
    //return static_cast<WirOlp::ReferenceFrame*>(getObject())->getObjects();

    WirCore::ReferenceFrame* rfObj = static_cast<WirCore::ReferenceFrame*>(pcObject);
    std::vector<App::DocumentObject*> result;
    auto& objs = rfObj->Objects.getValues();
    result.insert(result.end(), objs.begin(), objs.end());
    return result;


    //App::DocumentObject* o = rfObj->Object.getValue<App::DocumentObject*>();
    //std::vector<App::DocumentObject*> children;
    //children.push_back(static_cast<WirOlp::RobotObject*>(o));
    //return children;
}



