#include "PreCompiled.h"
#ifndef _PreComp_
#include <BRep_Builder.hxx>
#include <gp_Pln.hxx>
#include <TopoDS.hxx>
#include <TopExp.hxx>
#include <TopoDS_Edge.hxx>

#include <Inventor/nodes/SoBaseColor.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoDrawStyle.h>
#include <Inventor/nodes/SoLineSet.h>
#include <Inventor/nodes/SoSeparator.h>
#endif
#include "TaskMachiningOperations.h"
//#include "ui_TaskMachiningOperations.h"
#include <Mod/Part/App/TopoShape.h>
#include <Gui/BitmapFactory.h>
#include <App/Application.h>
#include <App/Document.h>
#include <Mod/WirCore/App/GeometryObject.h>
#include <Mod/Part/App/TopoShape.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <QMessageBox>
#include "ViewProviderGeometryObject.h"
#include <Mod/WirCore/App/WorkStationGroup.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/ActiveStationObject.h>

namespace WirCoreGui
{
/*
class ViewProviderCutterAxisPreview : public WirCoreGui::ViewProviderGeometryObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderCutterAxisPreview);
public:
    ViewProviderCutterAxisPreview()
    {
        /*
        wpts = new SoCoordinate3();
        wpts->ref();
        lines = new SoLineSet();
        lines->ref();
        SoBaseColor* color = new SoBaseColor();
        color->rgb.setValue(1.0f, 0.447059f, 0.337255f);
        SoDrawStyle* style = new SoDrawStyle();
        style->lineWidth.setValue(2.0f);

        this->pcRoot->addChild(color);
        this->pcRoot->addChild(style);
        this->pcRoot->addChild(wpts);
        this->pcRoot->addChild(lines);
        *//*
    }
    ~ViewProviderCutterAxisPreview()
    {
        //wpts->unref();
        //lines->unref();
    }
    //void updateData(const App::Property*){}

    /*const char* getDefaultDisplayMode() const
    {
        return "";
    }

    std::vector<std::string> getDisplayModes() const
    {
        return std::vector<std::string>();
    }*/
/*
    void setPathPoints(const std::vector<Base::Placement>& pts) {
        wpts->point.setNum(pts.size());
        SbVec3f* p = wpts->point.startEditing();
        for(unsigned int i = 0; i < pts.size(); i++) {
            const Base::Vector3d& pt = pts[i].getPosition();
            Base::Rotation rot(pts[i].getRotation());
            Base::Vector3d axis;
            double angle;
            rot.getValue(axis, angle);

            gp_Pnt pnt(pt.x, pt.y, pt.z);
            pnt.Rotate(gp_Ax1(gp_Pnt(), gp_Dir(axis.x, axis.y, axis.z)), angle);
            p[i].setValue(pnt.X(), pnt.Y(), pnt.Z());
        }
        wpts->point.finishEditing();
        unsigned int count = pts.size()/5;
        lines->numVertices.setNum(count);
        int32_t* l = lines->numVertices.startEditing();
        for(unsigned int i = 0; i < count; i++) {
            l[i] = pts.size();
        }
        lines->numVertices.finishEditing();
    }

private:
    SoCoordinate3* wpts;
    SoLineSet* lines;
};*/
WgtMachiningOperations::WgtMachiningOperations(QWidget* parent) :
    QWidget(parent)
{
    ui_ = new Ui_WgtMachiningOperations();
    ui_->setupUi(this);

    //display all geometry objects
    App::Document* doc = App::GetApplication().getActiveDocument();
    std::vector<WirCore::GeometryObject*> gobjs = doc->getObjectsOfType<WirCore::GeometryObject>();
    for(auto gobj : gobjs) {
        std::string name = gobj->getNameInDocument();
        ui_->geometry_combobox->addItem(QString::fromStdString(name));
    }

    //vp_cutter_axis_preview_ = new ViewProviderCutterAxisPreview();
    Gui::Document* gui_doc = Gui::Application::Instance->activeDocument();
    view_ = qobject_cast<Gui::View3DInventor*>(gui_doc->getActiveView());
    //if(view_) {
    //    view_->getViewer()->addViewProvider(vp_cutter_axis_preview_);
    //}

    vp_geometry_object_ = new ViewProviderGeometryObject();
    App::Color c(1.0, 0.0, 0.0);
    vp_geometry_object_->LineColor.setValue(c);
    vp_geometry_object_->ShapeColor.setValue(c);
    vp_geometry_object_->LineWidth.setValue(100);


    geometry_object_ = new WirCore::GeometryObject();

    vp_geometry_object_->attach(geometry_object_);
    if(view_) {
        view_->getViewer()->addViewProvider(vp_geometry_object_);
    }



    //connect(ui_->cutter_axis_button, SIGNAL(clicked()), this, SLOT(on_cutter_axis_button_clicked()));

    /*
    //display all robot objects
    std::vector<WirCore::RobotObject*> robjs = doc->getObjectsOfType<WirCore::RobotObject>();
    //retrieve all the robot in workstation and add to combobox
    for(auto robj : robjs) {
        std::string name = robj->getNameInDocument();
        ui->robotCombo->addItem(QString::fromStdString(name));
    }

    //display all trajectories
    std::vector<WirCore::TrajectoryObject*> trajs = doc->getObjectsOfType<WirCore::TrajectoryObject>();
    for(auto traj : trajs) {
        std::string name = traj->getNameInDocument();
        ui->trajCombo->addItem(QString::fromStdString(name));
    }
    */
    //ui_->stackedWidget->show();

    //TODO: connect signal slot here
}

WgtMachiningOperations::~WgtMachiningOperations()
{
    delete ui_;
    if(view_) {
        //view_->getViewer()->removeViewProvider(vp_cutter_axis_preview_);
        view_->getViewer()->removeViewProvider(vp_geometry_object_);
    }
    //delete vp_cutter_axis_preview_;
    delete vp_geometry_object_;
}

#define OPERATION_PAGE_INDEX 0
#define PROCESSING_ROUTE_SETTINGS_PAGE_INDEX 1
#define NON_PROCESSING_ROUTE_SETTINGS_PAGE_INDEX 2
#define CUTTER_AXIS_SETTINGS_PAGE_INDEX 3

void WgtMachiningOperations::on_cutter_axis_button_clicked()
{
    ui_->stackedWidget->setCurrentIndex(CUTTER_AXIS_SETTINGS_PAGE_INDEX);
}

void WgtMachiningOperations::on_processing_path_settings_button_clicked() {
    ui_->stackedWidget->setCurrentIndex(PROCESSING_ROUTE_SETTINGS_PAGE_INDEX);
}
void WgtMachiningOperations::on_non_processing_path_settings_button_clicked() {
    ui_->stackedWidget->setCurrentIndex(NON_PROCESSING_ROUTE_SETTINGS_PAGE_INDEX);
}

void WgtMachiningOperations::changeEvent(QEvent *e)
{
    if(e->type() == QEvent::LanguageChange) {
        ui_->retranslateUi(this);
    }
    else {
        QWidget::changeEvent(e);
    }
}

void WgtMachiningOperations::open()
{
}

bool WgtMachiningOperations::accept()
{
    QMessageBox::warning(this, tr("Test"), tr("Ok clicked"));
    int page_idx = ui_->stackedWidget->currentIndex();
    switch(page_idx){
    case OPERATION_PAGE_INDEX:
        //TODO: apply changes
        break;
    case PROCESSING_ROUTE_SETTINGS_PAGE_INDEX:
        //TODO: apply changes
        ui_->stackedWidget->setCurrentIndex(OPERATION_PAGE_INDEX);
        return false;
    case NON_PROCESSING_ROUTE_SETTINGS_PAGE_INDEX:
        //TODO: apply changes
        ui_->stackedWidget->setCurrentIndex(OPERATION_PAGE_INDEX);
        return false;
    case CUTTER_AXIS_SETTINGS_PAGE_INDEX:
        ui_->stackedWidget->setCurrentIndex(OPERATION_PAGE_INDEX);
        return false;
    default:
        return false;
    }

    return true;
}

bool WgtMachiningOperations::reject()
{
    QMessageBox::warning(this, tr("Test"), tr("Cancel clicked"));
    int page_idx = ui_->stackedWidget->currentIndex();
    switch(page_idx){
    case OPERATION_PAGE_INDEX:
        break;
    case PROCESSING_ROUTE_SETTINGS_PAGE_INDEX:
        ui_->stackedWidget->setCurrentIndex(OPERATION_PAGE_INDEX);
        return false;
    case NON_PROCESSING_ROUTE_SETTINGS_PAGE_INDEX:
        ui_->stackedWidget->setCurrentIndex(OPERATION_PAGE_INDEX);
        return false;
    case CUTTER_AXIS_SETTINGS_PAGE_INDEX:
        ui_->stackedWidget->setCurrentIndex(OPERATION_PAGE_INDEX);
        return false;
    default:
        return false;
    }
    return true;
}
void WgtMachiningOperations::read_parameter()
{
   Unprocess_Path->Get_Approach_Parameter()->Approach_Length=ui_->Approach_Length->text().toDouble();
   Unprocess_Path->Get_Approach_Parameter()->Approach_Rotation_Y=ui_->Approach_rotation_y->text().toDouble();
   Unprocess_Path->Get_Approach_Parameter()->Approach_Rotation_Z=ui_->Approach_rotation_z->text().toDouble();
   Unprocess_Path->Get_Departing_Parameter()->Departing_Length=ui_->Departing_Length->text().toDouble();
   Unprocess_Path->Get_Departing_Parameter()->Departing_Rotation_Y=ui_->Departing_rotation_y->text().toDouble();
   Unprocess_Path->Get_Departing_Parameter()->Departing_Rotation_Z=ui_->Departing_rotation_z->text().toDouble();
   Unprocess_Path->Get_Other_Parameter()->Safe_Height=ui_->Safe_hight->text().toDouble();
   Unprocess_Path->Get_Other_Parameter()->Buffer_Distance=ui_->Buffer_distance->text().toDouble();
   process_path->Get_Parameter()->angle=ui_->process_Max_angle->text().toDouble();
   process_path->Get_Parameter()->length=ui_->process_Max_length->text().toDouble();
   process_path->Get_Parameter()->tolerance=ui_->process_Max_tolerance->text().toDouble();
}
WirCore::TrajectoryObject *WgtMachiningOperations::Get_traj()
{
    return traj;
}
void WgtMachiningOperations::preview()
{
    //QMessageBox::warning(this, tr("Test"), tr("preview clicked"));
    int page_idx = ui_->stackedWidget->currentIndex();
    switch(page_idx)
    {
        case OPERATION_PAGE_INDEX:
        {
            break;
        }
        case PROCESSING_ROUTE_SETTINGS_PAGE_INDEX:
        {        //TODO: implement preview
            break;
        }
        case NON_PROCESSING_ROUTE_SETTINGS_PAGE_INDEX:
        {    //TODO: implement preview
            break;
        }
        case CUTTER_AXIS_SETTINGS_PAGE_INDEX:
            //TODO: implement preview
            //get the angle, get the geometry object, sample the point and display
        {
            QString gobj_name = ui_->geometry_combobox->currentText();
            App::Document* appdoc = App::GetApplication().getActiveDocument();
            App::DocumentObject* appdoc_obj = appdoc->getObject(gobj_name.toLocal8Bit().data());
            if(appdoc_obj) {
                WirCore::GeometryObject* gobj = static_cast<WirCore::GeometryObject*>(appdoc_obj);
                double lrp_angle = ui_->cutter_axis_angle_lrp_dspinbox->value();
                double fbp_angle = ui_->cutter_axis_angle_fbp_dspinbox->value();
                const Part::TopoShape& tp_shape = gobj->Shape.getShape();
                const TopoDS_Shape& tpds_shape = tp_shape.getShape();

                TopTools_IndexedMapOfShape edges;
                TopExp::MapShapes(tpds_shape, TopAbs_EDGE, edges);

                TopoDS_Compound aCompound;
                TopoDS_Builder aBuilder;
                aBuilder.MakeCompound(aCompound);
                for(int i = 1; i <= edges.Extent(); i++) {
                    //const TopoDS_Edge& e = TopoDS::Edge(edges.FindKey(i));
                    aBuilder.Add(aCompound, edges.FindKey(i));
                }

                /*vp_cutter_axis_preview_->attach(gobj);
                vp_cutter_axis_preview_->LineColor.setValue(App::Color(1.0, 0.0, 0.0));
                vp_cutter_axis_preview_->LineWidth.setValue(100);
                vp_cutter_axis_preview_->setActiveMode();
                vp_cutter_axis_preview_->updateView();
                static bool ok = false;
                vp_cutter_axis_preview_->setVisible(ok = !ok);
                */

                //geometry_object_->Shape.setValue((TopoDS_Shape)(aCompound));
                geometry_object_->Shape.setValue(tpds_shape);

                vp_geometry_object_->setActiveMode();
                vp_geometry_object_->updateView();
                static bool ok1 = false;
                vp_geometry_object_->setVisible(ok1 = !ok1);

                //TODO: use geometry to retrieve edges and generate waypoints
            }
            break;
        }
        default:
            break;
    }
    QString gobj_name = ui_->geometry_combobox->currentText();
    App::Document* appdoc = App::GetApplication().getActiveDocument();
    App::DocumentObject* appdoc_obj = appdoc->getObject(gobj_name.toLocal8Bit().data());
    if(appdoc_obj) {
        WirCore::GeometryObject* gobj = static_cast<WirCore::GeometryObject*>(appdoc_obj);
        WirCore::WorkFrameObject* wobj=new WirCore::WorkFrameObject;
        WirCore::ToolObjectReferenceFrame* toolObject=new WirCore::ToolObjectReferenceFrame;
        process_path->Ganerate_Process_Path(gobj,wobj,toolObject);
        traj=process_path->Get_trajectory();
        //Unprocess_Path->Ganerate_Approach_Path(,wobj);
    }

}

TaskMachiningOperations::TaskMachiningOperations(WirCore::TrajectoryObject* trajectory)
{
    this->setButtonPosition(TaskMachiningOperations::South);

    wgt_ = new WgtMachiningOperations();
    wgt_->setWindowTitle(QObject::tr("Create Operation"));
    taskbox_ = new Gui::TaskView::TaskBox(Gui::BitmapFactory().pixmap("BezSurf"),
                                          wgt_->windowTitle(), true, 0);
    trajectory=wgt_->Get_traj();
    taskbox_->groupLayout()->addWidget(wgt_);
    Content.push_back(taskbox_);
}

TaskMachiningOperations::~TaskMachiningOperations()
{

}

void TaskMachiningOperations::clicked(int id)
{
    if(id == QDialogButtonBox::Apply) {
        wgt_->preview();
    }
}

void TaskMachiningOperations::modifyStandardButtons(QDialogButtonBox *button)
{
    taskbox_->groupLayout()->addWidget(button);
}

void TaskMachiningOperations::open()
{
    wgt_->open();
}

bool TaskMachiningOperations::accept()
{
    return wgt_->accept();
}

bool TaskMachiningOperations::reject()
{
    return wgt_->reject();
}


}

#include "moc_TaskMachiningOperations.cpp"
