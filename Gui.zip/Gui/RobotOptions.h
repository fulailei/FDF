#ifndef WIRCORE_ROBOTOPTIONS_H
#define WIRCORE_ROBOTOPTIONS_H

#include <Gui/TaskView/TaskView.h>
#include <Gui/Selection.h>

#include <Mod/WirCore/App/RobotObject.h>

class Ui_RobotOptions;
class QLineEdit;

namespace App {
class Property;
}

namespace Gui {
class ViewProvider;
}

namespace WirCoreGui {

class RobotOptions : public Gui::TaskView::TaskBox
{
    Q_OBJECT

public:
    RobotOptions(WirCore::RobotObject *pcRobotObject, QWidget *parent = 0);
    ~RobotOptions();

    void setRobot(WirCore::RobotObject *pcRobotObject);

private Q_SLOTS:
    void setAxis(float A1, float A2, float A3, float A4, float A5, float A6, const Base::Placement &Tcp);
    void changeSliderA1(int value);
    void changeSliderA2(int value);
    void changeSliderA3(int value);
    void changeSliderA4(int value);
    void changeSliderA5(int value);
    void changeSliderA6(int value);
    void createPlacementDlg(void);

protected:
    WirCore::RobotObject *pcRobot;
    void viewTcp(const Base::Placement pos);
    void viewTool(const Base::Placement pos);
    void setColor(int i, float angle, QLineEdit &lineEdit);

private:
    QWidget* proxy;
    Ui_RobotOptions* ui;
    WirCore::Robot6Axis* Rob;

};

}












#endif // ROBOTOPTIONS_H
