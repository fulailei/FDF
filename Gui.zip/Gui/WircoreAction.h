#ifndef WIRCORE_ACTION_H
#define WIRCORE_ACTION_H

#include <Gui/Action.h>
#include <Gui/Command.h>

#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/MainWindow.h>
#include <Gui/Document.h>
#include <Gui/Command.h>

#include <QObject>

#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>

namespace WirCoreGui {

class Command;

// --------------------------------------------------------------------

/**
 * The TrajtoryListAction class holds a menu listed with the Trajtory.
 */
class ObjectListAction : public Gui::ActionGroup
{
    Q_OBJECT
public:
    ObjectListAction (Gui::Command* pcCmd, Base::Type _ObjectType, QObject * parent = 0);

    void removeSpecifyObject(App::DocumentObject* i_Object);

    virtual ~ObjectListAction();

    void setObjectList();

    Base::Type ObjectType;
};

// --------------------------------------------------------------------



}
#endif // WIRCORE_ACTION_H
