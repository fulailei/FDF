/***************************************************************************
 *   Copyright (c) 2013 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

#include "PreCompiled.h"

#ifndef _PreComp_
# include <QPixmap>
# include <QDialog>
#endif

#include <Gui/BitmapFactory.h>
#include <Gui/MainWindow.h>
#include <Base/Tools.h>
#include <Base/UnitsApi.h>

#include "ui_DlgChooseDirection.h"
#include "DlgChooseDirection.h"

using namespace WirCoreGui;

DlgChooseDirection::DlgChooseDirection()
  : QDialog(Gui::getMainWindow()), ui(new Ui_DlgChooseDirection)
{
    DirType = 0;
    ui->setupUi(this);
}

DlgChooseDirection::~DlgChooseDirection()
{
    delete ui;
}

void DlgChooseDirection::accept()
{
    Base::Vector3d movevec{0,0,0};
    int _rev = (ui->Reverse_checkBox->isChecked())?-1:1;
    double trans = ui->doubleSpinBox->value();
    if (ui->X_radioButton->isChecked())
    {
        movevec = Base::Vector3d(_rev* trans, 0, 0);
    }
    else if (ui->Y_radioButton->isChecked())
    {
        movevec = Base::Vector3d( 0, _rev* trans, 0);
    }
    else  if (ui->Z_radioButton->isChecked())
    {
        movevec = Base::Vector3d( 0, 0, _rev* trans);
    }
    Pos = Base::Placement(movevec,Base::Rotation());
    QDialog::accept();
}


#include "moc_DlgChooseDirection.cpp"
