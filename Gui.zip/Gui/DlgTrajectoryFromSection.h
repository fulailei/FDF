#ifndef WIRCORE_DLGTRAJECTORYFROMSECTION_H
#define WIRCORE_DLGTRAJECTORYFROMSECTION_H


#include <Gui/TaskView/TaskDialog.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/PointObject.h>
#include "SurfaceCross.h"

//#include "TrajFromSectionParameter.h"

namespace Gui {
namespace TaskView {
class TaskSelectLinkProperty;
}
}

namespace WirCoreGui {
class DlgTrajectoryFromSection : public Gui::TaskView::TaskDialog
{
    Q_OBJECT
    enum Plane { XY, XZ, YZ };
public:
    DlgTrajectoryFromSection(WirCore::TrajectoryObject* traj, WirCore::WorkFrameObject* wobj);
    ~DlgTrajectoryFromSection();

public:
    virtual bool accept();
    virtual bool reject();
    virtual void helpRequested();

    WirCore::TrajectoryObject* traj;
    WirCore::WorkFrameObject* wobj;

    bool generateTrajectory();

    SurfaceCross* widget;
    Gui::TaskView::TaskBox* taskbox;

    virtual QDialogButtonBox::StandardButtons getStandardButtons(void) const
    { return QDialogButtonBox::Ok | QDialogButtonBox::Cancel; }

    void modifyStandardButtons(QDialogButtonBox*);

protected:
    std::vector<double> m_d;
    Plane m_plane;
    gp_Trsf m_trsf;


};

};
#endif // DLGTRAJECTORYFROMSECTION_H
