#ifndef WIRCOREGUI_TASKMACHININGOPERATIONS_H
#define WIRCOREGUI_TASKMACHININGOPERATIONS_H

#include <Gui/TaskView/TaskView.h>
#include <Gui/TaskView/TaskDialog.h>
#include <Gui/DocumentObserver.h>
#include <Mod/Part/App/PartFeature.h>
#include "ui_TaskMachiningOperations.h"
#include "Mod/WirCore/App/Process_Path.h"
#include "Mod/WirCore/App/Unprocess_Path.h"
namespace Gui {
class View3DInventor;
}

namespace WirCore {
class GeometryObject;
}

namespace WirCoreGui
{

class ViewProviderCutterAxisPreview;
class ViewProviderProcessingPathPreview;
class ViewProviderNonProcessingPathPreview;
class ViewProviderGeometryObject;

class WgtMachiningOperations : public QWidget, Ui_WgtMachiningOperations
{
    Q_OBJECT;

public:
    WgtMachiningOperations(QWidget* parent = nullptr);
    ~WgtMachiningOperations();

    void open();
    bool accept();
    bool reject();
    void preview();
    void read_parameter();
    WirCore::TrajectoryObject *Get_traj();
private Q_SLOTS:
    void on_cutter_axis_button_clicked();
    void on_processing_path_settings_button_clicked();
    void on_non_processing_path_settings_button_clicked();

protected:
    void changeEvent(QEvent *e);

private:

    Ui_WgtMachiningOperations* ui_;
    //Part::Feature* geometry_object_;
    //ViewProviderCutterAxisPreview* vp_cutter_axis_preview_;
    ViewProviderGeometryObject* vp_geometry_object_;
    WirCore::GeometryObject* geometry_object_;
    ViewProviderProcessingPathPreview* vp_processing_path_preview_;
    ViewProviderNonProcessingPathPreview* vp_non_processing_path_preview;
    Gui::View3DInventor* view_;
    WirCore::Process_Path *process_path;
    WirCore::Unprocess_Path *Unprocess_Path;
    WirCore::TrajectoryObject *traj;
};

class TaskMachiningOperations : public Gui::TaskView::TaskDialog
{
    Q_OBJECT

public:
    TaskMachiningOperations(WirCore::TrajectoryObject* trajectory);
    ~TaskMachiningOperations();

    void modifyStandardButtons(QDialogButtonBox* button);

public:
    void open();
    bool accept();
    bool reject();
    void clicked(int id);


    virtual QDialogButtonBox::StandardButtons getStandardButtons() const
    { return QDialogButtonBox::Apply | QDialogButtonBox::Ok | QDialogButtonBox::Cancel; }

private:
    WgtMachiningOperations* wgt_;
    Gui::TaskView::TaskBox* taskbox_;
};

} //namespace WirCoreGui

#endif //WIRCOREGUI_TASKMACHININGOPERATIONS_H
