#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
# include <QCoreApplication>

# include <BRepBndLib.hxx>
# include <BRepBuilderAPI_MakeVertex.hxx>
# include <BRepExtrema_DistShapeShape.hxx>
# include <BRepMesh_IncrementalMesh.hxx>
# include <BRep_Tool.hxx>
# include <BRepTools.hxx>
# include <BRepAdaptor_Curve.hxx>
# include <BRepAdaptor_Surface.hxx>
# include <GeomLib.hxx>
# include <GeomAbs_CurveType.hxx>
# include <GeomAbs_SurfaceType.hxx>
# include <Geom_BezierCurve.hxx>
# include <Geom_BSplineCurve.hxx>
# include <Geom_BezierSurface.hxx>
# include <Geom_BSplineSurface.hxx>
# include <GeomAPI_ProjectPointOnSurf.hxx>
# include <GeomLProp_SLProps.hxx>
# include <gp_Trsf.hxx>
# include <Poly_Array1OfTriangle.hxx>
# include <Poly_Triangulation.hxx>
# include <Poly_Connect.hxx>
# include <Standard_Version.hxx>
# include <TColgp_Array1OfPnt.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Edge.hxx>
# include <TopoDS_Wire.hxx>
# include <TopoDS_Face.hxx>
# include <TopoDS_Shape.hxx>
# include <TopoDS_Vertex.hxx>
# include <TopoDS_Iterator.hxx>
# include <TopExp_Explorer.hxx>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Poly_PolygonOnTriangulation.hxx>
# include <TColStd_Array1OfInteger.hxx>
# include <TColgp_Array1OfDir.hxx>
# include <TColgp_Array1OfPnt2d.hxx>
# include <TopTools_ListOfShape.hxx>
# include <TShort_Array1OfShortReal.hxx>
# include <TShort_HArray1OfShortReal.hxx>
# include <Precision.hxx>

#endif

#include <Inventor/collision/SoIntersectionDetectionAction.h>
#include <Inventor/misc/SoChildList.h>
#include <Inventor/details/SoFaceDetail.h>

#include "ViewProviderRobotObject.h"
#include <Gui/Action.h>
#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>
#include <Gui/ViewProvider.h>
#include <Gui/SoFCSelection.h>
#include <Gui/ViewProviderPart.h>
#include <Base/Console.h>
#include <Gui/View3DInventor.h>
#include "Gui/View3DInventorViewer.h"
#include "Gui/MainWindow.h"
#include <Mod/WirCore/App/AllowedCollisionMatrix.h>
#include <Mod/WirCore/Gui/ViewProviderACM.h>
#include <Mod/WirCore/Gui/DlgCollisionMatrix.h>
//#include "../App/fcl/FCLMethodWrapper.h"




// #####################################################################################################

using namespace std;
using namespace Gui;
using namespace WirCoreGui;
using namespace WirCore;
//using namespace fcl;

void addACMObject()
{
    auto doc = App::GetApplication().getActiveDocument();
    if (!doc) return;

    if (!AllowedCollisionMatrix::bUnique)
    {
        std::string uni_name = doc->getUniqueObjectName(AllowedCollisionMatrix::uniqueName.c_str());
        doc->addObject(AllowedCollisionMatrix::getClassTypeId().getName(), uni_name.c_str(), TRUE);

        AllowedCollisionMatrix::bUnique = true;
        AllowedCollisionMatrix::uniqueName = uni_name;
    }
}

void deleteACMObject()
{
    auto doc = App::GetApplication().getActiveDocument();
    if (!doc) return;

    std::string acmUniqueName = AllowedCollisionMatrix::uniqueName;
    auto obj = doc->getObject(acmUniqueName.c_str());
    if (obj)
    {
        doc->removeObject(acmUniqueName.c_str());
        AllowedCollisionMatrix::bUnique = false;
    }
}

//===========================================================================
// CmdWirCoreCollisionCheck
//===========================================================================
class CmdWirCoreCollisionCheck : public Gui::Command
{
public:
    CmdWirCoreCollisionCheck();
    virtual ~CmdWirCoreCollisionCheck(){}
    virtual void languageChange();
    virtual const char* className() const {return "CmdWirCoreCollisionCheck";}
    //void updateIcon(const Gui::MDIView* view);
protected:
    virtual void activated(int iMsg);
    virtual bool isActive(void);
    virtual Gui::Action * createAction(void);
};

CmdWirCoreCollisionCheck::CmdWirCoreCollisionCheck()
    : Command("WirCore_CollisionCheck")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("CollisionCheck");
    sToolTipText    = QT_TR_NOOP("Whether collision detection is valid for the whole scene");
    sWhatsThis      = "WirCore_CollisionCheck";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_CollisionMatrix";
    //eType         = Alter3DView;
    //this->getGuiApplication()->signalActivateView.connect(boost::bind(&CmdWirCoreGraphToolsShowHide::updateIcon, this, _1));
}

Gui::Action * CmdWirCoreCollisionCheck::createAction(void)
{
    Gui::ActionGroup* pcAction = new Gui::ActionGroup(this, Gui::getMainWindow());
    pcAction->setExclusive(false);
    pcAction->setDropDownMenu(false); // this can make a style like workbench. fuck!!!
    applyCommandData(this->className(), pcAction);

    auto addAction = [&](QString name)
    {
        QAction* act = pcAction->addAction(/*QString()*/name);
        act->setObjectName(name);
        act->setText(name);
        act->setToolTip(name);
        act->setCheckable(true);
        act->setChecked(false);
        //act->setObjectName(name);
        //act->setIcon(BitmapFactory().iconFromTheme(""));
        //act->setShortcut(QKeySequence(QString::fromUtf8("V,1")));
    };
    auto s = QCoreApplication::translate(this->className(), sMenuText);
    addAction(QCoreApplication::translate(this->className(), sMenuText)/*QString::fromLatin1(QT_TR_NOOP("CollisonCheck"))*/);

    //pcAction->setIcon(a0->icon());
    _pcAction = pcAction;
    languageChange();
    return pcAction;
}

void CmdWirCoreCollisionCheck::activated(int iMsg)
{
    Gui::ActionGroup* pcAction = dynamic_cast<Gui::ActionGroup*>(_pcAction);
    auto actions = pcAction->actions();
    auto isOk = actions[iMsg]->isChecked();
    if (isOk)
    {
        addACMObject();

        std::string acmUniqueName = AllowedCollisionMatrix::uniqueName;
        App::DocumentObject* obj = getActiveGuiDocument()->getDocument()->getObject(acmUniqueName.c_str());
        WirCore::AllowedCollisionMatrix* acm;
        if(obj && obj->getTypeId()==AllowedCollisionMatrix::getClassTypeId())
        {
            acm = static_cast<AllowedCollisionMatrix*>(obj);
        }

        Gui::ViewProvider* vp = getActiveGuiDocument()->getViewProvider(obj);
        if (vp && vp->getTypeId() == ViewProviderACM::getClassTypeId())
        {
            ViewProviderACM* vACM = static_cast<ViewProviderACM*>(vp);
            if (acm->getCollisionType() == 0)
                vACM->initCollisionCheck();
            else
                vACM->initFCLCollisionCheck();

        }
    }
    else
        deleteACMObject();
}

bool CmdWirCoreCollisionCheck::isActive(void)
{
    auto doc = App::GetApplication().getActiveDocument();
    return doc != nullptr;
}

void CmdWirCoreCollisionCheck::languageChange()
{
    Command::languageChange();

    if (!_pcAction)
        return;
    ActionGroup* pcAction = qobject_cast<ActionGroup*>(_pcAction);
    QList<QAction*> acts = pcAction->actions();

    acts[0]->setText(QCoreApplication::translate(this->className(), sMenuText));
    //acts[1]->setText(QObject::tr("Load views..."));
    //acts[3]->setText(QObject::tr("Freeze view"));
    //acts[4]->setText(QObject::tr("Clear views"));
    //    int index=1;
    //    for (QList<QAction*>::ConstIterator it = acts.begin()+5; it != acts.end(); ++it, index++)
    //    {
    //        if ((*it)->isVisible()) {
    //            QString viewnr = QString(QObject::tr("Restore view &%1")).arg(index);
    //            (*it)->setText(viewnr);
    //        }
    //    }
}



//===========================================================================
// CmdWirCoreCollisionMatrix
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreCollisionMatrix);
CmdWirCoreCollisionMatrix::CmdWirCoreCollisionMatrix()
    :Command("WirCore_CollisionMatrix")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("CollisionMatrix");
    sToolTipText    = QT_TR_NOOP("Collision Matrix Setting for the whole scene");
    sWhatsThis      = "WirCore_CollisionMatrix";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_CollisionMatrix";
}

void CmdWirCoreCollisionMatrix::activated(int)
{
    std::string acmUniqueName = AllowedCollisionMatrix::uniqueName;
    App::DocumentObject* obj = getActiveGuiDocument()->getDocument()->getObject(acmUniqueName.c_str());
    if (!obj)
    {
        Base::Console().Message("AllowedCollisionMatrix object is not found\n");
        return;
    }


    //getActiveGuiDocument()->setEdit()
    Gui::ViewProvider* vp = getActiveGuiDocument()->getViewProvider(obj);
    if (vp && vp->getTypeId() == ViewProviderACM::getClassTypeId())
    {
        ViewProviderACM* vACM = static_cast<ViewProviderACM*>(vp);
        vACM->updateACM();
    }
    else
    {
        Base::Console().Message("ViewProviderACM object is not found\n");
        return;
    }

    // dlg
    WirCore::AllowedCollisionMatrix* acm;
    if(obj->getTypeId()==AllowedCollisionMatrix::getClassTypeId())
    {
        acm = static_cast<AllowedCollisionMatrix*>(obj);
        // Base::Console().Message("Enter Here1!!\n");
    }

    WirCoreGui::DlgCollisionMatrix dlg_cm(*acm, Gui::getMainWindow());
    dlg_cm.exec();
    acm->copy(dlg_cm.getACM());


    if (vp->getTypeId() == ViewProviderACM::getClassTypeId())
    {
        ViewProviderACM* vACM = static_cast<ViewProviderACM*>(vp);
        if (acm->getCollisionType() == 0)
            vACM->initCollisionCheck();
        else
            vACM->initFCLCollisionCheck();
    }
}

bool CmdWirCoreCollisionMatrix::isActive(void)
{
    return hasActiveDocument();
}

//===========================================================================
// CmdWirCoreSingleCollisionCheck
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreSingleCollisionCheck);
CmdWirCoreSingleCollisionCheck::CmdWirCoreSingleCollisionCheck()
    :Command("WirCore_SingleCollisionCheck")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("SingleCollisionCheck");
    sToolTipText    = QT_TR_NOOP("Single collision check");
    sWhatsThis      = "WirCore_SingleCollisionCheck";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_CollisionMatrix";
}

void CmdWirCoreSingleCollisionCheck::activated(int)
{
    std::string acmUniqueName = AllowedCollisionMatrix::uniqueName;
    App::DocumentObject* obj = getActiveGuiDocument()->getDocument()->getObject(acmUniqueName.c_str());
    if (!obj)
    {
        Base::Console().Message("AllowedCollisionMatrix object is not found\n");
        return;
    }

    WirCore::AllowedCollisionMatrix* acm;
    if(obj->getTypeId()==AllowedCollisionMatrix::getClassTypeId())
    {
        acm = static_cast<AllowedCollisionMatrix*>(obj);
    }


    Gui::ViewProvider* vp = getActiveGuiDocument()->getViewProvider(obj);
    if (vp && vp->getTypeId() == ViewProviderACM::getClassTypeId())
    {
        ViewProviderACM* vACM = static_cast<ViewProviderACM*>(vp);


        if (acm->getCollisionType() == 0)
        {
            vACM->updateACM();
            vACM->collisionCheck();
        }
        else
        {
            vACM->initFCLCollisionCheck();
            vACM->fclCollisionCheck();
        }
    }
    else
    {
        Base::Console().Message("ViewProviderACM object is not found\n");
        return;
    }

}

bool CmdWirCoreSingleCollisionCheck::isActive(void)
{
    auto doc = App::GetApplication().getActiveDocument();
    if (!doc)
        return false;

    auto obj = doc->getObject(AllowedCollisionMatrix::uniqueName.c_str());
    return obj != nullptr;
}

void CreateWirCoreCommandCollision(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();
    rcCmdMgr.addCommand(new CmdWirCoreCollisionMatrix());
    rcCmdMgr.addCommand(new CmdWirCoreCollisionCheck());
    rcCmdMgr.addCommand(new CmdWirCoreSingleCollisionCheck());
}
