#ifndef WIROLP_TRAJFROMEDGE_PARAMETER_H
#define WIROLP_TRAJFROMEDGE_PARAMETER_H


#include <Gui/TaskView/TaskView.h>
#include <Gui/Selection.h>

#include <Mod/WirCore/App/TrajectoryObject.h>

class Ui_TrajFromEdgeParameter;

namespace App {
class Property;
}

namespace Gui {
class ViewProvider;
}

namespace WirCoreGui {

class TrajFromEdgeParameter : public Gui::TaskView::TaskBox
                            , public Gui::SelectionSingleton::ObserverType
{
    Q_OBJECT


public Q_SLOTS:
    void sizingValueChanged(double size);

public:
    TrajFromEdgeParameter(QWidget *parent = 0);
    ~TrajFromEdgeParameter();
    /// Observer message from the Selection
    void OnChange(Gui::SelectionSingleton::SubjectType &rCaller,
                  Gui::SelectionSingleton::MessageType Reason);

    void setSelection2Buffer(void);

    App::DocumentObject* m_selEdgeObject;
    App::DocumentObject* m_selFaceObject;

    std::vector<std::string> edgeSubname;
    std::string faceSubname;

private:
    QWidget* proxy;
    Ui_TrajFromEdgeParameter* ui;

    std::string edgeFilter;
    std::string faceFilter;

    int m_sel;

public:
     bool eventFilter(QObject *,QEvent *);


};


}

#endif
