#ifndef WIRCORE_EXPORTPROGRAM_H
#define WIRCORE_EXPORTPROGRAM_H

#include "TextEdit.h"
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

namespace WirCoreGui
{


class ExportProgram
{
public:
    ExportProgram(WirCore::RobotObject *pcRobotObject, WirCore::TrajectoryObject *pcTrajectoryObject);
    ~ExportProgram();


    void generateRobotProgram();

private:
    WirCore::RobotObject* robot;
    WirCore::TrajectoryObject * traj;
    TextEdit* mw;

};

}

#endif // EXPORTPROGRAM_H
