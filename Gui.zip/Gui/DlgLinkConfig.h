#ifndef WIRCOREGUI_DLGLINKCONFIG_H
#define WIRCOREGUI_DLGLINKCONFIG_H

#include <QDialog>

namespace WirCoreGui {

class Ui_DlgLinkConfig;
class DlgLinkConfig : public QDialog
{
    Q_OBJECT

public:
    DlgLinkConfig(std::vector<bool> i_vec, QWidget* parent=0);
    ~DlgLinkConfig();

    void accept();
    void reject();

    std::vector<bool> getLinkConfig() {return m_LinkConfig;};

protected Q_SLOTS:
    void onCreateClicked();
    void onCancelClicked();

protected:
    Ui_DlgLinkConfig* ui;
    std::vector<bool> m_LinkConfig;
};
}
#endif
