#ifndef WIRCORE_VIEWPROVIDERROBOTTOOLOBJECT_H
#define WIRCORE_VIEWPROVIDERROBOTTOOLOBJECT_H

#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/TopoShape.h>

#include <Gui/ViewProviderGeometryObject.h>
#include <App/DocumentObject.h>

#include <Gui/ViewProviderOriginGroup.h>

namespace WirCoreGui
{

class ViewProviderRobotToolObject : public Gui::ViewProviderGeometryObject,
                                    public Gui::ViewProviderOriginGroupExtension
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderRobotToolObject);
public:
    ViewProviderRobotToolObject();

      ~ViewProviderRobotToolObject();

    bool canDragObjects() const;
    bool canDragObject(App::DocumentObject*) const;
    bool canDropObjects() const;
    bool canDropObject(App::DocumentObject*) const;

    std::vector<App::DocumentObject*> claimChildren(void) const;
    std::vector<App::DocumentObject*> claimChildren3D(void) const;

    virtual void onChanged(const App::Property* prop);

    bool showInTree() const
    {
      return false;
    }

protected:

};

}

#endif // WIRCORE_VIEWPROVIDERROBOTTOOLOBJECT_H
