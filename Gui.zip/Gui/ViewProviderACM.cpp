#include "PreCompiled.h"
#ifndef _PreComp_
# include <BRepBndLib.hxx>
# include <BRepBuilderAPI_MakeVertex.hxx>
# include <BRepExtrema_DistShapeShape.hxx>
# include <BRepMesh_IncrementalMesh.hxx>
# include <BRep_Tool.hxx>
# include <BRepTools.hxx>
# include <BRepAdaptor_Curve.hxx>
# include <BRepAdaptor_Surface.hxx>
# include <GeomLib.hxx>
# include <GeomAbs_CurveType.hxx>
# include <GeomAbs_SurfaceType.hxx>
# include <Geom_BezierCurve.hxx>
# include <Geom_BSplineCurve.hxx>
# include <Geom_BezierSurface.hxx>
# include <Geom_BSplineSurface.hxx>
# include <GeomAPI_ProjectPointOnSurf.hxx>
# include <GeomLProp_SLProps.hxx>
# include <gp_Trsf.hxx>
# include <Poly_Array1OfTriangle.hxx>
# include <Poly_Triangulation.hxx>
# include <Poly_Connect.hxx>
# include <Standard_Version.hxx>
# include <TColgp_Array1OfPnt.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Edge.hxx>
# include <TopoDS_Wire.hxx>
# include <TopoDS_Face.hxx>
# include <TopoDS_Shape.hxx>
# include <TopoDS_Vertex.hxx>
# include <TopoDS_Iterator.hxx>
# include <TopExp_Explorer.hxx>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Poly_PolygonOnTriangulation.hxx>
# include <TColStd_Array1OfInteger.hxx>
# include <TColgp_Array1OfDir.hxx>
# include <TColgp_Array1OfPnt2d.hxx>
# include <TopTools_ListOfShape.hxx>
# include <TShort_Array1OfShortReal.hxx>
# include <TShort_HArray1OfShortReal.hxx>
# include <Precision.hxx>
#endif

#include "ViewProviderACM.h"
#include <Gui/Application.h>

#include <Base/Console.h>
#include <boost/bind.hpp>
#include <Gui/Document.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include "Gui/SoFCUnifiedSelection.h"
#include "Gui/SoFCSelectionAction.h"
#include "ViewProviderRobotObject.h"
//#include "../App/fcl/FCLMethodWrapper.h"

using namespace WirCoreGui;
using namespace Gui;
using namespace PartGui;
using namespace WirCore;
//using namespace fclwrapper;

PROPERTY_SOURCE(WirCoreGui::ViewProviderACM,  Gui::ViewProviderDocumentObject)

ViewProviderACM::ViewProviderACM() :
    pRootScene(new SoGroup()),
    pCollisionDetectAction(new SoIntersectionDetectionAction)
{
    Document* doc = Gui::Application::Instance->activeDocument();
    doc->signalNewObject.connect(boost::bind (&ViewProviderACM::slotNewObject, this, _1));
}

ViewProviderACM::~ViewProviderACM()
{
    if (pCollisionDetectAction)
    {
        delete pCollisionDetectAction;
        pCollisionDetectAction = nullptr;
    }
    if (pRootScene)
    {
        pRootScene->unref();
        pRootScene = nullptr;
    }
//    if (fclCollision)
//    {
//        delete  fclCollision;
//        fclCollision = nullptr;
//    }

    collisionObjMap.clear();

    Document* doc = Gui::Application::Instance->activeDocument();
    doc->signalNewObject.disconnect(boost::bind (&ViewProviderACM::slotNewObject, this, _1));
}

//fclwrapper::FclSceneObjects ViewProviderACM::getFclEnvSceneObject()
//{
//    fclwrapper::FclSceneObjects fclObjs;

//    Gui::Document* document = Gui::Application::Instance->activeDocument();
//    if (!document)
//        return fclObjs;

//    PartGui::ViewProviderPart* worldObj = nullptr;
//    std::vector<ViewProvider*> vps = document->getViewProvidersOfType(Base::Type::fromName("PartGui::ViewProviderPart"));
//    for (std::vector<ViewProvider*>::iterator it = vps.begin(); it != vps.end(); it++)
//    {
//        worldObj = dynamic_cast<PartGui::ViewProviderPart*>(*it);
//        if (worldObj && worldObj->getObject()->getTypeId().isDerivedFrom(Part::Feature::getClassTypeId()))
//        {
//            // exclude meshes
//            std::map<std::string, App::Property*> Map;
//            worldObj->getObject()->getPropertyMap(Map);
//            // Mesh::MeshObject mesh;
//            for (std::map<std::string, App::Property*>::iterator jt = Map.begin(); jt != Map.end(); ++jt)
//            {
//                if (jt->first == "Shape" && jt->second->getTypeId().isDerivedFrom(App::PropertyComplexGeoData::getClassTypeId()))
//                {
//                    std::vector<Base::Vector3d> aPoints;
//                    std::vector<Data::ComplexGeoData::Facet> aTopo;
//                    const Data::ComplexGeoData* data = static_cast<App::PropertyComplexGeoData*>(jt->second)->getComplexData();
//                    if (data)
//                    {
//                        data->getFaces(aPoints, aTopo, 0.1); // QObject::tr("Enter tolerance for meshing geometry:"), 0.1, 0.01,10.0,2,&ok);
//                        //mesh.setFacets(aTopo, aPoints);
//                        fclwrapper::FclSceneObject sobj;
//                        for (auto point : aPoints)
//                            sobj.vertices.push_back(fcl::Vector3d(point.x, point.y, point.z));
//                        for(auto tri : aTopo)
//                            sobj.triangles.push_back(fcl::Triangle(tri.I1, tri.I2, tri.I3));
//                        fclObjs.push_back(sobj);
//                    }
//                }
//            }
//        }
//    }
//    return fclObjs;
//}

//fclwrapper::FclSceneObjects ViewProviderACM::getFclRobotSceneObject()
//{
//    fclwrapper::FclSceneObjects fclObjs;
//    Gui::Document* document = Gui::Application::Instance->activeDocument();
//    if (!document)
//        return fclObjs;

//    ViewProviderRobotObject* robotObj = nullptr;
//    std::vector<ViewProvider*> vps = document->getViewProvidersOfType(ViewProviderRobotObject::getClassTypeId());
//    for (std::vector<ViewProvider*>::iterator it = vps.begin(); it != vps.end(); it++)
//    {
//        robotObj = dynamic_cast<ViewProviderRobotObject*>(*it);
//        if (robotObj && robotObj->getObject()->getTypeId().isDerivedFrom(Mesh::Feature::getClassTypeId()))
//        {
//            // exclude meshes
//            std::map<std::string, App::Property*> Map;
//            robotObj->getObject()->getPropertyMap(Map);
//            Mesh::MeshObject mesh;
//            for (std::map<std::string, App::Property*>::iterator jt = Map.begin(); jt != Map.end(); ++jt)
//            {
//                if (jt->first == "Shape" && jt->second->getTypeId().isDerivedFrom(App::PropertyComplexGeoData::getClassTypeId()))
//                {
//                    std::vector<Base::Vector3d> aPoints;
//                    std::vector<Data::ComplexGeoData::Facet> aTopo;
//                    const Data::ComplexGeoData* data = static_cast<App::PropertyComplexGeoData*>(jt->second)->getComplexData();
//                    if (data)
//                    {
//                        data->getFaces(aPoints, aTopo, 0.1); // QObject::tr("Enter tolerance for meshing geometry:"), 0.1, 0.01,10.0,2,&ok);
//                        //mesh.setFacets(aTopo, aPoints);
//                        fclwrapper::FclSceneObject sobj;
//                        for (auto point : aPoints)
//                            sobj.vertices.push_back(fcl::Vector3d(point.x, point.y, point.z));
//                        for(auto tri : aTopo)
//                            sobj.triangles.push_back(fcl::Triangle(tri.I1, tri.I2, tri.I3));
//                        fclObjs.push_back(sobj);
//                    }
//                }
//            }
//        }
//    }
//    return fclObjs;
//}

void ViewProviderACM::slotNewObject(const ViewProviderDocumentObject& doc)
{
    this->updateACM();
}

void ViewProviderACM::updateACM()
{
    if (!createScene())
        return;
    updateACMObject();
    //deleteScene();
}

void ViewProviderACM::updateACMObject()
{
    App::DocumentObject* obj = this->getObject();
    if (!obj) return ;

    AllowedCollisionMatrix* acm;
    AllowedCollisionMatrix newAcm;
    if (obj && obj->getTypeId() == AllowedCollisionMatrix::getClassTypeId())
    {
        acm = static_cast<AllowedCollisionMatrix*>(obj);
        std::map<std::string,CollisionObject*>::iterator jt;

        //        bool res=true;
        //        for (jt = collisionObjMap.begin();jt != collisionObjMap.end(); ++jt){
        //            if (jt->second->getACM().getEntryNum()>0){
        //                //             Base::Console().Message("Enter Here6\n");
        //                res&=acm->subEntries(jt->second->getACM());
        //                //             Base::Console().Message("Enter Here7\n");
        //            }
        //            else
        //                res&=acm->hasEntry(jt->second->getName());
        //        }


        AllowedCollisionMatrix newAcm;
        for (jt = collisionObjMap.begin(); jt != collisionObjMap.end(); ++jt)
        {
            newAcm += jt->second->getACM();
        }

        // Base::Console().Message(newAcm.toString().c_str());
        acm->updateByEntryNames(newAcm);

        //        //        Base::Console().Message(acm->toString().c_str());
        //        if(!res)
        //        {
        //            for (jt = collisionObjMap.begin();jt != collisionObjMap.end(); ++jt)
        //            {
        //                //  Base::Console().Message("the entry number of ACM of this object is %d\n",jt->second->getACM().getEntryNum());
        //                if (jt->second->getACM().getEntryNum()>0)
        //                    newAcm+=jt->second->getACM();
        //                else
        //                    newAcm.addEntry(jt->second->getName());
        //            }
        //            acm->copy(newAcm);
        //        }
        //        else
        //        {
        //            Base::Console().Message("no need to update ACM!\n");
        //        }
    }
}

bool ViewProviderACM::createScene()
{
    Gui::Document* document = Gui::Application::Instance->activeDocument();
    if (!document)
        return false;

    ViewProviderRobotObject* robotObj = nullptr;
    PartGui::ViewProviderPart* worldObj = nullptr;

    std::vector<ViewProvider*>::iterator it;
    std::vector<ViewProvider*> vps = document->getViewProvidersOfType(ViewProviderRobotObject::getClassTypeId());
    for (it = vps.begin(); it != vps.end(); it++)
    {
        if ((*it)->getTypeId() == ViewProviderRobotObject::getClassTypeId())
        {
            Base::Console().Message("Robot Object is found\n");
            robotObj = static_cast<ViewProviderRobotObject*> ((*it));
            RobotCollisionObj* cobj = new RobotCollisionObj(robotObj);
            addCollisionObj(cobj);
        }
    }

    vps = document->getViewProvidersOfType(Base::Type::fromName("PartGui::ViewProviderPart"));
    for (it = vps.begin(); it != vps.end(); it++)
    {
        //if ((*it)->getTypeId()==PartGui::ViewProviderPart::getClassTypeId())
        {
            Base::Console().Message("Collision Object is found\n");
            worldObj = static_cast<PartGui::ViewProviderPart*> ((*it));
            if (worldObj)
            {
                CollisionObject* cobj = new CollisionObject(worldObj);
                addCollisionObj(cobj);
            }

        }
    }

    if (!robotObj && !worldObj)
        return false;
    else
        return true;
}

void ViewProviderACM::deleteScene()
{
    std::map<std::string,CollisionObject*>::iterator jt;
    for (jt = collisionObjMap.begin(); jt != collisionObjMap.end(); ++jt)
        delete jt->second;
    collisionObjMap.clear();
}

void ViewProviderACM::initFCLCollisionCheck()
{
    updateACM();



//    fclwrapper::FclSceneObjects envs, robots;
//    for (auto jt = collisionObjMap.begin(); jt != collisionObjMap.end(); ++jt)
//    {
//        RobotCollisionObj* robj = dynamic_cast<RobotCollisionObj*>(jt->second);
//        if (robj != nullptr)
//        {
//            robj->buildFclSceneObjects();
//            auto fclObjs = robj->getFclSceneObjects();
//            for (auto o : fclObjs)
//                robots.push_back(o);
//        }
//        else
//        {
//            jt->second->buildFclSceneObjects();
//            auto fclObjs = jt->second->getFclSceneObjects();
//            for (auto o : fclObjs)
//                envs.push_back(o);
//        }

//    }

//    if (fclCollision == nullptr)
//    {
//        //auto env = getFclEnvSceneObject();
//        //auto rob = getFclRobotSceneObject();
//        fclCollision =  new fclwrapper::FCLMethodWrapper(false, envs, robots);

//    }
//    fclCollision->clear();
//    fclCollision->configure(envs, robots);
}

void ViewProviderACM::fclCollisionCheck()
{
    //std::function<bool(std::string name1, std::string name2)> AA = this->ViewProviderACM::allowedCollision;
//    if (fclCollision != nullptr)
//        fclCollision->isValid();
}

void ViewProviderACM::initCollisionCheck()
{
    updateACM();

    if (pRootScene)
    {
        pRootScene->removeAllChildren();
        std::map<std::string,CollisionObject*>::iterator jt;
        //Base::Console().Message("There are %d objects in collisionObjMap\n", collisionObjMap.size());
        for (jt = collisionObjMap.begin(); jt != collisionObjMap.end(); ++jt)
        {
            //        RobotCollisionObj* robj = static_cast<RobotCollisionObj*>(jt->second);
            //        if (robj != nullptr)
            //        {
            //            auto num = robj->getChildRoot()->getNumChildren();
            //            for (int i = 0; i < num; ++i)
            //            {
            //                auto node = robj->getChildRoot()->getChild(i);
            //                auto s = node->getName();
            //                group->addChild(robj->getChildRoot()->getChild(i));
            //            }
            //        }
            //        else
            {
                pRootScene->addChild((SoNode*)(jt->second->getRoot()));
            }
        }
        auto n = pRootScene->getNumChildren();

        intersectionCount=0;

        if (pCollisionDetectAction)
        {
            pCollisionDetectAction->setFilterCallback(ViewProviderACM::intersectionFilter, this);
            pCollisionDetectAction->addIntersectionCallback(ViewProviderACM::onIntersection, this);
            pCollisionDetectAction->setDraggersEnabled(false);
            pCollisionDetectAction->setManipsEnabled(false);
            //collisionDetect->apply(group);
        }
    }
}

void ViewProviderACM::collisionCheck()
{
    ViewProviderACM::intersectionCount = 0;
    for (auto pairvc : vps)
    {
        Gui::ViewProvider* vp = pairvc.first;
        //auto iter = collisionObjMap.find(name);
        //        if (iter == collisionObjMap.end())
        //        {
        //            // maybe a robot
        //            vp = collisionObjMap.at("Abb4600")->getProvider();

        //        }
        //        else
        //            vp = collisionObjMap.at(name)->getProvider();

        App::Property* color = vp->getPropertyByName("ShapeColor");
        if (color && color->getTypeId() == App::PropertyColor::getClassTypeId())
        {
            App::PropertyColor* c = (App::PropertyColor*)color;

            //vps.push_back(std::make_pair(vp, c->getValue()));
            c->setValue(pairvc.second);
        }
    }
    vps.clear();

    if (pCollisionDetectAction && pRootScene)
        pCollisionDetectAction->apply(pRootScene);
}

bool ViewProviderACM::allowedCollision(std::string name1, std::string name2)
{
    App::DocumentObject* obj = this->getObject();
    AllowedCollisionMatrix* acm;
    if (!obj) return false;
    if (obj->getTypeId() == AllowedCollisionMatrix::getClassTypeId())
    {
        acm = static_cast<AllowedCollisionMatrix*>(obj);
        return acm->getEntry(name1, name2) == 1;
    }
    else
        return false;
}

SbBool ViewProviderACM::intersectionFilter (void *userData, const SoPath *p1, const SoPath *p2)
{
    ViewProviderACM* data = nullptr;
    if (userData != nullptr)
        data = static_cast<ViewProviderACM*>(userData);

    SoNode* node1 = p1->getTail();
    SoNode* node2 = p2->getTail();
    bool bAllowed = data->allowedCollision(node1->getName().getString(),node2->getName().getString());
    //    Base::Console().Message("the status of the acm is %d, name 1 is %s, name 2 is %s \n",
    //                                   bAllowed,node1->getName().getString(),node2->getName().getString());
    //    Base::Console().Message(" name 1 is %s, name 2 is %s \n",
    //                                       node1->getTypeId().getName().getString(),node2->getTypeId().getName().getString());
    return !bAllowed ? FALSE : TRUE;


    // WirCore::RobotObject* robObj1 = dynamic_cast<WirCore::RobotObject*>(robObj->getObject());
    // std::vector<App::DocumentObject*> partGroup = robObj1->LinkList.getValues();
    // std::vector<std::string> entry_names;
    // for (auto part : partGroup)
    //   entry_names.push_back(part->Label.getValue());

    // ViewProviderDocumentObject* vpd1 = 0;
    // ViewProviderDocumentObject* vpd2 = 0;
    // View3DInventorViewer* p = static_cast<View3DInventorViewer*>(userData);
    // ViewProvider* vp1 = p->getDocument()->getViewProviderByPathFromTail(p1/*primitive1->path*/);
    // ViewProvider* vp2 = p->getDocument()->getViewProviderByPathFromTail(p2/*primitive2->path*/);
    //  vp = p->getDocument()->getViewProviderByPathFromTail(primitive1->path);
    //   if (vp1 && vp2 &&
    //           vp1->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()) &&
    //           vp2->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
    //   {
    //       vpd1 = static_cast<ViewProviderDocumentObject*>(vp1);
    //       vpd2 = static_cast<ViewProviderDocumentObject*>(vp2);

    //       App::Property* color = vpd1->getPropertyByName("ShapeColor");
    //       if (color && color->getTypeId() == App::PropertyColor::getClassTypeId())
    //       {
    //                  App::PropertyColor* c = (App::PropertyColor*)color;
    //                  c->setValue(App::Color(1,0,0));
    //       }

    //         color = vpd2->getPropertyByName("ShapeColor");
    //         if (color && color->getTypeId() == App::PropertyColor::getClassTypeId())
    //         {
    //             App::PropertyColor* c = (App::PropertyColor*)color;
    //             c->setValue(App::Color(1,0,0));
    //         }
}

SoIntersectionDetectionAction::Resp
ViewProviderACM::onIntersection(void *userData,
                                const SoIntersectingPrimitive *primitive1,
                                const SoIntersectingPrimitive *primitive2)
{
    ViewProviderACM* data = nullptr;
    if (userData != nullptr)
        data = static_cast<ViewProviderACM*>(userData);

    Base::Console().Message("Collision check: Collision %d: %s (%s) *** %s (%s)\n",
                            //           RobotCollisionObj::intersectionCount,
                            data->intersectionCount,
                            (char *)primitive1->path->getTail()->getName().getString(),
                            (char *)primitive1->path->getTail()->getTypeId().getName().getString(),
                            (char *)primitive2->path->getTail()->getName().getString(),
                            (char *)primitive2->path->getTail()->getTypeId().getName().getString());

    data->changeColor(primitive1->path->getTail()->getName().getString());
    data->changeColor(primitive2->path->getTail()->getName().getString());

    data->intersectionCount++;
    // This callback will be called for the two next colliding shapes
    return SoIntersectionDetectionAction::NEXT_SHAPE;
}

void ViewProviderACM::changeColor(std::string name)
{
    if (collisionObjMap.empty())
        return;

    Gui::ViewProvider* vp = nullptr;
    auto iter = collisionObjMap.find(name);
    if (iter == collisionObjMap.end())
    {
        // maybe a robot
        vp = collisionObjMap.at("Abb4600")->getProvider();

    }
    else
        vp = collisionObjMap.at(name)->getProvider();

    if (vp)
    {
        App::Property* color = vp->getPropertyByName("ShapeColor");
        if (color && color->getTypeId() == App::PropertyColor::getClassTypeId())
        {
            App::PropertyColor* c = (App::PropertyColor*)color;

            if (vps.end() == vps.find(vp))
                vps[vp] = c->getValue();

            App::DocumentObject* obj = this->getObject();
            if (obj && obj->getTypeId() == AllowedCollisionMatrix::getClassTypeId())
            {
                AllowedCollisionMatrix* acm = static_cast<AllowedCollisionMatrix*>(obj);
                c->setValue(acm->getCollisionColor());
            }
        }
    }
}

void ViewProviderACM::addCollisionObj(CollisionObject* obj)
{
    collisionObjMap[obj->getName()] = obj;
}

