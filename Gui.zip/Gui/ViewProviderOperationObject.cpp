#include "PreCompiled.h"

#ifndef _PreComp_
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoDrawStyle.h>
#include <Inventor/nodes/SoLineSet.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoBaseColor.h>
#include <Inventor/nodes/SoMarkerSet.h>
#endif

#include "ViewProviderOperationObject.h"
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Gui/Inventor/MarkerBitmaps.h>
#include <App/Application.h>
#include <App/Document.h>

using namespace Gui;
using namespace WirCore;
using namespace WirCoreGui;

PROPERTY_SOURCE(WirCoreGui::ViewProviderOperationObject, Gui::ViewProviderDocumentObject)

ViewProviderOperationObject::ViewProviderOperationObject()
{
    pcOperationRoot = new Gui::SoFCSelection();
    pcOperationRoot->highlightMode = Gui::SoFCSelection::OFF;
    pcOperationRoot->selectionMode = Gui::SoFCSelection::SEL_OFF;
    pcOperationRoot->ref();

    pcCoords = new SoCoordinate3();
    pcCoords->ref();
    pcDrawStyle = new SoDrawStyle();
    pcDrawStyle->ref();
    pcDrawStyle->style = SoDrawStyle::LINES;
    pcDrawStyle->lineWidth = 2;

    pcLines = new SoLineSet;
    pcLines->ref();

    sPixmap = "WirCore_Trajectory";
}

ViewProviderOperationObject::~ViewProviderOperationObject()
{
    pcOperationRoot->unref();
    pcCoords->unref();
    pcDrawStyle->unref();
    pcLines->unref();

}

void ViewProviderOperationObject::attach(App::DocumentObject *pcObject)
{
    ViewProviderOperationObject::attach(pcObject);
    SoSeparator* linesep = new SoSeparator;
    SoBaseColor* basecol = new SoBaseColor;
    basecol->rgb.setValue(1.0f, 0.5f, 0.0f);
    linesep->addChild(basecol);
    linesep->addChild(pcCoords);
    linesep->addChild(pcLines);

    SoBaseColor* markcol = new SoBaseColor;
    markcol->rgb.setValue(1.0f, 1.0f, 0.0f);
    SoMarkerSet* marker = new SoMarkerSet;
    marker->markerIndex = Gui::Inventor::MarkerBitmaps::getMarkerIndex("CROSS", App::GetApplication().GetParameterGroupByPath("User Parameter:BaseApp/Preferences/View")->GetInt("MarkerSize", 5));
    linesep->addChild(markcol);
    linesep->addChild(marker);

    pcOperationRoot->addChild(linesep);
    addDisplayMaskMode(pcOperationRoot, "Waypoints");
    pcOperationRoot->objectName = pcObject->getNameInDocument();
    pcOperationRoot->documentName = pcObject->getDocument()->getName();
    pcOperationRoot->subElementName = "Main";
}

void ViewProviderOperationObject::setDisplayMode(const char *ModeName)
{
    if(strcmp("Waypoints", ModeName) == 0)
        setDisplayMaskMode("Waypoints");
    ViewProviderDocumentObject::setDisplayMode(ModeName);
}

std::vector<std::string> ViewProviderOperationObject::getDisplayModes() const
{
    std::vector<std::string> strList;
    strList.push_back("Waypoints");
    return strList;
}

void ViewProviderOperationObject::updateData(const App::Property *prop)
{
    WirCore::OperationObject* pcOperationObj = static_cast<WirCore::OperationObject*>(pcObject);
    if(prop == &pcOperationObj->updateEvent) {
        std::vector<WirCore::WaypointObject*> wpoints = pcOperationObj->getAllPointsInGeometry();
        int num = 0;
        pcCoords->point.deleteValues(0);
        for(WirCore::WaypointObject* obj : wpoints) {
            if(!obj) continue;
            auto pt = dynamic_cast<WirCore::PointObject*>(obj->linkPoint.getValue());
            if(!pt) continue;

            Base::Placement wp = pt->globalPlacement();
            Base::Vector3d pos = wp.getPosition();
            pcCoords->point.set1Value(num++, pos.x, pos.y, pos.z);
        }

        pcLines->numVertices.set1Value(0, num);
    }
}

void ViewProviderOperationObject::setupContextMenu(QMenu *menu, QObject *receiver, const char *member)
{
}

std::vector<App::DocumentObject*> ViewProviderOperationObject::claimChildren() const
{
    std::vector<App::DocumentObject*> children;
    return children;
}





