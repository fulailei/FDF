#include "PreCompiled.h"

#ifndef _PreComp_
#include <QApplication>
#endif

#include "DlgTrajectoryFromSection.h"

#include <Base/Console.h>
#include <Base/Exception.h>
#include <Gui/TaskView/TaskSelectLinkProperty.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>

#include <TopoDS.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopOpeBRepBuild_Tools.hxx>
#include <BRep_Tool.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRep_Builder.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <CPnts_AbscissaPoint.hxx>
#include <TopExp.hxx>
#include <GeomAPI_ProjectPointOnSurf.hxx>
#include <BOPTools_AlgoTools3D.hxx>

#include <Mod/Part/App/edgecluster.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/WirCore/App/ActiveStationObject.h>

# include <gp_Pln.hxx>
# include "IntersectSurface.h"


using namespace WirCoreGui;

DlgTrajectoryFromSection::DlgTrajectoryFromSection(WirCore::TrajectoryObject* _traj,  WirCore::WorkFrameObject* _wobj)
    : TaskDialog(),traj(_traj), wobj(_wobj)
{
    this->setButtonPosition(TaskDialog::South);
    widget = new SurfaceCross();
    taskbox = new Gui::TaskView::TaskBox();
    taskbox->groupLayout()->addWidget(widget);

    Content.push_back(taskbox);

    std::string Filter("SELECT Part::Feature SUBELEMENT Face COUNT 1");
    Gui::Selection().clearSelection();
    Gui::Selection().addSelectionGate(new Gui::SelectionFilterGate(Filter.c_str()));
}

DlgTrajectoryFromSection::~DlgTrajectoryFromSection()
{
    Gui::Selection().clearSelection();
}
bool DlgTrajectoryFromSection::accept()
{
    m_d.clear();
    m_d = widget->getPlanes();
    if(widget->GetPlaneType() == 0)
         m_plane = DlgTrajectoryFromSection::XY;
     else if(widget->GetPlaneType() == 1)
         m_plane = DlgTrajectoryFromSection::XZ;
     else
         m_plane = DlgTrajectoryFromSection::YZ;
    m_trsf = widget->getObjtrsf();
    return generateTrajectory();
}

bool DlgTrajectoryFromSection::generateTrajectory()
{
    std::vector<App::DocumentObject*> obj = Gui::Selection().getObjectsOfType(Part::Feature::getClassTypeId());
    if (obj.size() == 0)
    {
        Base::Console().Error("no object selected");
        return false;
    }
    if (obj.size() > 1)
    {
        Base::Console().Error("selected error");
        return false;
    }


    Part::Feature *base = dynamic_cast<Part::Feature*>(obj[0]);
    const Part::TopoShape& TopShape = base->Shape.getShape();

    std::vector<std::string> SubVals;

    std::vector<Gui::SelectionSingleton::SelObj> sel = Gui::Selection().getSelection();
    for (std::vector<Gui::SelectionSingleton::SelObj>::const_iterator it=sel.begin();it!=sel.end();++it)
    {
        if (strcmp(it->SubName, "") != 0){
            SubVals.push_back(it->SubName);
        }
    }

    if(SubVals.size() == 0)
        return new App::DocumentObjectExecReturn("No Faces specified");

    std::vector<TopoDS_Face> faces;
    for(std::vector<std::string>::const_iterator it = SubVals.begin(); it!=SubVals.end(); ++it){
        TopoDS_Face face = TopoDS::Face(TopShape.getSubShape(it->c_str()));
        faces.push_back(face);
    }

    //gp_XYZ ydir;
    double a = 0, b = 0, c = 0;
    switch(m_plane) {
    case DlgTrajectoryFromSection::XY:
        c = 1.0;
        break;
    case DlgTrajectoryFromSection::XZ:
        b = 1.0;
        break;
    case DlgTrajectoryFromSection::YZ:
        a = 1.0;
        break;
    }

    TopoDS_Shape FusedShape;

//    if (faces.size() > 1)
//    {
//        FusedShape = BRepAlgoAPI_Fuse(faces[0],faces[1]);
//    }
//    else
//    {
        FusedShape = faces[0];
//    }



    std::vector<TopoDS_Edge> edges;

    //  for(std::vector<TopoDS_Face>::const_iterator it = faces.begin(); it != faces.end(); ++it) {
    WirCoreGui::IntersectSurface is(a, b, c, FusedShape, m_trsf);
    TopoDS_Compound comp;
    BRep_Builder builder;
    builder.MakeCompound(comp);
    for(size_t i = 0; i < m_d.size(); i++) {
        const std::list<TopoDS_Wire>& wires = is.slice(m_d[i]);

        for(std::list<TopoDS_Wire>::const_iterator wit = wires.begin(); wit != wires.end(); ++wit) {
            if(!wit->IsNull())
                builder.Add(comp, *wit);
        }
    }
    TopoDS_Shape shape(comp);
    TopTools_IndexedMapOfShape t_edges;
    TopExp::MapShapes(shape, TopAbs_EDGE, t_edges);

    for(Standard_Integer i = 1; i <= t_edges.Extent(); i++)
    {
        TopoDS_Edge edge = TopoDS::Edge(t_edges.FindKey(i));
        edges.push_back(edge);
    }

    TopTools_IndexedDataMapOfShapeListOfShape anEFsMap;
    TopExp::MapShapesAndAncestors (TopShape.getShape(), TopAbs_EDGE, TopAbs_FACE, anEFsMap);

    gp_XYZ xdir;

    auto getRotation = [&](const gp_Pnt& p,
            const gp_Vec& v,
            Base::Rotation& rot){
        gp_XYZ zdir;
        for(std::vector<TopoDS_Face>::const_iterator it = faces.begin(); it != faces.end(); ++it) {
            TopoDS_Face face = (*it);
            Handle_Geom_Surface surface = BRep_Tool::Surface(face);
            GeomAPI_ProjectPointOnSurf proj(p, surface);
            Standard_Real U, V;
            proj.LowerDistanceParameters(U, V);
            gp_Dir tdir;
            BOPTools_AlgoTools3D::GetNormalToSurface(surface, U, V, tdir);
            if(face.Orientation() == TopAbs_Orientation::TopAbs_FORWARD){
                tdir = -tdir;
            }
            gp_XYZ txyz(tdir.X(), tdir.Y(), tdir.Z());
            zdir += txyz;

            gp_Pln slicePlane(a, b, c, 0);
            slicePlane.Transform(m_trsf);

            gp_Ax1 xaxis = slicePlane.Axis();
            gp_Dir dir = xaxis.Direction();
            //   gp_XYZ
            xdir = dir.XYZ();

        }
        zdir.Normalize();
        //   gp_XYZ xdir(v.X(), v.Y(), v.Z());
        gp_XYZ ydir = zdir.Crossed(xdir);

        Base::Matrix4D mat;
        mat[0][0] = xdir.X();
        mat[1][0] = xdir.Y();
        mat[2][0] = xdir.Z();
        mat[3][0] = 0;

        mat[0][1] = ydir.X();
        mat[1][1] = ydir.Y();
        mat[2][1] = ydir.Z();
        mat[3][1] = 0;

        mat[0][2] = zdir.X();
        mat[1][2] = zdir.Y();
        mat[2][2] = zdir.Z();
        mat[3][2] = 0;

        rot.setValue(mat);

    };

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    auto toolObject  = _station->GetActiveToolObject();


    bool first = true;
    bool edgeFirst = true;
    bool reversed = false;
    for(std::vector<TopoDS_Edge>::const_iterator it= edges.begin(); it!= edges.end(); ++it)
    {
        edgeFirst = true;
        BRepAdaptor_Curve adapt(*it);
        switch(adapt.GetType())
        {
        case GeomAbs_Line:
        {
            NCollection_List<TopoDS_Shape> pfaces;

            Base::Console().Message("GeomAbs_line: %d\n", adapt.GetType());
            adapt.Edge();
            adapt.Edge();
            gp_Pnt P1 = adapt.Value(adapt.FirstParameter());
            gp_Pnt P2 = adapt.Value(adapt.LastParameter());

            gp_Vec V1;
            adapt.D1(adapt.FirstParameter(), P1, V1);

            gp_Vec V2;
            adapt.D1(adapt.LastParameter(), P2, V2);
            Base::Rotation R1;
            Base::Rotation R2;

            getRotation(P1, V1, R1);
            getRotation(P2, V2, R2);
            if(first) {

                Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P1.X(), P1.Y(), P1.Z()), R1));

                traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                first = false;
            }

            Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P2.X(), P2.Y(), P2.Z()), R2));
            traj->addWaypointToTrajectory(_placement, wobj, toolObject);
            break;

            break;
        }
        case GeomAbs_BSplineCurve:
        {
            Base::Console().Message("GeomAbs_BSplineCurve: %d\n", adapt.GetType());
            Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
            Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
            // Standard_Real NbrSegments =Round(Length/SegValue.getValue());
            Standard_Real NbrSegments = Round(Length/0.5);
            Standard_Real beg = adapt.FirstParameter();
            Standard_Real end = adapt.LastParameter();
            Standard_Real stp = ParLength/NbrSegments;
            //Standard_Real stp = ui->sampleStep->value().getValue();

            //  bool reversed = ((*it).Orientation() == TopAbs_REVERSED);
            if(reversed) {
                Standard_Real temp = beg;
                beg = end;
                end = temp;
                stp = -stp;
            }
            first ? first = false : beg += stp;

            for(;(reversed ? beg > end : beg < end); beg += stp) {
                gp_Pnt P = adapt.Value(beg);
                //points.push_back(Base::Vector3f(P.X(), P.Y(), P.Z()));

                gp_Vec V;
                adapt.D1(beg, P, V);
                Base::Rotation rot;
                getRotation(P, V, rot);

                Base::Vector3d trans(P.X(), P.Y(), P.Z());

                Base::Placement pla(trans, rot);
                Base::Placement wpos = pla;

                Base::Placement _placement(wobj->placement().getValue().inverse()*wpos);
                traj->addWaypointToTrajectory(_placement, wobj, toolObject);
            }
            break;
        }

        case GeomAbs_Circle:
        {

            Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
            Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
            //Standard_Real NbrSegments = Round(Length/SegValue.getValue());
            Standard_Real NbrSegments = Round(Length/0.5);
            Standard_Real stp = ParLength/NbrSegments;
            //Standard_Real stp = ui->sampleStep->value().getValue();

            Standard_Real beg = adapt.FirstParameter();
            Standard_Real end = adapt.LastParameter();
            //    bool reversed = ((*it).Orientation() == TopAbs_REVERSED);
            if(reversed) {
                Standard_Real temp = beg;
                beg = end;
                end = temp;
                stp = -stp;
            }
            first ? first = false : beg += stp;
            for(; (reversed ? beg > end : beg < end); beg += stp)
            {
                gp_Pnt P = adapt.Value(beg);
                //points.push_back(Base::Vector3f(P.X(), P.Y(), P.Z()));

                gp_Vec V;
                adapt.D1(beg, P, V);

                Base::Rotation rot;

                getRotation(P, V, rot);

                Base::Vector3d trans(P.X(), P.Y(), P.Z());
                // Base::Rotation rot;
                //   rot.setYawPitchRoll(0, 0, 0);

                Base::Placement pla(trans, rot);
                Base::Placement wpos = pla;
                Base::Placement _placement(wobj->placement().getValue().inverse()*wpos);
                traj->addWaypointToTrajectory(_placement, wobj, toolObject);
            }
            Base::Console().Message("GeomAbs_Circle: %d\n", adapt.GetType());
            break;
        }
        default:
            throw Base::TypeError("Unknown Edge Type in WirOlp::TrajectoryObjFromEdge::execute()");
        }
        reversed = 1 - reversed;
    }

    return true;
}

bool DlgTrajectoryFromSection::reject()
{
    return true;
}

void DlgTrajectoryFromSection::helpRequested()
{

}

void DlgTrajectoryFromSection::modifyStandardButtons(QDialogButtonBox* button)
{
    taskbox->groupLayout()->addWidget(button);
    //button->hide();
}






#include "moc_DlgTrajectoryFromSection.cpp"
