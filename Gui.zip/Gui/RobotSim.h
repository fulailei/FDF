#ifndef WIRCORE_TASKVIEW_ROBOTSIM_H
#define WIRCORE_TASKVIEW_ROBOTSIM_H

#include <Base/UnitsApi.h>


#include <Gui/TaskView/TaskView.h>
#include <Gui/Selection.h>

#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/Simulation.h>

#include "ViewProviderRobotObject.h"


class Ui_RobotSim;

namespace App {
class Property;
}

namespace Gui {
class ViewProvider;
}

namespace WirCoreGui {



class RobotSim : public Gui::TaskView::TaskBox
{
    Q_OBJECT

public:
    RobotSim(WirCore::RobotObject *pcRobotObject,
             WirCore::TrajectoryObject *pcTrajectoryObject,
             QWidget *parent = 0);


    ~RobotSim();
    /// Observer message from the Selection
    void OnChange(Gui::SelectionSingleton::SubjectType &rCaller,
                  Gui::SelectionSingleton::MessageType Reason);

    static int isCollision;
private Q_SLOTS:
    void start(void);
    void stop(void);
    void run(void);
    void back(void);
    void forward(void);
    void end(void);

    void timerDone(void);
    void valueChanged ( int value );
    void valueChanged ( double d );

Q_SIGNALS:
    void axisChanged(float A1,float A2,float A3,float A4,float A5,float A6,const Base::Placement &Tcp);

protected:
    void setTo(void);
    void viewTool(const Base::Placement pos);

    QTimer *timer;

    WirCore::Simulation sim;
    WirCore::RobotObject *pcRobot;
    ViewProviderRobotObject *ViewProv;

    bool Run;
    bool block;

    float timePos;
    float duration;

private:
    QWidget* proxy;
    Ui_RobotSim* ui;
};

} //namespace PartDesignGui

#endif // GUI_TASKVIEW_TASKAPPERANCE_H
