lupdate ../../*.ui ../../*.h ../../*.cpp -ts WirCore_zh-CN.ts
