<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>CmdWirCoreAddtoTrajtory</name>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="243"/>
        <source>WirCore</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="244"/>
        <location filename="../../CommandPointOperate.cpp" line="245"/>
        <source>add to Trajectory</source>
        <translation>添加轨迹</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCollisionCheck</name>
    <message>
        <location filename="../../CommandCollisions.cpp" line="136"/>
        <source>WirCore</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../CommandCollisions.cpp" line="137"/>
        <source>CollisionCheck</source>
        <translation>碰撞检测</translation>
    </message>
    <message>
        <location filename="../../CommandCollisions.cpp" line="138"/>
        <source>Whether collision detection is valid for the whole scene</source>
        <translation>场景中是否执行碰撞检测</translation>
    </message>
    <message>
        <source>CollisonCheck</source>
        <translation type="vanished">碰撞检测</translation>
    </message>
    <message>
        <source>CollisonCheck1</source>
        <translation type="vanished">碰撞检测</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCollisionMatrix</name>
    <message>
        <location filename="../../CommandCollisions.cpp" line="245"/>
        <source>WirCore</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../CommandCollisions.cpp" line="246"/>
        <source>CollisionMatrix</source>
        <translation>碰撞矩阵</translation>
    </message>
    <message>
        <location filename="../../CommandCollisions.cpp" line="247"/>
        <source>Collision Matrix Setting for the whole scene</source>
        <translation>碰撞矩阵设置</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCoordinateSystem</name>
    <message>
        <location filename="../../Command.cpp" line="584"/>
        <source>CoordinateSystem</source>
        <translation>坐标系</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="585"/>
        <source>Create
 coordinate system
</source>
        <translation>添加坐标系</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="586"/>
        <source>Create a new coordinate system</source>
        <translation>添加新的坐标系</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCopyPoint</name>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="180"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="181"/>
        <source>Copy to</source>
        <translation type="unfinished">拷贝到</translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="182"/>
        <source>Copy Point</source>
        <translation type="unfinished">拷贝目标点</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCopyWayPoint</name>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="212"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="213"/>
        <source>Copy to</source>
        <translation type="unfinished">拷贝到</translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="214"/>
        <source>Copy WayPoint</source>
        <translation type="unfinished">拷贝轨迹点</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCreateEmptyTrajectory</name>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="65"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="66"/>
        <source>Create
 Empty Trajectory
</source>
        <translation>添加空轨迹</translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="67"/>
        <source>Create Empty Trajectory.</source>
        <translation>添加空轨迹</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCreateReferenceFrame</name>
    <message>
        <location filename="../../CommandCreateReferenceFrame.cpp" line="59"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandCreateReferenceFrame.cpp" line="60"/>
        <source>Create
 Reference Frame
</source>
        <translation>添加坐标系</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCreateToolObjectReferenceFrame</name>
    <message>
        <location filename="../../CommandCreateReferenceFrame.cpp" line="158"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandCreateReferenceFrame.cpp" line="159"/>
        <source>Create a ToolObject Reference Frame</source>
        <translation>添加工具坐标系</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreCreateWorkObjectReferenceFrame</name>
    <message>
        <location filename="../../CommandCreateReferenceFrame.cpp" line="98"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandCreateReferenceFrame.cpp" line="99"/>
        <source>Create a WorkObject Reference Frame</source>
        <translation>添加工件坐标系</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreDeviceLibrary</name>
    <message>
        <location filename="../../Command.cpp" line="554"/>
        <source>Create Workstation</source>
        <translation>添加工作站</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="555"/>
        <source>&amp;Device
 Library
</source>
        <translation>模型库</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="556"/>
        <location filename="../../Command.cpp" line="558"/>
        <source>Import a device in the active document</source>
        <translation>添加设备到激活的文档</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandClose</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="268"/>
        <location filename="../../CommandFreeHand.cpp" line="269"/>
        <source>FreehandClose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="270"/>
        <location filename="../../CommandFreeHand.cpp" line="271"/>
        <source>Close Freehand the selected object in the 3d view</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandJogJoint</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="191"/>
        <source>Freehand</source>
        <translatorcomment>Freehand</translatorcomment>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="192"/>
        <source>FreehandJogJoint</source>
        <translation>手动关节</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="193"/>
        <location filename="../../CommandFreeHand.cpp" line="194"/>
        <source>JogJoint the selected object in the 3d view</source>
        <translation>移动机器人的各轴</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandJogLinear</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="230"/>
        <source>Freehand</source>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="231"/>
        <source>FreehandJogLinear</source>
        <translation>手动线性</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="232"/>
        <location filename="../../CommandFreeHand.cpp" line="233"/>
        <source>JogLinear the selected object in the 3d view</source>
        <translation>在当前工具定义的坐标系中移动</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandLocalCS</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="74"/>
        <source>Freehand</source>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="75"/>
        <source>LocalCS</source>
        <translation>本地坐标系</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="76"/>
        <location filename="../../CommandFreeHand.cpp" line="77"/>
        <source>LocalCS of the selected object in the 3d view</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandMove</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="113"/>
        <source>Freehand</source>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="114"/>
        <source>Move</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="115"/>
        <location filename="../../CommandFreeHand.cpp" line="116"/>
        <source>Move the selected object in the 3d view</source>
        <translation>在三维视图中移动选中物体</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandRotate</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="152"/>
        <source>Freehand</source>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="153"/>
        <source>FreehandRotate</source>
        <translation>旋转</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="154"/>
        <location filename="../../CommandFreeHand.cpp" line="155"/>
        <source>Rotate the selected object in the 3d view</source>
        <translation>在三维视图中旋转选中物体</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreFreehandWorldCS</name>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="35"/>
        <source>Freehand</source>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="36"/>
        <location filename="../../Workbench.cpp" line="419"/>
        <location filename="../../Workbench.cpp" line="661"/>
        <source>WorldCS</source>
        <translation>大地坐标系</translation>
    </message>
    <message>
        <location filename="../../CommandFreeHand.cpp" line="37"/>
        <location filename="../../CommandFreeHand.cpp" line="38"/>
        <source>WorldCS of the selected object in the 3d view</source>
        <translation>三维视图中选中物体处于大地坐标系</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="420"/>
        <location filename="../../Workbench.cpp" line="662"/>
        <source>LocalCS</source>
        <translation>本地坐标系</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreGraphToolsFrameSize</name>
    <message>
        <source>GraphToolsFrameSize</source>
        <translation type="vanished">图形工具</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="199"/>
        <source>GraphTools</source>
        <translation>图形工具</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="200"/>
        <location filename="../../Workbench.cpp" line="529"/>
        <source>FrameSize</source>
        <translation>框架尺寸</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="226"/>
        <source>Large</source>
        <translation>大</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="227"/>
        <source>Medium</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="228"/>
        <source>Small</source>
        <translation>小</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreGraphToolsShowHide</name>
    <message>
        <source>GraphToolsShowHide</source>
        <translation type="vanished">图形工具</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="66"/>
        <source>GraphTools</source>
        <translation>图形工具</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="67"/>
        <location filename="../../Workbench.cpp" line="520"/>
        <source>Show/Hide</source>
        <translation>显示/隐藏</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="97"/>
        <source>AllGeometries</source>
        <translation>所有部件</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="98"/>
        <source>AllPaths</source>
        <translation>全部路径</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="99"/>
        <source>AllTargets</source>
        <translation>所有目标点</translation>
    </message>
    <message>
        <location filename="../../CommandGraphicsTools.cpp" line="100"/>
        <source>AllFrames</source>
        <translation>所有坐标系</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreImportGeometry</name>
    <message>
        <location filename="../../Command.cpp" line="454"/>
        <source>Create Workstation</source>
        <translation>添加工作站</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="455"/>
        <source>&amp;Import
 Geometry
</source>
        <translation>&amp;添加模型</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="456"/>
        <location filename="../../Command.cpp" line="458"/>
        <source>Import a geometry in the active document</source>
        <translation>在激活的文档中添加模型</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="468"/>
        <source>Supported formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="469"/>
        <source>All files (*.*)</source>
        <translation>所有文件(*.*)</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreInsertPoint</name>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="40"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="41"/>
        <source>InsertPoint</source>
        <translation>插入目标点</translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="42"/>
        <source>Insert a point into the specify workobject.</source>
        <translation>在选中的工件坐标系中插入目标点</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreInsertRobotTcp</name>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="91"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="92"/>
        <source>InsertTcpPoint</source>
        <translation>插入机器人末端点</translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="93"/>
        <source>Insert a robot Tcp point into the specify workobject.</source>
        <translation>在选中的工件坐标系中插入机器人末端位置的目标点</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreInstallToRobot</name>
    <message>
        <location filename="../../Command.cpp" line="376"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="377"/>
        <source>Install part to Robot</source>
        <translation>安装到</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreMoveWayPoint</name>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="281"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="282"/>
        <source>Move to</source>
        <translation>移动到</translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="283"/>
        <source>Move WayPoint</source>
        <translation>移动轨迹点</translation>
    </message>
</context>
<context>
    <name>CmdWirCorePointsConvert</name>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="35"/>
        <source>Points</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="36"/>
        <source>Convert to points...</source>
        <translation>指定坐标系准换成点云</translation>
    </message>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="37"/>
        <location filename="../../CommandPointCloud.cpp" line="39"/>
        <source>Convert to points</source>
        <translation>转换成点云</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreRobotInsertAbb4600</name>
    <message>
        <location filename="../../CommandInsertRobot.cpp" line="48"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandInsertRobot.cpp" line="49"/>
        <source>Abb4600</source>
        <translation>Abb4600</translation>
    </message>
    <message>
        <location filename="../../CommandInsertRobot.cpp" line="50"/>
        <source>Insert a Abb 4600 into the document.</source>
        <translation>插入Abb4600</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreRobotLibrary</name>
    <message>
        <location filename="../../Command.cpp" line="528"/>
        <source>Create Workstation</source>
        <translation>添加工作站</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="529"/>
        <source>&amp;Robot
 Library
</source>
        <translation>机器人库</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="530"/>
        <location filename="../../Command.cpp" line="532"/>
        <source>Import a robot in the active document</source>
        <translation>在激活的文档中插入机器人</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreSetPosition</name>
    <message>
        <location filename="../../Command.cpp" line="641"/>
        <location filename="../../Command.cpp" line="642"/>
        <location filename="../../Command.cpp" line="643"/>
        <location filename="../../Command.cpp" line="644"/>
        <location filename="../../Command.cpp" line="667"/>
        <source>SetPosition</source>
        <translation>设定位置</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="668"/>
        <source>OffsetPosition</source>
        <translation>移动位置</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="669"/>
        <source>RotatePosition</source>
        <translation>旋转位置</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreSimulateTrajtory</name>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="365"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="366"/>
        <source>Simulate Trajtory
</source>
        <translation>仿真</translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="367"/>
        <source>Simulate Trajectory.</source>
        <translation>仿真.</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreSingleCollisionCheck</name>
    <message>
        <location filename="../../CommandCollisions.cpp" line="313"/>
        <source>WirCore</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../CommandCollisions.cpp" line="314"/>
        <source>SingleCollisionCheck</source>
        <translation>单次碰撞检测</translation>
    </message>
    <message>
        <location filename="../../CommandCollisions.cpp" line="315"/>
        <source>Single collision check</source>
        <translation>单次碰撞检测</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreTrajectoryFromEdge</name>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="111"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="112"/>
        <source>Create Trajectory 
 From Edge
</source>
        <translation>通过一条线生成轨迹</translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="113"/>
        <source>Create Trajectory From Edge.</source>
        <translation>通过一条线生成轨迹.</translation>
    </message>
</context>
<context>
    <name>CmdWirCoreTrajectoryFromSection</name>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="161"/>
        <source>WirCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="162"/>
        <source>Create Trajectory 
 From Section
</source>
        <translation>通过一个切面生成轨迹</translation>
    </message>
    <message>
        <location filename="../../CommandTrajectory.cpp" line="163"/>
        <source>Create Trajectory From Section.</source>
        <translation>通过一个切面生成轨迹.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../Command.cpp" line="171"/>
        <source>Open document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="401"/>
        <location filename="../../Command.cpp" line="409"/>
        <location filename="../../CommandPointOperate.cpp" line="58"/>
        <location filename="../../CommandPointOperate.cpp" line="109"/>
        <source>Wrong Selection</source>
        <translation>错误的选择对象</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="402"/>
        <source>Select one Part</source>
        <translation>请选择一个零件</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="410"/>
        <source>Select one Part without link parts</source>
        <translation>请选择一个没有被包含的零件</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="493"/>
        <source>Import geometry</source>
        <translation>添加模型</translation>
    </message>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="46"/>
        <source>Distance</source>
        <translation>距离</translation>
    </message>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="47"/>
        <source>Enter maximum distance:</source>
        <translation>输入最大距离：</translation>
    </message>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="61"/>
        <source>CS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandPointCloud.cpp" line="62"/>
        <source>cs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommandPointOperate.cpp" line="59"/>
        <location filename="../../CommandPointOperate.cpp" line="110"/>
        <source>Select one Work Frame</source>
        <translation>请选择一个坐标系</translation>
    </message>
    <message>
        <location filename="../../DlgGenProgram.cpp" line="59"/>
        <source>Please make sure there is at least one robot object.</source>
        <translation>清选择一个机器人</translation>
    </message>
    <message>
        <location filename="../../DlgGenProgram.cpp" line="65"/>
        <source>Please make sure there is at least one trajectory object.</source>
        <translation>请选择一条轨迹</translation>
    </message>
    <message>
        <location filename="../../ViewProviderDatum.cpp" line="90"/>
        <source>Coordinate System</source>
        <translation>坐标系</translation>
    </message>
    <message>
        <location filename="../../ViewProviderDatum.cpp" line="170"/>
        <source>Line</source>
        <translation>线</translation>
    </message>
    <message>
        <location filename="../../ViewProviderDatum.cpp" line="176"/>
        <source>Plane</source>
        <translation>面</translation>
    </message>
    <message>
        <location filename="../../ViewProviderDatum.cpp" line="182"/>
        <source>Point</source>
        <translation>目标点</translation>
    </message>
    <message>
        <location filename="../../ViewProviderRobotObject.cpp" line="117"/>
        <source>Set to home position</source>
        <translation>回到初始位姿</translation>
    </message>
    <message>
        <location filename="../../ViewProviderTrajectory.cpp" line="211"/>
        <source>add transition point</source>
        <translation>添加过渡点</translation>
    </message>
    <message>
        <location filename="../../ViewProviderTrajectory.cpp" line="212"/>
        <source>Link Trajectory</source>
        <translation>连接的轨迹</translation>
    </message>
    <message>
        <source>Set active Tool</source>
        <translation type="vanished">设置激活的工具</translation>
    </message>
    <message>
        <source>Set active Wobj</source>
        <translation type="vanished">设置激活的工件</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="196"/>
        <location filename="../../Workbench.cpp" line="645"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="229"/>
        <location filename="../../Workbench.cpp" line="647"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="241"/>
        <location filename="../../Workbench.cpp" line="648"/>
        <source>Create Workstation</source>
        <translation>添加工作站</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="262"/>
        <location filename="../../Workbench.cpp" line="649"/>
        <source>Trajectory programming</source>
        <translation>轨迹编程</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="300"/>
        <location filename="../../Workbench.cpp" line="658"/>
        <source>Setting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="408"/>
        <location filename="../../Workbench.cpp" line="660"/>
        <source>Freehand</source>
        <translation>Freehand</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="514"/>
        <location filename="../../Workbench.cpp" line="663"/>
        <source>Graphics Tools</source>
        <translation>图形设置</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="542"/>
        <location filename="../../Workbench.cpp" line="625"/>
        <source>Model</source>
        <translation>模型</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="545"/>
        <location filename="../../Workbench.cpp" line="668"/>
        <source>Part</source>
        <translation>实体</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="563"/>
        <location filename="../../Workbench.cpp" line="669"/>
        <source>PointCloud</source>
        <translation>点云</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="583"/>
        <location filename="../../Workbench.cpp" line="626"/>
        <source>Simulation</source>
        <translation>仿真模拟</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="587"/>
        <location filename="../../Workbench.cpp" line="671"/>
        <source>Collision</source>
        <translation>碰撞</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="606"/>
        <source>Simulate Trajectory</source>
        <translation>轨迹仿真</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="627"/>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="646"/>
        <source>&amp;New</source>
        <translation>&amp;新建</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="650"/>
        <source>Insert Point</source>
        <translation>插入目标点</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="651"/>
        <source>Create
 Empty Trajectory
</source>
        <translation>添加空轨迹</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="652"/>
        <source>Create
 Reference Frame
</source>
        <translation>添加坐标系</translation>
    </message>
    <message>
        <source>Create Trajectory</source>
        <translation type="vanished">添加空轨迹</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="664"/>
        <source>Show/Hide</source>
        <translation>显示/隐藏</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="665"/>
        <source>FrameSize</source>
        <translation>框架尺寸</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="672"/>
        <source>SimulateTrajectory</source>
        <translation>轨迹仿真</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="194"/>
        <location filename="../../Workbench.cpp" line="624"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
</context>
<context>
    <name>RobotOptions</name>
    <message>
        <location filename="../../RobotOptions.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="22"/>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="69"/>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="116"/>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="163"/>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="210"/>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="257"/>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="314"/>
        <source>TCP: (200.23,300.23,400.23,234,343,343)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="331"/>
        <source>Tool: (0,0,400,0,0,0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotOptions.ui" line="347"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StdCmdNew</name>
    <message>
        <location filename="../../Command.cpp" line="88"/>
        <source>Unnamed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StdCmdOpen</name>
    <message>
        <location filename="../../Command.cpp" line="180"/>
        <source>Cannot open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="181"/>
        <source>Loading the file %1 is not supported</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Std_Delete</name>
    <message>
        <location filename="../../Command.cpp" line="291"/>
        <source>These items are linked to items selected for deletion and might break.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="303"/>
        <source>These items are selected for deletion, but are not in the active document.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="308"/>
        <source>Are you sure you want to continue?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="312"/>
        <source>Delete Selection Issues</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>TrajFromEdgeParameter</name>
    <message>
        <location filename="../../TrajFromEdgeParameter.ui" line="20"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../TrajFromEdgeParameter.ui" line="34"/>
        <source>Edge</source>
        <translation>线</translation>
    </message>
    <message>
        <location filename="../../TrajFromEdgeParameter.ui" line="55"/>
        <source>Face </source>
        <translation>面</translation>
    </message>
    <message>
        <location filename="../../TrajFromEdgeParameter.ui" line="76"/>
        <source>Sizing Value:</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WirCoreCmdDelete</name>
    <message>
        <location filename="../../Command.cpp" line="199"/>
        <source>WirCore</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="200"/>
        <source>&amp;Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="201"/>
        <location filename="../../Command.cpp" line="203"/>
        <source>Deletes the selected objects</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WirCoreCmdNew</name>
    <message>
        <location filename="../../Command.cpp" line="74"/>
        <source>File</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="75"/>
        <source>&amp;New</source>
        <translation>&amp;新建</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="76"/>
        <location filename="../../Command.cpp" line="78"/>
        <source>Create a new empty document</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WirCoreCmdOpen</name>
    <message>
        <location filename="../../Command.cpp" line="117"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="118"/>
        <source>&amp;Open Example...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="119"/>
        <location filename="../../Command.cpp" line="121"/>
        <source>Open a example file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="132"/>
        <source>Supported formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../Command.cpp" line="133"/>
        <source>All files (*.*)</source>
        <translation type="unfinished">所有文件(*.*)</translation>
    </message>
</context>
<context>
    <name>WirCoreGui::DlgFindRobot</name>
    <message>
        <location filename="../../DlgFindRobot.ui" line="14"/>
        <source>List</source>
        <translation>列表</translation>
    </message>
    <message>
        <location filename="../../DlgFindRobot.ui" line="32"/>
        <source>Search</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="../../DlgFindRobot.ui" line="39"/>
        <source>A search pattern to filter the results above</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgFindRobot.cpp" line="69"/>
        <source>No selection</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../../DlgFindRobot.cpp" line="69"/>
        <source>Please select an object from the list</source>
        <translation>请在列表中选择一项</translation>
    </message>
</context>
<context>
    <name>WirCoreGui::DlgGenProgram</name>
    <message>
        <location filename="../../DlgGenProgram.ui" line="14"/>
        <source>Program Settings</source>
        <translation>仿真设置</translation>
    </message>
    <message>
        <location filename="../../DlgGenProgram.ui" line="29"/>
        <source>Robot:</source>
        <translation>机器人：</translation>
    </message>
    <message>
        <location filename="../../DlgGenProgram.ui" line="36"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../DlgGenProgram.ui" line="46"/>
        <source>Trajectory:</source>
        <translation>轨迹：</translation>
    </message>
    <message>
        <location filename="../../DlgGenProgram.ui" line="56"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>WirCoreGui::DlgRobotSimulate</name>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="20"/>
        <source>Simulation</source>
        <translation>仿真模拟</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="67"/>
        <source>reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="105"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="143"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="178"/>
        <source>collison stop</source>
        <translation>碰撞即停</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="197"/>
        <location filename="../../DlgRobotSimulate.ui" line="204"/>
        <source>mim</source>
        <translation>最低</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="209"/>
        <source>low</source>
        <translation>较低</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="214"/>
        <source>common</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="219"/>
        <source>high</source>
        <translation>较高</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="224"/>
        <source>max</source>
        <translation>最高</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="232"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="304"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="338"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="372"/>
        <source>&gt;|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="390"/>
        <source>Time:</source>
        <translation>时刻：</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="402"/>
        <source>:::::::::::::::::::::::::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="409"/>
        <source>TargetsStats:</source>
        <translation>轨迹状态：</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="416"/>
        <source>Collision        :</source>
        <translation>碰撞检测：</translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="479"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="484"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="489"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="494"/>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgRobotSimulate.ui" line="499"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WirCoreGui::DlgSelActiveObj</name>
    <message>
        <location filename="../../DlgSelActiveObj.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgSelActiveObj.ui" line="52"/>
        <source>workstation</source>
        <translation>工作站</translation>
    </message>
    <message>
        <location filename="../../DlgSelActiveObj.ui" line="59"/>
        <source>objectframe</source>
        <translation>工件坐标系</translation>
    </message>
    <message>
        <location filename="../../DlgSelActiveObj.ui" line="66"/>
        <source>toolframe</source>
        <translation>工具坐标系</translation>
    </message>
    <message>
        <source>Station</source>
        <translation type="vanished">工作站</translation>
    </message>
    <message>
        <source>ToolObj</source>
        <translation type="vanished">工具</translation>
    </message>
    <message>
        <source>Wobj</source>
        <translation type="vanished">工件坐标系</translation>
    </message>
</context>
<context>
    <name>WirCoreGui::Form</name>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="14"/>
        <source>CollisionMatrix</source>
        <translation>碰撞矩阵</translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="29"/>
        <source>MarkCollisionPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="36"/>
        <source>CheckHideObject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="43"/>
        <source>CheckInSim</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="53"/>
        <source>CollisionType:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="74"/>
        <source>OpneInventor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="81"/>
        <source>FCL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="109"/>
        <source>CollisionColor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="134"/>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../DlgCollisionMatrix.ui" line="150"/>
        <source>CollisionMatrix:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WirCoreGui::RobotOptions</name>
    <message>
        <location filename="../../RobotOptions.cpp" line="26"/>
        <source>RobotOptions</source>
        <translation>机器人设置</translation>
    </message>
</context>
<context>
    <name>WirCoreGui::RobotSim</name>
    <message>
        <location filename="../../RobotSim.ui" line="20"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="67"/>
        <source>|&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="98"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="129"/>
        <source>||</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="160"/>
        <source>|&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="191"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="222"/>
        <source>&gt;|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="246"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="263"/>
        <source>10 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="268"/>
        <source>50 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="273"/>
        <source>100 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="278"/>
        <source>500 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="283"/>
        <source>1 s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="301"/>
        <source>Pos: (200.23, 300.23, 400.23, 234, 343 ,343)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="327"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="332"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="337"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="342"/>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.ui" line="347"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../RobotSim.cpp" line="43"/>
        <source>Trajectory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WirCoreGui::SurfaceCross</name>
    <message>
        <location filename="../../SurfaceCross.ui" line="14"/>
        <source>Intersect surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="20"/>
        <source>Use Multiple Planes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="34"/>
        <source>Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="54"/>
        <source>Offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="73"/>
        <source>Plane settings:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="81"/>
        <source>Start Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="97"/>
        <source>XZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="104"/>
        <source>YZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="111"/>
        <source>XY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="123"/>
        <source>The step length to sample points from intersected curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../SurfaceCross.ui" line="126"/>
        <source>Sample Step:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WirCoreGui::TrajFromEdgeParameter</name>
    <message>
        <location filename="../../TrajFromEdgeParameter.cpp" line="25"/>
        <source>TrajFromEdgeParameter</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WirCoreGui::Workbench</name>
    <message>
        <source>Model</source>
        <translation type="vanished">模型</translation>
    </message>
    <message>
        <source>Simulation</source>
        <translation type="vanished">仿真模拟1</translation>
    </message>
    <message>
        <source>World</source>
        <translation type="vanished">大地坐标系</translation>
    </message>
    <message>
        <source>Local</source>
        <translation type="vanished">本地坐标系</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="456"/>
        <source>Move</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="457"/>
        <source>Rotate</source>
        <translation>旋转</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="458"/>
        <source>JogJoint</source>
        <translation>手动关节</translation>
    </message>
    <message>
        <location filename="../../Workbench.cpp" line="459"/>
        <source>JogLinear</source>
        <translation>手动线性</translation>
    </message>
    <message>
        <source>Show/Hide</source>
        <translation type="vanished">显示/隐藏</translation>
    </message>
    <message>
        <source>FrameSize</source>
        <translation type="vanished">框架尺寸</translation>
    </message>
</context>
</TS>
