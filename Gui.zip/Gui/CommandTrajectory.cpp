/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
# include <algorithm>
#endif

#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>
#include <Gui/Control.h>

#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/WorkStationGroup.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/ToolObjectReferenceFrame.h>
#include <Mod/WirCore/App/ActiveStationObject.h>
#include <Mod/WirCore/Gui/DlgGenProgram.h>
#include "DlgSimulate.h"
#include "TaskDlgRobotSimulate.h"
#include "WircoreAction.h"
#include "DlgTrajectoryFromEdge.h"
#include "DlgTrajectoryFromSection.h"
#include "ExportProgram.h"


using namespace std;
using namespace WirCoreGui;

DEF_STD_CMD_A(CmdWirCoreCreateEmptyTrajectory);

CmdWirCoreCreateEmptyTrajectory::CmdWirCoreCreateEmptyTrajectory()
    :Command("WirCore_CreateTrajectory")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Create\n Empty Trajectory\n");
    sToolTipText    = QT_TR_NOOP("Create Empty Trajectory.");
    sWhatsThis      = "WirCore_CreateEmptyTrajectory";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_CreateTrajectory";
}

void CmdWirCoreCreateEmptyTrajectory::activated(int)
{
    openCommand("Create Empty Trajectory");

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* _TrajectoryObject = new WirCore::TrajectoryObject();

    std::string n = "Trajectory";
    _TrajectoryObject->Label.setValue(n);
    doc->addObject(_TrajectoryObject, n.c_str());

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    _station->setInStation(_TrajectoryObject);

    updateActive();
    commitCommand();
}

bool CmdWirCoreCreateEmptyTrajectory::isActive(void)
{
    return hasActiveDocument();
}



//==========================================
// WirCore_CmdWirCoreTrajectoryFromEdge
//==========================================


DEF_STD_CMD_A(CmdWirCoreTrajectoryFromEdge);

CmdWirCoreTrajectoryFromEdge::CmdWirCoreTrajectoryFromEdge()
    :Command("WirCore_TrajectoryFromEdge")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Create Trajectory \n From Edge\n");
    sToolTipText    = QT_TR_NOOP("Create Trajectory From Edge.");
    sWhatsThis      = "WirCore_TrajectoryFromEdge";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_TrajectoryFromEdge";
}

void CmdWirCoreTrajectoryFromEdge::activated(int)
{
    openCommand("Create TangentPlane Trajectory");

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* _TrajectoryObject = new WirCore::TrajectoryObject();

    std::string n = "Trajectory";
    _TrajectoryObject->Label.setValue(n);
    doc->addObject(_TrajectoryObject, n.c_str());

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    _station->setInStation(_TrajectoryObject);

    WirCore::WorkFrameObject* active_wobj = _station->GetActiveWobjObject();


    Gui::TaskView::TaskDialog* dlg = new DlgTrajectoryFromEdge(_TrajectoryObject, active_wobj);
    Gui::Control().showDialog(dlg);

    updateActive();
    commitCommand();
}

bool CmdWirCoreTrajectoryFromEdge::isActive(void)
{
    return hasActiveDocument();
}

//==========================================
// WirCore_CmdWirCoreTrajectoryFromSection
//==========================================


DEF_STD_CMD_A(CmdWirCoreTrajectoryFromSection);

CmdWirCoreTrajectoryFromSection::CmdWirCoreTrajectoryFromSection()
    :Command("WirCore_TrajectoryFromSection")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Create Trajectory \n From Section\n");
    sToolTipText    = QT_TR_NOOP("Create Trajectory From Section.");
    sWhatsThis      = "WirCore_TrajectoryFromSection";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_TrajectoryFromSection";
}

void CmdWirCoreTrajectoryFromSection::activated(int)
{
    openCommand("Create TangentPlane Trajectory");

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* _TrajectoryObject = new WirCore::TrajectoryObject();

    std::string n = "Trajectory";
    _TrajectoryObject->Label.setValue(n);
    doc->addObject(_TrajectoryObject, n.c_str());

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    _station->setInStation(_TrajectoryObject);

    WirCore::WorkFrameObject* active_wobj = _station->GetActiveWobjObject();


    Gui::TaskView::TaskDialog* dlg = new DlgTrajectoryFromSection(_TrajectoryObject, active_wobj);
    Gui::Control().showDialog(dlg);

    updateActive();
    commitCommand();
}

bool CmdWirCoreTrajectoryFromSection::isActive(void)
{
    return hasActiveDocument();
}



//==========================================
// WirCore_CmdWirCoreCopyWayPoint
//==========================================

DEF_STD_CMD_AC(CmdWirCoreCopyWayPoint)

CmdWirCoreCopyWayPoint::CmdWirCoreCopyWayPoint()
    :Command("WirCore_CopyWayPoint")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Copy to");
    sToolTipText    = QT_TR_NOOP("Copy WayPoint");
    sWhatsThis      = "WirCore_CopyWayPoint";
    sStatusTip      = sToolTipText;
}

Gui::Action * CmdWirCoreCopyWayPoint::createAction(void)
{
    ObjectListAction* pcAction = new ObjectListAction
            (this, WirCore::TrajectoryObject::getClassTypeId(),Gui::getMainWindow());
    pcAction->setObjectName(QLatin1String("CopyWayPoint_TrajertoryList"));
    pcAction->setDropDownMenu(true);
    applyCommandData(this->className(), pcAction);

    return pcAction;
}

void CmdWirCoreCopyWayPoint::activated(int iMsg)
{
    Gui::ActionGroup* pcAction = dynamic_cast<Gui::ActionGroup*>(_pcAction);
    auto actions = pcAction->actions();

    QString str = actions[iMsg]->text();

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* _Trajectory = dynamic_cast<WirCore::TrajectoryObject*>(doc->getObject(str.toStdString().c_str()));

    vector<App::DocumentObject*>  vec_selWaypoint;
    vec_selWaypoint = Gui::Selection().getObjectsOfType(WirCore::WaypointObject::getClassTypeId(), doc->getName());

    std::vector<App::DocumentObject*> pointGroup;
    pointGroup = _Trajectory->WayPointList.getValues();

    openCommand("Copy Waypoint");

    for (std::vector<App::DocumentObject*>::iterator it = vec_selWaypoint.begin(); it != vec_selWaypoint.end(); ++it)
    {
        WirCore::WaypointObject*  new_waypoint = new  WirCore::WaypointObject();
        WirCore::WaypointObject*  src_waypoint = dynamic_cast<WirCore::WaypointObject*>(*it);

        new_waypoint->copyFrom(src_waypoint);
        doc->addObject(new_waypoint);
        pointGroup.push_back(new_waypoint);
    }


    _Trajectory->WayPointList.setValues(pointGroup);

    updateActive();
    commitCommand();
}

bool CmdWirCoreCopyWayPoint::isActive(void)
{
    return hasActiveDocument();
}


//==========================================
// WirCore_CmdWirCoreMoveWayPoint
//==========================================

DEF_STD_CMD_AC(CmdWirCoreMoveWayPoint)

CmdWirCoreMoveWayPoint::CmdWirCoreMoveWayPoint()
    :Command("WirCore_MoveWayPoint")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Move to");
    sToolTipText    = QT_TR_NOOP("Move WayPoint");
    sWhatsThis      = "WirCore_MoveWayPoint";
    sStatusTip      = sToolTipText;
}

Gui::Action * CmdWirCoreMoveWayPoint::createAction(void)
{
    ObjectListAction* pcAction = new ObjectListAction
            (this,WirCore::TrajectoryObject::getClassTypeId() ,Gui::getMainWindow());

    pcAction->setObjectName(QLatin1String("MoveWayPoint_TrajertoryList"));
    pcAction->setDropDownMenu(true);
    applyCommandData(this->className(), pcAction);

    return pcAction;
}

void CmdWirCoreMoveWayPoint::activated(int iMsg)
{
    Gui::ActionGroup* pcAction = dynamic_cast<Gui::ActionGroup*>(_pcAction);
    auto actions = pcAction->actions();

    QString str = actions[iMsg]->text();

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* target_Trajectory = dynamic_cast<WirCore::TrajectoryObject*>(doc->getObject(str.toStdString().c_str()));

    vector<App::DocumentObject*>  vec_selWaypoint;

    vec_selWaypoint = Gui::Selection().getObjectsOfType(WirCore::WaypointObject::getClassTypeId(), doc->getName());

    std::vector<App::DocumentObject*> target_pointGroup;
    target_pointGroup = target_Trajectory->WayPointList.getValues();

    openCommand("Move Waypoint");

    for (std::vector<App::DocumentObject*>::iterator it = vec_selWaypoint.begin(); it != vec_selWaypoint.end(); ++it)
    {
        WirCore::WaypointObject*  waypoint = dynamic_cast<WirCore::WaypointObject*>(*it);

        std::vector<App::DocumentObject*> t_vec = waypoint->getInList();
        WirCore::TrajectoryObject* src_Trajectory;
        for (std::vector<App::DocumentObject*>::iterator it = t_vec.begin();it != t_vec.end(); ++it)
        {
            if ((*it)->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
            {
                src_Trajectory = dynamic_cast<WirCore::TrajectoryObject*>(*it);
                break;
            }
        }

        std::vector<App::DocumentObject*> src_pointGroup;
        src_pointGroup = src_Trajectory->WayPointList.getValues();

        vector<App::DocumentObject*>::iterator result = find( src_pointGroup.begin( ), src_pointGroup.end( ), waypoint);
        src_pointGroup.erase(result);
        src_Trajectory->WayPointList.setValues(src_pointGroup);

        target_pointGroup.push_back(*it);
    }
    target_Trajectory->WayPointList.setValues(target_pointGroup);

    updateActive();
    commitCommand();
}

bool CmdWirCoreMoveWayPoint::isActive(void)
{
    return hasActiveDocument();
}


//==========================================
// WirCore_CmdWirCoreSimulateTrajtory
//==========================================

DEF_STD_CMD_A(CmdWirCoreSimulateTrajtory);

CmdWirCoreSimulateTrajtory::CmdWirCoreSimulateTrajtory()
    :Command("WirCore_SimulateTrajtory")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Simulate Trajtory\n");
    sToolTipText    = QT_TR_NOOP("Simulate Trajectory.");
    sWhatsThis      = "WirCore_SimulateTrajtory";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_Simulate";
}

void CmdWirCoreSimulateTrajtory::activated(int)
{
    WirCoreGui::DlgGenProgram dlg;
    if (dlg.exec() == QDialog::Accepted)
    {
        //Gui::TaskView::TaskDialog* simdlg = new WirCoreGui::DlgSimulate(dlg.m_robj,dlg.m_tobj);
        //Gui::Control().showDialog(simdlg);

        Gui::TaskView::TaskDialog* dlg1 = new WirCoreGui::TaskDlgRobotSimulate(dlg.m_robj, dlg.m_tobj);
        Gui::Control().showDialog(dlg1);
    }

    updateActive();
}

bool CmdWirCoreSimulateTrajtory::isActive(void)
{
    App::Document* doc = App::GetApplication().getActiveDocument();

    return (hasActiveDocument()
           && (doc->getObjectsOfType(WirCore::RobotObject::getClassTypeId()).size() > 0)
           && (doc->getObjectsOfType(WirCore::TrajectoryObject::getClassTypeId()).size() > 0));
}



//==========================================
// WirCore_CmdWirCoreGenProgram
//==========================================

DEF_STD_CMD_A(CmdWirCoreGenProgram);

CmdWirCoreGenProgram::CmdWirCoreGenProgram()
    :Command("WirCore_GenProgram")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Export Program\n");
    sToolTipText    = QT_TR_NOOP("Export Program.");
    sWhatsThis      = "WirCore_GenProgram";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_RobotSimulate";
}

void CmdWirCoreGenProgram::activated(int)
{
    WirCoreGui::DlgGenProgram dlg;
    if (dlg.exec() == QDialog::Accepted)
    {
       ExportProgram* program = new ExportProgram(dlg.m_robj, dlg.m_tobj);
       program->generateRobotProgram();
    }

    updateActive();
}

bool CmdWirCoreGenProgram::isActive(void)
{
    if (!hasActiveDocument())
    {
        return false;
    }
    App::Document* doc = App::GetApplication().getActiveDocument();
    return ((doc->getObjectsOfType(WirCore::RobotObject::getClassTypeId()).size() > 0)
           && (doc->getObjectsOfType(WirCore::TrajectoryObject::getClassTypeId()).size() > 0));
}


// #####################################################################################################
void CreateWirCoreCommandTrajectory(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();

    rcCmdMgr.addCommand(new CmdWirCoreCreateEmptyTrajectory());
    rcCmdMgr.addCommand(new CmdWirCoreTrajectoryFromEdge());
    rcCmdMgr.addCommand(new CmdWirCoreTrajectoryFromSection());
    rcCmdMgr.addCommand(new CmdWirCoreCopyWayPoint());
    rcCmdMgr.addCommand(new CmdWirCoreMoveWayPoint());
    rcCmdMgr.addCommand(new CmdWirCoreSimulateTrajtory());
    rcCmdMgr.addCommand(new CmdWirCoreGenProgram());
}
