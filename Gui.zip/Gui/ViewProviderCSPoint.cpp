#include "PreCompiled.h"

#ifndef _PreComp_
#include <QMenu>
#include <QAction>
#include <QActionGroup>
#include <QObject>
#endif

#include "ViewProviderCSPoint.h"

#include <Gui/Application.h>
#include <Gui/ActionFunction.h>
#include <Gui/Document.h>

#include <App/Document.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/PointObject.h>

#include "ViewProviderTrajectory.h"

using namespace Gui;
using namespace WirCoreGui;

PROPERTY_SOURCE(WirCoreGui::ViewProviderCSPoint, WirCoreGui::ViewProviderDatumCoordinateSystem)


ViewProviderCSPoint::ViewProviderCSPoint()
{
    sPixmap = "WirCore_PointObject.svg";
    ViewProviderDatum::size = -0.9;
}


ViewProviderCSPoint::~ViewProviderCSPoint()
{

}


void ViewProviderCSPoint::setupContextMenu(QMenu* menu, QObject* receiver, const char* member)
{
    ViewProviderDatumCoordinateSystem::setupContextMenu(menu, receiver, member); // need this(has Position)
}

void ViewProviderCSPoint::updateData(const App::Property* prop)
{
    WirCore::PointObject* pObj = dynamic_cast<WirCore::PointObject*>(pcObject);
    if (prop == &pObj->Placement) {
        auto group = WirCore::TrajectoryObject::getInlistTrajectory(pObj);
        for (auto obj : group) {
           obj->updateEvent.setValue(true);
        }
    }
    ViewProviderDatumCoordinateSystem::updateData(prop);
}

