#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "DlgSimulate.h"

using namespace WirCoreGui;

DlgSimulate::DlgSimulate(WirCore::RobotObject *_pcRobotObject,
                         WirCore::TrajectoryObject *_pcTrajectoryObject)
    : TaskDialog()
{
    rob = new RobotOptions(_pcRobotObject);

    trac = new RobotSim(_pcRobotObject,_pcTrajectoryObject);

    QObject::connect(trac ,SIGNAL(axisChanged(float,float,float,float,float,float,const Base::Placement &)),
                     rob  ,SLOT  (setAxis(float,float,float,float,float,float,const Base::Placement &)));

    Content.push_back(rob);
    Content.push_back(trac);
}

DlgSimulate::~DlgSimulate()
{

}

//==== calls from the TaskView ===============================================================


void DlgSimulate::open()
{
}

void DlgSimulate::clicked(int)
{

}

bool DlgSimulate::accept()
{
    return true;
}

bool DlgSimulate::reject()
{
    return true;
}

void DlgSimulate::helpRequested()
{

}


#include "moc_DlgSimulate.cpp"
