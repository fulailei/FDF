﻿/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"

#ifndef _PreComp_
# include <QFile>
# include <QDomDocument>
# include <QProcess>
# include <Quantity_Color.hxx>

# include <TopExp_Explorer.hxx>
# include <TopTools_IndexedMapOfShape.hxx>

# include <Inventor/nodes/SoCamera.h>
# include <Inventor/projectors/SbSphereSectionProjector.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/nodes/SoTransform.h>
# include <Inventor/SoPickedPoint.h>
# include <Inventor/SoFullPath.h>
#endif

#include <Gui/SoFCCSysDragger.h>
#include "ViewProviderRobotObject.h"
#include <Gui/View3DInventorViewer.h>
#include <Gui/Document.h>
#include <Mod/WirCore/App/RobotToolObject.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/ReferenceFrame.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/Part/Gui/ViewProvider.h>

#include <Mod/Mesh/App/FeatureMeshImport.h>

#include <App/Document.h>
#include <Gui/Document.h>
#include <App/VRMLObject.h>
#include <App/Part.h>
#include <Gui/Application.h>
#include <Gui/ActionFunction.h>
#include <Base/FileInfo.h>
#include <Base/Stream.h>
#include <Base/Console.h>
#include <sstream>
#include "DlgLinkConfig.h"
#include <QAction>

using namespace Gui;
using namespace WirCoreGui;
using namespace Mesh;

const char*  sdefaultLinkNames[]={"Base","Link1","Link2","Link3","Link4","Link5","Link6"};

PROPERTY_SOURCE(WirCoreGui::ViewProviderRobotObject, Gui::ViewProviderGeometryObject)


Gui::SoFCCSysDragger* WirCoreGui::ViewProviderRobotObject::jogLinearDragger = new Gui::SoFCCSysDragger();
ViewProviderRobotObject::ViewProviderRobotObject()
{
    ADD_PROPERTY(Manipulator,(0));

    sPixmap = "WirCore_RobotObject.svg";

	Gui::ViewProviderOriginGroupExtension::initExtension(this);

    jogLinearDragger->showTranslationX();
    jogLinearDragger->showTranslationY();
    jogLinearDragger->showTranslationZ();

    jogLinearDragger->draggerSize.setValue(0.2f);
    jogLinearDragger->hideRotationX();
    jogLinearDragger->hideRotationY();
    jogLinearDragger->hideRotationZ();
    jogLinearDragger->addMotionCallback(sDraggerMotionCallback,this);
}

ViewProviderRobotObject::~ViewProviderRobotObject()
{

}

void ViewProviderRobotObject::SetRobotHome()
{
    WirCore::RobotObject* robObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
    robObj->Axis1.setValue(0.0);
    robObj->Axis2.setValue(0.0);
    robObj->Axis3.setValue(0.0);
    robObj->Axis4.setValue(0.0);
    robObj->Axis5.setValue(30.0);
    robObj->Axis6.setValue(0.0);

  //  setAxisTo(0.0,0.0,0.0,0.0,30.0,0.0);
}

void ViewProviderRobotObject::setupContextMenu(QMenu *menu, QObject *receiver, const char *member)
{
   Gui::ActionFunction* func = new Gui::ActionFunction(menu);
    QAction* act = menu->addAction(QObject::tr("Set to home position"), receiver, member);

    func->trigger(act, boost::bind(&ViewProviderRobotObject::SetRobotHome, this));

    QAction* act2 = menu->addAction(QObject::tr("Set Robot Config"), receiver, member);

    func->trigger(act2, boost::bind(&ViewProviderRobotObject::SetRobotConfig, this));

    Gui::ViewProviderGeometryObject::setupContextMenu(menu, receiver, member); // need this(has Position) 

}

void ViewProviderRobotObject::SetRobotConfig()
{
    auto robObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
    std::vector<bool> _LinkConfig;
    _LinkConfig.push_back(robObj->ConfigFront.getValue());
    _LinkConfig.push_back(robObj->ConfigUp.getValue());
    _LinkConfig.push_back(robObj->ConfigFlip.getValue());

    WirCoreGui::DlgLinkConfig dlg(_LinkConfig);

    if (dlg.exec() == QDialog::Accepted)
    {
       auto workObj = WirCore::WorkStationGroup::getStationGroupOfObject(robObj);

       if (workObj != nullptr)
       {
           auto _group = workObj->getAllWaypointsInStation();
           for (auto _obj : _group)
           {
               _obj->setLinkConfig(dlg.getLinkConfig());
           }
       }
       robObj->setLinkConfig(dlg.getLinkConfig());
    }
}


bool ViewProviderRobotObject::canDragObject(App::DocumentObject* obj) const
{
    return false;
}

bool ViewProviderRobotObject::canDragObjects() const
{
    return false;
}

bool ViewProviderRobotObject::canDropObjects() const
{
     return false;
}

bool ViewProviderRobotObject::canDropObject(App::DocumentObject* obj) const
{
     return false;
}


void ViewProviderRobotObject::updateData(const App::Property* prop)
{
    WirCore::RobotObject* robObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
    std::vector<App::DocumentObject*> partGroup;
    if (prop == &robObj->RobotXmlFile) {
        partGroup = robObj->LinkList.getValues();

        if (partGroup.size() > 0)
        {
            return;
        }

        // read also from file
        const char* filename = robObj->RobotXmlFile.getValue();

        robObj->analyzeConfigZip(filename);

        App::Document* doc = pcObject->getDocument();

        for (unsigned int i = 0; i < robObj->vecJointModFile.size(); i ++)
        {
            QByteArray ba = robObj->vecJointModFile[i].toLatin1();
            const char* mod_filename = ba.data();

            Mesh::Feature *pcFeature = static_cast<Mesh::Feature *>
                    (doc->addObject("Mesh::Feature", sdefaultLinkNames[i]));

            loadMesh(pcFeature, mod_filename);

            Mesh::MeshObject kernel = pcFeature->Mesh.getValue();
//            Part::TopoShape aShape;
//            aShape.importStep(mod_filename);

            if (i > 1) //base模块不用处理
            {
                Base::Placement pla;
                int JointIndex = i - 1;

                //将模型旋转中心移动到正确位置
                pla = robObj->SpecifyJointTcp[JointIndex - 1];
                Base::Matrix4D trclMat = pla.toMatrix();
                trclMat.inverse();
                kernel.transformGeometry(trclMat);
                pcFeature->Mesh.setValue(kernel);

                pcFeature->Placement.setValue(pla);
                //记录各轴之间的转换矩阵
                Base::Placement prepla;
                if (JointIndex > 1)
                {
                    prepla = robObj->SpecifyJointTcp[JointIndex - 2];
                }

                Base::Matrix4D tmp = prepla.toMatrix();
                tmp.inverse();
                prepla.fromMatrix(tmp);
                robObj->vecJointsTransForm.push_back(prepla * pla);

            }


          //  pcFeature->Label.setValue(sdefaultLinkNames[i]);

            partGroup.push_back(static_cast<App::DocumentObject*>(pcFeature));

            if (this->extensionCanDropObject(static_cast<App::DocumentObject*>(pcFeature)))
            {
                this->extensionDropObject(static_cast<App::DocumentObject*>(pcFeature));
            }
        }
        robObj->LinkList.setValues(partGroup);
    }else if (prop == &robObj->Axis1 || prop == &robObj->Axis2 ||
              prop == &robObj->Axis3 || prop == &robObj->Axis4 ||
              prop == &robObj->Axis5 || prop == &robObj->Axis6 ||
              prop == &robObj->Placement)
    {

        setAxisTo(robObj->Axis1.getValue(), robObj->Axis2.getValue(), robObj->Axis3.getValue(),
                  robObj->Axis4.getValue(), robObj->Axis5.getValue(), robObj->Axis6.getValue());
            if (s_freehandModNum == JogLinearFreehand)
            {
                // Synchronize
                Base::Placement loc = robObj->Tcp.getValue();
                SbMatrix  M1;
                M1.setTransform(SbVec3f(loc.getPosition().x,loc.getPosition().y,loc.getPosition().z),
                                SbRotation(loc.getRotation()[0],loc.getRotation()[1],loc.getRotation()[2],loc.getRotation()[3]),
                        SbVec3f(150,150,150));
                jogLinearDragger->setMotionMatrix(M1);
            }


    }else if (prop == &robObj->Tcp) {
        App::DocumentObject* o = robObj->ToolShape.getValue<App::DocumentObject*>();
        if(o && ((o->isDerivedFrom(App::Part::getClassTypeId())) || (o->isDerivedFrom(Part::Feature::getClassTypeId()))))
        {
            auto p = dynamic_cast<App::GeoFeature *>(o);
            p->Placement.setValue(robObj->Tcp.getValue());

            if (s_freehandModNum == JogLinearFreehand)
            {
                // Synchronize
                Base::Placement loc = robObj->Tcp.getValue();
                SbMatrix  M1;
                M1.setTransform(SbVec3f(loc.getPosition().x,loc.getPosition().y,loc.getPosition().z),
                                SbRotation(loc.getRotation()[0],loc.getRotation()[1],loc.getRotation()[2],loc.getRotation()[3]),
                        SbVec3f(150,150,150));
                jogLinearDragger->setMotionMatrix(M1);
            }
        }
    }
    Gui::ViewProviderGeometryObject::updateData(prop);
}


bool ViewProviderRobotObject::extensionOnDelete(const std::vector< std::string >& ) {
    // If the group is nonempty ask the user if he wants to delete its content
    Gui::Command::doCommand(Gui::Command::Doc,
         "App.getDocument(\"%s\").getObject(\"%s\").removeObjectsFromDocument()"
         , getExtendedViewProvider()->getObject()->getDocument()->getName()
         , getExtendedViewProvider()->getObject()->getNameInDocument());
    return true;
}



void ViewProviderRobotObject::loadMesh(Mesh::Feature *pcFeature, const char* filename)
{
    Mesh::MeshObject mesh;
    MeshCore::Material mat;
    if (mesh.load(filename, &mat)) {
        Base::FileInfo file(filename);
        unsigned long segmct = mesh.countSegments();
        if (segmct > 1)
        {
            for (unsigned long i=0; i<segmct; i++)
            {
                const Mesh::Segment& group = mesh.getSegment(i);
                std::string groupName = group.getName();
                if (groupName.empty())
                    groupName = file.fileNamePure();

                std::unique_ptr<Mesh::MeshObject> segm(mesh.meshFromSegment(group.getIndices()));
                pcFeature->Mesh.swapMesh(*segm);
                pcFeature->purgeTouched();
            }
        }
        else
        {
            pcFeature->Mesh.swapMesh(mesh);
            pcFeature->purgeTouched();
        }
    }
}

void ViewProviderRobotObject::setAxisTo(float A1,float A2,float A3,float A4,float A5,float A6)
{
    //return;
    WirCore::RobotObject* robObj = static_cast<WirCore::RobotObject*>(pcObject);

    std::vector<App::DocumentObject*> partGroup;
    partGroup = robObj->LinkList.getValues();

    if (partGroup.size() <= 0)
    {
        return;
    }

    double axis[6] = {0.0};
    axis[0] = A1; axis[1] = A2;
    axis[2] = A3; axis[3] = A4;
    axis[4] = A5; axis[5] = A6;

    Base::Placement partpla/* = robObj->Placement.getValue()*/;

    Mesh::Feature* mesh = dynamic_cast<Mesh::Feature*>(partGroup[0]);
    mesh->Placement.setValue(partpla);
    for (int i = 0; i < 6; i++ )
    {
        mesh = dynamic_cast<Mesh::Feature*>(partGroup[i + 1]);

        Base::Rotation r;
        r.setValue(Base::Vector3d(0, 0, 1), axis[i] * (M_PI/180));

        Base::Placement transform( Base::Vector3d(0,0,0), r);
        partpla *= transform;

        mesh->Placement.setValue(partpla);
        if (i + 1 > robObj->vecJointsTransForm.size())
        {
            break;
        }
        partpla *= robObj->vecJointsTransForm[i];
    }

    App::DocumentObject* o = robObj->ToolShape.getValue<App::DocumentObject*>();
    if(o && ((o->isDerivedFrom(App::Part::getClassTypeId())) || (o->isDerivedFrom(Part::Feature::getClassTypeId()))))
    {
        auto p = dynamic_cast<App::GeoFeature *>(o);
        p->Placement.setValue(robObj->Tcp.getValue());
    }
}

bool ViewProviderRobotObject::setEdit(int ModNum)
{
    if (ModNum == JogLinearFreehand)
    {
        Manipulator.setValue(true);
    }
    return ViewProviderGeometryObject::setEdit(ModNum);
}

void ViewProviderRobotObject::unsetEdit(int ModNum)
{
    if (ModNum == JogLinearFreehand)
    {
        Manipulator.setValue(false);
    }
    return ViewProviderGeometryObject::unsetEdit(ModNum);
}

bool ViewProviderRobotObject::mouseMove(const SbVec2s &cursorPos, Gui::View3DInventorViewer* viewer)
{
    if (s_freehandModNum == JogJointFreehand)
    {
        if (m_isLeftBtnPressed && axisIndex < 7)
        {

            auto pRbtObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
            if (!pRbtObj)
                return false;

            auto links = pRbtObj->LinkList.getValues();
            if (links.size() >= 6)
            {
                auto obj = links[axisIndex];
                if (obj->isDerivedFrom(App::GeoFeature::getClassTypeId()))
                {
                    auto geoFeature = static_cast<App::GeoFeature *>(obj);
                    auto place = geoFeature->Placement.getValue();
                    auto gplace = geoFeature->globalPlacement();

                    //                    SbSphereSectionProjector* spinprojector = new SbSphereSectionProjector(SbSphere(SbVec3f(0, 0, 0), m_len/*0.8f*/));
                    //                    spinprojector->setViewVolume(m_pViewer->getCamera()->getViewVolume());
                    //                    SbMatrix mat = convert(gplace.toMatrix());
                    //                    spinprojector->setWorkingSpace(mat);

                    //                    SbVec2f pick;
                    //                    pick[0] = m_prePressedPos[0];
                    //                    pick[1] = m_prePressedPos[1];
                    //                    spinprojector->project(pick);

                    //                    SbVec2f curPos = (SbVec2f)cursorPos;
                    //                    SbRotation r;
                    //                    spinprojector->projectAndGetRotation(curPos, r);

                    auto spinprojector = new SbSphereSectionProjector(SbSphere(SbVec3f(0, 0, 0), 0.8f));
                    SbViewVolume volume;
                    volume.ortho(-1, 1, -1, 1, -1, 1);
                    spinprojector->setViewVolume(volume);
                    SbMatrix mat;
                    viewer->getSoRenderManager()->getCamera()->orientation.getValue().getValue(mat);
                    spinprojector->setWorkingSpace(mat);
                    SbVec2f lastpos;
                    lastpos[0] = float(m_prePressedPos[0]);
                    lastpos[1] = float(m_prePressedPos[1]);
                    spinprojector->project(lastpos);
                    SbRotation r;
                    SbVec2f vs = (SbVec2f)cursorPos;
                    spinprojector->projectAndGetRotation(vs, r);
                    float sensitivity = 2;
                    if (sensitivity > 1.0f)
                    {
                        SbVec3f axis;
                        float radians;
                        r.getValue(axis, radians);
                        radians = sensitivity * radians;
                        int delX = cursorPos[0] - m_prePressedPos[0];
                        int delY = cursorPos[1] - m_prePressedPos[1];
                        bool dir = (abs(delX) < abs(delY)) ? delY >= 0 : delX >= 0;
                        dir == true ?  radians : radians = (-radians);
                        radians = radians * 180 / M_PI;
                        switch (axisIndex)
                        {
                        case 1:
                            pRbtObj->Axis1.setValue(pRbtObj->Axis1.getValue() + radians);
                            break;
                        case 2:
                            pRbtObj->Axis2.setValue(pRbtObj->Axis2.getValue() + radians);
                            break;
                        case 3:
                            pRbtObj->Axis3.setValue(pRbtObj->Axis3.getValue() + radians);
                            break;
                        case 4:
                            pRbtObj->Axis4.setValue(pRbtObj->Axis4.getValue() + radians);
                            break;
                        case 5:
                            pRbtObj->Axis5.setValue(pRbtObj->Axis5.getValue() + radians);
                            break;
                        case 6:
                            pRbtObj->Axis6.setValue(pRbtObj->Axis6.getValue() + radians);
                            break;
                        }

                        m_prePressedPos[0] = cursorPos[0];
                        m_prePressedPos[1] = cursorPos[1];
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

bool ViewProviderRobotObject::mouseButtonPressed(int button, bool pressed, const SbVec2s & cursorPos,
                                                 const Gui::View3DInventorViewer* viewer)
{
    if (s_freehandModNum == JogJointFreehand)
    {
        if (button == 1) // LeftBtn
        {
            auto document = Application::Instance->activeDocument();
            if (!document) return false;

            m_isLeftBtnPressed = pressed;
            m_prePressedPos[0] = cursorPos[0];
            m_prePressedPos[1] = cursorPos[1];

            auto pRobObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
            if(pRobObj)
            {
                axisIndex = 0;
                for (auto obj : pRobObj->LinkList.getValues())
                {
                    auto vp = document->getViewProvider(obj);
                    if (vp)
                    {
                        auto vpObj = dynamic_cast<Gui::ViewProviderGeometryObject*>(vp);
                        if (vpObj)
                        {
                            SoPickedPointList pList = vpObj->getPickedPoints(cursorPos, *viewer);
                            int num = pList.getLength();
                            if (num)
                            {
                                //                                SoPickedPoint* point = vpObj->getPickedPoint(cursorPos, *viewer);
                                //                                m_PickPos[0] = point->getObjectPoint()[0];
                                //                                m_PickPos[1] = point->getObjectPoint()[1];
                                //                                m_PickPos[2] = point->getObjectPoint()[2];
                                //                                m_len = (double)(point->getObjectPoint().length());
                                break;
                            }
                        }
                    }
                    axisIndex++;
                }
            }
            if (axisIndex)
                return true;
        }
    }
    //    else if (s_freehandModNum == JogLinearFreehand)
    //    {
    //        Manipulator.setValue(true);
    //    }
    return false;
}

void ViewProviderRobotObject::sDraggerMotionCallback(void *data, SoDragger *dragger)
{
    static_cast<ViewProviderRobotObject*>(data)->DraggerMotionCallback(dragger);
}

void ViewProviderRobotObject::DraggerMotionCallback(SoDragger *dragger)
{
    float q0, q1, q2, q3;
    auto robObj = static_cast<WirCore::RobotObject*>(pcObject);

    auto Tcp = robObj->Tcp.getValue();
    const SbMatrix & M = dragger->getMotionMatrix ();
    SbVec3f    translation;
    SbRotation rotation;
    SbVec3f    scaleFactor;
    SbRotation scaleOrientation;
    SbVec3f    center(Tcp.getPosition().x,Tcp.getPosition().y,Tcp.getPosition().z);
    M.getTransform(translation, rotation, scaleFactor, scaleOrientation);
    rotation.getValue(q0, q1, q2, q3);
    //Base::Console().Message("M %f %f %f\n", M[3][0], M[3][1], M[3][2]);
    Base::Rotation rot(q0, q1, q2, q3);
    Base::Vector3d pos(translation[0],translation[1],translation[2]);
    robObj->Tcp.setValue(Base::Placement(pos,rot));

    // Synchronize
    auto loc = robObj->Tcp.getValue();
    SbMatrix  M1;
    M1.setTransform(SbVec3f(loc.getPosition().x,loc.getPosition().y,loc.getPosition().z),
                    SbRotation(loc.getRotation()[0],loc.getRotation()[1],loc.getRotation()[2],loc.getRotation()[3]),
            SbVec3f(150,150,150));
    jogLinearDragger->setMotionMatrix(M1);
}

void ViewProviderRobotObject::setDragger()
{
    auto document = Application::Instance->activeDocument();
    if (!document)
        return;

    auto pRbtObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
    auto links = pRbtObj->LinkList.getValues();
    if (links.size() >= 6)
    {
        auto obj = links[5]; // tcp
        Gui::ViewProvider* vp = document->getViewProvider(obj);
        if (vp)
        {
            auto loc = pRbtObj->Tcp.getValue();
            SbMatrix  M;
            M.setTransform(SbVec3f(loc.getPosition().x,loc.getPosition().y,loc.getPosition().z),
                           SbRotation(loc.getRotation()[0],loc.getRotation()[1],loc.getRotation()[2],loc.getRotation()[3]),
                    SbVec3f(150,150,150));
            jogLinearDragger->setMotionMatrix(M);
            jogLinearDragger->showTranslationX();
            jogLinearDragger->showTranslationY();
            jogLinearDragger->showTranslationZ();
            vp->getRoot()->insertChild(jogLinearDragger, 0);
        }
    }
}

void ViewProviderRobotObject::resetDragger()
{
    auto document = Application::Instance->activeDocument();
    if (!document)
        return;

    auto pRbtObj = dynamic_cast<WirCore::RobotObject*>(pcObject);
    auto links = pRbtObj->LinkList.getValues();
    if (links.size() >= 6)
    {
        auto obj = links[5]; // tcp
        auto vp = document->getViewProvider(obj);
        if (vp)
        {
            jogLinearDragger->hideTranslationX();
            jogLinearDragger->hideTranslationY();
            jogLinearDragger->hideTranslationZ();
            if (jogLinearDragger->getRefCount() == 1)
                jogLinearDragger->ref();
            vp->getRoot()->removeChild(jogLinearDragger);
        }
    }
}

void ViewProviderRobotObject::onChanged(const App::Property* prop)
{
    if (prop == &Manipulator)
    {
        if (Manipulator.getValue())
            this->setDragger();
        else
            this->resetDragger();
    }
    else
    {
        ViewProviderGeometryObject::onChanged(prop);
    }
}

bool ViewProviderRobotObject::doubleClicked(void)
{
    if (Gui::ViewProvider::s_freehandModNum == JogJointFreehand ||
            Gui::ViewProvider::s_freehandModNum == JogLinearFreehand)
    {
        Gui::Application::Instance->activeDocument()->setEdit(this, Gui::ViewProvider::s_freehandModNum);
    }
    else
    {
        Gui::Application::Instance->activeDocument()->setEdit(this, /*(int)ViewProvider::Default*/(int)Gui::ViewProvider::s_freehandModNum);
    }
    return true;
}
