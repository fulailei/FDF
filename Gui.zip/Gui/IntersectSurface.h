#ifndef WIRCORE_INTERSECTSURFACE_H
#define WIRCORE_INTERSECTSURFACE_H

#include <list>
#include <TopTools_IndexedMapOfShape.hxx>
#include <gp_Trsf.hxx>

class TopoDS_Shape;
class TopoDS_Wire;
class TopoDS_Edge;
namespace WirCoreGui {

class IntersectSurface
{
public:
    IntersectSurface(double a, double b, double c, const TopoDS_Shape& s, gp_Trsf i_rsf);
    std::list<TopoDS_Wire> slice(double d) const;

private:
    void sliceNonSolid(double d, const TopoDS_Shape&, std::list<TopoDS_Wire>& wires) const;
    void sliceSolid(double d, const TopoDS_Shape&, std::list<TopoDS_Wire>& wires) const;
    void connectEdges(const std::list<TopoDS_Edge>& edges, std::list<TopoDS_Wire>& wires) const;
    void connectWires(const TopTools_IndexedMapOfShape& wireMap, std::list<TopoDS_Wire>& wires) const;

private:
    double a,b,c;
    const TopoDS_Shape& s;

    gp_Trsf trf;
}; //IntersectSurface

}

#endif // WirCore
