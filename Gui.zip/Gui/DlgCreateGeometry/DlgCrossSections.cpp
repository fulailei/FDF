#include "PreCompiled.h"
#ifndef _PreComp_
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
# include <cfloat>
# include <QFuture>
# include <QFutureWatcher>
# include <QKeyEvent>
# include <QtConcurrentMap>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
#endif

#include "ui_DlgCrossSections.h"
#include "DlgCrossSections.h"
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/CrossSection.h>
#include <Gui/BitmapFactory.h>
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Document.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Base/Sequencer.h>
#include <Base/UnitsApi.h>

using namespace WirCoreGui;
#undef CS_FUTURE // multi-threading causes some problems

namespace WirCoreGui
{

class ViewProviderCrossSections : public Gui::ViewProvider
{
public:
    ViewProviderCrossSections()
    {
        coords = new SoCoordinate3();
        coords->ref();
        planes = new SoLineSet();
        planes->ref();

        SoBaseColor* color = new SoBaseColor();
        color->rgb.setValue(1.0f, 0.447059f, 0.337255f);
        SoDrawStyle* style = new SoDrawStyle();
        style->lineWidth.setValue(2.0f);

        SoGroup* sep = new SoGroup();
        sep->addChild(color);
        sep->addChild(style);
        sep->addChild(coords);
        sep->addChild(planes);
        addDisplayMaskMode(sep, "Base");
        setDisplayMaskMode("Base");
    }

    ~ViewProviderCrossSections()
    {
        coords->unref();
        planes->unref();
    }

    void setCoords(const std::vector<Base::Vector3f>& v)
    {
        coords->point.setNum(v.size());
        SbVec3f* p = coords->point.startEditing();
        for (unsigned int i=0; i<v.size(); i++) {
            const Base::Vector3f& pt = v[i];
            p[i].setValue(pt.x,pt.y,pt.z);
        }
        coords->point.finishEditing();
        unsigned int count = v.size()/5;
        planes->numVertices.setNum(count);
        int32_t* l = planes->numVertices.startEditing();
        for (unsigned int i=0; i<count; i++) {
            l[i] = 5;
        }
        planes->numVertices.finishEditing();
    }

private:
    SoCoordinate3* coords;
    SoLineSet* planes;
};
}


class DlgCrossSections::Private
{
public:
    double position = 5;
    double distance = 0;
    int countSections = 1;
    bool isSectionsBox = false;
    bool isCheckBothSides = false;

    bool isXYPlane = true;
    bool isXZPlane = false;
    bool isYZPlane = false;
};

DlgCrossSections::DlgCrossSections(const Base::BoundBox3d& bb, QWidget* parent, Qt::WindowFlags fl)
    : bbox(bb), d(new Private)
{
    ui = new Ui_DlgCrossSections();
    ui->setupUi(this);
    ui->position->setRange(-DBL_MAX, DBL_MAX);
    ui->position->setUnit(Base::Unit::Length);
    ui->distance->setRange(0, DBL_MAX);
    ui->distance->setUnit(Base::Unit::Length);
    vp = new ViewProviderCrossSections();

    Base::Vector3d c = bbox.GetCenter();
    calcPlane(DlgCrossSections::XY, c.z);
    ui->position->setValue(c.z);

    Gui::Document* doc = Gui::Application::Instance->activeDocument();
    view = qobject_cast<Gui::View3DInventor*>(doc->getActiveView());
    if (view)
    {
        view->getViewer()->addViewProvider(vp);
    }

    QObject::connect(ui->buttonBox, SIGNAL(accepted()), this, SLOT(accept()));
    QObject::connect(ui->buttonBox, SIGNAL(rejected()), this, SLOT(reject()));
}

/*  
 *  Destroys the object and frees any allocated resources
 */
DlgCrossSections::~DlgCrossSections()
{
    // no need to delete child widgets, Qt does it all for us
    delete ui;
    if (view)
    {
        view->getViewer()->removeViewProvider(vp);
    }
    delete vp;
}

void DlgCrossSections::setBoundBox3d(const Base::BoundBox3d& bb)
{
    bbox = bb;
}

void DlgCrossSections::setSelectedFaces(std::vector<SubSetObjs>& faces)
{
    m_selectedFaces = faces;
}

DlgCrossSections::Plane DlgCrossSections::plane() const
{
    if (ui->xyPlane->isChecked())
        return DlgCrossSections::XY;
    else if (ui->xzPlane->isChecked())
        return DlgCrossSections::XZ;
    else
        return DlgCrossSections::YZ;
}

void DlgCrossSections::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange)
    {
        //ui->retranslateUi(this);
    }
    else
    {
        QWidget::changeEvent(e);
    }

}

//void DlgCrossSections::keyPressEvent(QKeyEvent* ke)
//{
//    // The cross-sections dialog is embedded into a task panel
//    // which is a parent widget and will handle the event
//    ke->ignore();
//}

void DlgCrossSections::accept()
{
    this->d.get()->distance = ui->distance->value().getValue();
    this->d.get()->position = ui->position->value().getValue();
    this->d.get()->countSections = ui->countSections->value();
    this->d.get()->isCheckBothSides = ui->checkBothSides->isChecked();
    this->d.get()->isSectionsBox = ui->sectionsBox->isChecked();
    this->d.get()->isXYPlane = ui->xyPlane->isChecked();
    this->d.get()->isXZPlane = ui->xzPlane->isChecked();
    this->d.get()->isYZPlane = ui->yzPlane->isChecked();

    vp->hide();

    Q_EMIT sigCancel();
}

void DlgCrossSections::reject()
{

    vp->hide();
    Q_EMIT sigOK();
}

void DlgCrossSections::preView(bool ok)
{
    if (vp)
        vp->setVisible(ok);
}

TopoDS_Shape DlgCrossSections::getShape()
{
    TopoDS_Compound comp;
    if (!m_selectedFaces.empty())
    {
        std::vector<double> d;
        if (ui->sectionsBox->isChecked())
            d = getPlanes();
        else
            d.push_back(ui->position->value().getValue());

        double a=0, b=0, c=0;
        switch (plane())
        {
        case DlgCrossSections::XY:
            c = 1.0;
            break;
        case DlgCrossSections::XZ:
            b = 1.0;
            break;
        case DlgCrossSections::YZ:
            a = 1.0;
            break;
        }

        //TopoDS_Compound comp;
        BRep_Builder builder;
        builder.MakeCompound(comp);

        auto dir = Base::Vector3d(a, b, c);
        auto obj = dynamic_cast<Part::Feature*>(m_selectedFaces[0].first);
        auto subEs = m_selectedFaces[0].second;

        auto propShape = dynamic_cast<Part::PropertyPartShape*>(obj->Shape.Copy());
        auto shape = propShape->getShape();
        shape.setPlacement(obj->globalPlacement());

        for (auto i : subEs)
        {     
            auto curShape = shape.getSubShape(i.c_str());
            if (curShape.ShapeType() == TopAbs_FACE)
            {
                Part::TopoShape tshape(curShape);
                std::list<TopoDS_Wire> wires;
                for (auto i : d)
                {
                    wires = tshape.slice(dir, i);
                    for (auto j : wires)
                        builder.Add(comp, j);
                }
            }
        }


        //        App::Document* doc = obj->getDocument();
        //        std::string s = obj->getNameInDocument();
        //        s += "_cs";
        //        Part::Feature* section = static_cast<Part::Feature*>
        //                (doc->addObject("Part::Feature",s.c_str()));
        //        section->Shape.setValue(comp);
        //        section->purgeTouched();
    }
    return (TopoDS_Shape)(comp);
}

void DlgCrossSections::show()
{
    // 辅助图形
    vp->show();

    this->QWidget::show();

    // 界面数据
    if (this->d.get()->isXYPlane)
        ui->xyPlane->setChecked(true);
    else if (this->d.get()->isXZPlane)
        ui->xzPlane->setChecked(true);
    else
        ui->yzPlane->setChecked(true);

    ui->checkBothSides->setChecked(this->d.get()->isCheckBothSides);
    ui->sectionsBox->setChecked(this->d.get()->isSectionsBox);

    ui->distance->setValue(this->d.get()->distance);
    ui->position->setValue(this->d.get()->position);
    ui->countSections->setValue(this->d.get()->countSections);
}

void DlgCrossSections::on_xyPlane_clicked()
{
    Base::Vector3d c = bbox.GetCenter();
    ui->position->setValue(c.z);
    if (!ui->sectionsBox->isChecked()) {
        calcPlane(DlgCrossSections::XY, c.z);
    }
    else {
        double dist = bbox.LengthZ() / ui->countSections->value();
        if (!ui->checkBothSides->isChecked())
            dist *= 0.5f;
        ui->distance->setValue(dist);
        calcPlanes(DlgCrossSections::XY);
    }
}

void DlgCrossSections::on_xzPlane_clicked()
{
    Base::Vector3d c = bbox.GetCenter();
    ui->position->setValue(c.y);
    if (!ui->sectionsBox->isChecked()) {
        calcPlane(DlgCrossSections::XZ, c.y);
    }
    else {
        double dist = bbox.LengthY() / ui->countSections->value();
        if (!ui->checkBothSides->isChecked())
            dist *= 0.5f;
        ui->distance->setValue(dist);
        calcPlanes(DlgCrossSections::XZ);
    }
}

void DlgCrossSections::on_yzPlane_clicked()
{
    Base::Vector3d c = bbox.GetCenter();
    ui->position->setValue(c.x);
    if (!ui->sectionsBox->isChecked()) {
        calcPlane(DlgCrossSections::YZ, c.x);
    }
    else {
        double dist = bbox.LengthX() / ui->countSections->value();
        if (!ui->checkBothSides->isChecked())
            dist *= 0.5f;
        ui->distance->setValue(dist);
        calcPlanes(DlgCrossSections::YZ);
    }
}

void DlgCrossSections::on_position_valueChanged(double v)
{
    if (!ui->sectionsBox->isChecked()) {
        calcPlane(plane(), v);
    }
    else {
        calcPlanes(plane());
    }
}

void DlgCrossSections::on_sectionsBox_toggled(bool b)
{
    if (b)
    {
        on_countSections_valueChanged(ui->countSections->value());
    }
    else {
        DlgCrossSections::Plane type = plane();
        Base::Vector3d c = bbox.GetCenter();
        double value = 0;
        switch (type) {
        case DlgCrossSections::XY:
            value = c.z;
            break;
        case DlgCrossSections::XZ:
            value = c.y;
            break;
        case DlgCrossSections::YZ:
            value = c.x;
            break;
        }

        ui->position->setValue(value);
        calcPlane(type, value);
    }
}

void DlgCrossSections::on_checkBothSides_toggled(bool b)
{
    double d = ui->distance->value().getValue();
    d = b ? 2.0 * d : 0.5 * d;
    ui->distance->setValue(d);
    calcPlanes(plane());
}

void DlgCrossSections::on_countSections_valueChanged(int v)
{
    DlgCrossSections::Plane type = plane();
    double dist = 0;
    switch (type) {
    case DlgCrossSections::XY:
        dist = bbox.LengthZ() / v;
        break;
    case DlgCrossSections::XZ:
        dist = bbox.LengthY() / v;
        break;
    case DlgCrossSections::YZ:
        dist = bbox.LengthX() / v;
        break;
    }
    if (!ui->checkBothSides->isChecked())
        dist *= 0.5f;
    ui->distance->setValue(dist);
    calcPlanes(type);
}

void DlgCrossSections::on_distance_valueChanged(double)
{
    calcPlanes(plane());
}

void DlgCrossSections::calcPlane(Plane type, double pos)
{
    double bound[4];
    switch (type) {
    case XY:
        bound[0] = bbox.MinX;
        bound[1] = bbox.MaxX;
        bound[2] = bbox.MinY;
        bound[3] = bbox.MaxY;
        break;
    case XZ:
        bound[0] = bbox.MinX;
        bound[1] = bbox.MaxX;
        bound[2] = bbox.MinZ;
        bound[3] = bbox.MaxZ;
        break;
    case YZ:
        bound[0] = bbox.MinY;
        bound[1] = bbox.MaxY;
        bound[2] = bbox.MinZ;
        bound[3] = bbox.MaxZ;
        break;
    }

    std::vector<double> d;
    d.push_back(pos);
    makePlanes(type, d, bound);
}

void DlgCrossSections::calcPlanes(Plane type)
{
    double bound[4];
    switch (type) {
    case XY:
        bound[0] = bbox.MinX;
        bound[1] = bbox.MaxX;
        bound[2] = bbox.MinY;
        bound[3] = bbox.MaxY;
        break;
    case XZ:
        bound[0] = bbox.MinX;
        bound[1] = bbox.MaxX;
        bound[2] = bbox.MinZ;
        bound[3] = bbox.MaxZ;
        break;
    case YZ:
        bound[0] = bbox.MinY;
        bound[1] = bbox.MaxY;
        bound[2] = bbox.MinZ;
        bound[3] = bbox.MaxZ;
        break;
    }

    std::vector<double> d = getPlanes();
    makePlanes(type, d, bound);
}

std::vector<double> DlgCrossSections::getPlanes() const
{
    int count = ui->countSections->value();
    double pos = ui->position->value().getValue();
    double stp = ui->distance->value().getValue();
    bool both = ui->checkBothSides->isChecked();

    std::vector<double> d;
    if (both) {
        double start = pos-0.5f*(count-1)*stp;
        for (int i=0; i<count; i++) {
            d.push_back(start+i*stp);
        }
    }
    else {
        for (int i=0; i<count; i++) {
            d.push_back(pos+i*stp);
        }
    }
    return d;
}

void DlgCrossSections::makePlanes(Plane type, const std::vector<double>& d, double bound[4])
{
    std::vector<Base::Vector3f> points;
    for (std::vector<double>::const_iterator it = d.begin(); it != d.end(); ++it) {
        Base::Vector3f v[4];
        switch (type) {
        case XY:
            v[0].Set(bound[0],bound[2],*it);
            v[1].Set(bound[1],bound[2],*it);
            v[2].Set(bound[1],bound[3],*it);
            v[3].Set(bound[0],bound[3],*it);
            break;
        case XZ:
            v[0].Set(bound[0],*it,bound[2]);
            v[1].Set(bound[1],*it,bound[2]);
            v[2].Set(bound[1],*it,bound[3]);
            v[3].Set(bound[0],*it,bound[3]);
            break;
        case YZ:
            v[0].Set(*it,bound[0],bound[2]);
            v[1].Set(*it,bound[1],bound[2]);
            v[2].Set(*it,bound[1],bound[3]);
            v[3].Set(*it,bound[0],bound[3]);
            break;
        }

        points.push_back(v[0]);
        points.push_back(v[1]);
        points.push_back(v[2]);
        points.push_back(v[3]);
        points.push_back(v[0]);
    }
    vp->setCoords(points);
}

#include "moc_DlgCrossSections.cpp"
