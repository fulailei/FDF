#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
#endif

#include "BaseDialog.h"
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Document.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <App/Property.h>
#include <Mod/Part/App/PropertyTopoShape.h>
#include <Mod/WirCore/App/GeometryObject.h>
#include <Mod/WirCore/Gui/ViewProviderGeometryObject.h>

using namespace WirCoreGui;
using namespace WirCore;

BaseDialog::BaseDialog()
{
}

BaseDialog::~BaseDialog()
{

}

void BaseDialog::makeGlobalTDShape(const App::Property* shape, const Base::Placement& pla, TopoDS_Shape& tdShape)
{
    auto s = const_cast<App::Property*>(shape);
    auto propShape = dynamic_cast<Part::PropertyPartShape*>(s);
    assert(propShape != nullptr);

    auto propShapeNew = dynamic_cast<Part::PropertyPartShape*>(propShape->Copy());
    auto sNew = propShapeNew->getShape();
    sNew.setPlacement(pla);
    tdShape = sNew.getShape();
}

void BaseDialog::makeGlobalPropShape(const App::Property* shape, const Base::Placement& pla, Part::PropertyPartShape& propShape)
{
    auto s = const_cast<App::Property*>(shape);
    auto propShapeOld = dynamic_cast<Part::PropertyPartShape*>(s);
    assert(propShapeOld != nullptr);

    auto propShapeNew = dynamic_cast<Part::PropertyPartShape*>(propShapeOld->Copy());
    auto sNew = propShapeNew->getShape();
    sNew.setPlacement(pla);
    propShape.setValue(sNew);
}

#include "moc_BaseDialog.cpp"
