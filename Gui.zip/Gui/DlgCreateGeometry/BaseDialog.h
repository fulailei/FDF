#ifndef WIRCOREGUI_BASEDIALOG_H
#define WIRCOREGUI_BASEDIALOG_H

#include <QWidget>
#include <string>
#include <vector>
#include <set>
#include "TopoDS_Shape.hxx"

namespace Base
{
class Placement;
}
namespace App
{
class DocumentObject;
class Property;
}

namespace Part
{
class PropertyPartShape;
}

namespace WirCoreGui
{
class ViewProviderGeometry;
class BaseDialog : public QWidget
{
    Q_OBJECT

public:
    typedef std::pair<App::DocumentObject*, std::set<std::string>> SubSetObjs;

    BaseDialog();
    ~BaseDialog();
    //virtual void show(){}
    virtual TopoDS_Shape getShape(){ return TopoDS_Shape();};

    static void makeGlobalTDShape(const App::Property* shape, const Base::Placement& pla, TopoDS_Shape& tdShape);
    static void makeGlobalPropShape(const App::Property* shape, const Base::Placement& pla, Part::PropertyPartShape& propShape);

Q_SIGNALS:
    void sigCancel();
    void sigOK();
};
} //namespace WirCoreGui

#endif // WIRCOREGUI_BASEDIALOG_H
