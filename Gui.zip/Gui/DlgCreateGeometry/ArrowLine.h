#ifndef WIRCOREGUI_ARROWLINE_H
#define WIRCOREGUI_ARROWLINE_H

#include <gp_Vec.hxx>
#include <gp_Lin.hxx>

#include <Inventor/fields/SoSFVec3f.h>
#include <Inventor/fields/SoSFMatrix.h>
#include <Inventor/fields/SoSFString.h>
#include <Inventor/nodekits/SoSeparatorKit.h>
#include <Inventor/fields/SoSFColor.h>
#include <Inventor/fields/SoSFRotation.h>
#include <Inventor/fields/SoSFFloat.h>
#include <Inventor/engines/SoSubEngine.h>
#include <Inventor/engines/SoEngine.h>


class TopoDS_Shape;
class TopoDS_Face;
class TopoDS_Edge;
class TopoDS_Vertex;
class gp_Pnt;
class BRepExtrema_DistShapeShape;

class QPushButton;
class QPixmap;
class QLabel;

namespace WirCoreGui
{
/*!creates one dimension from points with color
 * @param point1 first point
 * @param point2 second point
 * @param color color of dimension
 * @return an inventor node to add to a scenegraph
 */
SoNode* createLinearDimension(const gp_Pnt &point1, const gp_Pnt &point2, const SbColor &color);


class DimensionLinear : public SoSeparatorKit
{
    SO_KIT_HEADER(DimensionLinear);

    SO_KIT_CATALOG_ENTRY_HEADER(transformation);
    SO_KIT_CATALOG_ENTRY_HEADER(annotate);
    SO_KIT_CATALOG_ENTRY_HEADER(leftArrow);
    SO_KIT_CATALOG_ENTRY_HEADER(rightArrow);
    SO_KIT_CATALOG_ENTRY_HEADER(line);
    //SO_KIT_CATALOG_ENTRY_HEADER(textSep);

public:
    DimensionLinear();
    static void initClass();
    virtual SbBool affectsState() const;
    void setupDimension();

    SoSFVec3f point1;
    SoSFVec3f point2;
    //SoSFString text;
    SoSFColor dColor;
protected:
    SoSFRotation rotate;
    SoSFFloat length;
    SoSFVec3f origin;

private:
    virtual ~DimensionLinear();
};

}

#endif // WIRCOREGUI_ARROWLINE_H
