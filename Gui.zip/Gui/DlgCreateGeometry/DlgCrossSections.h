#ifndef WIRCOREGUI_DLGCROSSSECTIONS_H
#define WIRCOREGUI_DLGCROSSSECTIONS_H

#include <Gui/TaskView/TaskDialog.h>
#include <Gui/TaskView/TaskView.h>
#include <Base/BoundBox.h>
#include <BaseDialog.h>
#include <QPointer>

namespace Gui
{
class View3DInventor;
}

namespace WirCoreGui
{

class ViewProviderCrossSections;
class Ui_DlgCrossSections;

class DlgCrossSections : public BaseDialog
{
    Q_OBJECT

    enum Plane { XY, XZ, YZ };

public:
    DlgCrossSections(const Base::BoundBox3d& bb, QWidget* parent = 0, Qt::WindowFlags fl = 0);
    ~DlgCrossSections();
    void setBoundBox3d(const Base::BoundBox3d& bb);
    void setSelectedFaces(std::vector<SubSetObjs>& faces);
    TopoDS_Shape getShape() override;
    void preView(bool ok);
    void show();

public Q_SLOTS:
    void accept();
    void reject();

protected:
    void changeEvent(QEvent *e);

private Q_SLOTS:
    void on_xyPlane_clicked();
    void on_xzPlane_clicked();
    void on_yzPlane_clicked();
    void on_position_valueChanged(double);
    void on_distance_valueChanged(double);
    void on_countSections_valueChanged(int);
    void on_checkBothSides_toggled(bool);
    void on_sectionsBox_toggled(bool);

private:
    std::vector<double> getPlanes() const;
    void calcPlane(Plane, double);
    void calcPlanes(Plane/*, double, bool, int*/);
    void makePlanes(Plane, const std::vector<double>&, double[4]);
    Plane plane() const;

private:
    Ui_DlgCrossSections* ui;
    Base::BoundBox3d bbox;
    ViewProviderCrossSections* vp;
    QPointer<Gui::View3DInventor> view;

    std::vector<SubSetObjs> m_selectedFaces;

    class Private;
    std::unique_ptr<Private> d;
};

} // namespace WircoreGui

#endif // WIRCOREGUI_DLGCROSSSECTIONS_H
