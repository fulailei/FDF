#include "PreCompiled.h"
#ifndef _PreCpmp_
#endif

#include <TopoDS_Shape.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <BRep_Tool.hxx>
#include <TopExp.hxx>
#include <Geom_ElementarySurface.hxx>
#include <Geom_CylindricalSurface.hxx>
#include <Geom_SphericalSurface.hxx>
#include <Geom_Line.hxx>
#include <GeomAPI_ProjectPointOnCurve.hxx>
#include <GeomAPI_ExtremaCurveCurve.hxx>

#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoMatrixTransform.h>
#include <Inventor/nodes/SoVertexProperty.h>
#include <Inventor/nodes/SoLineSet.h>
#include <Inventor/nodes/SoIndexedLineSet.h>
#include <Inventor/nodes/SoText2.h>
#include <Inventor/nodes/SoFont.h>
#include <Inventor/nodes/SoAnnotation.h>
#include <Inventor/nodekits/SoShapeKit.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoNurbsCurve.h>
#include <Inventor/engines/SoComposeVec3f.h>
#include <Inventor/engines/SoCalculator.h>
#include <Inventor/nodes/SoResetTransform.h>
#include <Inventor/engines/SoConcatenate.h>
#include <Inventor/engines/SoComposeRotationFromTo.h>
#include <Inventor/engines/SoComposeRotation.h>
#include <Inventor/nodes/SoMaterial.h>
#include <ArrowLine.h>

#include <Base/UnitsApi.h>


using namespace WirCoreGui;

namespace  WirCoreGui
{
SoNode* createLinearDimension(const gp_Pnt &point1, const gp_Pnt &point2, const SbColor &color)
{
    SbVec3f vec1(point1.X(), point1.Y(), point1.Z());
    SbVec3f vec2(point2.X(), point2.Y(), point2.Z());
    if ((vec2-vec1).length() < FLT_EPSILON)
        return new SoSeparator(); //empty object.
    WirCoreGui::DimensionLinear *dimension = new WirCoreGui::DimensionLinear();
    dimension->point1.setValue(vec1);
    dimension->point2.setValue(vec2);
    dimension->setupDimension();

    //Base::Quantity quantity(static_cast<double>((vec2-vec1).length()), Base::Unit::Length);
    //dimension->text.setValue(quantity.getUserString().toUtf8().constData());

    dimension->dColor.setValue(color);
    return dimension;
}

}

SO_KIT_SOURCE(WirCoreGui::DimensionLinear);

void WirCoreGui::DimensionLinear::initClass()
{
    SO_KIT_INIT_CLASS(DimensionLinear, SoSeparatorKit, "SeparatorKit");
}

WirCoreGui::DimensionLinear::DimensionLinear()
{
    SO_KIT_CONSTRUCTOR(WirCoreGui::DimensionLinear);

    SO_KIT_ADD_CATALOG_ENTRY(transformation, SoTransform, true, topSeparator,"" , true);
    SO_KIT_ADD_CATALOG_ENTRY(annotate, SoAnnotation, true, topSeparator,"" , true);
    SO_KIT_ADD_CATALOG_ENTRY(leftArrow, SoShapeKit, true, topSeparator,"" ,true);
    SO_KIT_ADD_CATALOG_ENTRY(rightArrow, SoShapeKit, true, topSeparator,"" ,true);
    SO_KIT_ADD_CATALOG_ENTRY(line, SoShapeKit, true, annotate,"" ,true);
    //SO_KIT_ADD_CATALOG_ENTRY(textSep, SoSeparator, true, annotate,"" ,true);

    SO_KIT_INIT_INSTANCE();

    SO_NODE_ADD_FIELD(rotate, (1.0, 0.0, 0.0, 0.0));//position orientation of the dimension.
    SO_NODE_ADD_FIELD(length, (1.0));//turns into dimension length
    SO_NODE_ADD_FIELD(origin, (0.0, 0.0, 0.0));//static
    //SO_NODE_ADD_FIELD(text, ("test"));//dimension text
    SO_NODE_ADD_FIELD(dColor, (1.0, 0.0, 0.0));//dimension color.
}

WirCoreGui::DimensionLinear::~DimensionLinear()
{

}

SbBool WirCoreGui::DimensionLinear::affectsState() const
{
    return false;
}

void WirCoreGui::DimensionLinear::setupDimension()
{
    //transformation
    SoTransform *trans = static_cast<SoTransform *>(getPart("transformation", true));
    trans->translation.connectFrom(&point1);
    //build engine for vector subtraction and length.
    SoCalculator *hyp = new SoCalculator();
    hyp->A.connectFrom(&point1);
    hyp->B.connectFrom(&point2);
    hyp->expression.set1Value(0, "oA = B-A");
    hyp->expression.set1Value(1, "oB = normalize(oA)");
    hyp->expression.set1Value(2, "oa = length(oA)");
    length.connectFrom(&hyp->oa);

    //build engine for rotation.
    SoComposeRotationFromTo *rotationEngine = new SoComposeRotationFromTo();
    rotationEngine->from.setValue(SbVec3f(1.0, 0.0, 0.0));
    rotationEngine->to.connectFrom(&hyp->oB);
    trans->rotation.connectFrom(&rotationEngine->rotation);

    //color
    SoMaterial *material = new SoMaterial;
    material->diffuseColor.connectFrom(&dColor);

    //dimension arrows
    float dimLength = (point2.getValue()-point1.getValue()).length();
    float coneHeight = dimLength * 0.05 ;
    float coneRadius = coneHeight * 0.5;

    SoCone *cone = new SoCone();
    cone->bottomRadius.setValue(coneRadius);
    cone->height.setValue(coneHeight);

    char lStr[100];
    char rStr[100];
    snprintf(lStr, sizeof(lStr), "translation %.6f 0.0 0.0", coneHeight * 0.5);
    snprintf(rStr, sizeof(rStr), "translation 0.0 -%.6f 0.0", coneHeight * 0.5);

    setPart("leftArrow.shape", cone);
    set("leftArrow.transform", "rotation 0.0 0.0 1.0 1.5707963");
    set("leftArrow.transform", lStr);
    setPart("rightArrow.shape", cone);
    set("rightArrow.transform", "rotation 0.0 0.0 -1.0 1.5707963"); //no constant for PI.
    //have use local here to do the offset because the main is wired up to length of dimension.
    set("rightArrow.localTransform", rStr);

    SoTransform *transform = static_cast<SoTransform *>(getPart("rightArrow.transform", false));
    if (!transform)
        return;//what to do here?
    SoComposeVec3f *vec = new SoComposeVec3f;
    vec->x.connectFrom(&length);
    vec->y.setValue(0.0);
    vec->z.setValue(0.0);
    transform->translation.connectFrom(&vec->vector);

    setPart("leftArrow.material", material);
    setPart("rightArrow.material", material);

    //line
    SoConcatenate *catEngine = new SoConcatenate(SoMFVec3f::getClassTypeId());
    //don't know how to get around having this dummy origin. cat engine wants to connectfrom?
    catEngine->input[0]->connectFrom(&origin);
    catEngine->input[1]->connectFrom(&vec->vector);

    SoVertexProperty *lineVerts = new SoVertexProperty;
    lineVerts->vertex.connectFrom(catEngine->output);

    int lineVertexMap[] = {0, 1};
    int lineVertexMapSize(sizeof(lineVertexMap)/sizeof(int));
    SoIndexedLineSet *line = new SoIndexedLineSet;
    line->vertexProperty = lineVerts;
    line->coordIndex.setValues(0, lineVertexMapSize, lineVertexMap);

    setPart("line.shape", line);
    setPart("line.material", material);

//    //text
//    SoSeparator *textSep = static_cast<SoSeparator *>(getPart("textSep", true));
//    if (!textSep)
//        return;

//    textSep->addChild(material);

//    SoCalculator *textVecCalc = new SoCalculator();
//    textVecCalc->A.connectFrom(&vec->vector);
//    textVecCalc->B.set1Value(0, 0.0, 0.250, 0.0);
//    textVecCalc->expression.set1Value(0, "oA = (A / 2) + B");

    //SoTransform *textTransform =  new SoTransform();
    //textTransform->translation.connectFrom(&textVecCalc->oA);
    //textSep->addChild(textTransform);

   // SoFont *fontNode = new SoFont();
   // fontNode->name.setValue("defaultFont");
   // fontNode->size.setValue(30);
   // textSep->addChild(fontNode);

    //SoText2 *textNode = new SoText2();
    //textNode->justification = SoText2::CENTER;
    //textNode->string.connectFrom(&text);
    //textSep->addChild(textNode);

    //this prevents the 2d text from screwing up the bounding box for a viewall
    //SoResetTransform *rTrans = new SoResetTransform;
    //rTrans->whatToReset = SoResetTransform::BBOX;
   // textSep->addChild(rTrans);
}
