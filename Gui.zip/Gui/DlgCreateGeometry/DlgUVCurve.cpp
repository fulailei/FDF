#include "PreCompiled.h"
#ifndef _PreComp_
# include <Inventor/nodes/SoSeparator.h>
# include <TopoDS_Face.hxx>
# include <TopExp.hxx>
# include <TopExp_Explorer.hxx>
# include <BRepProj_Projection.hxx>
# include <TopoDS_Builder.hxx>
# include <TopoDS_Edge.hxx>
# include <ShapeAnalysis.hxx>
# include <ShapeAnalysis_FreeBounds.hxx>
# include <ShapeFix_Wire.hxx>
# include <BRep_Tool.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Geom_TrimmedCurve.hxx>
# include <GeomProjLib.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include "ShapeFix_Edge.hxx"
# include <BRepBuilderAPI_MakeFace.hxx>
# include <ShapeFix_Face.hxx>
# include <BRepCheck_Analyzer.hxx>
# include <ShapeFix_Wireframe.hxx>
# include <BRepPrimAPI_MakePrism.hxx>
# include <gp_Ax1.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_Transform.hxx>
# include <QAction>
# include <QMenu>
# include <QMessageBox>
# include <QTimer>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
# include <cfloat>
# include <QFuture>
# include <QFutureWatcher>
# include <QKeyEvent>
# include <QtConcurrentMap>
# include <QStandardItemModel>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/actions/SoSearchAction.h>
# include <Inventor/details/SoLineDetail.h>
# include <Inventor/details/SoFaceDetail.h>
#endif

#include "DlgUVCurve.h"
#include "ui_DlgUVCurve.h"
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/Command.h>
#include <Gui/SelectionObject.h>
#include <Base/Console.h>
#include <Gui/Control.h>
#include <Gui/BitmapFactory.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>
#include <Mod/Part/Gui/CrossSections.h>
#include "Gui/MainWindow.h"
#include "Gui/MDIView.h"
#include "Gui/View3DInventor.h"
#include "Gui/View3DInventorViewer.h"
#include "Inventor/SbVec3d.h"
#include "Mod/Part/Gui/ViewProviderExt.h"
#include "ViewProviderGeometryObject.h"
#include "Mod/Part/App/PropertyTopoShape.h"
#include "Mod/WirCore/App/WorkObjectReferenceFrame.h"
#include "Mod/Part/Gui/SoBrepFaceSet.h"
#include "Mod/Part/Gui/SoBrepEdgeSet.h"
#include "Mod/Part/Gui/SoBrepPointSet.h"
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/SoFCUnifiedSelection.h>
#include <QDoubleSpinBox>

using namespace WirCore;
using namespace WirCoreGui;

namespace WirCoreGui
{
//// ----------------------------------------------------------------------------
DlgUVCurve::DlgUVCurve(App::Document* doc, QWidget* parent)
    : ui(new Ui_DlgUVCurve())
    , m_pParent(parent)
    , m_pDoc(doc)
{
    ui->setupUi(this);

    //    // set tree view with three columns
    //    QStandardItemModel* model = new QStandardItemModel(this);
    //    model->insertColumns(0,1);
    //    ui->treeView->setRootIsDecorated(false);
    //    ui->treeView->setModel(model);
    //    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    //    // Create context menu
    //    QAction* action = new QAction(tr("Remove"), this);
    //    action->setShortcut(QString::fromLatin1("Del"));
    //    connect(action, SIGNAL(triggered()), this, SLOT(onDeleteEdge()));

    //    ui->treeView->addAction(action);
    //    ui->treeView->setContextMenuPolicy(Qt::ActionsContextMenu);

    //    // fuck: qt has a bug
    //    connect(ui->treeView, SIGNAL(clicked(const QModelIndex&)), this, SLOT(clickedTreeItem(const QModelIndex&)));

//    vp = new ViewProviderProjectCurve();
//    spline = new ProjectCurve();
//    vp->attach(spline);
//    Gui::Document* curdoc = Gui::Application::Instance->activeDocument();
//    view = (Gui::View3DInventor*)(curdoc->getActiveView());
//    if (view)
//    {
//        view->getViewer()->addViewProvider(vp);
//        //view->getViewer()->update();
//    }
//    //m_partDocument->recompute();

//    //on_radioLine_clicked();
//    projectLineType = ProjectCurve::Line;
//    spline->setShapes(ProjectCurve::Line);

    // make connection to the needed signals
    connect(ui->buttonBox,SIGNAL(accepted()), this,SLOT(accept()));
    connect(ui->buttonBox,SIGNAL(rejected()), this,SLOT(reject()));

    //connect(ui->groupBox, SIGNAL(clicked(const QModelIndex&)), this, SLOT(clickedTreeItem(const QModelIndex&)));
}

DlgUVCurve::~DlgUVCurve()
{
    // no need to delete child widgets, Qt does it all for us
    //if (view)
    //{
        //view->getViewer()->removeViewProvider(vp);
    //}
   // delete vp;

    // no need to delete child widgets, Qt does it all for us
    delete ui;
}

TopoDS_Shape DlgUVCurve::getShape()
{
    //    TopoDS_Compound aCompound;
    //    if (!m_saveEdges.empty())
    //    {
    //        auto obj = m_saveEdges.at(0).first;
    //        auto es = m_saveEdges.at(0).second;

    //        auto shape = dynamic_cast<Part::Feature*>(obj)->Shape.getShape().getShape();
    //        TopTools_IndexedMapOfShape edges;
    //        TopExp::MapShapes(shape, TopAbs_EDGE, edges);

    //        TopoDS_Builder aBuilder;
    //        aBuilder.MakeCompound(aCompound);
    //        for (auto e : es)
    //        {
    //            std::string::size_type pos = e.find_first_of("0123456789");
    //            int index = -1;
    //            if (pos != std::string::npos)
    //            {
    //                index = std::atoi(e.substr(pos).c_str());
    //                e = e.substr(0,pos);
    //            }
    //            aBuilder.Add(aCompound, edges.FindKey(index));
    //        }
    //    }
    //    return (TopoDS_Shape)(aCompound);
}

void DlgUVCurve::show()
{
    //    // 有可能save中的Edge所在面已经被删除
    //    assert(m_relyFaces.size() == 1);
    //    auto pRelyObj = m_relyFaces.at(0).first;

    //    if (!m_saveEdges.empty())
    //    {
    //        assert(m_saveEdges.size() == 1);
    //        auto pEdgeObj = m_saveEdges.at(0).first;
    //        if (pRelyObj != pEdgeObj)
    //        {
    //            m_saveEdges.clear();
    //        }

    //        // 将面上的边收集起来
    //        std::set<QString> setEdgeNames;
    //        for (auto it : m_relyFaces)
    //        {
    //            auto aPart = dynamic_cast<Part::Feature*>(it.first);
    //            auto allShape = aPart->Shape.getShape().getShape();
    //            QString text;
    //            TopTools_IndexedMapOfShape edges;
    //            TopExp::MapShapes(allShape, TopAbs_EDGE, edges);

    //            if (aPart)
    //            {
    //                for (auto jt : it.second)
    //                {
    //                    auto curShape =  aPart->Shape.getShape().getSubShape(jt.c_str());
    //                    if (curShape.ShapeType() == TopAbs_FACE)
    //                    {
    //                        TopTools_IndexedMapOfShape fedges;
    //                        TopExp::MapShapes(curShape, TopAbs_EDGE, fedges);
    //                        for (int i = 1; i <= fedges.Extent(); i++)
    //                        {
    //                            //const TopoDS_Shape& edge = edges.FindKey(i);
    //                            auto index = edges.FindIndex(fedges.FindKey(i));
    //                            QString text = QString::fromLatin1("Edge%1").arg(index);
    //                            setEdgeNames.insert(text);
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        std::vector<int> rmvIndex;
    //        auto& subEdges = m_saveEdges[0].second;
    //        std::set<std::string> subEdgesTemp = m_saveEdges[0].second;
    //        for (auto it : subEdgesTemp)
    //        {
    //            if (setEdgeNames.end() == setEdgeNames.find(QString::fromStdString(it)))
    //            {
    //                auto itor = subEdges.find(it);
    //                if (subEdges.end() != itor)
    //                    subEdges.erase(it);
    //            }
    //        }
    //    }

    //    m_selectEdges = m_saveEdges;

    //    Gui::Selection().addSelectionGate(new ShapeSelection(m_pDoc, selectionMode, m_selectEdges, m_relyFaces));
    //    selectionMode = AppendEdge;

    //    updateTreeView(m_selectEdges);

    //    highlightReferences(Edge, m_selectEdges, true);

    this->QWidget::show();
}

void DlgUVCurve::preview(bool ok)
{
    //highlightReferences(Edge, m_saveEdges, ok);
}

void DlgUVCurve::setSelectedFaces(std::vector<SubSetObjs>& faces)
{
    //m_relyFaces = faces;
}

void DlgUVCurve::accept()
{
    Q_EMIT sigCancel();

    //    selectionMode = None;
    //    Gui::Selection().rmvSelectionGate();

    //    //    if (editedObject->mustExecute())
    //    //        editedObject->recomputeFeature();
    //    //    if (!editedObject->isValid()) {
    //    //        QMessageBox::warning(this, tr("Invalid object"),
    //    //            QString::fromLatin1(editedObject->getStatusString()));
    //    //        return false;
    //    //    }

    //    highlightReferences(Edge, m_selectEdges, false);

    //    //    // unhighlight the referenced Edge
    //    //    std::vector<App::PropertyLinkSubList::SubSet> links;
    //    //    links.push_back(std::make_pair(editedObject->InitialEdge.getValue(),
    //    //                                   editedObject->InitialEdge.getSubValues()));
    //    //    this->vp->highlightReferences(ViewProviderFilling::Edge, links, false);
    //    m_saveEdges = m_selectEdges;

}

void DlgUVCurve::reject()
{
    Q_EMIT sigOK();

    //    highlightReferences(Edge, m_selectEdges, false);

    //    selectionMode = None;
    //    Gui::Selection().rmvSelectionGate();

    //    m_selectEdges.clear();
}

}
#include "moc_DlgUVCurve.cpp"
