#include "PreCompiled.h"
#ifndef _PreComp_
# include <Inventor/nodes/SoSeparator.h>
# include <TopoDS_Face.hxx>
# include <TopExp.hxx>
# include <TopExp_Explorer.hxx>
# include <BRepProj_Projection.hxx>
# include <TopoDS_Builder.hxx>
# include <TopoDS_Edge.hxx>
# include <ShapeAnalysis.hxx>
# include <ShapeAnalysis_FreeBounds.hxx>
# include <ShapeFix_Wire.hxx>
# include <BRep_Tool.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Geom_TrimmedCurve.hxx>
# include <GeomProjLib.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include "ShapeFix_Edge.hxx"
# include <BRepBuilderAPI_MakeFace.hxx>
# include <ShapeFix_Face.hxx>
# include <BRepCheck_Analyzer.hxx>
# include <ShapeFix_Wireframe.hxx>
# include <BRepPrimAPI_MakePrism.hxx>
# include <gp_Ax1.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_Transform.hxx>
# include <QAction>
# include <QMenu>
# include <QMessageBox>
# include <QTimer>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
# include <cfloat>
# include <QFuture>
# include <QFutureWatcher>
# include <QStandardItemModel>
# include <QStandardItem>
# include <QKeyEvent>
# include <QtConcurrentMap>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/actions/SoSearchAction.h>
# include <Inventor/details/SoLineDetail.h>
# include <Inventor/details/SoFaceDetail.h>
#endif

#include "DlgSpecifyArea.h"
#include "ui_DlgSpecifyArea.h"
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/Command.h>
#include <Gui/SelectionObject.h>
#include <Base/Console.h>
#include <Gui/Control.h>
#include <Gui/BitmapFactory.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>
#include <Mod/Part/Gui/CrossSections.h>
#include "Gui/MainWindow.h"
#include "Gui/MDIView.h"
#include "Gui/View3DInventor.h"
#include "Gui/View3DInventorViewer.h"
#include "Inventor/SbVec3d.h"
#include "Mod/Part/Gui/ViewProviderExt.h"
#include "ViewProviderGeometryObject.h"
#include "Mod/Part/App/PropertyTopoShape.h"
#include "Mod/WirCore/App/WorkObjectReferenceFrame.h"
#include "Mod/Part/Gui/SoBrepFaceSet.h"
#include "Mod/Part/Gui/SoBrepEdgeSet.h"
#include "Mod/Part/Gui/SoBrepPointSet.h"
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/SoFCUnifiedSelection.h>

using namespace WirCore;
using namespace WirCoreGui;

namespace WirCoreGui
{

class findObjByDocObj
{
public:
    findObjByDocObj(const App::DocumentObject* obj) : pObj(obj) {}

    bool operator () (const std::pair<App::DocumentObject*, std::set<std::string>>& elem) const
    {
        if (!pObj) return false;
        if (elem.first == pObj)
            return true;
        else
            return false;
    }

    const App::DocumentObject* pObj = nullptr;
};
class findObjByName
{
public:
    findObjByName(const std::string& str) : str(str) {}

    bool operator () (const std::pair<App::DocumentObject*, std::set<std::string>>& elem) const
    {
        if (str.empty()) return false;
        if (elem.first->Label.getName() == str)
            return true;
        else
            return false;
    }

    const std::string str;
};


class DlgSpecifyArea::ShapeSelection : public Gui::SelectionFilterGate
{
public:
    ShapeSelection(App::Document* doc, SelectionMode& mode, std::vector<SubSetObjs>& subObjects)
        : Gui::SelectionFilterGate(static_cast<Gui::SelectionFilter*>(nullptr))
        , pDoc(doc)
        , mode(mode)
        , selectFaces(subObjects)
    {
    }

    ~ShapeSelection()
    {
        mode = None;
    }

    /**
      * Allow the user to pick only edges.
    */
    bool allow(App::Document* doc, App::DocumentObject* pObj, const char* sSubName)
    {
        if (pDoc != doc) return false; // 不能跨doc

        if (!pObj->isDerivedFrom(Part::Feature::getClassTypeId()))
            return false;

        if (!sSubName || sSubName[0] == '\0')
            return false;

        // 不能跨obj
        if (!selectFaces.empty())
        {
            auto itor = std::find_if(selectFaces.begin(), selectFaces.end(), findObjByDocObj(pObj));
            if (itor == selectFaces.end())
                return false;
        }

        switch (mode)
        {
        case AppendFace:
            return allowFace(pObj, sSubName);
        case AppendEdge:
            return allowEdge(true, pObj, sSubName);
        case RemoveEdge:
            return allowEdge(false, pObj, sSubName);
        default:
            return false;
        }
    }

private:
    bool allowFace(App::DocumentObject*, const char* sSubName)
    {
        std::string element(sSubName);
        if (element.substr(0,4) != "Face")
            return false;
        return true;
    }

    bool allowEdge(bool appendEdges, App::DocumentObject* pObj, const char* sSubName)
    {
        std::string element(sSubName);
        if (element.substr(0,4) != "Edge")
            return false;

        auto links = selectFaces;
        for (auto it : links)
        {
            if (it.first == pObj)
            {
                for (auto jt : it.second)
                {
                    if (jt == sSubName)
                        return !appendEdges;
                }
            }
        }

        return appendEdges;
    }

private:
    App::Document* pDoc = nullptr;
    SelectionMode& mode;
    std::vector<SubSetObjs>& selectFaces;
};


//// ----------------------------------------------------------------------------
DlgSpecifyArea::DlgSpecifyArea(App::Document* doc, QWidget* parent)
    : ui(new Ui_DlgSpecifyArea())
    , m_pParent(parent)
    , m_pDoc(doc)
{
    ui->setupUi(this);

    // set tree view with three columns
    QStandardItemModel* model = new QStandardItemModel(this);
    model->insertColumns(0,1);
    ui->treeView->setRootIsDecorated(false);
    ui->treeView->setModel(model);
    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // Create context menu
    QAction* action = new QAction(tr("Remove"), this);
    action->setShortcut(QString::fromLatin1("Del"));
    connect(action, SIGNAL(triggered()), this, SLOT(onDeleteEdge()));

    ui->treeView->addAction(action);
    ui->treeView->setContextMenuPolicy(Qt::ActionsContextMenu);

    // fuck: qt has a bug
    connect(ui->treeView, SIGNAL(clicked(const QModelIndex&)), this, SLOT(clickedTreeItem(const QModelIndex&)));

    // make connection to the needed signals
    connect(ui->buttonBox,SIGNAL(accepted()), this,SLOT(accept()));
    connect(ui->buttonBox,SIGNAL(rejected()), this,SLOT(reject()));


    ui->toolbuttonAll->hide();
    ui->toolbuttonNone->hide();

    Gui::Selection().addSelectionGate(new ShapeSelection(m_pDoc, selectionMode, m_selectFaces));
    selectionMode = AppendFace;
}

void DlgSpecifyArea::show()
{
    m_selectFaces = m_saveFaces;

    Gui::Selection().addSelectionGate(new ShapeSelection(m_pDoc, selectionMode, m_selectFaces));
    selectionMode = AppendFace;

    updateTreeView(m_selectFaces);

    highlightReferences(Face, m_selectFaces, true);

    this->QWidget::show();
}

void DlgSpecifyArea::preview(bool ok)
{
    highlightReferences(Face, m_saveFaces, ok);
}

void DlgSpecifyArea::clickedTreeItem(const QModelIndex& index)
{
    if (!m_pDoc) return;
    if (!m_pDocObj) return;

    bool block = this->blockConnection(true);

    // is item checked
    Gui::Selection().clearSelection();

    int id = index.data(Qt::UserRole).toInt();
    QString name = QString::fromLatin1("Face%1").arg(id);
    Gui::Selection().addSelection(m_pDoc->getName(),
                                  m_pDocObj->getNameInDocument(),
                                  (const char*)name.toLatin1());

    this->blockConnection(block);
}

void DlgSpecifyArea::onDeleteEdge()
{
    auto curRow = ui->treeView->currentIndex();

    QStandardItemModel* model = dynamic_cast<QStandardItemModel*>(ui->treeView->model());
    auto item = model->itemFromIndex(curRow);
    auto str = item->text();
    QString objName = str.split(QString::fromLocal8Bit("."))[0];
    QString subEleName = str.split(QString::fromLocal8Bit("."))[1];

    highlightReferences(Face, m_selectFaces, false);

    int i = 0;
    for (auto& it : m_selectFaces)
    {
        QString str1 = QString::fromLatin1(it.first->Label.getValue());
        if (str1 == objName)
        {
            auto itor = std::find(it.second.begin(), it.second.end(), subEleName.toStdString());
            if (itor != it.second.end())
            {
                if (it.second.size() == 1)
                    m_selectFaces.erase(m_selectFaces.begin() + i);
                else
                    it.second.erase(itor);
                break;
            }
        }
        i++;
    }

    highlightReferences(Face, m_selectFaces, true);

    model->removeRow(curRow.row());
    ui->treeView->update();
}

void DlgSpecifyArea::accept()
{
    Q_EMIT sigCancel();

    selectionMode = None;
    Gui::Selection().rmvSelectionGate();

    highlightReferences(Face, m_selectFaces, false);

    m_saveFaces = m_selectFaces;
}

void DlgSpecifyArea::reject()
{
    Q_EMIT sigOK();

    highlightReferences(Face, m_selectFaces, false);

    selectionMode = None;
    Gui::Selection().rmvSelectionGate();

    m_selectFaces.clear();
}

/*
 *  Destroys the object and frees any allocated resources
 */
DlgSpecifyArea::~DlgSpecifyArea()
{
    //    disconnect(d->highlighttimer,SIGNAL(timeout()),
    //            this, SLOT(onHighlightFaces()));
    //    // no need to delete child widgets, Qt does it all for us
    //    if (view) {
    //        view->getViewer()->removeViewProvider(vp);
    //    }
    //    delete vp;

    // no need to delete child widgets, Qt does it all for us
    delete ui;
}

void DlgSpecifyArea::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange)
    {
        //ui->retranslateUi(this);
    }
    else
    {
        QWidget::changeEvent(e);
    }
}

void DlgSpecifyArea::slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj)
{
    // If this view provider is being deleted then reset the colors of
    // referenced part objects. The dialog will be deleted later.
    //if (this->vp == &Obj) {
    //    this->vp->highlightReferences(false);
    //}
}

void DlgSpecifyArea::onSelectionChanged(const Gui::SelectionChanges& msg)
{
    if (selectionMode == None) return;

    if (msg.Type == Gui::SelectionChanges::AddSelection)
    {
        if (selectionMode == AppendFace)
        {
            Gui::SelectionObject sel(msg);
            QString text = QString::fromLatin1("%1.%2")
                    .arg(QString::fromUtf8(sel.getObject()->Label.getValue()))
                    .arg(QString::fromLocal8Bit(msg.pSubName));

            m_pDocObj = sel.getObject();

            appendToSelectFaces(sel.getObject(), msg.pSubName);

            highlightReferences(Face, m_selectFaces, true);
            updateTreeView(m_selectFaces, text);

            //Gui::Selection().rmvSelectionGate();
            //selectionMode = None;
        }

        //QTimer::singleShot(50, this, SLOT(clearSelection()));
    }

    // 点击场景空白区域，发送取消所有选中信号，对应取消对话框中treeitem的选择
    if (msg.Type == Gui::SelectionChanges::ClrSelection)
    {
        ui->treeView->clearSelection();
    }
}

void DlgSpecifyArea::appendToSelectFaces(const App::DocumentObject* obj, const std::string& subName)
{
    assert(obj != nullptr);
    assert(!subName.empty());

    SubSetObjs* curItem = nullptr;
    if (isInSelectFaces(obj, curItem))
    {
        curItem->second.insert(subName);
    }
    else
    {
        std::set<std::string> subList;
        subList.insert(subName);
        m_selectFaces.push_back(std::make_pair(const_cast<App::DocumentObject*>(obj), subList));
    }
}

bool DlgSpecifyArea::isInSelectFaces(const App::DocumentObject* obj, SubSetObjs*& pCurItem)
{
    assert(obj != nullptr);

    auto itor = std::find_if(m_selectFaces.begin(), m_selectFaces.end(), findObjByDocObj(obj));
    if (itor == m_selectFaces.end())
        return false;

    pCurItem = &*itor;
    return true;
}

void DlgSpecifyArea::updateTreeView(const std::vector<SubSetObjs>& objs, QString curText)
{
    QStandardItemModel* model = dynamic_cast<QStandardItemModel*>(ui->treeView->model());
    model->clear();

    QStandardItem* curItem = nullptr;
    QStandardItem *rootItem = model->invisibleRootItem();
    for (auto it : objs)
    {
        Part::Feature* base = dynamic_cast<Part::Feature*>(it.first);
        if (base)
        {
            for (auto jt : it.second)
            {
                auto subName = QString::fromStdString(jt);
                QString name = QString::fromLatin1("%1.%2")
                        .arg(QString::fromUtf8(it.first->Label.getValue()))
                        .arg(subName);

                QStandardItem *item = new QStandardItem(name);
                auto str = subName.right(subName.size() - 4).toInt();
                item->setData(QVariant(str), Qt::UserRole);
                rootItem->appendRow(item);

                if (curText == item->text())
                    curItem = item;
            }
        }
    }


    if (curItem)
        ui->treeView->setCurrentIndex(curItem->index());

    ui->treeView->update();
}

void DlgSpecifyArea::highlightReferences(ShapeType type, std::vector<SubSetObjs>& refs, bool on)
{
    for (auto it : refs)
    {
        Part::Feature* base = dynamic_cast<Part::Feature*>(it.first);
        if (base)
        {
            PartGui::ViewProviderPartExt* svp = dynamic_cast<PartGui::ViewProviderPartExt*>(
                        Gui::Application::Instance->getViewProvider(base));
            if (svp)
            {
                switch (type)
                {
                case DlgSpecifyArea::Vertex:
                    if (on)
                    {
                        std::vector<App::Color> colors;
                        TopTools_IndexedMapOfShape vMap;
                        TopExp::MapShapes(base->Shape.getValue(), TopAbs_VERTEX, vMap);
                        colors.resize(vMap.Extent(), svp->PointColor.getValue());

                        for (auto jt : it.second)
                        {
                            // check again that the index is in range because it's possible that the
                            // sub-names are invalid
                            std::size_t idx = static_cast<std::size_t>(std::stoi(jt.substr(6)) - 1);
                            if (idx < colors.size())
                                colors[idx] = App::Color(1., 172/255., 64/255.); // magenta
                        }
                        svp->setHighlightedPoints(colors);
                    }
                    else
                    {
                        svp->unsetHighlightedPoints();
                    }
                    break;
                case DlgSpecifyArea::Edge:
                    if (on)
                    {
                        std::vector<App::Color> colors;
                        TopTools_IndexedMapOfShape eMap;
                        TopExp::MapShapes(base->Shape.getValue(), TopAbs_EDGE, eMap);
                        colors.resize(eMap.Extent(), svp->LineColor.getValue());

                        for (auto jt : it.second) {
                            std::size_t idx = static_cast<std::size_t>(std::stoi(jt.substr(4)) - 1);
                            // check again that the index is in range because it's possible that the
                            // sub-names are invalid
                            if (idx < colors.size())
                                colors[idx] = App::Color(1., 172/255., 64/255.); // magenta
                        }

                        svp->setHighlightedEdges(colors);
                    }
                    else {
                        svp->unsetHighlightedEdges();
                    }
                    break;
                case DlgSpecifyArea::Face:
                    if (on)
                    {
                        std::vector<App::Color> colors;
                        TopTools_IndexedMapOfShape fMap;
                        TopExp::MapShapes(base->Shape.getValue(), TopAbs_FACE, fMap);
                        colors.resize(fMap.Extent(), svp->ShapeColor.getValue());

                        for (auto jt : it.second)
                        {
                            std::size_t idx = static_cast<std::size_t>(std::stoi(jt.substr(4)) - 1);
                            // check again that the index is in range because it's possible that the
                            // sub-names are invalid
                            if (idx < colors.size())
                                colors[idx] = App::Color(1., 172/255., 64/255.); // magenta
                        }

                        svp->setHighlightedFaces(colors);
                    }
                    else {
                        svp->unsetHighlightedFaces();
                    }
                    break;
                }
            }
        }
    }
}

}

#include "moc_DlgSpecifyArea.cpp"
