#ifndef WIRCOREGUI_DLGUVCURVE_H
#define WIRCOREGUI_DLGUVCURVE_H

#include "TopoDS_Shape.hxx"
#include "TopoDS_Edge.hxx"
#include "TopoDS_Face.hxx"
#include "TopoDS_Wire.hxx"
#include "gp_Dir.hxx"

#include "Mod/Part/App/PartFeature.h"
#include <Gui/TaskView/TaskView.h>
#include <Gui/SelectionFilter.h>
#include <Gui/DocumentObserver.h>
#include <Base/BoundBox.h>
#include <BaseDialog.h>

class QStandardItem;
class QDoubleSpinBox;

namespace Gui
{
class View3DInventor;
}

namespace WirCoreGui
{
class Ui_DlgUVCurve;
class DocumentObject;
class ViewProviderProjectCurve;
class ProjectCurve;


class DlgUVCurve : public BaseDialog//,
                       //public Gui::SelectionObserver//,
                       //public Gui::DocumentObserver
{
    Q_OBJECT

public:
    typedef std::pair<App::DocumentObject*, std::set<std::string>> SubSetObjs;
    enum ProjectLineType { Line, Splin, Polyline };

    DlgUVCurve(App::Document* doc, QWidget* parent);
    ~DlgUVCurve();
    void showCurve();
    void showDirection();
    void show();
    void preview(bool ok);
    void setSelectedFaces(std::vector<SubSetObjs>& faces);
    TopoDS_Shape getShape() override;

    //enum ShapeType {Vertex, Edge, Face};
    //enum SelectionMode { None, AppendFace, RemoveFace, AppendEdge, RemoveEdge };
    //SelectionMode selectionMode;
    int projectLineType; // project

public Q_SLOTS:
    void accept();
    void reject();


protected:
    //void changeEvent(QEvent *e);
    //virtual void onSelectionChanged(const Gui::SelectionChanges& msg);
    /** Notifies on undo */
    //virtual void slotUndoDocument(const Gui::Document& Doc);
    /** Notifies on redo */
   // virtual void slotRedoDocument(const Gui::Document& Doc);
    /** Notifies when the object is about to be removed. */
    //virtual void slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj);

private:
    class ShapeSelection;

    Ui_DlgUVCurve* ui = nullptr;
    QWidget* m_pParent = nullptr;
    App::Document* m_pDoc = nullptr;
    App::DocumentObject* m_pDocObj = nullptr;
    std::vector<SubSetObjs> m_selectEdges;

    ViewProviderProjectCurve* vp;
    ProjectCurve* spline;
    Gui::View3DInventor* view = nullptr;


    void get_camera_direction(void);
//    std::vector<SubSetObjs> m_saveEdges; // 点击ok后的存储结果
//    std::vector<SubSetObjs> m_relyFaces;
};
} //namespace WirCoreGui

#endif //
