#ifndef WIRCOREGUI_DLGSPECIFYEDGE_H
#define WIRCOREGUI_DLGSPECIFYEDGE_H

#include "TopoDS_Shape.hxx"
#include "TopoDS_Edge.hxx"
#include "TopoDS_Face.hxx"
#include "TopoDS_Wire.hxx"
#include "gp_Dir.hxx"

#include "Mod/Part/App/PartFeature.h"
#include <Gui/TaskView/TaskView.h>
#include <Gui/SelectionFilter.h>
#include <Gui/DocumentObserver.h>
#include <Base/BoundBox.h>
#include <BaseDialog.h>

class QStandardItem;

namespace WirCoreGui
{
class Ui_DlgSpecifyEdge;
class DocumentObject;


class DlgSpecifyEdge : public BaseDialog,
        public Gui::SelectionObserver//,
        //public Gui::DocumentObserver
{
    Q_OBJECT

public:
    typedef std::pair<App::DocumentObject*, std::set<std::string>> SubSetObjs;
    typedef std::pair<App::DocumentObject*, App::DocumentObject*> edge_face;
    std::vector<edge_face> obj_group;
    DlgSpecifyEdge(App::Document* doc, QWidget* parent);
    ~DlgSpecifyEdge();
    void show();
    void preview(bool ok);
    void setSelectedFaces(std::vector<SubSetObjs>& faces);
    TopoDS_Shape getShape() override;

    enum ShapeType {Vertex, Edge, Face};
    enum SelectionMode { None, AppendFace, RemoveFace, AppendEdge, RemoveEdge };
    SelectionMode selectionMode;

public Q_SLOTS:
    void accept();
    void reject();
    void onDeleteEdge(void); // 右击删除item
    void clickedTreeItem(const QModelIndex&); // 选中treeItem

protected:
    void changeEvent(QEvent *e);
    virtual void onSelectionChanged(const Gui::SelectionChanges& msg);
    /** Notifies on undo */
    //virtual void slotUndoDocument(const Gui::Document& Doc);
    /** Notifies on redo */
    // virtual void slotRedoDocument(const Gui::Document& Doc);
    /** Notifies when the object is about to be removed. */
    virtual void slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj);

private:
    class ShapeSelection;

    Ui_DlgSpecifyEdge* ui = nullptr;
    QWidget* m_pParent = nullptr;
    App::Document* m_pDoc = nullptr;
    App::DocumentObject* m_pDocObj = nullptr;
    std::vector<SubSetObjs> m_selectEdges;
    std::vector<SubSetObjs> m_saveEdges; // 点击ok后的存储结果
    std::vector<SubSetObjs> m_relyFaces;


    void highlightReferences(ShapeType type, std::vector<SubSetObjs>& objs, bool on);
    void highlightSingleEdge(std::vector<SubSetObjs>& objs, bool on);
    // 默认空字符选第一个
    void updateTreeView(const std::vector<SubSetObjs>& objs, QString curText = QString::fromLocal8Bit(""));
    // obj,obj的字结构名字
    // 只要合乎指针不空，名字不空，就能被插入[是否属于同一个doc,obj,是在selectgate中]
    void appendToSelectEdges(const App::DocumentObject* obj, const std::string& subName);
    bool isInSelectEdges(const App::DocumentObject* obj, SubSetObjs*& pCurItem);
};

} //namespace WirCoreGui

#endif //
