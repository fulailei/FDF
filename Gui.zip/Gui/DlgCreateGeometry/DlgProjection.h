#ifndef WIRCOREGUI_DLGPROJECTION_H
#define WIRCOREGUI_DLGPROJECTION_H

#include "TopoDS_Shape.hxx"
#include "TopoDS_Edge.hxx"
#include "TopoDS_Face.hxx"
#include "TopoDS_Wire.hxx"
#include "gp_Dir.hxx"

#include "Mod/Part/App/PartFeature.h"
#include <Gui/TaskView/TaskView.h>
#include <Gui/SelectionFilter.h>
#include <Gui/DocumentObserver.h>
#include <Base/BoundBox.h>
#include <BaseDialog.h>

class QStandardItem;
class QDoubleSpinBox;


namespace Gui
{
class View3DInventor;
class ViewProvider;
}

namespace WirCore
{
class Geometry;
}

namespace WirCoreGui
{
class Ui_DlgProjection;
class DocumentObject;
class ViewProviderProjectCurve;
class ViewProviderProjectDir;
class ProjectCurve;
class DimensionLinear;

class DlgProjection : public BaseDialog//,
                       //public Gui::SelectionObserver//,
                       //public Gui::DocumentObserver
{
    Q_OBJECT

public:
    typedef std::pair<App::DocumentObject*, std::set<std::string>> SubSetObjs;
    enum ProjectLineType { Line, Splin, Polyline };

    DlgProjection(App::Document* doc, QWidget* parent);
    ~DlgProjection();
    void showCurve();
    void showDirection();
    void show();
    void previewCurve(bool ok);
    void previewDirection(bool ok);
    void setSelectedFaces(std::vector<SubSetObjs>& faces);
    TopoDS_Shape getShape() override;
    //void setDir(const gp_Pnt &point1, const gp_Pnt &point2);

    //enum ShapeType {Vertex, Edge, Face};
    //enum SelectionMode { None, AppendFace, RemoveFace, AppendEdge, RemoveEdge };
    //SelectionMode selectionMode;
    int projectLineType; // project


public Q_SLOTS:
    void accept();
    void reject();
    //void onDeleteEdge(void); // 右击删除item
    //void clickedTreeItem(const QModelIndex&); // 选中treeItem
    void on_radioLine_clicked();
    void on_radioSplin_clicked();
    void on_radioPolylin_clicked();

    void on_pushButtonGetCurrentCamDir_clicked();
    void set_xyz_dir_spinbox(QDoubleSpinBox* icurrentSpinBox);
    void on_pushButtonDirX_clicked();
    void on_pushButtonDirY_clicked();
    void on_pushButtonDirZ_clicked();

protected:
    //void changeEvent(QEvent *e);
    //virtual void onSelectionChanged(const Gui::SelectionChanges& msg);
    /** Notifies on undo */
    //virtual void slotUndoDocument(const Gui::Document& Doc);
    /** Notifies on redo */
   // virtual void slotRedoDocument(const Gui::Document& Doc);
    /** Notifies when the object is about to be removed. */
    //virtual void slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj);

private:
    class ShapeSelection;

    Ui_DlgProjection* ui = nullptr;
    QWidget* m_pParent = nullptr;
    App::Document* m_pDoc = nullptr;
    App::DocumentObject* m_pDocObj = nullptr;
    std::vector<SubSetObjs> m_selectEdges;

    ViewProviderProjectCurve* vp = nullptr;
    ViewProviderProjectDir* vpDir = nullptr;
    ProjectCurve* spline = nullptr;
    Gui::View3DInventor* view = nullptr;
    //SoTransform* m_pAxisTrans;


    void get_camera_direction(void);
//    std::vector<SubSetObjs> m_saveEdges; // 点击ok后的存储结果
    std::vector<SubSetObjs> m_relyFaces;

    class Private;
    std::unique_ptr<Private> d;
};
} //namespace WirCoreGui

#endif //
