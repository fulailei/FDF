#include "PreCompiled.h"
#ifndef _PreComp_
# include <Inventor/nodes/SoSeparator.h>
# include <TopoDS_Face.hxx>
# include <TopExp.hxx>
# include <TopExp_Explorer.hxx>
# include <BRepProj_Projection.hxx>
# include <TopoDS_Builder.hxx>
# include <TopoDS_Edge.hxx>
# include <ShapeAnalysis.hxx>
# include <ShapeAnalysis_FreeBounds.hxx>
# include <ShapeFix_Wire.hxx>
# include <BRep_Tool.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Geom_TrimmedCurve.hxx>
# include <GeomProjLib.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include "ShapeFix_Edge.hxx"
# include <BRepBuilderAPI_MakeFace.hxx>
# include <ShapeFix_Face.hxx>
# include <BRepCheck_Analyzer.hxx>
# include <ShapeFix_Wireframe.hxx>
# include <BRepPrimAPI_MakePrism.hxx>
# include <gp_Ax1.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_Transform.hxx>
# include <QAction>
# include <QMenu>
# include <QMessageBox>
# include <QTimer>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
# include <cfloat>
# include <QFuture>
# include <QFutureWatcher>
# include <QKeyEvent>
# include <QtConcurrentMap>
# include <QStandardItemModel>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/actions/SoSearchAction.h>
# include <Inventor/details/SoLineDetail.h>
# include <Inventor/details/SoFaceDetail.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoGroup.h>
#include <Inventor/nodekits/SoShapeKit.h>
#include <Inventor/fields/SoSFVec3f.h>
#include <Inventor/fields/SoSFMatrix.h>
#include <Inventor/fields/SoSFString.h>
#include <Inventor/nodekits/SoSeparatorKit.h>
#include <Inventor/fields/SoSFColor.h>
#include <Inventor/fields/SoSFRotation.h>
#include <Inventor/fields/SoSFFloat.h>
#include <Inventor/engines/SoSubEngine.h>
#include <Inventor/engines/SoEngine.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoMatrixTransform.h>
#include <Inventor/nodes/SoVertexProperty.h>
#include <Inventor/nodes/SoLineSet.h>
#include <Inventor/nodes/SoIndexedLineSet.h>
#include <Inventor/nodes/SoText2.h>
#include <Inventor/nodes/SoFont.h>
#include <Inventor/nodes/SoAnnotation.h>
#include <Inventor/nodekits/SoShapeKit.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoNurbsCurve.h>
#include <Inventor/engines/SoComposeVec3f.h>
#include <Inventor/engines/SoCalculator.h>
#include <Inventor/nodes/SoResetTransform.h>
#include <Inventor/engines/SoConcatenate.h>
#include <Inventor/engines/SoComposeRotationFromTo.h>
#include <Inventor/engines/SoComposeRotation.h>
#include <Inventor/nodes/SoMaterial.h>
# include <Inventor/nodes/SoNode.h>
#endif

#include <QAction>
#include <Gui/SoFCBoundingBox.h>
#include <Gui/SoAxisCrossKit.h>
#include <App/Document.h>
#include "DlgProjection.h"
#include "ui_DlgProjection.h"
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/Command.h>
#include <Gui/SelectionObject.h>
#include <Base/Console.h>
#include <Gui/Control.h>
#include <Gui/BitmapFactory.h>
#include <Mod/Part/Gui/ViewProvider.h>
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>
#include <Mod/Part/Gui/CrossSections.h>
#include "Gui/MainWindow.h"
#include "Gui/MDIView.h"
#include "Gui/View3DInventor.h"
#include "Gui/View3DInventorViewer.h"
#include "Inventor/SbVec3d.h"
#include "Mod/Part/Gui/ViewProviderExt.h"
#include "ViewProviderGeometryObject.h"
#include "Mod/Part/App/PropertyTopoShape.h"
#include "Mod/WirCore/App/WorkObjectReferenceFrame.h"
#include "Mod/Part/Gui/SoBrepFaceSet.h"
#include "Mod/Part/Gui/SoBrepEdgeSet.h"
#include "Mod/Part/Gui/SoBrepPointSet.h"
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/SoFCUnifiedSelection.h>
#include <QDoubleSpinBox>
#include <ArrowLine.h>


using namespace WirCore;
using namespace WirCoreGui;

namespace WirCoreGui
{

class ProjectCurve : public Part::Feature
{
public:
    enum ProjectLineType { Line, Splin, Polyline };
    ProjectCurve()
    {
        createLineShape();
        createSplinShape();
        createPolylinShape();
    }

    ~ProjectCurve()
    {
    }

    /// returns the type name of the ViewProvider
    const char* getViewProviderName(void) const
    {
        return "WirCoreGui::ViewProviderProjectCurve";
    }

    std::vector<TopoDS_Shape> getShapes(int i)
    {
        assert(i == Line || i == Splin || i == Polyline);
        switch(i)
        {
        case Line:
            return m_dataLine;
        case Splin:
            return m_dataSplin;
        case Polyline:
            return m_dataPolylin;
        }
        return std::vector<TopoDS_Shape>();
    }

    void setShapes(int i)
    {
        auto comShape = [](std::vector<TopoDS_Shape>& v)->TopoDS_Shape
        {
            TopoDS_Compound aCompound;
            TopoDS_Builder aBuilder;
            aBuilder.MakeCompound(aCompound);
            for (auto it2 : v)
                aBuilder.Add(aCompound, it2);
            return aCompound;
        };

        assert(i == Line || i == Splin || i == Polyline);
        switch(i)
        {
        case Line:
            this->Shape.setValue(comShape(m_dataLine));
            break;
        case Splin:
            this->Shape.setValue(comShape(m_dataSplin));
            break;
        case Polyline:
            this->Shape.setValue(comShape(m_dataPolylin));
            break;
        }
    }

private:
    void createSegLine(const gp_Pnt& p1, const gp_Pnt& p2, std::vector<TopoDS_Shape>& vShapes)
    {
        auto line = GC_MakeSegment(p1, p2);
        auto edge = BRepBuilderAPI_MakeEdge(line.Value());
        vShapes.push_back(edge);
    }

    void createLineShape()
    {
        m_dataLine.clear();
        createSegLine(gp_Pnt(0, 0, 0), gp_Pnt(0, 5, 0), m_dataLine);
        createSegLine(gp_Pnt(5, 0, 0), gp_Pnt(5, 5, 0), m_dataLine);
        createSegLine(gp_Pnt(10, 0, 0), gp_Pnt(10, 5, 0), m_dataLine);
        createSegLine(gp_Pnt(15, 0, 0), gp_Pnt(15, 5, 0), m_dataLine);
    }

    void createSplinShape()
    {
        m_dataSplin.clear();
        const std::vector<gp_Pnt> p{gp_Pnt(0,0,0), gp_Pnt(5,5,0), gp_Pnt(10,0,0), gp_Pnt(15,5,0), gp_Pnt(20,0,0)};
        const std::vector<gp_Vec> t{gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0)};
        auto spline = new Part::GeomBSplineCurve;
        spline->interpolate(p,t);
        m_dataSplin.push_back(spline->toShape());
    }

    void createPolylinShape()
    {
        m_dataPolylin.clear();
        createSegLine(gp_Pnt(0, 0, 0), gp_Pnt(5, 5, 0), m_dataPolylin);
        createSegLine(gp_Pnt(5, 5, 0), gp_Pnt(10, 0, 0), m_dataPolylin);
        createSegLine(gp_Pnt(10, 0, 0), gp_Pnt(15, 5, 0), m_dataPolylin);
        createSegLine(gp_Pnt(15, 5, 0), gp_Pnt(20, 0, 0), m_dataPolylin);
    }
    //ProjectLineType curType;
    std::vector<TopoDS_Shape> m_dataLine;
    std::vector<TopoDS_Shape> m_dataSplin;
    std::vector<TopoDS_Shape> m_dataPolylin;
};

class ViewProviderProjectCurve : public PartGui::ViewProviderPartExt
{
public:
    ViewProviderProjectCurve()
    {
    }
    ~ViewProviderProjectCurve()
    {
    }
};

class ViewProviderProjectDir : public Gui::ViewProviderGeometryObject
{
    //PROPERTY_HEADER(PartGui::ViewProviderPartExt);

public:
    ViewProviderProjectDir()
    {

        Base::BoundBox3d bbox;
        auto objs = App::GetApplication().getActiveDocument()->getObjects();
        for (auto o : objs)
        {
             bbox.Add(static_cast<Part::Feature*>(o)->Shape.getBoundingBox());
        }

        auto len = bbox.CalcDiagonalLength() * 6;
        gp_Pnt point1(0, 0, 0);
        gp_Pnt point2(len, len, len);
        //vpDir->setDir(point1, point2);

        //gp_Pnt point1(0, 0, 0);
        //gp_Pnt point2(100, 100, 100);




        m_pArrowNode = dynamic_cast<DimensionLinear*>(WirCoreGui::createLinearDimension(point1, point2, SbColor(1.0, 0.0, 0.0)));
        addDisplayMaskMode(m_pArrowNode, "Base");
        setDisplayMaskMode("Base");
    };

    ~ViewProviderProjectDir(){};

    void setDir(const gp_Pnt &point1, const gp_Pnt &point2)
    {
        SbVec3f vec1(point1.X(), point1.Y(), point1.Z());
        SbVec3f vec2(point2.X(), point2.Y(), point2.Z());
        if ((vec2-vec1).length() < FLT_EPSILON)
            return; //empty object.

        m_pArrowNode->point1.setValue(vec1);
        m_pArrowNode->point2.setValue(vec2);
    }

    //   void attach(App::DocumentObject *pcObject);
    //   void setDisplayMode(const char* ModeName);
    //   std::vector<std::string> getDisplayModes() const;
    //   void updateData(const App::Property*);

    //   virtual void onChanged(const App::Property* prop);
    //   void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);

    //   std::vector<App::DocumentObject*> claimChildren(void) const;

    //protected:
    //   Gui::SoFCSelection* refFrameRoot;

    //   Gui::SoShapeScale* axisCross;
    //   SoGroup* axisGroup;
    //   SoTransform* axisTrans;
private:
    DimensionLinear* m_pArrowNode = nullptr;
};

class DlgProjection::Private
{
public:
    int type;
    SbVec3f dir;
};

//// ----------------------------------------------------------------------------
DlgProjection::DlgProjection(App::Document* doc, QWidget* parent)
    : ui(new Ui_DlgProjection())
    , d(new Private)
    , m_pParent(parent)
    , m_pDoc(doc)
{
    ui->setupUi(this);

    //    // set tree view with three columns
    //    QStandardItemModel* model = new QStandardItemModel(this);
    //    model->insertColumns(0,1);
    //    ui->treeView->setRootIsDecorated(false);
    //    ui->treeView->setModel(model);
    //    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    //    // Create context menu
    //    QAction* action = new QAction(tr("Remove"), this);
    //    action->setShortcut(QString::fromLatin1("Del"));
    //    connect(action, SIGNAL(triggered()), this, SLOT(onDeleteEdge()));

    //    ui->treeView->addAction(action);
    //    ui->treeView->setContextMenuPolicy(Qt::ActionsContextMenu);

    //    // fuck: qt has a bug
    //    connect(ui->treeView, SIGNAL(clicked(const QModelIndex&)), this, SLOT(clickedTreeItem(const QModelIndex&)));

    vp = new ViewProviderProjectCurve();
    spline = new ProjectCurve();
    vp->attach(spline);
    Gui::Document* curdoc = Gui::Application::Instance->activeDocument();
    view = (Gui::View3DInventor*)(curdoc->getActiveView());

    vpDir = new ViewProviderProjectDir();
    if (view)
    {
        view->getViewer()->addViewProvider(vp);
        view->getViewer()->addViewProvider(vpDir);
    }

    //on_radioLine_clicked();
    projectLineType = ProjectCurve::Line;
    spline->setShapes(ProjectCurve::Line);

    // make connection to the needed signals
    connect(ui->buttonBox,SIGNAL(accepted()), this,SLOT(accept()));
    connect(ui->buttonBox,SIGNAL(rejected()), this,SLOT(reject()));

    //connect(ui->groupBox, SIGNAL(clicked(const QModelIndex&)), this, SLOT(clickedTreeItem(const QModelIndex&)));
}

void DlgProjection::showCurve()
{
    ui->groupBox->show();
    ui->stackedWidget->show();
    ui->widget_8->hide();
}

void DlgProjection::showDirection()
{
    ui->groupBox->hide();
    ui->stackedWidget->hide();
    ui->widget_8->show();
}

void DlgProjection::on_radioLine_clicked()
{
    projectLineType = DlgProjection::Line;
    ui->stackedWidget->setCurrentIndex(0);
    spline->setShapes(ProjectCurve::Line);
    vp->setActiveMode();
    vp->updateView();
}

void DlgProjection::on_radioSplin_clicked()
{
    projectLineType = DlgProjection::Splin;
    ui->stackedWidget->setCurrentIndex(1);
    spline->setShapes(ProjectCurve::Splin);
    vp->setActiveMode();
    vp->updateView();
}

void DlgProjection::on_radioPolylin_clicked()
{
    projectLineType = DlgProjection::Polyline;
    ui->stackedWidget->setCurrentIndex(2);
    spline->setShapes(ProjectCurve::Polyline);
    vp->setActiveMode();
    vp->updateView();
}

void DlgProjection::on_pushButtonGetCurrentCamDir_clicked()
{
    get_camera_direction();
}

void DlgProjection::set_xyz_dir_spinbox(QDoubleSpinBox* icurrentSpinBox)
{
    auto currentVal = icurrentSpinBox->value();
    auto newVal = 0.0;
    if (currentVal != 1.0 && currentVal != -1.0)
    {
        newVal = -1;
    }
    else if (currentVal == 1.0)
    {
        newVal = -1;
    }
    else if (currentVal == -1.0)
    {
        newVal = 1;
    }

    ui->doubleSpinBoxDirX->setValue(0);
    ui->doubleSpinBoxDirY->setValue(0);
    ui->doubleSpinBoxDirZ->setValue(0);
    icurrentSpinBox->setValue(newVal);
}

void DlgProjection::on_pushButtonDirX_clicked()
{
    set_xyz_dir_spinbox(ui->doubleSpinBoxDirX);
}

void DlgProjection::on_pushButtonDirY_clicked()
{
    set_xyz_dir_spinbox(ui->doubleSpinBoxDirY);
}

void DlgProjection::on_pushButtonDirZ_clicked()
{
    set_xyz_dir_spinbox(ui->doubleSpinBoxDirZ);
}

void DlgProjection::get_camera_direction(void)
{
    auto mainWindow = Gui::getMainWindow();

    auto mdiObject = dynamic_cast<Gui::View3DInventor*>(mainWindow->activeWindow());
    if (!mdiObject) return;
    auto camerRotation = mdiObject->getViewer()->getCameraOrientation();

    SbVec3f lookAt(0, 0, -1);
    camerRotation.multVec(lookAt, lookAt);

    float valX, valY, valZ;
    lookAt.getValue(valX, valY, valZ);

    ui->doubleSpinBoxDirX->setValue(valX);
    ui->doubleSpinBoxDirY->setValue(valY);
    ui->doubleSpinBoxDirZ->setValue(valZ);

    // 预览功能
    if (vpDir)
    {
        Base::BoundBox3d bbox;
        auto objs = m_pDoc->getObjects();
        for (auto o : objs)
        {
             bbox.Add(static_cast<Part::Feature*>(o)->Shape.getBoundingBox());
        }

        auto len = bbox.CalcDiagonalLength() * 3;
        gp_Pnt point1(0, 0, 0);
        gp_Pnt point2(valX*len, valY*len, valZ*len);
        vpDir->setDir(point1, point2);
    }
}

DlgProjection::~DlgProjection()
{
    if (view)
    {
        view->getViewer()->removeViewProvider(vp);
        view->getViewer()->removeViewProvider(vpDir);
    }
    delete vp;
    delete vpDir;

    // no need to delete child widgets, Qt does it all for us
    delete ui;
}

TopoDS_Shape DlgProjection::getShape()
{
    auto valX =  ui->doubleSpinBoxDirX->value();
    auto valY = ui->doubleSpinBoxDirY->value();
    auto valZ = ui->doubleSpinBoxDirZ->value();
    auto dir = gp_Dir(valX, valY, valZ);

    TopoDS_Compound aCompound;
    if (!m_relyFaces.empty())
    {
        BRep_Builder builder;
        builder.MakeCompound(aCompound);

        auto lines = spline->getShapes(projectLineType);
        auto obj = dynamic_cast<Part::Feature*>(m_relyFaces[0].first);
        auto subEs = m_relyFaces[0].second;
        for (auto i : subEs)
        {
            auto curShape =  obj->Shape.getShape().getSubShape(i.c_str());
            if (curShape.ShapeType() == TopAbs_FACE)
            {
                Part::TopoShape tshape(curShape);
                std::list<TopoDS_Wire> wires;
                for (auto i : lines)
                {
                    BRepProj_Projection aProjection(i, curShape, dir);
                    auto currentProjection = aProjection.Shape();
                    for (TopExp_Explorer aExplorer(currentProjection, TopAbs_EDGE); aExplorer.More(); aExplorer.Next())
                    {
                        //aCompound.push_back(TopoDS::Edge(aExplorer.Current()));
                        builder.Add(aCompound, TopoDS::Edge(aExplorer.Current()));
                    }
                }
            }
        }
    }
    return (TopoDS_Shape)(aCompound);
}

void DlgProjection::show()
{
    //    // 有可能save中的Edge所在面已经被删除
    //    assert(m_relyFaces.size() == 1);
    //    auto pRelyObj = m_relyFaces.at(0).first;

    //    if (!m_saveEdges.empty())
    //    {
    //        assert(m_saveEdges.size() == 1);
    //        auto pEdgeObj = m_saveEdges.at(0).first;
    //        if (pRelyObj != pEdgeObj)
    //        {
    //            m_saveEdges.clear();
    //        }

    //        // 将面上的边收集起来
    //        std::set<QString> setEdgeNames;
    //        for (auto it : m_relyFaces)
    //        {
    //            auto aPart = dynamic_cast<Part::Feature*>(it.first);
    //            auto allShape = aPart->Shape.getShape().getShape();
    //            QString text;
    //            TopTools_IndexedMapOfShape edges;
    //            TopExp::MapShapes(allShape, TopAbs_EDGE, edges);

    //            if (aPart)
    //            {
    //                for (auto jt : it.second)
    //                {
    //                    auto curShape =  aPart->Shape.getShape().getSubShape(jt.c_str());
    //                    if (curShape.ShapeType() == TopAbs_FACE)
    //                    {
    //                        TopTools_IndexedMapOfShape fedges;
    //                        TopExp::MapShapes(curShape, TopAbs_EDGE, fedges);
    //                        for (int i = 1; i <= fedges.Extent(); i++)
    //                        {
    //                            //const TopoDS_Shape& edge = edges.FindKey(i);
    //                            auto index = edges.FindIndex(fedges.FindKey(i));
    //                            QString text = QString::fromLatin1("Edge%1").arg(index);
    //                            setEdgeNames.insert(text);
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        std::vector<int> rmvIndex;
    //        auto& subEdges = m_saveEdges[0].second;
    //        std::set<std::string> subEdgesTemp = m_saveEdges[0].second;
    //        for (auto it : subEdgesTemp)
    //        {
    //            if (setEdgeNames.end() == setEdgeNames.find(QString::fromStdString(it)))
    //            {
    //                auto itor = subEdges.find(it);
    //                if (subEdges.end() != itor)
    //                    subEdges.erase(it);
    //            }
    //        }
    //    }

    //    m_selectEdges = m_saveEdges;

    //    Gui::Selection().addSelectionGate(new ShapeSelection(m_pDoc, selectionMode, m_selectEdges, m_relyFaces));
    //    selectionMode = AppendEdge;

    //    updateTreeView(m_selectEdges);

    //    highlightReferences(Edge, m_selectEdges, true);

    this->QWidget::show();
}

void DlgProjection::previewCurve(bool ok)
{
    if (vp)
        vp->setVisible(ok);
}

void DlgProjection::previewDirection(bool ok)
{
    if (vpDir)
        vpDir->setVisible(ok);
}

void DlgProjection::setSelectedFaces(std::vector<SubSetObjs>& faces)
{
    m_relyFaces = faces;
}

void DlgProjection::accept()
{
    Q_EMIT sigCancel();

    //    selectionMode = None;
    //    Gui::Selection().rmvSelectionGate();

    //    //    if (editedObject->mustExecute())
    //    //        editedObject->recomputeFeature();
    //    //    if (!editedObject->isValid()) {
    //    //        QMessageBox::warning(this, tr("Invalid object"),
    //    //            QString::fromLatin1(editedObject->getStatusString()));
    //    //        return false;
    //    //    }

    //    highlightReferences(Edge, m_selectEdges, false);

    //    //    // unhighlight the referenced Edge
    //    //    std::vector<App::PropertyLinkSubList::SubSet> links;
    //    //    links.push_back(std::make_pair(editedObject->InitialEdge.getValue(),
    //    //                                   editedObject->InitialEdge.getSubValues()));
    //    //    this->vp->highlightReferences(ViewProviderFilling::Edge, links, false);
    //    m_saveEdges = m_selectEdges;

}

void DlgProjection::reject()
{
    Q_EMIT sigOK();

    //    highlightReferences(Edge, m_selectEdges, false);

    //    selectionMode = None;
    //    Gui::Selection().rmvSelectionGate();

    //    m_selectEdges.clear();
}

}
#include "moc_DlgProjection.cpp"
