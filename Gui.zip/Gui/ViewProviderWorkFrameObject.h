#ifndef WIRCORE_VIEWPROVIDERWORKFRAMEOBJECT_H
#define WIRCORE_VIEWPROVIDERWORKFRAMEOBJECT_H

#include <Gui/ViewProviderOriginGroup.h>
#include <Gui/ViewProviderGeometryObject.h>

#include <App/DocumentObject.h>


namespace WirCoreGui
{

class ViewProviderWorkFrameObject: public Gui::ViewProviderGeometryObject,
                                   public Gui::ViewProviderGeoFeatureGroupExtension

{
    PROPERTY_HEADER(WirCoreGui::ViewProviderWorkFrameObject);

public:
    ViewProviderWorkFrameObject();
    ~ViewProviderWorkFrameObject();

    bool canDragObjects() const;
    bool canDragObject(App::DocumentObject*) const;
    bool canDropObjects() const;
    bool canDropObject(App::DocumentObject*) const;

    bool showInTree() const
    {
      return false;
    }

    virtual void onChanged(const App::Property* prop);
    void updateData(const App::Property* prop);

};
}
#endif // VIEWPROVIDERWORKFRAMEOBJECT_H
