#pragma once

#include <QDialog>
#include "ui_DlgRobotSimulate.h"
#include <Gui/TaskView/TaskDialog.h>
#include <Gui/TaskView/TaskView.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/Simulation.h>
#include "ViewProviderRobotObject.h"

namespace WirCoreGui
{
class DlgRobotSimulate : public QDialog, public Ui_DlgRobotSimulate
{
    Q_OBJECT

public:
    DlgRobotSimulate(WirCore::RobotObject* pRobotObject, WirCore::TrajectoryObject* pTrajectoryObject,
                     QWidget *parent = nullptr);
    ~DlgRobotSimulate();

Q_SIGNALS:
    void axisChanged(float A1, float A2, float A3, float A4, float A5, float A6, const Base::Placement& Tcp);

private Q_SLOTS:
    void start(void);
    void stop(void);
    void run(void);
    void back(void);
    void forward(void);
    void end(void);

    void collisionStop(void);
    void close(void) {}
    void speed(int);

    void timerDone(void);
    void valueChanged (int value); // manual
    void valueChanged (double d);

    void valueChangedSpeed(int d);
    void onTarBarValueChanged(int value); // progressbar
    void onCollisionBarValueChanged(int value); // progressbar

protected:
    void setTo();

    QTimer *timer;
    WirCore::Simulation sim;
    WirCore::RobotObject *pcRobot;
    WirCore::TrajectoryObject* trace;
    ViewProviderRobotObject *ViewProv;
    bool Run;
    bool block;
    float timePos;
    float duration;
    int pointIndex = 0;

private:
    void initTrajectoryTable();
    void initWayPointStates();
    void initSimControlBar();
    void collisonCheck();
    void setTargetValue(int index);
    int checkWayPoint(float time);

    bool isCollisionStop = false;

};

} //namespace WirCoreGui
