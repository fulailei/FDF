#include "PreCompiled.h"

#ifndef _PreComp_

# include <QApplication>
# include <QFileDialog>
# include <QLabel>
#endif

#include "ViewProviderWorkFrameObject.h"
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/PointObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

using namespace Gui;
using namespace WirCoreGui;
using namespace std;


PROPERTY_SOURCE(WirCoreGui::ViewProviderWorkFrameObject, Gui::ViewProviderGeometryObject)


ViewProviderWorkFrameObject::ViewProviderWorkFrameObject()
{
     sPixmap = "WirCore_WobjReferenceFrame";
     Gui::ViewProviderGeoFeatureGroupExtension::initExtension(this);
}

ViewProviderWorkFrameObject::~ViewProviderWorkFrameObject()
{
}

void ViewProviderWorkFrameObject::onChanged(const App::Property* prop)
{
    ViewProviderGeometryObject::onChanged(prop);
}

bool ViewProviderWorkFrameObject::canDragObject(App::DocumentObject* obj) const
{
    return false;
}

bool ViewProviderWorkFrameObject::canDragObjects() const
{
    return false;
}

bool ViewProviderWorkFrameObject::canDropObjects() const
{
     return false;
}

bool ViewProviderWorkFrameObject::canDropObject(App::DocumentObject* obj) const
{
     return false;
}

void ViewProviderWorkFrameObject::updateData(const App::Property* prop)
{
    std::vector<WirCore::TrajectoryObject*> _trajs;
    std::string trajsLabel = "";
    WirCore::WorkFrameObject* pObj = dynamic_cast<WirCore::WorkFrameObject*>(pcObject);
    if (prop == &pObj->Placement) {
        auto group = pObj->getObjectsOfType(WirCore::PointObject::getClassTypeId());
        for (auto obj : group) {
           auto group1 = WirCore::TrajectoryObject::getInlistTrajectory(obj);
           for (auto obj1 : group1)
           {
               std::string  str = "#*&^%";
               str.append(obj1->Label.getValue());
               str.append("%^&*#");
               if (trajsLabel.find(str) == std::string::npos )
               {
                   _trajs.push_back(obj1);
                   trajsLabel.append(str);
               }
           }
        }
        for (auto obj : _trajs) {
           obj->updateEvent.setValue(true);
        }

    }
    Gui::ViewProviderGeometryObject::updateData(prop);
}


