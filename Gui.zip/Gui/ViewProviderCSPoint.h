#ifndef WIRCORE_VIEWPROVIDERCSPOINT_H
#define WIRCORE_VIEWPROVIDERCSPOINT_H


#include "ViewProviderDatumCS.h"

namespace WirCoreGui {
class ViewProviderCSPoint : public ViewProviderDatumCoordinateSystem
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderCSPoint);

public:
    ViewProviderCSPoint();
    ~ViewProviderCSPoint();

    void setupContextMenu(QMenu*, QObject*, const char*);

    bool showInTree() const
    {
      return false;
    }

    void updateData(const App::Property*);
};

}
#endif // VIEWPROVIDERCSPOINT_H
