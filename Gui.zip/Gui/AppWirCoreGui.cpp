    /***************************************************************************
 *   Copyright (c) YEAR YOUR NAME         <Your e-mail address>            *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"
#ifndef _PreComp_
# include <Python.h>
#endif

#include <Base/Console.h>
#include <Base/PyObjectBase.h>
#include <Gui/Application.h>
#include "ViewProviderRobotObject.h"
#include "ViewProviderRobotToolObject.h"
#include "ViewProviderWorkFrameObject.h"
#include "ViewProviderDatum.h"
#include "ViewProviderDatumCS.h"
#include "ViewProviderReferenceFrame.h"
#include "ViewProviderTrajectory.h"
#include "ViewProviderCSPoint.h"
#include "ViewProviderWaypointObject.h"
#include "ViewProviderWorkStationGroup.h"
#include "ViewProviderLinkTrajectory.h"
#include "ViewProviderACM.h"
#include "Mod/WirCore/Gui/DlgCreateGeometry/ArrowLine.h"
#include "ViewProviderGeometryObject.h"
#include "ViewProviderOperationObject.h"

#include <Gui/Language/Translator.h>

#include "Workbench.h"

#include <CXX/Extensions.hxx>
#include <CXX/Objects.hxx>

// use a different name to CreateCommand()
void CreateWirCoreCommands(void);
void CreateWirCoreCommandInsertRobot(void);
void CreateWirCoreCommandFreeHand(void);
void CreateWirCoreCommandGraphicsTools(void);
void CreateWirCoreCommandCollision(void);
void CreateWirCoreCommandCreateReferenceFrame();
void CreateWirCoreCommandPointOperate(void);
void CreateWirCoreCommandTrajectory();
void CreatePointCloudCommands();
void CreateWirCoreCommandCreateGeometry();
void CreateWirCoreCommandCreateOperation();

void loadWirCoreResource() {
    Q_INIT_RESOURCE(WirCore);
    Gui::Translator::instance()->refresh();
}



namespace WirCoreGui {
class Module : public Py::ExtensionModule<Module>
{
public:
    Module() : Py::ExtensionModule<Module>("WirCoreGui")
    {
        initialize("This module is the WirCoreGui module."); // register with Python
    }

    virtual ~Module() {}

private:
};

PyObject* initModule()
{
    return (new Module)->module().ptr();
}

} // namespace WirCoreGui


/* Python entry */
PyMOD_INIT_FUNC(WirCoreGui)
{
    if (!Gui::Application::Instance) {
        PyErr_SetString(PyExc_ImportError, "Cannot load Gui module in console application.");
        PyMOD_Return(0);
    }
    try {
        Base::Interpreter().runString("import PartGui");
        Base::Interpreter().runString("import Part");
        Base::Interpreter().runString("import WirCore");
        Base::Interpreter().runString("import Points");
        Base::Interpreter().runString("import PointsGui");
        //Base::Interpreter().runString("import DraftUtils");

        // set some default values
        // default speed for trajectory is 1m/s
        Base::Interpreter().runString("_DefSpeed = '1 m/s'");
        // default Cintinuity is off
        Base::Interpreter().runString("_DefCont = False");
        // default Cintinuity is off
        Base::Interpreter().runString("_DefAccelaration = '1 m/s^2'");
        // default orientation of a waypoint if no other constraint
        Base::Interpreter().runString("_DefOrientation = FreeCAD.Rotation()");
        // default displacement while e.g. picking
        Base::Interpreter().runString("_DefDisplacement = FreeCAD.Vector(0,0,0)");
    }
    catch(const Base::Exception& e) {
        PyErr_SetString(PyExc_ImportError, e.what());
        PyMOD_Return(0);
    }

    PyObject* mod = WirCoreGui::initModule();
    Base::Console().Log("Loading GUI of WirWirCore module... done\n");


    // instantiating the commands
    CreateWirCoreCommands();
    CreateWirCoreCommandInsertRobot();
	CreateWirCoreCommandCreateReferenceFrame();
    CreateWirCoreCommandPointOperate();
    CreateWirCoreCommandTrajectory();
	
    CreateWirCoreCommandFreeHand();
    CreateWirCoreCommandGraphicsTools();
    CreateWirCoreCommandCollision();
    CreatePointCloudCommands();
    CreateWirCoreCommandCreateGeometry();
    CreateWirCoreCommandCreateOperation();

    WirCoreGui::Workbench                        ::init();
    WirCoreGui::ViewProviderRobotObject          ::init();
    WirCoreGui::ViewProviderRobotToolObject      ::init();
    WirCoreGui::ViewProviderWorkFrameObject      ::init();
    WirCoreGui::ViewProviderReferenceFrame       ::init();

    WirCoreGui::ViewProviderDatum                ::init();
    WirCoreGui::ViewProviderDatumCoordinateSystem::init();
    WirCoreGui::ViewProviderTrajectory           ::init();
    WirCoreGui::ViewProviderCSPoint              ::init();
    WirCoreGui::ViewProviderWaypointObject       ::init();
    WirCoreGui::ViewProviderWorkStationGroup     ::init();
    WirCoreGui::ViewProviderLinkTrajectory       ::init();
    WirCoreGui::ViewProviderACM                  ::init();

    WirCoreGui::DimensionLinear                  ::initClass();
    WirCoreGui::ViewProviderGeometryObject       ::init();
    WirCoreGui::ViewProviderOperationObject      ::init();

    loadWirCoreResource();

    PyMOD_Return(mod);
}
