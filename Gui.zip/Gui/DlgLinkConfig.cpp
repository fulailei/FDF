#include "PreCompiled.h"
#ifndef _PreComp_
#endif
#include "DlgLinkConfig.h"
#include "ui_DlgLinkConfig.h"
#include <QMessageBox>

using namespace WirCoreGui;

DlgLinkConfig::DlgLinkConfig(std::vector<bool> i_vec, QWidget* parent)
    : QDialog(parent), ui(new Ui_DlgLinkConfig)
{
    ui->setupUi(this);

    QObject::connect(ui->createButton, SIGNAL(clicked()), this, SLOT(onCreateClicked()));
    QObject::connect(ui->cancelButton, SIGNAL(clicked()), this, SLOT(onCancelClicked()));


    ui->radioFront->setChecked(i_vec[0]);
    ui->radioBack->setChecked(!i_vec[0]);

    ui->radioUp->setChecked(i_vec[1]);
    ui->radioDown->setChecked(!i_vec[1]);

    ui->radioFlip->setChecked(i_vec[2]);
    ui->radioNoflip->setChecked(!i_vec[2]);
}

DlgLinkConfig::~DlgLinkConfig()
{
    delete ui;
}

void DlgLinkConfig::onCreateClicked()
{
    accept();
}

void DlgLinkConfig::onCancelClicked()
{
    reject();
}

void DlgLinkConfig::accept()
{
    m_LinkConfig.clear();
    if (ui->radioFront->isChecked())
    {
        m_LinkConfig.push_back(true);
    }
    else
    {
        m_LinkConfig.push_back(false);
    }

    if (ui->radioUp->isChecked())
    {
        m_LinkConfig.push_back(true);
    }
    else
    {
        m_LinkConfig.push_back(false);
    }

    if (ui->radioFlip->isChecked())
    {
        m_LinkConfig.push_back(true);
    }
    else
    {
        m_LinkConfig.push_back(false);
    }


    QDialog::accept();
    //close();
}

void DlgLinkConfig::reject()
{
    QDialog::reject();
    //close();
}
#include "moc_DlgLinkConfig.cpp"
