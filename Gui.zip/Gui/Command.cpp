/***************************************************************************
 *   Copyright (c) YEAR YOUR NAME         <Your e-mail address>            *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"
#ifndef _PreComp_
#include <QMessageBox>
#include <QFileDialog>
#include <QApplication>
#include <QTextStream>
#endif

#include "Inventor/nodes/SoTransform.h"
#include <Gui/Action.h>
#include <Base/Console.h>
#include <Base/Placement.h>
#include <Base/Tools.h>
#include <App/Document.h>
#include <App/Part.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Document.h>
#include <Gui/MainWindow.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/Control.h>
#include <Gui/FileDialog.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Gui/ViewProvider.h>
#include <Gui/FileDialog.h>
#include <Gui/PositionDlg/TaskPositionDlg.h>
#include <Gui/ViewProviderDragger.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/RobotToolObject.h>
#include <Mod/Part/App/PartFeature.h>
//#include <Gui/TaskView/TaskDialog.h>
#include <Mod/WirCore/Gui/DlgFindRobot.h>

using namespace std;
using namespace WirCore;

//===========================================================================
// Std_New
//===========================================================================

DEF_STD_CMD(WirCoreCmdNew);

WirCoreCmdNew::WirCoreCmdNew()
    :Command("WirCore_New")
{
    sGroup        = QT_TR_NOOP("File");
    sMenuText     = QT_TR_NOOP("&New");
    sToolTipText  = QT_TR_NOOP("Create a new empty document");
    sWhatsThis    = "Std_New";
    sStatusTip    = QT_TR_NOOP("Create a new empty document");
    sPixmap       = "document-new";
    sAccel        = keySequenceToAccel(QKeySequence::New);
}

void WirCoreCmdNew::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    QString cmd;
    cmd = QString::fromLatin1("App.newDocument(\"%1\")")
            .arg(qApp->translate("StdCmdNew","Unnamed"));
    runCommand(Command::Doc,cmd.toUtf8());
    doCommand(Command::Gui,"Gui.activeDocument().activeView().viewDefaultOrientation()");

    std::string FeatName = getUniqueObjectName("default station");
    std::string activeName = "select_active_station";

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::WorkStationGroup* _obj = new WirCore::WorkStationGroup();
    doc->addObject(_obj, FeatName.c_str());
    _obj->Initialization();


    doCommand(Doc,"App.activeDocument().addObject(\"WirCore::ActiveStationObject\", \"%s\")", activeName.c_str());
    doCommand(Doc,"App.activeDocument().%s.Object = App.activeDocument().%s",activeName.c_str(), _obj->Label.getValue());

}


//===========================================================================
// WirCore_Open
//===========================================================================

DEF_STD_CMD(WirCoreCmdOpen);

WirCoreCmdOpen::WirCoreCmdOpen()
    : Command("WirCore_Open")
{
    // setting the
    sGroup        = QT_TR_NOOP("File");
    sMenuText     = QT_TR_NOOP("&Open Example...");
    sToolTipText  = QT_TR_NOOP("Open a example file");
    sWhatsThis    = "WirCore_Open";
    sStatusTip    = QT_TR_NOOP("Open a example file");
    sPixmap       = "document-open";
    sAccel        = keySequenceToAccel(QKeySequence::Open);
}

void WirCoreCmdOpen::activated(int iMsg)
{
    Q_UNUSED(iMsg);

    // fill the list of registered endings
    QString formatList;
    const char* supported = QT_TR_NOOP("Supported formats");
    const char* allFiles = QT_TR_NOOP("All files (*.*)");
    formatList = QObject::tr(supported);
    formatList += QLatin1String(" (");

    std::vector<std::string> filetypes = App::GetApplication().getImportTypes();
    std::vector<std::string>::iterator it;
    // Make sure FCStd is the very first fileformat
    it = std::find(filetypes.begin(), filetypes.end(), "FCStd");
    if (it != filetypes.end()) {
        filetypes.erase(it);
        filetypes.insert(filetypes.begin(), "FCStd");
    }
    for (it=filetypes.begin();it != filetypes.end();++it) {
        formatList += QLatin1String(" *.");
        formatList += QLatin1String(it->c_str());
    }

    formatList += QLatin1String(");;");

    std::map<std::string, std::string> FilterList = App::GetApplication().getImportFilters();
    std::map<std::string, std::string>::iterator jt;
    // Make sure the format name for FCStd is the very first in the list
    for (jt=FilterList.begin();jt != FilterList.end();++jt) {
        if (jt->first.find("*.FCStd") != std::string::npos) {
            formatList += QLatin1String(jt->first.c_str());
            formatList += QLatin1String(";;");
            FilterList.erase(jt);
            break;
        }
    }
    for (jt=FilterList.begin();jt != FilterList.end();++jt) {
        formatList += QLatin1String(jt->first.c_str());
        formatList += QLatin1String(";;");
    }
    formatList += QObject::tr(allFiles);

    QString selectedFilter;
    QStringList fileList = Gui::FileDialog::getOpenFileNames(Gui::getMainWindow(),
                                                             QObject::tr("Open document"), QLatin1String("/home/zsj/work/WirOlp/WirOlp/build/data/Mod/WirCore/examples"), formatList, &selectedFilter);

    if (fileList.isEmpty())
        return;

    // load the files with the associated modules
    Gui::SelectModule::Dict dict = Gui::SelectModule::importHandler(fileList, selectedFilter);
    if (dict.isEmpty()) {
        QMessageBox::critical(Gui::getMainWindow(),
                              qApp->translate("StdCmdOpen", "Cannot open file"),
                              qApp->translate("StdCmdOpen", "Loading the file %1 is not supported").arg(fileList.front()));
    }
    else {
        for (Gui::SelectModule::Dict::iterator it = dict.begin(); it != dict.end(); ++it) {
            getGuiApplication()->open(it.key().toUtf8(), it.value().toLatin1());
        }
    }
}


//===========================================================================
// WirCore_Delete
//===========================================================================
DEF_STD_CMD_A(WirCoreCmdDelete);

WirCoreCmdDelete::WirCoreCmdDelete()
    :Command("WirCore_Delete")
{
    sGroup        = QT_TR_NOOP("WirCore");
    sMenuText     = QT_TR_NOOP("&Delete");
    sToolTipText  = QT_TR_NOOP("Deletes the selected objects");
    sWhatsThis    = "WirCore_Delete";
    sStatusTip    = QT_TR_NOOP("Deletes the selected objects");
#if QT_VERSION >= 0x040200
    sPixmap       = "edit-delete";
#endif
    sAccel        = keySequenceToAccel(QKeySequence::Delete);
    eType         = ForEdit;
}

void WirCoreCmdDelete::activated(int iMsg)
{
    Q_UNUSED(iMsg);

    // go through all documents
    const Gui::SelectionSingleton& rSel = Gui::Selection();
    const std::vector<App::Document*> docs = App::GetApplication().getDocuments();
    for (std::vector<App::Document*>::const_iterator it = docs.begin(); it != docs.end(); ++it) {
        Gui::Document* pGuiDoc = Gui::Application::Instance->getDocument(*it);
        std::vector<Gui::SelectionObject> sel = rSel.getSelectionEx((*it)->getName());
        if (!sel.empty()) {
            bool autoDeletion = true;

            // if an object is in edit mode handle only this object even if unselected (#0001838)
            Gui::ViewProvider* vpedit = pGuiDoc->getInEdit();
            if (vpedit) {
                // check if the edited view provider is selected
                for (std::vector<Gui::SelectionObject>::iterator ft = sel.begin(); ft != sel.end(); ++ft) {
                    Gui::ViewProvider* vp = pGuiDoc->getViewProvider(ft->getObject());
                    if (vp == vpedit) {
                        if (!ft->getSubNames().empty()) {
                            // handle the view provider
                            Gui::getMainWindow()->setUpdatesEnabled(false);

                            try {
                                (*it)->openTransaction("Delete");
                                vpedit->onDelete(ft->getSubNames());
                                (*it)->commitTransaction();
                            }
                            catch (const Base::Exception& e) {
                                (*it)->abortTransaction();
                                e.ReportException();
                            }

                            Gui::getMainWindow()->setUpdatesEnabled(true);
                            Gui::getMainWindow()->update();
                        }
                        break;
                    }
                }
            }
            else {
                // check if we can delete the object - linked objects
                std::set<QString> affectedLabels;
                for (std::vector<Gui::SelectionObject>::iterator ft = sel.begin(); ft != sel.end(); ++ft) {
                    App::DocumentObject* obj = ft->getObject();
                    std::vector<App::DocumentObject*> links = obj->getInList();
                    if (!links.empty()) {
                        // check if the referenced objects are groups or are selected too
                        for (std::vector<App::DocumentObject*>::iterator lt = links.begin(); lt != links.end(); ++lt) {
                            if (!rSel.isSelected(*lt)) {
                                Gui::ViewProvider* vp = pGuiDoc->getViewProvider(*lt);
                                if (!vp->canDelete(obj)) {
                                    autoDeletion = false;
                                    affectedLabels.insert(QString::fromUtf8((*lt)->Label.getValue()));
                                }
                            }
                        }
                    }
                }

                //check for inactive objects in selection (Mantis #3477)
                std::set<QString> inactiveLabels;
                App::Application& app = App::GetApplication();
                App::Document* actDoc = app.getActiveDocument();
                for (std::vector<Gui::SelectionObject>::iterator ft = sel.begin(); ft != sel.end(); ++ft) {
                    App::DocumentObject* obj = ft->getObject();
                    App::Document* objDoc = obj->getDocument();
                    if (actDoc != objDoc) {
                        inactiveLabels.insert(QString::fromUtf8(obj->Label.getValue()));
                        autoDeletion = false;
                    }
                }

                if (!autoDeletion) {   //can't just delete, need to ask
                    QString bodyMessage;
                    QTextStream bodyMessageStream(&bodyMessage);

                    //message for linked items
                    if (!affectedLabels.empty()) {
                        bodyMessageStream << qApp->translate("Std_Delete",
                                                             "These items are linked to items selected for deletion and might break.") << "\n\n";
                        for (const auto &currentLabel : affectedLabels)
                            bodyMessageStream << currentLabel << '\n';
                    }

                    //message for inactive items
                    if (!inactiveLabels.empty()) {
                        if (!affectedLabels.empty()) {
                            bodyMessageStream << "\n";
                        }
                        std::string thisDoc = pGuiDoc->getDocument()->getName();
                        bodyMessageStream << qApp->translate("Std_Delete",
                                                             "These items are selected for deletion, but are not in the active document.") << "\n\n";
                        for (const auto &currentLabel : inactiveLabels)
                            bodyMessageStream << currentLabel << " / " << Base::Tools::fromStdString(thisDoc) << '\n';
                    }
                    bodyMessageStream << "\n\n" << qApp->translate("Std_Delete",
                                                                   "Are you sure you want to continue?");

                    int ret = QMessageBox::question(Gui::getMainWindow(),
                                                    qApp->translate("Std_Delete", "Delete Selection Issues"), bodyMessage,
                                                    QMessageBox::Yes, QMessageBox::No);
                    if (ret == QMessageBox::Yes)
                        autoDeletion = true;
                }

                App::Document* doc = App::GetApplication().getActiveDocument();
                if (autoDeletion) {
                    Gui::getMainWindow()->setUpdatesEnabled(false);
                    try {
                        (*it)->openTransaction("Delete");
                        for (std::vector<Gui::SelectionObject>::iterator ft = sel.begin(); ft != sel.end(); ++ft) {
                            Gui::ViewProvider* vp = pGuiDoc->getViewProvider(ft->getObject());
                            if (vp) {
                                // ask the ViewProvider if it wants to do some clean up
                                if (vp->onDelete(ft->getSubNames())) {
                                    //if wants clean up TrajectoryObject,clean up all WayPoints first
                                    if (ft->getObject()->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
                                    {
                                        auto _group = dynamic_cast<WirCore::TrajectoryObject*>(ft->getObject())->WayPointList.getValues();
                                        for (auto obj : _group)
                                        {
                                            if (obj)
                                            {
                                                doc->removeObject(obj->getNameInDocument());
                                            }
                                        }
                                    }
                                }
                                doCommand(Doc,"App.getDocument(\"%s\").removeObject(\"%s\")"
                                          ,(*it)->getName(), ft->getFeatName());
                            }
                        }
                        (*it)->commitTransaction();
                    }
                    catch (const Base::Exception& e) {
                        (*it)->abortTransaction();
                        e.ReportException();
                    }

                    Gui::getMainWindow()->setUpdatesEnabled(true);
                    Gui::getMainWindow()->update();
                }
            }
        }
        doCommand(Doc,"App.getDocument(\"%s\").recompute()", (*it)->getName());
    }
}

bool WirCoreCmdDelete::isActive(void)
{
    return Gui::Selection().getCompleteSelection().size() > 0;
}


//================================================
// WirCore Install Tool to Robot
//================================================
DEF_STD_CMD_A(CmdWirCoreInstallToRobot);

CmdWirCoreInstallToRobot::CmdWirCoreInstallToRobot()
    :Command("WirCore_InstallToRobot")
{
    sAppModule = "WirCore";
    sGroup = QT_TR_NOOP("WirCore");
    sMenuText = QT_TR_NOOP("Install part to Robot");
    sWhatsThis = "WirCore_InstallToRobot";
    sStatusTip = sToolTipText;
    // sPixmap = "WirCore_InstallToRobot";
}

void CmdWirCoreInstallToRobot::activated(int) {

    Gui::SelectionFilter partFeatureFilter  ("SELECT Part::Feature COUNT 1");
    Gui::SelectionFilter partFilter  ("SELECT App::Part COUNT 1");

    Part::Feature *pcFeatureObject;
    App::Part* pcPartObject;
    App::DocumentObject* toolobject;

    if(partFeatureFilter.match()) {
        pcFeatureObject = static_cast<Part::Feature*>(partFeatureFilter.Result[0][0].getObject());
        toolobject = static_cast<App::DocumentObject*>(pcFeatureObject);
    }
    else if(partFilter.match()) {
        pcPartObject = static_cast<App::Part*>(partFilter.Result[0][0].getObject());
        toolobject = static_cast< App::DocumentObject*>(pcPartObject);
    }
    else {
        QMessageBox::warning(Gui::getMainWindow(), QObject::tr("Wrong Selection"),
                             QObject::tr("Select one Part"));
        return;
    }

    std::vector<App::DocumentObject*> list = toolobject->getInList();
    if (list.size() > 0)
    {
        QMessageBox::warning(Gui::getMainWindow(), QObject::tr("Wrong Selection"),
                             QObject::tr("Select one Part without link parts"));

        return;
    }

    App::Document* doc = App::GetApplication().getActiveDocument();

    QStringList link;
    link << QLatin1String(doc->getName());
    link << QLatin1String("WirCore::RobotObject");
    link << QLatin1String("None");
    link << QLatin1String("");

    WirCoreGui::DlgFindRobot dlg(link);
    if (dlg.exec() == QDialog::Accepted) {
        QString _str = dlg.propertyLink();

        if (_str == QLatin1String(""))
        {
            return;
        }
        WirCore::RobotObject* _robotobject = dynamic_cast<WirCore::RobotObject*>(doc->getObject(_str.toStdString().c_str()));

        _robotobject ->ToolShape.setValue(static_cast<App::DocumentObject*>(toolobject));

    }

    updateActive();
    commitCommand();
}

bool CmdWirCoreInstallToRobot::isActive(void)
{
    return (getSelection().countObjectsOfType(Part::Feature::getClassTypeId())
            || getSelection().countObjectsOfType(App::Part::getClassTypeId()))== 1;
}

//===========================================================================
// CmdWirCoreImport:  import geometry
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreImportGeometry)
CmdWirCoreImportGeometry::CmdWirCoreImportGeometry()
    : Command("WirCore_ImportGeometry")
{
    sGroup = QT_TR_NOOP("Create Workstation");
    sMenuText = QT_TR_NOOP("&Import\n Geometry\n");
    sToolTipText = QT_TR_NOOP("Import a geometry in the active document");
    sWhatsThis = "WirCore_Import";
    sStatusTip = QT_TR_NOOP("Import a geometry in the active document");
    sPixmap = "WirCore_ImportGeometry.png";
    //sAccel = "Ctrl+G";
}

void CmdWirCoreImportGeometry::activated(int iMsg)
{
    Q_UNUSED(iMsg);

    QString formatList;
    const char* supported = QT_TR_NOOP("Supported formats");
    const char* allFiles = QT_TR_NOOP("All files (*.*)");
    formatList = QObject::tr(supported);
    formatList += QLatin1String(" (");

    //only support stp and step for now
    formatList += QLatin1String(" *.stp *.step)");
    //formatList += QLatin1String(");;");

    //filter
    /*
    std::map<std::string, std::string> filterList = App::GetApplication().getImportFilters();
    std::map<std::string, std::string>::const_iterator it;
    for(it = filterList.begin(); it != filterList.end(); ++it) {
        if(it->first.find("(*.FCStd)") == std::string::npos) {
            formatList += QLatin1String(it->first.c_str());
            formatList += QLatin1String(";;");
        }
    }*/
    //formatList += QObject::tr(allFiles);

    Base::Reference<ParameterGrp> hPath = App::GetApplication().GetUserParameter().GetGroup("BaseApp")
            ->GetGroup("Preferences")->GetGroup("General");
    QString selectedFilter = QString::fromStdString(hPath->GetASCII("FileImportFilter"));
    QStringList fileList = Gui::FileDialog::getOpenFileNames(Gui::getMainWindow(),
                                                             QObject::tr("Import geometry"), QString(), formatList, &selectedFilter);
    if (!fileList.isEmpty()) {
        hPath->SetASCII("FileImportFilter", selectedFilter.toLatin1().constData());
        Gui::SelectModule::Dict dict = Gui::SelectModule::importHandler(fileList, selectedFilter);

        bool emptyDoc = (getActiveGuiDocument()->getDocument()->countObjects() == 0);
        // load the files with the associated modules
        for (Gui::SelectModule::Dict::iterator it = dict.begin(); it != dict.end(); ++it) {
            getGuiApplication()->importFrom(it.key().toUtf8(),
                                            getActiveGuiDocument()->getDocument()->getName(),
                                            it.value().toLatin1());
        }

        if (emptyDoc) {
            // only do a view fit if the document was empty before. See also parameter 'AutoFitToView' in importFrom()
            std::list<Gui::MDIView*> views = getActiveGuiDocument()->getMDIViewsOfType(Gui::View3DInventor::getClassTypeId());
            for (std::list<Gui::MDIView*>::iterator it = views.begin(); it != views.end(); ++it) {
                (*it)->viewAll();
            }
        }
    }
}

bool CmdWirCoreImportGeometry::isActive(void)
{
    return (getActiveGuiDocument() ? true : false);
}

//===========================================================================
// CmdWirCoreRobotLibrary:  import robot
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreRobotLibrary)
CmdWirCoreRobotLibrary::CmdWirCoreRobotLibrary()
    : Command("WirCore_RobotLibrary")
{
    sGroup = QT_TR_NOOP("Create Workstation");
    sMenuText = QT_TR_NOOP("&Robot\n Library\n");
    sToolTipText = QT_TR_NOOP("Import a robot in the active document");
    sWhatsThis = "WirCore_Import";
    sStatusTip = QT_TR_NOOP("Import a robot in the active document");
    sPixmap = "WirCore_RobotLibrary";
    //sAccel = "Ctrl+G";
}

void CmdWirCoreRobotLibrary::activated(int iMsg)
{
    Q_UNUSED(iMsg);
}

bool CmdWirCoreRobotLibrary::isActive(void)
{
    return (getActiveGuiDocument() ? true : false);
}

//===========================================================================
// CmdWirCoreDeviceLibrary:  import device
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreDeviceLibrary)
CmdWirCoreDeviceLibrary::CmdWirCoreDeviceLibrary()
    : Command("WirCore_DeviceLibrary")
{
    sGroup = QT_TR_NOOP("Create Workstation");
    sMenuText = QT_TR_NOOP("&Device\n Library\n");
    sToolTipText = QT_TR_NOOP("Import a device in the active document");
    sWhatsThis = "WirCore_Import";
    sStatusTip = QT_TR_NOOP("Import a device in the active document");
    sPixmap = "WirCore_DeviceLibrary";
    //sAccel = "Ctrl+G";
}

void CmdWirCoreDeviceLibrary::activated(int iMsg)
{
    Q_UNUSED(iMsg);
}

bool CmdWirCoreDeviceLibrary::isActive(void)
{
    return (getActiveGuiDocument() ? true : false);
}




//===========================================================================
// CmdCoordinateSystem:  Create a coordinate system
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreCoordinateSystem)
CmdWirCoreCoordinateSystem::CmdWirCoreCoordinateSystem()
    :Command("WirCore_CoordinateSystem")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("CoordinateSystem");
    sMenuText       = QT_TR_NOOP("Create\n coordinate system\n");
    sToolTipText    = QT_TR_NOOP("Create a new coordinate system");
    sWhatsThis      = "WirCore_CoordinateSystem";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_CoordinateSystem";
    eType           = 0;
}

void CmdWirCoreCoordinateSystem::activated(int iMsg)
{
    Q_UNUSED(iMsg);

    auto UnifiedDatumCommand = [](Gui::Command &cmd, Base::Type type, std::string name)
    {
        std::string fullTypeName (type.getName());
        //        App::PropertyLinkSubList support;
        //        cmd.getSelection().getAsPropertyLinkSubList(support);

        std::string csName = cmd.getUniqueObjectName(name.c_str());
        std::string tmp = std::string("Create ")+name;
        cmd.openCommand(tmp.c_str());
        cmd.doCommand(Gui::Command::Doc,"App.activeDocument().addObject('%s','%s')", "WirCore::CoordinateSystem", csName.c_str());

    };

    UnifiedDatumCommand(*this, Base::Type::fromName("WirCore::CoordinateSystem"), "Cs");
}

bool CmdWirCoreCoordinateSystem::isActive(void)
{
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}

//===========================================================================
// CmdWirCoreSetPosition
//===========================================================================
class CmdWirCoreSetPosition : public Gui::Command
{
public:
    CmdWirCoreSetPosition();
    virtual ~CmdWirCoreSetPosition(){}
    virtual void languageChange();
    virtual const char* className() const {return "CmdWirCoreSetPosition";}
    //void updateIcon(const Gui::MDIView* view);
protected:
    virtual void activated(int iMsg);
    virtual bool isActive(void);
    virtual Gui::Action * createAction(void);
};

CmdWirCoreSetPosition::CmdWirCoreSetPosition()
    : Command("WirCore_SetPosition")
{
    sGroup        = QT_TR_NOOP("SetPosition");
    sMenuText     = QT_TR_NOOP("SetPosition");
    sToolTipText  = QT_TR_NOOP("SetPosition");
    sStatusTip    = QT_TR_NOOP("SetPosition");
    //sPixmap       = "WirCore_SetPosition";
    //eType         = Alter3DView;
}

Gui::Action * CmdWirCoreSetPosition::createAction(void)
{
    Gui::ActionGroup* pcAction = new Gui::ActionGroup(this, Gui::getMainWindow());
    pcAction->setExclusive(false);
    pcAction->setDropDownMenu(false); // this can make a style like workbench. fuck!!!
    applyCommandData(this->className(), pcAction);

    auto addAction = [&](QString name)
    {
        QAction* act = pcAction->addAction(/*QString()*/name);
        act->setText(name);
        act->setToolTip(name);
        act->setCheckable(false);
        //act->setChecked(true);
        act->setObjectName(name);
        //act->setIcon(BitmapFactory().iconFromTheme(""));
        //act->setShortcut(QKeySequence(QString::fromUtf8("V,1")));
    };
    addAction(QString::fromLatin1(QT_TR_NOOP("SetPosition")));
    addAction(QString::fromLatin1(QT_TR_NOOP("OffsetPosition")));
    addAction(QString::fromLatin1(QT_TR_NOOP("RotatePosition")));

    //pcAction->setIcon(a0->icon());
    _pcAction = pcAction;
    languageChange();
    return pcAction;
}

void CmdWirCoreSetPosition::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    iMsg += 2;
    auto updateTransform = [](const Base::Placement& from, SoTransform* to)
    {
        float q0 = (float)from.getRotation().getValue()[0];
        float q1 = (float)from.getRotation().getValue()[1];
        float q2 = (float)from.getRotation().getValue()[2];
        float q3 = (float)from.getRotation().getValue()[3];
        float px = (float)from.getPosition().x;
        float py = (float)from.getPosition().y;
        float pz = (float)from.getPosition().z;
        to->rotation.setValue(q0,q1,q2,q3);
        to->translation.setValue(px,py,pz);
        to->center.setValue(0.0f,0.0f,0.0f);
        to->scaleFactor.setValue(1.0f,1.0f,1.0f);
    };

    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (!sel.empty() && sel[0])
    {
        App::GeoFeature *geoFeature = static_cast<App::GeoFeature *>(sel[0]);
        const Base::Placement &placement = geoFeature->Placement.getValue();
        SoTransform *tempTransform = new SoTransform();
        tempTransform->ref();
        updateTransform(placement, tempTransform);


        Gui::TaskView::TaskDialog* dlg = Gui::Control().activeDialog();
        Gui::Dialog::TaskPositionDlg* task;
        task = qobject_cast<Gui::Dialog::TaskPositionDlg*>(dlg);
        if (dlg && !task) {
            // there is already another task dialog which must be closed first
            Gui::Control().showDialog(dlg);
        }
        if (!task) {


            Gui::Document* document = Gui::Application::Instance->activeDocument();
            if (document)
            {
                Gui::ViewProvider* vp = document->getViewProvider(sel[0]);
                task = new Gui::Dialog::TaskPositionDlg(iMsg);

                //auto dragger = dynamic_cast<Gui::ViewProviderDragger*>(vp);
                //dragger->curTask = static_cast<Gui::Dialog::TaskPositionDlg*>(task);

                task->setGlobalPlacement(geoFeature->globalPlacement());
                task->setPlacement(vp->getRoot(), placement);

                ///dragger->connectSendPosSignal();

                ///task->bindSendPosSignal(boost::bind(&Gui::ViewProviderDragger::sendPosSignal, dragger));
                ///task->disonnectSendPosSignal(boost::bind(&Gui::ViewProviderDragger::disConnectSignal, dragger));

            }
            //task->setPropertyName(propertyname);
            Gui::Control().showDialog(task);
        }
    }
}

bool CmdWirCoreSetPosition::isActive(void)
{
    Gui::Document* active = Gui::Application::Instance->activeDocument();
    if (active)
    {
        App::Document* document = active->getDocument();
        if (document)
        {
            auto objs = document->getObjectsOfType(App::GeoFeature::getClassTypeId());
            if (!objs.empty())
                return true;
        }
    }

    return false;
}

void CmdWirCoreSetPosition::languageChange()
{
    Command::languageChange();

    if (!_pcAction)
        return;
    Gui::ActionGroup* pcAction = qobject_cast<Gui::ActionGroup*>(_pcAction);
    QList<QAction*> acts = pcAction->actions();

    acts[0]->setText(QCoreApplication::translate(this->className(), "SetPosition"));
    acts[1]->setText(QCoreApplication::translate(this->className(), "OffsetPosition"));
    acts[2]->setText(QCoreApplication::translate(this->className(), "RotatePosition"));
}

void CreateWirCoreCommands(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();
    rcCmdMgr.addCommand(new WirCoreCmdNew());
    rcCmdMgr.addCommand(new WirCoreCmdDelete());
    rcCmdMgr.addCommand(new WirCoreCmdOpen());
    rcCmdMgr.addCommand(new CmdWirCoreInstallToRobot());
    rcCmdMgr.addCommand(new CmdWirCoreImportGeometry());
    rcCmdMgr.addCommand(new CmdWirCoreRobotLibrary());
    rcCmdMgr.addCommand(new CmdWirCoreDeviceLibrary());
    rcCmdMgr.addCommand(new CmdWirCoreCoordinateSystem());
    rcCmdMgr.addCommand(new CmdWirCoreSetPosition());

}
