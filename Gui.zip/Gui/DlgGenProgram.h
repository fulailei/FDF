#ifndef WIRCOREGUI_DLGGENPROGRAME_H
#define WIRCOREGUI_DLGGENPROGRAME_H

#include <QDialog>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>


namespace WirCoreGui {

class Ui_DlgGenProgram;
class DlgGenProgram : public QDialog
{
    Q_OBJECT

public:
    DlgGenProgram(QWidget* parent=0, Qt::WindowFlags fl=0);
    ~DlgGenProgram();

    void accept();
    void reject();

    WirCore::RobotObject* m_robj;
    WirCore::TrajectoryObject* m_tobj;

protected Q_SLOTS:
    void onCreateClicked();
    void onCancelClicked();

protected:
    Ui_DlgGenProgram* ui;
};
}
#endif
