#include "PreCompiled.h"
#ifndef _PreComp_
# include <Standard_math.hxx>
# include <BRep_Builder.hxx>
# include <BRepAlgoAPI_Section.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <BRepAlgoAPI_Fuse.hxx>
# include <TopoDS.hxx>
#include <TColgp_HArray1OfPnt.hxx>
#include <TopExp.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
# include <TopoDS_Compound.hxx>
# include <TopExp_Explorer.hxx>
# include <gp_Pln.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <CPnts_AbscissaPoint.hxx>
# include <cfloat>
//# include <QFuture>
//# include <QFutureWatcher>
# include <QKeyEvent>
//# include <QtConcurrentMap>
# include <boost/bind.hpp>
# include <Python.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoSeparator.h>
#endif
#include "ui_SurfaceCross.h"
#include "SurfaceCross.h"
#include <Mod/WirOlp/App/Trajectory.h>
#include <Mod/WirOlp/App/TrajectoryObject.h>
#include <Mod/WirOlp/App/Waypoint.h>
#include <Mod/Part/App/PartFeature.h>
#include <Gui/BitmapFactory.h>
#include <Gui/ViewProvider.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Document.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Base/Sequencer.h>
#include <Base/UnitsApi.h>

using namespace WirCoreGui;

class TopoDS_Shape;

namespace WirCoreGui {



class ViewProviderSurfaceCross : public Gui::ViewProvider
{
public:
    ViewProviderSurfaceCross()
    {
        coords = new SoCoordinate3();
        coords->ref();
        planes = new SoLineSet();
        planes->ref();
        SoBaseColor* color = new SoBaseColor();
        color->rgb.setValue(1.0f, 0.447059f, 0.337255f);
        SoDrawStyle* style = new SoDrawStyle();
        style->lineWidth.setValue(2.0f);
        this->pcRoot->addChild(color);
        this->pcRoot->addChild(style);
        this->pcRoot->addChild(coords);
        this->pcRoot->addChild(planes);
    }
    ~ViewProviderSurfaceCross()
    {
        coords->unref();
        planes->unref();
    }
    void updateData(const App::Property*)
    {
    }

    const char * getDefaultDisplayMode() const
    {
        return "";
    }

    std::vector<std::string> getDisplayModes(void) const
    {
        return std::vector<std::string>();
    }
    void setCoords(const std::vector<Base::Vector3f>& v)
    {
        std::vector<App::DocumentObject*> obj = Gui::Selection().getObjectsOfType(Part::Feature::getClassTypeId());
        if (obj.size() == 0)  return;
        App::GeoFeature *geoFeature = static_cast<App::GeoFeature *>(obj[0]);

        const Base::Placement &placement = geoFeature->Placement.getValue();

        Base::Rotation rot(placement.getRotation());
        Base::Vector3d axis;

        Base::Vector3d pos(placement.getPosition());

        double angle;
        rot.getValue(axis, angle);

        coords->point.setNum(v.size());
        SbVec3f* p = coords->point.startEditing();
        for (unsigned int i=0; i<v.size(); i++) {
            const Base::Vector3f& pt = v[i];

            gp_Pnt pnt(pt.x, pt.y, pt.z);
            pnt.Rotate(gp_Ax1(gp_Pnt(), gp_Dir(axis.x, axis.y, axis.z)), angle);

            p[i].setValue(pnt.X() + pos.x,pnt.Y() + pos.y,pnt.Z() + pos.z);

       //     p[i].setValue(pt.x,pt.y,pt.z);
        }
        coords->point.finishEditing();
        unsigned int count = v.size()/5;
        planes->numVertices.setNum(count);
        int32_t* l = planes->numVertices.startEditing();
        for (unsigned int i=0; i<count; i++) {
            l[i] = 5;
        }
        planes->numVertices.finishEditing();
    }

    void updateCoords(const std::vector<Base::Vector3f>& v)
    {
        coords->point.setNum(v.size());
        SbVec3f* p = coords->point.startEditing();
        for (unsigned int i=0; i<v.size(); i++) {
            const Base::Vector3f& pt = v[i];
            p[i].setValue(pt.x,pt.y,pt.z);
        }
        coords->point.finishEditing();
        unsigned int count = 1;
        planes->numVertices.setNum(count);
        int32_t* l = planes->numVertices.startEditing();
        for (unsigned int i=0; i<count; i++) {
            l[i] = v.size();
        }
        planes->numVertices.finishEditing();
    }

private:
    SoCoordinate3* coords;
    SoLineSet* planes;
};
}

SurfaceCross::SurfaceCross(QWidget* parent, Qt::WindowFlags fl)
  : QDialog(parent, fl)
{
    ui = new Ui_SurfaceCross();
    ui->setupUi(this);
    ui->location->setRange(-DBL_MAX, DBL_MAX);
    ui->location->setUnit(Base::Unit::Length);
    ui->sampleStep->setRange(0, DBL_MAX);
    ui->sampleStep->setUnit(Base::Unit::Length);
    ui->sampleStep->setValue(1);
    ui->offset->setRange(0, DBL_MAX);
    ui->offset->setUnit(Base::Unit::Length);
    vp = new ViewProviderSurfaceCross();

    Base::Vector3d c = bbox.GetCenter();
    calcPlane(SurfaceCross::XY, c.z);

    ui->location->setValue(c.z);

    Gui::Document* doc = Gui::Application::Instance->activeDocument();
    view = qobject_cast<Gui::View3DInventor*>(doc->getActiveView());
    if (view) {
        view->getViewer()->addViewProvider(vp);
    }
}

SurfaceCross::~SurfaceCross()
{
    delete ui;
    if(view) {
        view->getViewer()->removeViewProvider(vp);
    }
    delete vp;
    Gui::Selection().clearSelection();
}

SurfaceCross::Plane SurfaceCross::plane() const
{
    if(ui->xyPlane->isChecked())
        return SurfaceCross::XY;
    else if(ui->xzPlane->isChecked())
        return SurfaceCross::XZ;
    else
        return SurfaceCross::YZ;
}

int SurfaceCross::GetPlaneType()
{
    if(ui->xyPlane->isChecked())
        return 0;
    else if(ui->xzPlane->isChecked())
        return 1;
    else
        return 2;
}

void SurfaceCross::changeEvent(QEvent *e)
{
    if(e->type() == QEvent::LanguageChange) {
        ui->retranslateUi(this);
    }
    else {
        QDialog::changeEvent(e);
    }
}

void SurfaceCross::keyPressEvent(QKeyEvent *ke)
{
    ke->ignore();
}

void SurfaceCross::accept()
{
    QDialog::accept();
}

void SurfaceCross::on_xyPlane_clicked()
{
    ui->location->setValue(c.z);
    if(!ui->planesBox->isChecked()) {
        calcPlane(SurfaceCross::XY, c.z);
    }
    else {
        //double dist = bbox.LengthZ() / ui->numPlanes->value();
        //ui->offset->setValue(dist);
        calcPlanes(SurfaceCross::XY);
    }
}

void SurfaceCross::on_xzPlane_clicked()
{
    ui->location->setValue(c.y);
    if(!ui->planesBox->isChecked()) {
        calcPlane(SurfaceCross::XZ, c.y);
    }
    else {
        //double dist = bbox.LengthY() / ui->numPlanes->value();
        //ui->offset->setValue(dist);
        calcPlanes(SurfaceCross::XZ);
    }
}

void SurfaceCross::on_yzPlane_clicked()
{
    ui->location->setValue(c.x);
    if(!ui->planesBox->isChecked()) {
        calcPlane(SurfaceCross::YZ, c.x);
    }
    else {
        //double dist = bbox.LengthX()/ui->numPlanes->value();
        //ui->offset->setValue(dist);
        calcPlanes(SurfaceCross::YZ);
    }
}

void SurfaceCross::on_location_valueChanged(double v)
{
    if(!ui->planesBox->isChecked()) {
        calcPlane(plane(), v);
    }
    else {
        calcPlanes(plane());
    }
}

void SurfaceCross::on_sampleStep_valueChanged(double step)
{
    Q_UNUSED(step);
}


void SurfaceCross::on_planesBox_toggled(bool b)
{
    if(b) {
        on_numPlanes_valueChanged(ui->numPlanes->value());
    }
    else {
        SurfaceCross::Plane type = plane();
   //     Base::Vector3d c = bbox.GetCenter();
        double value = 0;
        switch(type) {
        case SurfaceCross::XY:
            value = c.z;
            break;
        case SurfaceCross::XZ:
            value = c.y;
            break;
        case SurfaceCross::YZ:
            value = c.x;
            break;
        }

        ui->location->setValue(value);
        calcPlane(type, value);
    }
}

void SurfaceCross::on_numPlanes_valueChanged(int v)
{
    SurfaceCross::Plane type = plane();
    calcPlanes(type);
}

void SurfaceCross::on_offset_valueChanged(double d)
{
    Q_UNUSED(d);
    calcPlanes(plane());
}

void SurfaceCross::calcPlane(Plane type, double pos)
{
    std::vector<App::DocumentObject*> obj = Gui::Selection().getObjectsOfType(Part::Feature::getClassTypeId());

    if (obj.size() == 0)  return;

    for (std::vector<App::DocumentObject*>::iterator it = obj.begin(); it != obj.end(); ++it) {
        bbox.Add(static_cast<Part::Feature*>(*it)->Shape.getBoundingBox());
    }

    c = bbox.GetCenter();

    c.x = c.x - vecPos.x;
    c.y = c.y - vecPos.y;
    c.z = c.z - vecPos.z;

    App::GeoFeature *geoFeature = static_cast<App::GeoFeature *>(obj[0]);
    const Base::Placement &placement = geoFeature->Placement.getValue();

    vecPos = placement.getPosition();

    double bound[4];
    switch(type) {
    case XY:
        bound[0] = bbox.MinX - vecPos.x;
        bound[1] = bbox.MaxX - vecPos.x;
        bound[2] = bbox.MinY - vecPos.y;
        bound[3] = bbox.MaxY - vecPos.y;
        break;
    case XZ:
        bound[0] = bbox.MinX - vecPos.x;
        bound[1] = bbox.MaxX - vecPos.x;
        bound[2] = bbox.MinZ - vecPos.z;
        bound[3] = bbox.MaxZ - vecPos.z;
        break;
    case YZ:
        bound[0] = bbox.MinY - vecPos.y;
        bound[1] = bbox.MaxY - vecPos.y;
        bound[2] = bbox.MinZ - vecPos.z;
        bound[3] = bbox.MaxZ - vecPos.z;
        break;
    }

    std::vector<double> d;
    d.push_back(pos);
    makePlanes(type, d, bound);
}

void SurfaceCross::calcPlanes(Plane type)
{
    double bound[4];
    switch(type) {
    case XY:
        bound[0] = bbox.MinX - vecPos.x;
        bound[1] = bbox.MaxX - vecPos.x;
        bound[2] = bbox.MinY - vecPos.y;
        bound[3] = bbox.MaxY - vecPos.y;
        break;
    case XZ:
        bound[0] = bbox.MinX - vecPos.x;
        bound[1] = bbox.MaxX - vecPos.x;
        bound[2] = bbox.MinZ - vecPos.z;
        bound[3] = bbox.MaxZ - vecPos.z;
        break;
    case YZ:
        bound[0] = bbox.MinY - vecPos.y;
        bound[1] = bbox.MaxY - vecPos.y;
        bound[2] = bbox.MinZ - vecPos.z;
        bound[3] = bbox.MaxZ - vecPos.z;
        break;
    }

    std::vector<double> d = getPlanes();
    makePlanes(type, d, bound);
}

std::vector<double> SurfaceCross::getPlanes() const
{
    int count = ui->numPlanes->value();
    double pos = ui->location->value().getValue();
    double ofs = ui->offset->value().getValue();

    std::vector<double> d;

    for(int i = 0; i < count; i++) {
        d.push_back(pos + i*ofs);
    }
    return d;
}

void SurfaceCross::makePlanes(Plane type, const std::vector<double> & d, double bound[4])
{
    std::vector<Base::Vector3f> points;
    for(std::vector<double>::const_iterator it=d.begin(); it != d.end(); ++it) {
        Base::Vector3f v[4];
        switch (type) {
        case XY:
            v[0].Set(bound[0], bound[2], *it);
            v[1].Set(bound[1], bound[2], *it);
            v[2].Set(bound[1], bound[3], *it);
            v[3].Set(bound[0], bound[3], *it);
            break;
        case XZ:
            v[0].Set(bound[0], *it, bound[2]);
            v[1].Set(bound[1], *it, bound[2]);
            v[2].Set(bound[1], *it, bound[3]);
            v[3].Set(bound[0], *it, bound[3]);
            break;
        case YZ:
            v[0].Set(*it, bound[0], bound[2]);
            v[1].Set(*it, bound[1], bound[2]);
            v[2].Set(*it, bound[1], bound[3]);
            v[3].Set(*it, bound[0], bound[3]);
            break;
        }

        points.push_back(v[0]);
        points.push_back(v[1]);
        points.push_back(v[2]);
        points.push_back(v[3]);
        points.push_back(v[0]);
    }
    vp->setCoords(points);
}
gp_Trsf SurfaceCross::getObjtrsf()
{
    std::vector<App::DocumentObject*> obj = Gui::Selection().getObjectsOfType(Part::Feature::getClassTypeId());
    App::GeoFeature *geoFeature = static_cast<App::GeoFeature *>(obj[0]);
    const Base::Placement &placement = geoFeature->Placement.getValue();

    Base::Rotation rot(placement.getRotation());
    Base::Vector3d axis;

    double angle;
    rot.getValue(axis, angle);
    gp_Trsf trf;
    trf.SetRotation(gp_Ax1(gp_Pnt(), gp_Dir(axis.x, axis.y, axis.z)), angle);
    trf.SetTranslationPart(gp_Vec(placement.getPosition().x,placement.getPosition().y,placement.getPosition().z));
    return trf;
}

#include "moc_SurfaceCross.cpp"
