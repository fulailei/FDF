#include "PreCompiled.h"

#ifndef _PreComp_
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoDrawStyle.h>
#include <Inventor/nodes/SoLineSet.h>
#include <Inventor/nodes/SoSphere.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoBaseColor.h>
#include <Inventor/actions/SoSearchAction.h>
#include <Inventor/nodes/SoMarkerSet.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoGroup.h>
#include <QFile>
#include <QAction>
#include <QMenu>
#endif

#include "ViewProviderTrajectory.h"
#include <Mod/WirCore/App/PointObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/LinkTrajectoryObject.h>
#include <Mod/WirCore/App/TrajectoryOptimization.h>

#include <App/Document.h>
#include <Base/FileInfo.h>
#include <Base/Stream.h>
#include <Base/Console.h>
#include <App/Application.h>
#include <Gui/Inventor/MarkerBitmaps.h>
#include <Gui/ActionFunction.h>
#include <sstream>

#include "WircoreAction.h"
#include <DlgFindRobot.h>
#include "DlgChooseDirection.h"
#include "DlgTrajectoryOpt.h"

using namespace Gui;
using namespace WirCoreGui;
using namespace WirCore;

PROPERTY_SOURCE(WirCoreGui::ViewProviderTrajectory, Gui::ViewProviderDocumentObject)

ViewProviderTrajectory::ViewProviderTrajectory()
{
    pcTrajectoryRoot = new Gui::SoFCSelection();
    pcTrajectoryRoot->highlightMode = Gui::SoFCSelection::OFF;
    pcTrajectoryRoot->selectionMode = Gui::SoFCSelection::SEL_OFF;
    pcTrajectoryRoot->ref();

    pcCoords = new SoCoordinate3();
    pcCoords->ref();
    pcDrawStyle = new SoDrawStyle();
    pcDrawStyle->ref();
    pcDrawStyle->style = SoDrawStyle::LINES;
    pcDrawStyle->lineWidth = 2;

    pcLines = new SoLineSet;
    pcLines->ref();

    sPixmap = "WirCore_Trajectory";

    ObjectListAction* pcAction = Gui::getMainWindow()->findChild<ObjectListAction*>
            (QString::fromLatin1("add2Trajectory_TrajertoryList"));
    if (pcAction)
    {
        pcAction->setObjectList();
    }

    pcAction = Gui::getMainWindow()->findChild<ObjectListAction*>
            (QString::fromLatin1("CopyWayPoint_TrajertoryList"));
    if (pcAction)
    {
        pcAction->setObjectList();
    }

    pcAction = Gui::getMainWindow()->findChild<ObjectListAction*>
            (QString::fromLatin1("MoveWayPoint_TrajertoryList"));
    if (pcAction)
    {
        pcAction->setObjectList();
    }


}

ViewProviderTrajectory::~ViewProviderTrajectory()
{
    pcTrajectoryRoot->unref();
    pcCoords->unref();
    pcDrawStyle->unref();
    pcLines->unref();
}

void ViewProviderTrajectory::attach(App::DocumentObject *pcObj)
{
    ViewProviderDocumentObject::attach(pcObj);
    SoSeparator* linesep = new SoSeparator;
    SoBaseColor* basecol = new SoBaseColor;
    basecol->rgb.setValue(1.0f, 0.5f, 0.0f);
    linesep->addChild(basecol);
    linesep->addChild(pcCoords);
    linesep->addChild(pcLines);

    SoBaseColor* markcol = new SoBaseColor;
    markcol->rgb.setValue(1.0f, 1.0f, 0.0f);
    SoMarkerSet* marker = new SoMarkerSet;
    marker->markerIndex = Gui::Inventor::MarkerBitmaps::getMarkerIndex("CROSS", App::GetApplication().GetParameterGroupByPath("User parameter:BaseApp/Preferences/View")->GetInt("MarkerSize", 5));
    linesep->addChild(markcol);
    linesep->addChild(marker);

    pcTrajectoryRoot->addChild(linesep);

    addDisplayMaskMode(pcTrajectoryRoot, "Waypoints");
    pcTrajectoryRoot->objectName = pcObj->getNameInDocument();
    pcTrajectoryRoot->documentName = pcObj->getDocument()->getName();
    pcTrajectoryRoot->subElementName = "Main";

}

void ViewProviderTrajectory::setDisplayMode(const char *ModeName)
{
    if(strcmp("Waypoints", ModeName) == 0)
        setDisplayMaskMode("Waypoints");
    ViewProviderDocumentObject::setDisplayMode(ModeName);
}

std::vector<std::string> ViewProviderTrajectory::getDisplayModes() const
{
    std::vector<std::string> strList;
    strList.push_back("Waypoints");
    return strList;
}

void ViewProviderTrajectory::updateData(const App::Property *prop)
{
    WirCore::TrajectoryObject* pcTracObj = static_cast<WirCore::TrajectoryObject*>(pcObject);
    if(prop == &pcTracObj->updateEvent) {
        updataLines();
    }
}

void ViewProviderTrajectory::updataLines()
{
    WirCore::TrajectoryObject* pcTracObj = static_cast<WirCore::TrajectoryObject*>(pcObject);

    std::vector<WirCore::WaypointObject*> vecPoint = pcTracObj->getAllPointsInTrajectory();
    int num = 0;
    pcCoords->point.deleteValues(0);
    for (WirCore::WaypointObject* obj: vecPoint)
    {
        if (!obj)
        {
            continue;
        }
        auto _point = dynamic_cast<WirCore::PointObject*>(obj->linkPoint.getValue());
        if (!_point)
        {
            continue;
        }
        Base::Placement wp = _point->globalPlacement();
        Base::Vector3d pos = wp.getPosition();
        pcCoords->point.set1Value(num++, pos.x, pos.y, pos.z);

    }
    pcLines->numVertices.set1Value(0, num);
}

void ViewProviderTrajectory::TrajectoryOptimization()
{
    WirCore::TrajectoryObject* pcTracObj = static_cast<WirCore::TrajectoryObject*>(pcObject);

    WirCore::TrajectoryOptimization* _OptTrac = new WirCore::TrajectoryOptimization(pcTracObj);

    WirCoreGui::DlgTrajectoryOpt _DlgOpt(_OptTrac->getTracMap());
    if (_DlgOpt.exec() == QDialog::Accepted)
    {

    }

}

void ViewProviderTrajectory::LinkToTrajectory()
{
    WirCore::TrajectoryObject* pcTracObj = dynamic_cast<WirCore::TrajectoryObject*>(pcObject);
    App::Document* doc = App::GetApplication().getActiveDocument();

    QStringList link;
    link << QLatin1String(doc->getName());
    link << QLatin1String("WirCore::TrajectoryObject");
    link << QLatin1String("None");
    link << QLatin1String("");

    DlgFindRobot dlg(link);
    if (dlg.exec() == QDialog::Accepted) {
        QString _str = dlg.propertyLink();

        if (_str == QLatin1String(""))
        {
            return;
        }
        auto _object = dynamic_cast<WirCore::TrajectoryObject*>(doc->getObject(_str.toStdString().c_str()));

        WirCore::LinkTrajectoryObject* _LinkTrajectory = new WirCore::LinkTrajectoryObject();

        std::string n = "Link" + _str.toStdString() + "_";
        _LinkTrajectory->Label.setValue(n);
        _LinkTrajectory->linkTrajectory.setValue(_object);
        doc->addObject(_LinkTrajectory, n.c_str());

        std::vector<App::DocumentObject*> pointGroup;
        pointGroup = pcTracObj->WayPointList.getValues();
        pointGroup.push_back(_LinkTrajectory);

        pcTracObj->WayPointList.setValues(pointGroup);
    }
}

void ViewProviderTrajectory::setupContextMenu(QMenu *menu, QObject *receiver, const char *member)
{
    Gui::ActionFunction* func = new Gui::ActionFunction(menu);

    QAction* act = menu->addAction(QObject::tr("add transition point"), receiver, member);
    QAction* act2 = menu->addAction(QObject::tr("Link Trajectory"), receiver, member);
    QAction* act3 = menu->addAction(QObject::tr(" Trajectory Optimization "), receiver, member);

    func->trigger(act, boost::bind(&ViewProviderTrajectory::addTransitionPoint, this));
    func->trigger(act2, boost::bind(&ViewProviderTrajectory::LinkToTrajectory, this));
    func->trigger(act3, boost::bind(&ViewProviderTrajectory::TrajectoryOptimization, this));

}

WirCore::WaypointObject* ViewProviderTrajectory::addPointbyOld(WirCore::WaypointObject* i_Old, Base::Placement _pla)
{
    App::Document* doc = App::GetApplication().getActiveDocument();

    auto NewWayPoint = new  WirCore::WaypointObject();
    NewWayPoint->copyFrom(i_Old);
    doc->addObject(NewWayPoint);

    auto NewTarget  = new  WirCore::PointObject();
    auto _target = dynamic_cast<WirCore::PointObject*>(i_Old->linkPoint.getValue());
    NewTarget->copyFrom(_target);
    std::string FeatName = "TransitionPoint";
    doc->addObject(NewTarget, FeatName.c_str());

    WirCore::WorkFrameObject* _wobj = WirCore::WorkFrameObject::getWorkFrameInlist(_target);
    _wobj->addObject(NewTarget);

    NewTarget->transformPlacement(_pla);
    NewWayPoint->linkPoint.setValue(NewTarget);

    return NewWayPoint;
}

void ViewProviderTrajectory::addTransitionPoint()
{
    Base::Placement transform;
    WirCoreGui::DlgChooseDirection dlg;
    if (dlg.exec() == QDialog::Accepted)
    {
        transform = dlg.getPos();
    }
    else
    {
        return;
    }

    WirCore::TrajectoryObject* pcTracObj = dynamic_cast<WirCore::TrajectoryObject*>(pcObject);
    std::vector<WirCore::WaypointObject*> pointGroup;
    pointGroup = pcTracObj->getAllPointsInTrajectory();
    auto _FirstPoint = pointGroup[0];

    auto NewWayPoint = addPointbyOld(_FirstPoint, transform);

    auto _LastPoint = pointGroup.back();
    auto NewLastPoint = addPointbyOld(_LastPoint, transform);


    std::vector<App::DocumentObject*> _pointGroup;
    _pointGroup = pcTracObj->WayPointList.getValues();

    _pointGroup.insert(_pointGroup.begin(),NewWayPoint);
    _pointGroup.push_back(NewLastPoint);

    pcTracObj->WayPointList.setValues(_pointGroup);
}

std::vector<App::DocumentObject*> ViewProviderTrajectory::claimChildren(void) const {
    WirCore::TrajectoryObject* pcTracObj = dynamic_cast<WirCore::TrajectoryObject*>(pcObject);
    std::vector<App::DocumentObject*> children;

    std::vector<App::DocumentObject*> pointGroup;
    pointGroup = pcTracObj->WayPointList.getValues();

    for (unsigned int i = 0; i < pointGroup.size(); i ++ )
    {
         children.push_back(pointGroup[i]);
    }

    return children;
}


bool ViewProviderTrajectory::canDropObjects() const
{
     return true;
}


bool ViewProviderTrajectory::canDropObject(App::DocumentObject* obj) const
{
    if (obj->isDerivedFrom(WirCore::TrajectoryOperationObject::getClassTypeId()))
    {
        return true;
    }

    return false;
}

bool ViewProviderTrajectory::canDragObjects() const
{
     return true;
}


void ViewProviderTrajectory::dropObject(App::DocumentObject* obj)
{
    //删除原位置结点
    WirCore::TrajectoryObject* src_TrajectoryObject = findTrajtoryContainPoint(obj);
    std::vector<App::DocumentObject*> src_pointGroup = src_TrajectoryObject->WayPointList.getValues();
    std::vector<App::DocumentObject*>::iterator
                   result = find(src_pointGroup.begin( ), src_pointGroup.end( ), obj);
    src_pointGroup.erase(result);
    src_TrajectoryObject->WayPointList.setValues(src_pointGroup);

    //找到要插入的位置
    WirCore::TrajectoryObject* pcTracObj = dynamic_cast<WirCore::TrajectoryObject*>(pcObject);
    std::vector<App::DocumentObject*> fix_pointGroup = pcTracObj->WayPointList.getValues();
    fix_pointGroup.push_back(obj);
    pcTracObj->WayPointList.setValues(fix_pointGroup);
}


WirCore::TrajectoryObject* ViewProviderTrajectory::findTrajtoryContainPoint(App::DocumentObject* obj)
{
    std::vector<App::DocumentObject*> t_vec = obj->getInList();
    WirCore::TrajectoryObject* src_Trajectory;
    for (std::vector<App::DocumentObject*>::iterator it = t_vec.begin();it != t_vec.end(); ++it)
    {
        if ((*it)->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
        {
            src_Trajectory = dynamic_cast<WirCore::TrajectoryObject*>(*it);
            break;
        }
    }

    return  src_Trajectory;
}




