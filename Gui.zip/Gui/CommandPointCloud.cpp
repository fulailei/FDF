#include "PreCompiled.h"
#ifndef _PreComp_
# include <algorithm>
# include <QFileInfo>
# include <QInputDialog>
# include <Python.h>
# include <Inventor/events/SoMouseButtonEvent.h>
#endif

#include <Base/Exception.h>
#include <Base/Matrix.h>
#include <App/Application.h>
#include <App/Document.h>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <Gui/MainWindow.h>
#include <Gui/Command.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/ViewProvider.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Gui/WaitCursor.h>
#include <Mod/Points/App/PointsFeature.h>
#include <Mod/Points/App/Properties.h>
#include <Mod/Points/App/Points.h>

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
DEF_STD_CMD_A(CmdWirCorePointsConvert);

CmdWirCorePointsConvert::CmdWirCorePointsConvert()
  :Command("WirCore_Points_Convert")
{
    sAppModule    = "WirCore";
    sGroup        = QT_TR_NOOP("Points");
    sMenuText     = QT_TR_NOOP("Convert to points...");
    sToolTipText  = QT_TR_NOOP("Convert to points");
    sWhatsThis    = "Points_Convert";
    sStatusTip    = QT_TR_NOOP("Convert to points");
    sPixmap       = "WirCore_ConvertToPointCloud";
}

void CmdWirCorePointsConvert::activated(int iMsg)
{
    bool ok;
    double tol = QInputDialog::getDouble(Gui::getMainWindow(), QObject::tr("Distance"),
        QObject::tr("Enter maximum distance:"), 0.1, 0.05, 10.0, 2, &ok);
    if (!ok)
        return;

    //tol = 0.025;

    // get CS
    QStringList items;
    Gui::Document* doc = Gui::Application::Instance->activeDocument();
    App::Document* app = doc->getDocument();
    std::vector<App::DocumentObject*> obj = app->getObjectsOfType(Base::Type::fromName("Part::Datum" /*"WirCore::CoordinateSystem"*/));
    for (std::vector<App::DocumentObject*>::iterator it=obj.begin();it!=obj.end();++it)
        items << QString::fromLocal8Bit((*it)->Label.getValue());

    QString item = QInputDialog::getItem(Gui::getMainWindow(), QObject::tr("CS"),
                                         QObject::tr("cs:"), items, 0, false, &ok);
    if (!(ok && !item.isEmpty()))
        return;

    Base::Placement globalRelatedPlacement;
    auto objCS = app->getObject(item.toLocal8Bit());
    if (objCS)
        globalRelatedPlacement = static_cast<App::GeoFeature*>(objCS)->globalPlacement();


    Gui::WaitCursor wc;
    openCommand("Convert to points");
    std::vector<App::DocumentObject*> geoObject = getSelection().getObjectsOfType(Base::Type::fromName("App::GeoFeature"));

    bool addedPoints = false;
    for (std::vector<App::DocumentObject*>::iterator it = geoObject.begin(); it != geoObject.end(); ++it) {
        Base::Placement globalPlacement = static_cast<App::GeoFeature*>(*it)->globalPlacement();
        Base::Placement localPlacement = static_cast<App::GeoFeature*>(*it)->Placement.getValue();
        localPlacement = globalPlacement * localPlacement.inverse();
        const App::PropertyComplexGeoData* prop = static_cast<App::GeoFeature*>(*it)->getPropertyOfGeometry();
        if (prop) {
            const Data::ComplexGeoData* data = prop->getComplexData();
            std::vector<Base::Vector3d> vertexes;
            std::vector<Base::Vector3d> normals;
            data->getPoints(vertexes, normals, static_cast<float>(tol));
            if (!vertexes.empty()) {
                Points::Feature* fea = 0;
                if (vertexes.size() == normals.size()) {
                    fea = static_cast<Points::Feature*>(Base::Type::fromName("Points::FeatureCustom").createInstance());
                    if (!fea) {
                        Base::Console().Error("Failed to create instance of 'Points::FeatureCustom'\n");
                        continue;
                    }
                    Points::PropertyNormalList* prop = static_cast<Points::PropertyNormalList*>
                        (fea->addDynamicProperty("Points::PropertyNormalList", "Normal"));
                    if (prop) {
                        std::vector<Base::Vector3f> normf;
                        normf.resize(normals.size());
                        std::transform(normals.begin(), normals.end(), normf.begin(), Base::toVector<float, double>);
                        prop->setValues(normf);
                    }
                }
                else {
                    fea = new Points::Feature;
                }

                Points::PointKernel kernel;
                kernel.reserve(vertexes.size());
                for (std::vector<Base::Vector3d>::iterator pt = vertexes.begin(); pt != vertexes.end(); ++pt)
                    kernel.push_back(*pt);

                // change cs
                fea->Points.setValue(kernel);
                localPlacement = globalRelatedPlacement.inverse() * localPlacement;
                fea->Placement.setValue(localPlacement);

                App::Document* doc = (*it)->getDocument();
                doc->addObject(fea, "Points");
                fea->purgeTouched();
                addedPoints = true;
            }
        }
    }

    if (addedPoints)
        commitCommand();
    else
        abortCommand();
}

bool CmdWirCorePointsConvert::isActive(void)
{
    return getSelection().countObjectsOfType(Base::Type::fromName("App::GeoFeature")) > 0;
}

void CreatePointCloudCommands(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();
    rcCmdMgr.addCommand(new CmdWirCorePointsConvert());
}
