#pragma once
#include <Gui/TaskView/TaskView.h>
#include <Gui/Selection.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/AllowedCollisionMatrix.h>
#include <vector>
#include <QDialog>

namespace WirCoreGui
{

namespace Ui
{
    class Form;
}

class DlgCollisionMatrix : public QDialog // : public Gui::TaskView::TaskBox
{
    Q_OBJECT

public:
    DlgCollisionMatrix(WirCore::AllowedCollisionMatrix& acm,
                    QWidget* parent = nullptr,
                    Qt::WindowFlags fl = nullptr);

    ~DlgCollisionMatrix() { delete ui; }

    WirCore::AllowedCollisionMatrix& getACM() { return acm; }

public Q_SLOTS:
    void on_colorButton_clicked();
    void on_checkBox_CheckHideObject_toggled();
    void on_checkBox_MarkCollisionPoint_toggled();
    void on_checkBox_CheckInSim_toggled();
    void on_fcl_toggled();
    void on_openinventor_toggled();

private Q_SLOTS:
    void slotCellDoubleClicked(int row, int column);

private:
    void setTableWidgeSize();
    void updateTable();

    Ui::Form* ui;
    //QWidget* proxy;
    WirCore::AllowedCollisionMatrix& acm;
    std::vector<bool> bflipValues;
    static DlgCollisionMatrix* _instance;

    /*
private Q_SLOTS:
    void setAxis(float A1, float A2, float A3, float A4, float A5, float A6, const Base::Placement &Tcp);
    void changeSliderA1(int value);
    void changeSliderA2(int value);
    void changeSliderA3(int value);
    void changeSliderA4(int value);
    void changeSliderA5(int value);
    void changeSliderA6(int value);
    void createPlacementDlg(void);
*/
};
}
