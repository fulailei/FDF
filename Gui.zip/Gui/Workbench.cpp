
#include "PreCompiled.h"

#ifndef _PreComp_

#include <QDir>
#include <QFileInfo>
#include <QMessageBox>
#include <QMenu>
#include <QObject>
#include <QTextEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QAction>
#include <QActionGroup>
#include <QComboBox>
#include <QIcon>
#include <QButtonGroup>
#include <QAbstractButton>
#include <QTextStream>
#include <TabToolbar/TabToolbar.h>
#include <TabToolbar/Page.h>
#include <TabToolbar/Group.h>
#include <TabToolbar/SubGroup.h>
#include <TabToolbar/StyleTools.h>
#endif

#include <Gui/Action.h>
#include "Workbench.h"
#include <App/Application.h>
#include <Gui/MenuManager.h>
#include <Gui/MainWindow.h>
#include <Gui/ToolBarManager.h>
#include <Gui/WaitCursor.h>
#include <Gui/Control.h>
#include <Gui/TaskView/TaskWatcher.h>
#include "RobotWatcher.h"
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/DockWindowManager.h>
#include <Gui/BitmapFactory.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/PointObject.h>
#include <DlgSelActiveObj.h>
#include <Gui/MenuManager.h>
#include <Gui/ToolBarManager.h>

//#include <Mod/WirCore/App/log/log.h>
//#include <Gui/Log/log.h>

using namespace WirCoreGui;
using namespace WirCore;


/// @namespace WirCoreGui @class Workbench
TYPESYSTEM_SOURCE(WirCoreGui::Workbench, Gui::BlankWorkbench)

Workbench::Workbench()
{
    // WirCore::Log::Init();
    //WIR_TRACE("Hello world");
}

Workbench::~Workbench()
{
}

void Workbench::setupContextMenu(const char *recipient, Gui::MenuItem *item) const
{
    Gui::BlankWorkbench::setupContextMenu(recipient, item);
    if(strcmp(recipient, "View") == 0)
    {
        Gui::MenuItem* wirViews = new Gui::MenuItem;
        wirViews->setCommand("Standard views");

        *wirViews << "Std_ViewIsometric" << "Separator" << "Std_ViewFront" << "Std_ViewTop" << "Std_ViewRight"
                  << "Std_ViewRear" << "Std_ViewBottom" << "Std_ViewLeft" << "Separator" << "Std_ViewRotateLeft" << "Std_ViewRotateRight";

        *item << "Std_ViewFitAll" << "Std_ViewFitSelection" << "Std_DrawStyle"
              << "Separator" << "Std_ViewDockUndockFullscreen";
    }
    else if(strcmp(recipient, "Tree") == 0) {
        if(Gui::Selection().countObjectsOfType(App::DocumentObject::getClassTypeId()) > 0) {
            *item << "Std_ToggleVisibility";
            if (Gui::Selection().countObjectsOfType(App::DocumentObject::getClassTypeId())
                    == Gui::Selection().countObjectsOfType(WirCore::WaypointObject::getClassTypeId()))
            {
                *item << "Separator"<< "WirCore_CopyWayPoint"<<"WirCore_MoveWayPoint";
            }
            else if (Gui::Selection().countObjectsOfType(App::DocumentObject::getClassTypeId())
                     == Gui::Selection().countObjectsOfType(WirCore::PointObject::getClassTypeId()))
            {
                *item << "Separator"<< "WirCore_CopyPoint"<< "WirCore_AddtoTrajtory";
            }
            if (Gui::Selection().countObjectsOfType(WirCore::WorkStationGroup::getClassTypeId()) == 0 &&
                    Gui::Selection().countObjectsOfType(App::DocumentObjectGroup::getClassTypeId()) == 0)
            {
                *item << "Separator" << "Std_Cut" << "WirCore_Delete";
            }
            if (Gui::Selection().countObjectsOfType(App::Part::getClassTypeId()) == 1 ||
                    Gui::Selection().countObjectsOfType(Part::Feature::getClassTypeId()) == 1)
            {
                *item << "Separator" <<"WirCore_InstallToRobot";
            }

        }
    }
}

void Workbench::activated() {
    Gui::Workbench::activated();

    std::vector<Gui::TaskView::TaskWatcher*> Watcher;

    Watcher.push_back(new RobotWatcher());
    addTaskWatcher(Watcher);
    Gui::Control().showTaskView();

}

void Workbench::deactivated() {
    Gui::Workbench::deactivated();
    removeTaskWatcher();
}

Gui::MenuItem* Workbench::setupMenuBar() const
{
    return new Gui::MenuItem;
}

Gui::ToolBarItem* Workbench::setupToolBars() const
{   
    //    auto hGrp = App::GetApplication().GetParameterGroupByPath("User parameter:BaseApp/Preferences/MainWindow");
    //    std::string style = hGrp->GetASCII("StyleSheet");
    //    if (!style.empty())
    //    {
    //        QFile f(QLatin1String(style.c_str()));
    //        if (f.open(QFile::ReadOnly)) {
    //           // mdi->setBackground(QBrush(Qt::NoBrush));
    //            QTextStream str(&f);
    //            tt->setStyleSheet(str.readAll());
    //            //ActionStyleEvent e(ActionStyleEvent::Clear);
    //            //qApp->sendEvent(&mw, &e);
    //        }
    //    }
    delete m_pTabToolbar;
    m_pTabToolbar = new tt::TabToolbar(Gui::getMainWindow(), 90, 3);
    m_pTabToolbar->setObjectName(QString::fromLatin1("tt"));
    m_pTabToolbar->SetStyle(QString::fromStdString("Vienna"));
    //Gui::getMainWindow()->addToolBar(Qt::TopToolBarArea, tt);
    Gui::getMainWindow()->addToolBarBreak(Qt::TopToolBarArea/*, tt*/);
    Gui::getMainWindow()->addToolBar(m_pTabToolbar);

    m_pPage_Start = createStartPage();
    m_pPage_Model = createModelPage();
    m_pPage_Simulation = createSimulatePage();
    m_pPage_View = createViewPage();
    m_pPage_Machining = createMachiningPage();

    //------------------------------------CornerAction
    QAction* actionHelp = new QAction(QString::fromStdString("Help"));
    m_pTabToolbar->AddCornerAction(actionHelp);

    QList<QAction*> actions = m_pTabToolbar->actions();
    QAction* actionReference = setupAction(actions, "Std_DlgPreferences");
    m_pTabToolbar->AddCornerAction(actionReference);

    return nullptr;
}

Gui::DockWindowItems* Workbench::setupDockWindows() const
{
    Gui::DockWindowItems* root = new Gui::DockWindowItems();
    root->addDockWidget("Std_TreeView2", Qt::LeftDockWidgetArea, true, false);
    root->addDockWidget("Std_CombiView2", Qt::RightDockWidgetArea, true, false);
    root->addDockWidget("Std_PropertyView", Qt::RightDockWidgetArea, true, false);
    root->addDockWidget("Std_ReportView", Qt::BottomDockWidgetArea, true, true);
    root->addDockWidget("Std_PythonView", Qt::BottomDockWidgetArea, true, true);
    root->addDockWidget("Std_WirCoreReportView", Qt::BottomDockWidgetArea, true, true);

    return root;
}

Gui::ToolBarItem* Workbench::setupCommandBars() const
{
    return new Gui::ToolBarItem;
}

tt::Page* Workbench::createStartPage() const
{
    QList<QAction*> actions = m_pTabToolbar->actions();

    //-------------------------Start page
    tt::Page* startPage = m_pTabToolbar->AddPage(/*QString::fromLocal8Bit("开始")*/QObject::tr("Start"));

    m_pGroup_File = startPage->AddGroup(/*QString::fromLocal8Bit("文件")*/QObject::tr("File"));
    tt::Group* sp_g1 = m_pGroup_File;
    //----File group and actions
    QAction* actionNew = setupAction(actions, "WirCore_New");
    actionNew->setObjectName(QString::fromLatin1("&New"));
    QAction* actionOpen = setupAction(actions, "Std_Open");
    QAction* actionExample = setupAction(actions, "WirCore_Open");
    QAction* actionSave = setupAction(actions, "Std_Save");
    QAction* actionSaveAs = setupAction(actions, "Std_SaveAs");
    QAction* actionImport = setupAction(actions, "Std_Import");
    QAction* actionExport = setupAction(actions, "Std_Export");
    QAction* actionCloseActiveWindow = setupAction(actions, "Std_CloseActiveWindow");
    QAction* actionCloseAllWindows = setupAction(actions, "Std_CloseAllWindows");
    QAction* actionQuit = setupAction(actions, "Std_Quit");

    QMenu* menuFile = new QMenu();
    menuFile->addAction(actionNew);
    menuFile->addAction(actionOpen);
    menuFile->addAction(actionExample);
    menuFile->addSeparator();
    menuFile->addAction(actionImport);
    menuFile->addAction(actionExport);
    menuFile->addSeparator();
    menuFile->addAction(actionCloseActiveWindow);
    menuFile->addAction(actionCloseAllWindows);
    menuFile->addSeparator();
    menuFile->addAction(actionSave);
    menuFile->addAction(actionSaveAs);
    menuFile->addSeparator();
    menuFile->addAction(actionQuit);
    sp_g1->AddAction(QToolButton::MenuButtonPopup, actionNew, menuFile);

    //----Edit group and actions
    m_pGroup_Edit = startPage->AddGroup(QObject::tr("Edit") /*QString::fromLocal8Bit("编辑")*/);
    tt::Group* sp_g2 = m_pGroup_Edit;
    QAction* actionUndo = setupAction(actions, "Std_Undo");
    QAction* actionRedo = setupAction(actions, "Std_Redo");

    tt::SubGroup* sp_g2s = sp_g2->AddSubGroup(tt::SubGroup::Align::Yes);
    sp_g2s->AddAction(QToolButton::DelayedPopup, actionUndo);
    sp_g2s->AddAction(QToolButton::DelayedPopup, actionRedo);
    //sp_g2s->AddAction(QToolButton::InstantPopup, actionClose, menu);


    //----create workstation group and actions
    tt::Group* sp_g3 = startPage->AddGroup(QObject::tr("Create Workstation") /*QString::fromLocal8Bit("创建工作站")*/);
    m_pGroup_CreateWorkstation = sp_g3;

    QAction* actionRobotlib = setupAction(actions, "WirCore_RobotLibrary");
    QAction* actionDeviceLib = setupAction(actions, "WirCore_DeviceLibrary");
    QAction* actionImportGeom = setupAction(actions, "WirCore_ImportGeometry");

    QAction* actionInsertAbb4600 = setupAction(actions, "WirCore_InsertAbb4600");

    QMenu* menuRobotLib = new QMenu();
    menuRobotLib->addAction(actionRobotlib);
    menuRobotLib->addAction(actionInsertAbb4600);
    sp_g3->AddAction(QToolButton::InstantPopup, actionRobotlib, menuRobotLib);
    QMenu* menuDeviceLib = new QMenu();
    menuDeviceLib->addAction(actionDeviceLib);
    sp_g3->AddAction(QToolButton::InstantPopup, actionDeviceLib, menuDeviceLib);
    QMenu* menuImport = new QMenu();
    menuImport->addAction(actionImportGeom);
    sp_g3->AddAction(QToolButton::InstantPopup, actionImportGeom);

    //----Trajectory programming group and actions
    tt::Group* sp_gProgramming = startPage->AddGroup(QObject::tr("Trajectory programming") /*QString::fromLocal8Bit("轨迹编程")*/);
    m_pGroup_TrajectoryProgramming = sp_gProgramming;


    QAction* actionFrame = setupAction(actions, "WirCore_CreateReferenceFrame");
    actionFrame->setObjectName(QString::fromLatin1("Create\n Reference Frame\n"));
    QAction* actionWobjFrame = setupAction(actions, "WirCore_CreateWorkObjectReferenceFrame");
    QAction* actionToolFrame = setupAction(actions, "WirCore_CreateToolObjectReferenceFrame");
    QMenu* menuFrame = new QMenu();
    menuFrame->addAction(actionFrame);
    menuFrame->addAction(actionWobjFrame);
    menuFrame->addAction(actionToolFrame);
    sp_gProgramming->AddAction(QToolButton::MenuButtonPopup, actionFrame, menuFrame);

    // insert point
    //  tt::Group* sp_gPoint = startPage->AddGroup(QString::fromStdString("Insert Point"));
    QAction* actionInsertPoint = setupAction(actions, "WirCore_InsertPoint");
    actionInsertPoint->setObjectName(QString::fromLatin1("Insert Point"));
    QAction* actionInsertTcpPoint = setupAction(actions, "WirCore_InsertTcpPoint");
    QMenu* menuPoint = new QMenu();
    menuPoint->addAction(actionInsertPoint);
    menuPoint->addAction(actionInsertTcpPoint);
    sp_gProgramming->AddAction(QToolButton::MenuButtonPopup, actionInsertPoint, menuPoint);


    // create trajectory
    //    tt::Group* sp_gTrajectory = startPage->AddGroup(QString::fromStdString("Create Trajectory"));
    QAction* actionCreateTrajectory = setupAction(actions, "WirCore_CreateTrajectory");
    actionCreateTrajectory->setObjectName(QString::fromLatin1("Create\n Empty Trajectory\n"));
    QAction* actionTrajectoryFromEdge = setupAction(actions, "WirCore_TrajectoryFromEdge");
    QAction* actionTrajectoryFromSection = setupAction(actions, "WirCore_TrajectoryFromSection");
    QMenu* menuTrajectory = new QMenu();
    menuTrajectory->addAction(actionCreateTrajectory);
    menuTrajectory->addAction(actionTrajectoryFromEdge);
    menuTrajectory->addAction(actionTrajectoryFromSection);
    sp_gProgramming->AddAction(QToolButton::MenuButtonPopup, actionCreateTrajectory, menuTrajectory);


    QAction* actionProgram = setupAction(actions, "WirCore_GenProgram");
    QMenu* menuProgram = new QMenu();
    menuProgram->addAction(actionProgram);
    sp_gProgramming->AddAction(QToolButton::MenuButtonPopup, actionProgram, menuProgram);

    //----setting(active) group and actions
    tt::Group* sp_gActiveObj = startPage->AddGroup(QObject::tr("Setting") /*QString::fromLocal8Bit("设置")*/);
    m_pGroup_Setting = sp_gActiveObj;


    QWidget* activeObj = new QWidget(sp_gActiveObj);
    m_pActiveObj = activeObj;
    QVBoxLayout* vLayout = new QVBoxLayout(activeObj);
    activeObj->setLayout(vLayout);
    DlgSelActiveObj* cBox = new DlgSelActiveObj(Gui::getMainWindow());
    cBox->setObjectName(QLatin1String("ActiveSelectObj"));
    vLayout->addWidget(cBox);
    sp_gActiveObj->AddWidget(activeObj);

    //-----FreeHand group and actions
    m_pGroup_Freehand = createFreeHandGroup(startPage, actions);

    //-----GraphicsTools group and actions
    m_pGroup_GraphicsTools = createrGraphicsToolsGroup(startPage);

    return startPage;
}

tt::Group* Workbench::createFreeHandGroup(tt::Page* startPage, QList<QAction*> actions/*, std::function<QAction*(const QList<QAction*>& actions, const char* name)> setupAction*/) const
{
    tt::Group* sp_gFreehand = startPage->AddGroup(QObject::tr("Freehand") /*QCoreApplication::translate("CmdWirCoreFreehandWorldCS", "Freehand")*/);

    QWidget* freeHand = new QWidget(sp_gFreehand);
    //freeHand->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QVBoxLayout* vLayout = new QVBoxLayout(freeHand);
    //vLayout->setSpacing(0);
    //vLayout->setMargin(0);
    freeHand->setLayout(vLayout);

    m_pComCS = new QComboBox(freeHand);
    m_pComCS->insertItem(0, QCoreApplication::translate("CmdWirCoreFreehandWorldCS", "WorldCS")/*QString::fromLatin1(QT_TR_NOOP("World"))*/);
    m_pComCS->insertItem(1, QCoreApplication::translate("CmdWirCoreFreehandWorldCS", "LocalCS")/*QString::fromLatin1(QT_TR_NOOP("Local"))*/);
    vLayout->addWidget(m_pComCS);

    QAction* actionWorldCS= setupAction(actions, "WirCore_FreehandWorldCS");
    QAction* actionLocalCS = setupAction(actions, "WirCore_FreehandLocalCS");

    QObject::connect(m_pComCS, static_cast<void(QComboBox::*)(int)>(&QComboBox::activated), m_pComCS, [=](int i)
    {
        if (i == 0)
            actionWorldCS->trigger();
        else
            actionLocalCS->trigger();
    });


    QWidget* btns = new QWidget(freeHand);
    QHBoxLayout* hLayout = new QHBoxLayout(btns);
    btns->setLayout(hLayout);
    hLayout->setMargin(0);
    vLayout->addWidget(btns);

    QButtonGroup* groupBtns = new QButtonGroup(btns);
    groupBtns->setExclusive(true);
    int i = 0;

    auto addButton = [&](QString name, QString iconName)
    {
        QPushButton* btn = new QPushButton(btns);
        btn->setIcon(QIcon(Gui::BitmapFactory().pixmap(iconName.toLocal8Bit())));
        btn->setObjectName(iconName);
        //btn->setToolTip();
        btn->setFlat(true);
        hLayout->addWidget(btn);
        groupBtns->addButton(btn, i);
        i++;
    };
    addButton(QString::fromLatin1(QT_TR_NOOP("Move")), QString::fromLocal8Bit("WirCore_FreehandMove"));
    addButton(QString::fromLatin1(QT_TR_NOOP("Rotate")), QString::fromLocal8Bit("WirCore_FreehandRotate"));
    addButton(QString::fromLatin1(QT_TR_NOOP("JogJoint")), QString::fromLocal8Bit("WirCore_FreehandJogJoint"));
    addButton(QString::fromLatin1(QT_TR_NOOP("JogLinear")), QString::fromLocal8Bit("WirCore_FreehandJogLinear"));

    QAction* actionMove = setupAction(actions, "WirCore_FreehandMove");
    QAction* actionRotate = setupAction(actions, "WirCore_FreehandRotate");
    QAction* actionJogJoint = setupAction(actions, "WirCore_FreehandJogJoint");
    QAction* actionJogLinear = setupAction(actions, "WirCore_FreehandJogLinear");
    QAction* actionFreeHandClose = setupAction(actions, "WirCore_FreehandClose");

    QObject::connect(groupBtns, static_cast<void(QButtonGroup::*)(int)>(&QButtonGroup::buttonClicked), groupBtns, [=](int i)
    {
        QList<QAbstractButton*> btns = groupBtns->buttons();
        QPushButton* btn = dynamic_cast<QPushButton*>(groupBtns->button(i));
        static int preId = -1;
        if (btn)
        {
            QString objNmae = btn->objectName();
            if (preId != i)
            {
                btn->setIcon(QIcon(Gui::BitmapFactory().pixmap(objNmae.toLocal8Bit() + "_Pressed")));
                if (objNmae.contains(QString::fromLocal8Bit("Move")))
                    actionMove->trigger();
                else if (objNmae.contains(QString::fromLocal8Bit("Rotate")))
                {
                    actionRotate->trigger();
                }
                else if (objNmae.contains(QString::fromLocal8Bit("JogJoint")))
                {
                    actionJogJoint->trigger();
                }
                else
                {
                    actionJogLinear->trigger();
                }
                if (preId != -1)
                    btns[preId]->setIcon(QIcon(Gui::BitmapFactory().pixmap(btns[preId]->objectName().toLocal8Bit())));
                preId = i;
            }
            else
            {
                actionFreeHandClose->trigger();
                btn->setIcon(QIcon(Gui::BitmapFactory().pixmap(objNmae.toLocal8Bit())));
                preId = -1;
            }
        }
    });

    sp_gFreehand->AddWidget(freeHand);

    return sp_gFreehand;
}

tt::Group* Workbench::createrGraphicsToolsGroup(tt::Page* startPage) const
{
    Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();

    tt::Group* sp_gGraphTools = startPage->AddGroup(QObject::tr("Graphics Tools")/*QCoreApplication::translate("CmdWirCoreGraphToolsShowHide", "GraphTools")*/);
    tt::SubGroup* subTools = sp_gGraphTools->AddSubGroup(tt::SubGroup::Align::Yes);

    QMenu* menuShowHide = new QMenu();
    mgr.getCommandByName("WirCore_GraphToolsShowHide")->addTo(menuShowHide);
    //menuShowHide->insertSeparator(menuShowHide->actions()[3]);
    auto actShowHide = new QAction(QCoreApplication::translate("CmdWirCoreGraphToolsShowHide", "Show/Hide"));
    m_pActShowHide = actShowHide;

    actShowHide->setObjectName(QString::fromLatin1("actShowHide"));
    actShowHide->setIcon(QIcon(Gui::BitmapFactory().pixmap(QString::fromLocal8Bit("WirCore_GraphToolsShowHide").toLocal8Bit())));
    subTools->AddAction(QToolButton::InstantPopup, actShowHide, menuShowHide);

    QMenu* menuFrameSize = new QMenu();
    mgr.getCommandByName("WirCore_GraphToolsFrameSize")->addTo(menuFrameSize);
    auto actFrameSize = new QAction(QCoreApplication::translate("CmdWirCoreGraphToolsFrameSize", "FrameSize"));
    m_PActFrameSize = actFrameSize;

    actFrameSize->setIcon(QIcon(Gui::BitmapFactory().pixmap(QString::fromLocal8Bit("WirCore_GraphToolsFrameSize").toLocal8Bit())));
    subTools->AddAction(QToolButton::InstantPopup, actFrameSize, menuFrameSize);

    return sp_gGraphTools;
}

tt::Page* Workbench::createModelPage() const
{
    QList<QAction*> actions = m_pTabToolbar->actions();
    //------------------------------------------------Mode
    tt::Page* modelPage = m_pTabToolbar->AddPage(QObject::tr("Model")/*QString::fromLocal8Bit("模型")*/);

    //----Create PointCloud
    tt::Group* partFrame = modelPage->AddGroup(QObject::tr("Part") /*QString::fromLocal8Bit("模型")*/);
    m_pGroup_Part = partFrame;

    QAction* actionBox = setupAction(actions, "Part_Box");
    QAction* actionCylinder = setupAction(actions, "Part_Cylinder");
    QAction* actionSphere = setupAction(actions, "Part_Sphere");
    QAction* actionCone = setupAction(actions, "Part_Cone");
    QAction* actionTorus = setupAction(actions, "Part_Torus");

    QMenu* menuImportGeo = new QMenu();
    menuImportGeo->addAction(actionBox);
    menuImportGeo->addAction(actionCylinder);
    menuImportGeo->addAction(actionSphere);
    menuImportGeo->addAction(actionCone);
    menuImportGeo->addAction(actionTorus);
    partFrame->AddAction(QToolButton::InstantPopup, actionBox, menuImportGeo);

    //----Create PointCloud
    tt::Group* PointCloudFrame = modelPage->AddGroup(QObject::tr("PointCloud") /*QString::fromLocal8Bit("点云")*/);
    m_pGroup_PointCloud = PointCloudFrame;
    QAction* actionPointsImport = setupAction(actions, "Points_Import");
    QAction* actionPointsExport = setupAction(actions, "Points_Export");
    QAction* actionPointsConvert = setupAction(actions, "WirCore_Points_Convert");

    QMenu* menuPointCloud = new QMenu();
    menuPointCloud->addAction(actionPointsImport);
    menuPointCloud->addAction(actionPointsExport);
    menuPointCloud->addAction(actionPointsConvert);
    PointCloudFrame->AddAction(QToolButton::InstantPopup, actionPointsImport, menuPointCloud);

    //----Create Measure
    tt::Group* MeasureFrame = modelPage->AddGroup(QObject::tr("Measure"));
    m_pGroup_Measure = MeasureFrame;
    QAction* actionMeasureDistance = setupAction(actions, "Std_MeasureDistance");

    QMenu* menuMeasure = new QMenu();
    menuMeasure->addAction(actionMeasureDistance);
    MeasureFrame->AddAction(QToolButton::InstantPopup, actionMeasureDistance, menuMeasure);

    return modelPage;
}

tt::Page* Workbench::createSimulatePage() const
{
    QList<QAction*> actions = m_pTabToolbar->actions();
    //-------------------------------------------simulation

    tt::Page* simPage = m_pTabToolbar->AddPage(QObject::tr("Simulation")/*QString::fromLocal8Bit("仿真")*/);
    //simPage->setObjectName(QString::fromLatin1("simPage"));

    // Create Collisions
    tt::Group* pCollisonFrame = simPage->AddGroup(QObject::tr("Collision")/*QString::fromLocal8Bit("碰撞")*/);
    m_pGroup_Collision = pCollisonFrame;

    pCollisonFrame->setObjectName(QString::fromLatin1("pCollisonFrame"));

    QAction* actionSingleCollisionCheck = setupAction(actions, "WirCore_SingleCollisionCheck");
    QAction* actionCollisionMatrix = setupAction(actions, "WirCore_CollisionMatrix");
    QAction* actionCollisionCheck = setupAction(actions, "WirCore_CollisionCheck");
    actionCollisionCheck->setObjectName(QString::fromLatin1("actionCollisionCheck"));

    QMenu* menuCollison = new QMenu();
    menuCollison->setObjectName(QString::fromLatin1("menuCollison"));

    menuCollison->addAction(actionSingleCollisionCheck);
    menuCollison->addAction(actionCollisionMatrix);
    menuCollison->addAction(actionCollisionCheck);
    pCollisonFrame->AddAction(QToolButton::InstantPopup, actionCollisionMatrix, menuCollison);

    // Simulate Trajtory
    tt::Group* sp_gSimulate = simPage->AddGroup(QObject::tr("Simulate Trajectory") /*QString::fromLocal8Bit("轨迹仿真")*/);
    m_pGroup_SimulateTrajectory = sp_gSimulate;
    QAction* actionSimulateTrajectory = setupAction(actions, "WirCore_SimulateTrajtory");
    QMenu* menuSimulate = new QMenu();
    menuSimulate->addAction(actionSimulateTrajectory);
    sp_gSimulate->AddAction(QToolButton::InstantPopup, actionSimulateTrajectory, menuSimulate);

    return simPage;
}

tt::Page* Workbench::createViewPage() const
{
    QList<QAction*> actions = m_pTabToolbar->actions();
    //------------------------------------------------View

    tt::Page* viewPage = m_pTabToolbar->AddPage(QString::fromStdString("View"));
    //m_pPage_View = viewPage;
    tt::Group* g1 = viewPage->AddGroup(QString::fromStdString("Group 1"));
    tt::Group* g2 = viewPage->AddGroup(QString::fromStdString("Group 2"));
    tt::Group* g3 = viewPage->AddGroup(QString::fromStdString("Group 3"));

    //g1->AddAction(QToolButton::DelayedPopup, actionNew);
    //g1->AddAction(QToolButton::DelayedPopup, actionOpen);

    QAction* actionPolypaint = new QAction(QString::fromStdString("Polypaint"));
    QAction* actionScale = new QAction(QString::fromStdString("Scale"));

    QMenu* menu = new QMenu(QString::fromStdString("dummyMenu"), nullptr);
    QAction* actionDummy = new QAction(QString::fromStdString("Dummy"));
    menu->addActions({actionDummy});
    g2->AddAction(QToolButton::InstantPopup, actionPolypaint, menu);
    g2->AddAction(QToolButton::InstantPopup, actionScale, menu);

    g2->AddSeparator();

    QTextEdit* te = new QTextEdit();
    g2->AddWidget(te);
    te->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Ignored);
    te->setMaximumWidth(100);

    tt::SubGroup* g2s = g2->AddSubGroup(tt::SubGroup::Align::Yes);
    QAction* actionClose = new QAction(QString::fromStdString("Close"));
    //g2s->AddAction(QToolButton::DelayedPopup, actionUndo);
    //g2s->AddAction(QToolButton::DelayedPopup, actionRedo);
    g2s->AddAction(QToolButton::InstantPopup, actionClose, menu);


    QAction* actionSettings = new QAction(QString::fromStdString("Settings"));
    g3->AddAction(QToolButton::MenuButtonPopup, actionSettings, menu);

    tt::SubGroup* g3s = g3->AddSubGroup(tt::SubGroup::Align::Yes);
    // g3s->AddHorizontalButtons({{QToolButton::DelayedPopup, actionSave},
    //                           {QToolButton::InstantPopup, actionPolypaint, menu},
    //                           {QToolButton::MenuButtonPopup, actionSettings, menu}});

    QMenu* workbench = new QMenu(QString::fromStdString("Workbench"));

    Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();
    mgr.getCommandByName("Std_Workbench")->addTo(workbench);
    QAction* actionWorkbench = setupAction(actions, "Std_Workbench");
    g3s->AddHorizontalButtons({/*{QToolButton::DelayedPopup, actionUndo},*/
                               /*{QToolButton::DelayedPopup, actionRedo},*/
                               {QToolButton::InstantPopup, actionClose, menu},
                               {QToolButton::InstantPopup, actionWorkbench, workbench}});
    QCheckBox* ch = new QCheckBox(QString::fromStdString("Check 1"));
    g3s->AddWidget(ch);

    g3->AddSeparator();
    tt::SubGroup* g3ss = g3->AddSubGroup(tt::SubGroup::Align::No);
    QPushButton* btn = new QPushButton(QString::fromStdString("Edit"));
    g3ss->AddWidget(btn);

    //g3ss->AddAction(QToolButton::DelayedPopup, actionSaveAs);

    //    }


    //    {

    // Create Snap
    //tt::Group* snapFrame = viewPage->AddGroup(QString::fromStdString("PointCloud"));
    // QAction* actionSnapGrid11 = setupAction(actions, "Draft_Point1");
    //  actionSnapGrid11->setChecked(true);

    //QAction* actionSnapGrid12 = setupAction(actions, "IsoCurve");//        QAction* actionEndpoint = setupAction(actions, "Draft_Snap_Endpoint");
    //        QAction* actionEndpointFalse = setupAction(actions, "Draft_Snap_EndpointFalse");

    //        QAction* actionMidpoint = setupAction(actions, "Draft_Snap_Midpoint");
    //        QAction* actionMidpointFalse = setupAction(actions, "Draft_Snap_MidpointFalse");

    //        QAction* actionNear = setupAction(actions, "Draft_Snap_Near");
    //        QAction* actionNearFalse = setupAction(actions, "Draft_Snap_NearFalse");

    //        QAction* actionCenter = setupAction(actions, "Draft_Snap_Center");
    //        QAction* actionCenterFalse = setupAction(actions, "Draft_Snap_CenterFalse");


    //        QAction* actionSnapClose = setupAction(actions, "Draft_Snap_Lock");


    //  QMenu* menuSnap = new QMenu();
    //        menuSnap->addAction(actionEndpoint);
    //        menuSnap->addAction(actionEndpointFalse);
    //        menuSnap->addAction(actionMidpoint);
    //        menuSnap->addAction(actionMidpointFalse);
    //        menuSnap->addAction(actionNear);
    //        menuSnap->addAction(actionNearFalse);
    //        menuSnap->addAction(actionCenter);
    //        menuSnap->addAction(actionCenterFalse);
    //  menuSnap->addAction(actionSnapGrid11);
    // menuSnap->addAction(actionSnapClose);

    // snapFrame->AddAction(QToolButton::InstantPopup, actionSnapGrid11, menuSnap);


    return viewPage;
}

tt::Page* Workbench::createMachiningPage() const
{
    QList<QAction*> actions = m_pTabToolbar->actions();
    //-------------------------------------------Machining-------------------------------------------

    // create geometry
    tt::Page* machinPage = m_pTabToolbar->AddPage(QObject::tr("Machining")/*QString::fromLocal8Bit("")*/);
    //machinPage->setObjectName(QString::fromLatin1("machinPage"));

    tt::Group* createGeometryFrame = machinPage->AddGroup(QString::fromStdString("Create Geometry"));

    QAction* actionCreateGeometry = setupAction(actions, "WirCoreCreateGeometry"); // Geometry
    QAction* actionprojectionOnSurface = setupAction(actions, "WirCore_projectionOnSurface"); // Geometry

    QMenu* menuGeometry = new QMenu();
    menuGeometry->addAction(actionCreateGeometry);
    menuGeometry->addAction(actionprojectionOnSurface);
    createGeometryFrame->AddAction(QToolButton::InstantPopup, actionCreateGeometry, menuGeometry);

    // create operation
    tt::Group* createOperationFrame = machinPage->AddGroup(QString::fromStdString("Create Operation"));
    QAction* actionCreateOperation = setupAction(actions, "WirCoreCreateOperation"); // operation

    QMenu* menuOperation = new QMenu();
    menuOperation->addAction(actionCreateOperation);
    createOperationFrame->AddAction(QToolButton::InstantPopup, actionCreateOperation, menuOperation);

    return machinPage;
}

void Workbench::retranslate() const
{
    Gui::BlankWorkbench::retranslate();

    auto tabBar = m_pTabToolbar->findChildren<QTabWidget*>();
    assert(tabBar.size() == 1);
    auto cnt = tabBar[0]->count();
    assert(cnt >= 4);
    tabBar[0]->setTabText(0, QObject::tr("Start"));
    tabBar[0]->setTabText(1, QObject::tr("Model"));
    tabBar[0]->setTabText(2, QObject::tr("Simulation"));
    tabBar[0]->setTabText(3, QObject::tr("View"));


    auto transGroup = [](tt::Group* pg, QString s)
    {
        auto ls = pg->findChildren<QLabel*>();
        //assert(ls.size() >= 1);
        if (!ls.empty())
            ls[0]->setText(s);
    };

    auto tansTrajProgToolbtn = [](tt::Group* pg, QString objectName ,QString s)
    {
        auto btn = pg->findChild<QToolButton*>(QString::fromLatin1("downButton_") + objectName);
        if (btn)
            btn->setText(s);
    };

    transGroup(m_pGroup_File, QObject::tr("File"));
    tansTrajProgToolbtn(m_pGroup_File, QString::fromLatin1("&New"), QObject::tr("&New"));
    transGroup(m_pGroup_Edit, QObject::tr("Edit"));
    transGroup(m_pGroup_CreateWorkstation, QObject::tr("Create Workstation"));
    transGroup(m_pGroup_TrajectoryProgramming, QObject::tr("Trajectory programming"));
    tansTrajProgToolbtn(m_pGroup_TrajectoryProgramming, QString::fromLatin1("Insert Point"), QObject::tr("Insert Point"));
    tansTrajProgToolbtn(m_pGroup_TrajectoryProgramming, QString::fromLatin1("Create\n Empty Trajectory\n"), QObject::tr("Create\n Empty Trajectory\n"));
    tansTrajProgToolbtn(m_pGroup_TrajectoryProgramming, QString::fromLatin1("Create\n Reference Frame\n"), QObject::tr("Create\n Reference Frame\n"));


    //transGroup(m_pGroup_Setting, QObject::tr("Setting"));
    auto label = m_pGroup_Setting->findChild<QLabel*>(QString::fromLatin1(""));
    if (label)
        label->setText(QObject::tr("Setting"));

    transGroup(m_pGroup_Freehand, QObject::tr("Freehand"));
    m_pComCS->setItemText(0, QCoreApplication::translate("CmdWirCoreFreehandWorldCS", "WorldCS"));
    m_pComCS->setItemText(1, QCoreApplication::translate("CmdWirCoreFreehandWorldCS", "LocalCS"));
    transGroup(m_pGroup_GraphicsTools, QObject::tr("Graphics Tools"));
    m_pActShowHide->setText(QObject::tr("Show/Hide"));
    m_PActFrameSize->setText(QObject::tr("FrameSize"));


    transGroup(m_pGroup_Part, QObject::tr("Part"));
    transGroup(m_pGroup_PointCloud, QObject::tr("PointCloud"));

    transGroup(m_pGroup_Collision, QObject::tr("Collision"));
    transGroup(m_pGroup_SimulateTrajectory, QObject::tr("SimulateTrajectory"));
}

QAction* Workbench::findAction(const QList<QAction*>& actions, std::string& name) const
{
    for (auto it = actions.begin(); it != actions.end(); ++it)
    {
        if ((*it)->data().toString().toStdString() == name)
            return *it;
    }
    return nullptr;
}

QAction* Workbench::setupAction(const QList<QAction*>& actions, const char* name) const
{
    Gui::CommandManager& mgr = Gui::Application::Instance->commandManager();

    std::string names(name);
    QAction* action = findAction(actions, names);
    if(!action)
    {
        if (mgr.addTo(name, m_pTabToolbar))
        {
            action = m_pTabToolbar->actions().last();
            m_pTabToolbar->removeAction(action);//mgr.addTo will also add action to toolbar, remove it to avoid duplication
        }
        if (action)
            action->setData(QString::fromStdString(names));
    }
    return action;
}
