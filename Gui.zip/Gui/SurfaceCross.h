#ifndef WIROLPGUI_SURFACECROSS_H
#define WIROLPGUI_SURFACECROSS_H


#include <Gui/TaskView/TaskDialog.h>
#include <Gui/TaskView/TaskView.h>
#include <Base/BoundBox.h>
#include <QDialog>
#include <QPointer>
# include <gp_Pln.hxx>


namespace Gui {
class View3DInventor;
}

namespace WirCoreGui {

class ViewProviderSurfaceCross;
class Ui_SurfaceCross;
class SurfaceCross : public QDialog
{
    Q_OBJECT

    enum Plane { XY, XZ, YZ };

public:
    SurfaceCross(QWidget* parent = 0, Qt::WindowFlags fl = 0);
    ~SurfaceCross();
    void accept();
    void apply();
    std::vector<double> getPlanes() const;
    int GetPlaneType();
    gp_Trsf getObjtrsf();

protected:
    void changeEvent(QEvent *e);
    void keyPressEvent(QKeyEvent *);

private Q_SLOTS:
    void on_xyPlane_clicked();
    void on_xzPlane_clicked();
    void on_yzPlane_clicked();

    void on_location_valueChanged(double pos);
    void on_sampleStep_valueChanged(double step);
    void on_offset_valueChanged(double offset);
    void on_numPlanes_valueChanged(int num);
    void on_planesBox_toggled(bool b);

private:

    void calcPlane(Plane type, double pos);
    void calcPlanes(Plane type);
    void makePlanes(Plane type, const std::vector<double>& d, double bound[4]);
    Plane plane() const;
    Base::Vector3d c;


private:
    Ui_SurfaceCross* ui;
    Base::BoundBox3d bbox;
    ViewProviderSurfaceCross* vp;
    QPointer<Gui::View3DInventor> view;
    Base::Vector3d vecPos;
};

}

#endif // WIRBLADEGUI_SURFACECROSS_H
