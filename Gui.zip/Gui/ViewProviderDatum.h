#pragma once
#include <Gui/ViewProviderGeometryObject.h>
#include <Base/BoundBox.h>

class SoPickStyle;
class SbBox3f;
class SoGetBoundingBoxAction;

namespace WirCoreGui {

class WirCoreGuiExport ViewProviderDatum : public Gui::ViewProviderGeometryObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderDatum);

public:
    ViewProviderDatum();
    virtual ~ViewProviderDatum();

    void setupContextMenu(QMenu*, QObject*, const char*);

    virtual void attach(App::DocumentObject *);
    virtual bool onDelete(const std::vector<std::string> &);
    virtual bool doubleClicked(void);
    std::vector<std::string> getDisplayModes(void) const;
    void setDisplayMode(const char* ModeName);

    /// indicates if the ViewProvider use the new Selection model
    virtual bool useNewSelectionModel(void) const { return true; }
    /// indicates if the ViewProvider can be selected
    virtual bool isSelectable(void) const ;
    /// return a hit element to the selection path or 0
    virtual std::string getElement(const SoDetail *) const;
    virtual SoDetail* getDetail(const char*) const;

    /** 
     * Enable/Disable the selectability of the datum
     * This differs from the normal ViewProvider selectability in that, that with this enabled one 
     * can pick through the datum and select stuff behind it.
     */
    bool isPickable();
    void setPickable(bool val);
    
    /**
     * Update the visual size to match the given extents
     * @note should be reimplemented in the offspings
     * @note use FreeCAD-specific bbox here to simplify the math in derived classes
     */
    virtual void setExtents (Base::BoundBox3d /*bbox*/)
        { }

    /// Update the visual sizes. This overloaded version of the previous function to allow pass coin type
    void setExtents (const SbBox3f &bbox);

    /// update size to match the guessed bounding box
    void updateExtents ();

    /// The datum type (Plane, Line or Point)
    // TODO remove this attribute (2015-09-08, Fat-Zer)
    QString datumType;
    QString datumText;

    /**
     * Computes appropriate bounding box for the given list of objects to be passed to setExtents ()
     * @param bboxAction  a coin action for traverse the given objects views.
     * @param objs        the list of objects to traverse, due to we traverse the scene graph, the geo children
     *                    will likely be traveresed too.
     */
    static SbBox3f getRelevantBoundBox (
            SoGetBoundingBoxAction &bboxAction,
            const std::vector <App::DocumentObject *> &objs);

    /// Default size used to produce the default bbox
    static const double defaultSize;

    // Returned default bounding box if relevant is can't be used for some reason
    static SbBox3f defaultBoundBox ();

    // Returns a default margin factor (part of size )
    static double marginFactor () { return size; };
    static double size;

    bool showInTree() const
    {
      return false;
    }

protected:
    virtual bool setEdit(int ModNum);
    virtual void unsetEdit(int ModNum);

    /**
     * Guesses the context this datum belongs to and returns appropriate bounding box of all
     *  visible content of the feature
     *
     * Currently known contexts are:
     *  - PartDesign::Body
     *  - App::DocumentObjectGroup (App::Part as well as subclass)
     *  - Whole document
     */
    SbBox3f getRelevantBoundBox() const;

    // Get the separator to fill with datum content
    SoSeparator *getShapeRoot () { return pShapeSep; }

private:
    SoSeparator* pShapeSep;
    SoPickStyle* pPickStyle;
    App::DocumentObject* oldTip;

};

} // namespace Gui
