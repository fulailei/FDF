#ifndef WIRCORE_VIEWPROVIDERTRAJECTORY_H
#define WIRCORE_VIEWPROVIDERTRAJECTORY_H

#include <Inventor/VRMLnodes/SoVRMLTransform.h>
#include <Gui/ViewProviderGeometryObject.h>
#include <Gui/SoFCSelection.h>
#include <Gui/SoAxisCrossKit.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

class SoDragger;
class SoJackDragger;
class SoCoordinate3;
class SoDrawStyle;
class SoLineSet;

namespace WirCoreGui
{

class WirCoreGuiExport ViewProviderTrajectory : public Gui::ViewProviderDocumentObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderTrajectory);

public:
    /// constructor.
    ViewProviderTrajectory();

    /// destructor.
    ~ViewProviderTrajectory();

    void attach(App::DocumentObject *pcObject);
    void setDisplayMode(const char* ModeName);
    std::vector<std::string> getDisplayModes() const;
    void updateData(const App::Property*);
    void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);
    std::vector<App::DocumentObject*> claimChildren(void) const;

    bool canDropObjects() const;
    bool canDragObjects() const;
    bool canDropObject(App::DocumentObject* obj) const;

    void dropObject(App::DocumentObject* obj);

    WirCore::TrajectoryObject* findTrajtoryContainPoint(App::DocumentObject* obj);

    void updataLines();
    void addTransitionPoint();
    WirCore::WaypointObject* addPointbyOld(WirCore::WaypointObject* i_Old, Base::Placement _pla);
    void  LinkToTrajectory();
    void  TrajectoryOptimization();
    bool showInTree() const
    {
      return false;
    }
protected:

    Gui::SoFCSelection    * pcTrajectoryRoot;
    SoCoordinate3         * pcCoords;
    SoDrawStyle           * pcDrawStyle;
    SoLineSet             * pcLines;

    SoGroup* axisGroup;

 };

}

#endif
