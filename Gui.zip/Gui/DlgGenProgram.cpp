#include "PreCompiled.h"
#ifndef _PreComp_
#endif
#include "DlgGenProgram.h"
#include "ui_DlgGenProgram.h"
#include <QMessageBox>
#include <Gui/Application.h>
#include <Gui/Document.h>
#include <App/Document.h>

using namespace WirCoreGui;

DlgGenProgram::DlgGenProgram(QWidget* parent, Qt::WindowFlags fl)
    : QDialog(parent, fl|Qt::WindowCloseButtonHint),
      ui(new Ui_DlgGenProgram)
{
    ui->setupUi(this);
    //this->setAttribute(Qt::WA_DeleteOnClose);

    QObject::connect(ui->createButton, SIGNAL(clicked()), this, SLOT(onCreateClicked()));
    QObject::connect(ui->cancelButton, SIGNAL(clicked()), this, SLOT(onCancelClicked()));

    App::Document* doc = App::GetApplication().getActiveDocument();

    //display all robot objects
    std::vector<WirCore::RobotObject*> robjs = doc->getObjectsOfType<WirCore::RobotObject>();
    //retrieve all the robot in workstation and add to combobox
    for(auto robj : robjs) {
        std::string name = robj->getNameInDocument();
        ui->robotCombo->addItem(QString::fromStdString(name));
    }

    //display all trajectories
    std::vector<WirCore::TrajectoryObject*> trajs = doc->getObjectsOfType<WirCore::TrajectoryObject>();
    for(auto traj : trajs) {
        std::string name = traj->getNameInDocument();
        ui->trajCombo->addItem(QString::fromStdString(name));
    }

}

DlgGenProgram::~DlgGenProgram()
{
    delete ui;
}

void DlgGenProgram::onCreateClicked()
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    QString rname = ui->robotCombo->currentText();
    WirCore::RobotObject* robj = dynamic_cast<WirCore::RobotObject*>(doc->getObject(rname.toLatin1().data()));


    QString tname = ui->trajCombo->currentText();
    WirCore::TrajectoryObject* tobj = dynamic_cast<WirCore::TrajectoryObject*>(doc->getObject(tname.toLatin1().data()));

    if(!robj) {
        QMessageBox msgBox;
        msgBox.setText(QObject::tr("Please make sure there is at least one robot object."));
        msgBox.exec();
        return;
    }
    if(!tobj) {
        QMessageBox msgBox;
        msgBox.setText(QObject::tr("Please make sure there is at least one trajectory object."));
        msgBox.exec();
        return;
    }

    Base::Console().Warning("RobotObject: %s, trajectory object: %s", robj->getNameInDocument(), tobj->getNameInDocument());

    m_robj = robj;
    m_tobj = tobj;
    accept();
}

void DlgGenProgram::onCancelClicked()
{
    reject();
}

void DlgGenProgram::accept()
{
    QDialog::accept();
    //close();
}

void DlgGenProgram::reject()
{
    QDialog::reject();
    //close();
}
#include "moc_DlgGenProgram.cpp"
