#include "PreCompiled.h"

#ifndef _PreComp_
#include <QAction>
#include <QMenu>
#endif
#include <Gui/ActionFunction.h>
#include <Gui/MainWindow.h>
#include <App/Application.h>
#include <App/Document.h>

#include "ViewProviderWorkStationGroup.h"
#include <DlgFindRobot.h>
#include <DlgSelActiveObj.h>

using namespace Gui;
using namespace WirCoreGui;
using namespace std;

PROPERTY_SOURCE_WITH_EXTENSIONS(WirCoreGui::ViewProviderWorkStationGroup, Gui::ViewProviderDocumentObjectGroup);
ViewProviderWorkStationGroup::ViewProviderWorkStationGroup()
{
     sPixmap = "WirCore_RobotWorkStation";
     Gui::ViewProviderDocumentObjectGroup::initExtension(this);     
}

ViewProviderWorkStationGroup::~ViewProviderWorkStationGroup()
{

}


std::vector<App::DocumentObject*> ViewProviderWorkStationGroup::claimChildren(void) const {
    WirCore::WorkStationGroup* pcObj = dynamic_cast<WirCore::WorkStationGroup*>(pcObject);
    std::vector<App::DocumentObject*> children;

    children.push_back(pcObj->WobjGroup.getValue());
    children.push_back(pcObj->ToolGroup.getValue());
    children.push_back(pcObj->TrajtoryGroup.getValue());

    return children;
}


void ViewProviderWorkStationGroup::UpdateActiveView()
{
    WirCore::WorkStationGroup* pObj = dynamic_cast<WirCore::WorkStationGroup*>(pcObject);

    auto pcAction = Gui::getMainWindow()->findChild<WirCoreGui::DlgSelActiveObj*>
            (QString::fromLatin1("ActiveSelectObj"));
    if (pcAction)
    {
        pcAction->UpdateStationCombo();
    }

}

void ViewProviderWorkStationGroup::updateData(const App::Property *prop)
{
    WirCore::WorkStationGroup* pObj = dynamic_cast<WirCore::WorkStationGroup*>(pcObject);

    if (prop == &pObj->UpdateComboEvent) {
        UpdateActiveView();
    }

    ViewProviderDocumentObjectGroup::updateData(prop);
}



void ViewProviderWorkStationGroup::SetActiveTool()
{
    WirCore::WorkStationGroup* pcObj = dynamic_cast<WirCore::WorkStationGroup*>(pcObject);
    App::Document* doc = App::GetApplication().getActiveDocument();

    QStringList link;
    link << QLatin1String(doc->getName());
    link << QLatin1String("WirCore::ToolObjectReferenceFrame");
    link << QLatin1String("None");
    link << QLatin1String("");

    DlgFindRobot dlg(link);
    if (dlg.exec() == QDialog::Accepted) {
        QString _str = dlg.propertyLink();

        if (_str == QLatin1String(""))
        {
            return;
        }
    //    auto _object = dynamic_cast<WirCore::ToolObjectReferenceFrame*>(doc->getObject(_str.toStdString().c_str()));

        pcObj->activeToolObjectName.setValue(_str.toStdString().c_str());
    }
    UpdateActiveView();
}

void ViewProviderWorkStationGroup::SetActiveWobj()
{
    WirCore::WorkStationGroup* pcObj = dynamic_cast<WirCore::WorkStationGroup*>(pcObject);
    App::Document* doc = App::GetApplication().getActiveDocument();

    QStringList link;
    link << QLatin1String(doc->getName());
    link << QLatin1String("WirCore::WorkFrameObject");
    link << QLatin1String("None");
    link << QLatin1String("");

    DlgFindRobot dlg(link);
    if (dlg.exec() == QDialog::Accepted) {
        QString _str = dlg.propertyLink();

        if (_str == QLatin1String(""))
        {
            return;
        }
     //   auto _object = dynamic_cast<WirCore::WorkFrameObject*>(doc->getObject(_str.toStdString().c_str()));
        pcObj->activeWobjObjectName.setValue(_str.toStdString().c_str());
    }
    UpdateActiveView();
}


void ViewProviderWorkStationGroup::setupContextMenu(QMenu *menu, QObject *receiver, const char *member)
{
    Gui::ActionFunction* func = new Gui::ActionFunction(menu);

//    QAction* act = menu->addAction(QObject::tr("Set active Tool"), receiver, member);
//    func->trigger(act, boost::bind(&ViewProviderWorkStationGroup::SetActiveTool, this));

//    QAction* act2 = menu->addAction(QObject::tr("Set active Wobj"), receiver, member);
//    func->trigger(act2, boost::bind(&ViewProviderWorkStationGroup::SetActiveWobj, this));

}
