#include "PreCompiled.h"
#ifndef _PreComp_
#include <QMessageBox>
#include <QFileDialog>
#endif

#include <Base/Console.h>
#include <Base/Placement.h>
#include <App/Document.h>
#include <App/Part.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Document.h>
#include <Gui/MainWindow.h>
#include <Gui/Selection.h>
#include <Gui/SelectionFilter.h>
#include <Gui/Control.h>
#include <Gui/FileDialog.h>
#include <Gui/View3DInventor.h>
#include <Gui/View3DInventorViewer.h>
#include <Gui/ViewProvider.h>
#include <Mod/Part/App/PartFeature.h>

using namespace std;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//===========================================================================
// WirCore_FreehandWorldCS
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandWorldCS);
CmdWirCoreFreehandWorldCS::CmdWirCoreFreehandWorldCS()
  : Command("WirCore_FreehandWorldCS")
{
    sGroup        = QT_TR_NOOP("Freehand");
    sMenuText     = QT_TR_NOOP("WorldCS");
    sToolTipText  = QT_TR_NOOP("WorldCS of the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("WorldCS of the selected object in the 3d view");
    sWhatsThis    = "WirCore_FreehandWorldCS";
}

void CmdWirCoreFreehandWorldCS::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    Gui::ViewProvider::s_freehandCS = 0;
    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();
    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->setEdit(vp, Gui::ViewProvider::s_freehandModNum);
    }
}

bool CmdWirCoreFreehandWorldCS::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}

//===========================================================================
// WirCore_FreehandLocalCS
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandLocalCS);
CmdWirCoreFreehandLocalCS::CmdWirCoreFreehandLocalCS()
  : Command("WirCore_FreehandLocalCS")
{
    sGroup        = QT_TR_NOOP("Freehand");
    sMenuText     = QT_TR_NOOP("LocalCS");
    sToolTipText  = QT_TR_NOOP("LocalCS of the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("LocalCS of the selected object in the 3d view");
    sWhatsThis    = "WirCore_FreehandLocalCS";
}

void CmdWirCoreFreehandLocalCS::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    Gui::ViewProvider::s_freehandCS = 1;
    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();
    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->setEdit(vp, Gui::ViewProvider::s_freehandModNum);
    }
}

bool CmdWirCoreFreehandLocalCS::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}

//===========================================================================
// WirCore_FreehandMove
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandMove);
CmdWirCoreFreehandMove::CmdWirCoreFreehandMove()
  : Command("WirCore_FreehandMove")
{
    sGroup        = QT_TR_NOOP("Freehand");
    sMenuText     = QT_TR_NOOP("Move");
    sToolTipText  = QT_TR_NOOP("Move the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("Move the selected object in the 3d view");
    sWhatsThis    = "WirCore_FreehandMove";
}

void CmdWirCoreFreehandMove::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    Gui::ViewProvider::s_freehandModNum = Gui::ViewProvider::OffsetFreehand;
    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();
    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->setEdit(vp, Gui::ViewProvider::OffsetFreehand);
    }
}

bool CmdWirCoreFreehandMove::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}

//===========================================================================
// WirCore_FreehandRotate
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandRotate);
CmdWirCoreFreehandRotate::CmdWirCoreFreehandRotate()
  : Command("WirCore_FreehandRotate")
{
    sGroup        = QT_TR_NOOP("Freehand");
    sMenuText     = QT_TR_NOOP("FreehandRotate");
    sToolTipText  = QT_TR_NOOP("Rotate the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("Rotate the selected object in the 3d view");
    sWhatsThis    = "WirCore_FreehandRotate";
}

void CmdWirCoreFreehandRotate::activated(int iMsg)
{
    Q_UNUSED(iMsg);
     Gui::ViewProvider::s_freehandModNum = Gui::ViewProvider::RotateFreehand;
    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();
    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->setEdit(vp, Gui::ViewProvider::RotateFreehand);
    }
}

bool CmdWirCoreFreehandRotate::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}

//===========================================================================
// WirCore_FreehandJogJoint
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandJogJoint);
CmdWirCoreFreehandJogJoint::CmdWirCoreFreehandJogJoint()
  : Command("WirCore_FreehandJogJoint")
{
    sGroup        = QT_TR_NOOP("Freehand");
    sMenuText     = QT_TR_NOOP("FreehandJogJoint");
    sToolTipText  = QT_TR_NOOP("JogJoint the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("JogJoint the selected object in the 3d view");
    sWhatsThis    = "FreehandJogJoint";
}

void CmdWirCoreFreehandJogJoint::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    Gui::ViewProvider::s_freehandModNum = Gui::ViewProvider::JogJointFreehand;
    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();
    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->setEdit(vp, Gui::ViewProvider::JogJointFreehand);
    }
}

bool CmdWirCoreFreehandJogJoint::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}

//===========================================================================
// WirCore_FreehandJogLinear
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandJogLinear);
CmdWirCoreFreehandJogLinear::CmdWirCoreFreehandJogLinear()
  : Command("WirCore_FreehandJogLinear")
{
    sGroup        = QT_TR_NOOP("Freehand");
    sMenuText     = QT_TR_NOOP("FreehandJogLinear");
    sToolTipText  = QT_TR_NOOP("JogLinear the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("JogLinear the selected object in the 3d view");
    sWhatsThis    = "WirCore_FreehandJogLinear";
}

void CmdWirCoreFreehandJogLinear::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    Gui::ViewProvider::s_freehandModNum = Gui::ViewProvider::JogLinearFreehand;
    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();
    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->setEdit(vp, Gui::ViewProvider::JogLinearFreehand);
    }
}

bool CmdWirCoreFreehandJogLinear::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}
//===========================================================================
// WirCore_FreehandClose
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreFreehandClose);
CmdWirCoreFreehandClose::CmdWirCoreFreehandClose()
  : Command("WirCore_FreehandClose")
{
    sGroup        = QT_TR_NOOP("FreehandClose");
    sMenuText     = QT_TR_NOOP("FreehandClose");
    sToolTipText  = QT_TR_NOOP("Close Freehand the selected object in the 3d view");
    sStatusTip    = QT_TR_NOOP("Close Freehand the selected object in the 3d view");
    sWhatsThis    = "WirCore_FreehandClose";
}

void CmdWirCoreFreehandClose::activated(int iMsg)
{
    Q_UNUSED(iMsg);
    //Gui::ViewProvider::s_freehandModNum = Gui::ViewProvider::Default;

    if (getActiveGuiDocument()->getInEdit())
        getActiveGuiDocument()->resetEdit();

    Gui::ViewProvider::s_freehandModNum = Gui::ViewProvider::Default;

    std::vector<App::DocumentObject*> sel = Gui::Selection().getObjectsOfType(App::GeoFeature::getClassTypeId());
    if (sel.empty())
        return;
    Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(sel.front());
    if (vp)
    {
        getActiveGuiDocument()->resetEdit(/*vp, Gui::ViewProvider::Default*/);
    }

}

bool CmdWirCoreFreehandClose::isActive(void)
{
    //return Gui::Selection().countObjectsOfType(App::GeoFeature::getClassTypeId()) == 1;
    if (getActiveGuiDocument())
        return true;
    else
        return false;
}


void CreateWirCoreCommandFreeHand(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();
    rcCmdMgr.addCommand(new CmdWirCoreFreehandMove());
    rcCmdMgr.addCommand(new CmdWirCoreFreehandRotate());
    rcCmdMgr.addCommand(new CmdWirCoreFreehandJogJoint());
    rcCmdMgr.addCommand(new CmdWirCoreFreehandJogLinear());
    rcCmdMgr.addCommand(new CmdWirCoreFreehandClose());
    rcCmdMgr.addCommand(new CmdWirCoreFreehandWorldCS());
    rcCmdMgr.addCommand(new CmdWirCoreFreehandLocalCS());
}
