/***************************************************************************
 *   Copyright (c) 2013 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

#include "PreCompiled.h"

#ifndef _PreComp_
# include <QPixmap>
# include <QDialog>
#endif

#include <Gui/BitmapFactory.h>
#include <Gui/MainWindow.h>
#include <Base/Tools.h>
#include <Base/UnitsApi.h>

#include "ui_DlgTrajectoryOpt.h"
#include "DlgTrajectoryOpt.h"


using namespace WirCoreGui;

DlgTrajectoryOpt::DlgTrajectoryOpt(std::vector<std::vector<WirCore::TrajectoryOptimization::PointType>> vec)
  : m_vec(vec), QDialog(Gui::getMainWindow()), ui(new Ui_DlgTrajectoryOpt)
{
    ui->setupUi(this);

    init_curve_parameter();
    init_signals_and_slots();
    init_curve_chart_view();
}

DlgTrajectoryOpt::~DlgTrajectoryOpt()
{
    delete ui;
}

void DlgTrajectoryOpt::accept()
{

    QDialog::accept();
}


void DlgTrajectoryOpt::init_curve_parameter()
{
    minX = 0;
    maxX = m_vec.size() - 1;
    minY = -180;
    maxY = 180;
    curveIndex = 0;
    int map[2] = { 0x696969, 0x1E90FF };
    memcpy(color_map, map, sizeof(int)* 2);

    QScatterSeries *scatter1 = new QScatterSeries();
    QSplineSeries *spline1 = new QSplineSeries();
    for (unsigned int  i = 0; i < m_vec.size(); i++)
    {
        scatter1->append(i, 0);
        spline1->append(i, 0);
    }
    scatterList.append(scatter1);
    splineList.append(spline1);

}


void DlgTrajectoryOpt::init_signals_and_slots()
{
    QObject::connect(ui->widgetChart, SIGNAL(signalMouseMovePoint(QPoint)),
        this, SLOT(slotMouseMovePoint(QPoint)));	// mouse drag event
    QObject::connect(ui->widgetChart, SIGNAL(signalCurrentDragPoint(QPointF)),
        this, SLOT(slotCurrentDragPoint(QPointF)));	// drag point event
}



void DlgTrajectoryOpt::init_curve_chart_view()
{
    QChart *chart = new QChart();

    // add series
    for (int i = 0; i < scatterList.count(); i++)
    {
        QScatterSeries *scatter = scatterList.at(i);
        QSplineSeries *spline = splineList.at(i);

        QPen pen;
        pen.setColor(color_map[i]);
        pen.setWidth(2);
        spline->setPen(pen);

        scatter->setMarkerShape(QScatterSeries::MarkerShapeCircle);
        scatter->setBorderColor(color_map[i]);
        scatter->setBrush(QBrush(color_map[i]));
        scatter->setMarkerSize(8);

        if (i != curveIndex)
        {
            scatter->hide();
            spline->hide();
        }

        chart->addSeries(spline);
        chart->addSeries(scatter);
    }


    for (unsigned int  i = 0; i < m_vec.size(); i++)
    {
        std::vector<WirCore::TrajectoryOptimization::PointType> _vecType = m_vec[i];
        bool flag = false;
        QLineSeries* spline = new QLineSeries;
        spline->setPen(QPen(Qt::red, 8));

        QPointF LastPoint;
        for (int  j = 0; j < _vecType.size(); j++)
        {
            if (!flag && _vecType[j] == WirCore::TrajectoryOptimization::UnArriveable)
            {
                QPointF firstPoint = QPointF(i,minY + j * 10);
                spline->append(firstPoint);
                flag = true;
            }
            else if (flag && _vecType[j] == WirCore::TrajectoryOptimization::UnArriveable)
            {
               LastPoint = QPointF(i,minY + j * 10);
            }
            else if (flag && _vecType[j] != WirCore::TrajectoryOptimization::UnArriveable)
            {
                flag = false;
                spline->append(LastPoint);
                chart->addSeries(spline);
            }
        }
        if (flag)
        {
            spline->append(LastPoint);
            chart->addSeries(spline);
        }
    }

    for (unsigned int  i = 0; i < m_vec.size(); i++)
    {
        std::vector<WirCore::TrajectoryOptimization::PointType> _vecType = m_vec[i];
        bool flag = false;
        QLineSeries* _pLineSeries = new QLineSeries;
        _pLineSeries->setPen(QPen(Qt::yellow, 8));
        QPointF LastPoint;
        for (int  j = 0; j < _vecType.size(); j++)
        {
            if (!flag && _vecType[j] == WirCore::TrajectoryOptimization::OutOfLimit)
            {
                _pLineSeries->append(QPointF(i,minY + j * 10));
                flag = true;
            }
            else if (flag && _vecType[j] == WirCore::TrajectoryOptimization::OutOfLimit)
            {
                LastPoint = QPointF(i,minY + j * 10);
            }
            else if (flag && _vecType[j] != WirCore::TrajectoryOptimization::OutOfLimit)
            {
                flag = false;
                _pLineSeries->append(LastPoint);
                chart->addSeries(_pLineSeries);
            }

        }
        if (flag)
        {
            _pLineSeries->append(LastPoint);
            chart->addSeries(_pLineSeries);
        }
    }



    chart->createDefaultAxes();
    chart->legend()->hide();
    chart->axisY()->setRange(minY, maxY);
    chart->axisY()->setTitleText(QString::fromLatin1("y"));
    chart->axisX()->setRange(minX, maxX);
    chart->axisX()->setTitleText(QString::fromLatin1("x"));
    chart->setMargins(QMargins(1, 1, 1, 1));






    ui->widgetChart->setChart(chart);
    ui->widgetChart->setRenderHint(QPainter::Antialiasing);
    ui->widgetChart->setSeriesIndex(0);
    ui->widgetChart->setForceCorrectnessOnDrag(false);
    ui->widgetChart->setYRange(minY, maxY);
    ui->widgetChart->setSeriesList(scatterList, splineList);
}


void DlgTrajectoryOpt::curve_type_combo_changed(int index)
{
    if (scatterList.isEmpty() || splineList.isEmpty())
        return;

    // update series index
    curveIndex = index;
    ui->widgetChart->setSeriesIndex(curveIndex);

    // set current curve display
    for (int i = 0; i < scatterList.count(); i++)
    {
        scatterList.at(i)->hide();
        splineList.at(i)->hide();
    }
    scatterList.at(curveIndex)->show();
    splineList.at(curveIndex)->show();
}


void DlgTrajectoryOpt::force_correctness_on_drag_checked(bool status)
{
    ui->widgetChart->setForceCorrectnessOnDrag(status);
}


void DlgTrajectoryOpt::set_value_on_clicked()
{
    // check value
    QString strx = ui->editX->text();
    QString stry = ui->editY->text();
    if (strx.isEmpty() || stry.isEmpty())
        return;

    int x = strx.toInt();
    int y = stry.toInt();
    if (y < minY)
        ui->editY->setText(QString::asprintf("%d", y));
    else if (y > maxY)
        ui->editY->setText(QString::asprintf("%d", y));

    // set value and update curve data
    QPointF point((float)x, (float)y);
    ui->widgetChart->setCurrentPointValue(point);
}


void DlgTrajectoryOpt::slotMouseMovePoint(QPoint point)
{
    // convert to chart value
    QPointF curPoint = ui->widgetChart->chart()->mapToValue(point);

    // update position label
    if (curPoint.x() >= minX && curPoint.x() <= maxX &&
        curPoint.y() >= minY && curPoint.y() <= maxY)
    {
        ui->labelPosition->setText(QString::asprintf("Position: X=%d, Y=%d.",
            (int)curPoint.x(), (int)curPoint.y()));
    }
    else
    {
        ui->labelPosition->setText(QString::asprintf("Position: Out of chart range."));
    }
}


void DlgTrajectoryOpt::slotCurrentDragPoint(QPointF point)
{
    ui->editX->setText(QString::asprintf("%d", (int)point.x()));
    ui->editY->setText(QString::asprintf("%d", (int)point.y()));
}



#include "moc_DlgTrajectoryOpt.cpp"
