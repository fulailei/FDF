/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
#endif

#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>

#include <Mod/WirCore/App/ReferenceFrame.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/WorkObjectReferenceFrame.h>
#include <Mod/WirCore/App/ToolObjectReferenceFrame.h>
#include <Mod/WirCore/App/WorkStationGroup.h>
#include <Mod/WirCore/App/ActiveStationObject.h>

#include "WircoreAction.h"

using namespace std;
using namespace WirCore;
using namespace WirCoreGui;

//==========================================
// WirCore_CreateReferenceFrame
//==========================================
DEF_STD_CMD_A(CmdWirCoreCreateReferenceFrame)

CmdWirCoreCreateReferenceFrame::CmdWirCoreCreateReferenceFrame()
    :Command("WirCore_CreateReferenceFrame")
{
    sAppModule = "WirCore";
    sGroup = QT_TR_NOOP("WirCore");
    sMenuText = QT_TR_NOOP("Create\n Reference Frame\n");
    sWhatsThis = "WirCore_CreateReferenceFrame";
    sStatusTip = sToolTipText;
    sPixmap = "WirCore_CreateReferenceFrame";
}

void CmdWirCoreCreateReferenceFrame::activated(int iMsg)
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    //count the number of reference frame objects in the scene

    openCommand("Creat ReferenceFrame");

    WirCore::ReferenceFrame* ref = new WirCore::ReferenceFrame();
    Base::Placement p;
    p.setPosition(Base::Vector3d(0, 0, 0));
    ref->Placement.setValue(p);
    std::string n = "Frame";
    doc->addObject(ref, n.c_str());

    updateActive();
    commitCommand();
}

bool CmdWirCoreCreateReferenceFrame::isActive()
{
    return hasActiveDocument();
}

//==========================================
// WirCore_CreateWorkObjectReferenceFrame
//==========================================
DEF_STD_CMD_A(CmdWirCoreCreateWorkObjectReferenceFrame)

CmdWirCoreCreateWorkObjectReferenceFrame::CmdWirCoreCreateWorkObjectReferenceFrame()
    :Command("WirCore_CreateWorkObjectReferenceFrame")
{
    sAppModule = "WirCore";
    sGroup = QT_TR_NOOP("WirCore");
    sMenuText = QT_TR_NOOP("Create a WorkObject Reference Frame");
    sWhatsThis = "WirCore_CreateWorkObjectReferenceFrame";
    sStatusTip = sToolTipText;
    sPixmap = "WirCore_WobjReferenceFrame";
}

void CmdWirCoreCreateWorkObjectReferenceFrame::activated(int iMsg)
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    //count the number of reference frame objects in the scene

    openCommand("Creat WobjFrame");

    WirCore::WorkFrameObject* wobj = new WirCore::WorkFrameObject();
    std::string n = "WobjFrame";
    wobj->Label.setValue(n);


    WirCore::WorkObjectReferenceFrame* ref = new WirCore::WorkObjectReferenceFrame();
    wobj->WObjReferenceFrame.setValue(ref);
    doc->addObject(wobj, n.c_str());

    std::string t_str = wobj->Label.getValue() + std::string("_of");
    ref->Label.setValue(t_str);
    doc->addObject(ref, t_str.c_str());
    wobj->addObject(ref);

    ObjectListAction* pcAction = Gui::getMainWindow()->findChild<ObjectListAction*>
         (QString::fromLatin1("WorkObjectList"));
    if (pcAction)
    {
        pcAction->setObjectList();
    }

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    _station->setInStation(wobj);
    _station->UpdateComboEvent.setValue(true);

    updateActive();
    commitCommand();
}

bool CmdWirCoreCreateWorkObjectReferenceFrame::isActive()
{
    return hasActiveDocument();
}


//==========================================
// WirCore_CreateWorkObjectReferenceFrame
//==========================================
DEF_STD_CMD_A(CmdWirCoreCreateToolObjectReferenceFrame)

CmdWirCoreCreateToolObjectReferenceFrame::CmdWirCoreCreateToolObjectReferenceFrame()
    :Command("WirCore_CreateToolObjectReferenceFrame")
{
    sAppModule = "WirCore";
    sGroup = QT_TR_NOOP("WirCore");
    sMenuText = QT_TR_NOOP("Create a ToolObject Reference Frame");
    sWhatsThis = "WirCore_CreateToolObjectReferenceFrame";
    sStatusTip = sToolTipText;
    sPixmap = "WirCore_ToolReferenceFrame";
}

void CmdWirCoreCreateToolObjectReferenceFrame::activated(int iMsg)
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    //count the number of reference frame objects in the scene

    openCommand("Creat ToolObjectFrame");

    WirCore::ToolObjectReferenceFrame* ref = new WirCore::ToolObjectReferenceFrame();
    Base::Placement p;
    p.setPosition(Base::Vector3d(0, 0, 0));
    ref->Placement.setValue(p);
    std::string n = "ToolFrame";
    ref->Label.setValue(n);
    doc->addObject(ref, n.c_str());

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    _station->setInStation(ref);
    _station->UpdateComboEvent.setValue(true);

    updateActive();
    commitCommand();

}

bool CmdWirCoreCreateToolObjectReferenceFrame::isActive()
{
    return hasActiveDocument();
}



// #####################################################################################################
void CreateWirCoreCommandCreateReferenceFrame(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();

    rcCmdMgr.addCommand(new CmdWirCoreCreateReferenceFrame());
    rcCmdMgr.addCommand(new CmdWirCoreCreateWorkObjectReferenceFrame());
    rcCmdMgr.addCommand(new CmdWirCoreCreateToolObjectReferenceFrame());
}
