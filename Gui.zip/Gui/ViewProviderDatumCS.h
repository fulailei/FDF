#pragma once
#include <Gui/ViewProviderGeometryObject.h>
#include "ViewProviderDatum.h"

class SoFont;
class SoTranslation;
class SoCoordinate3;

namespace WirCoreGui {

class WirCoreGuiExport ViewProviderDatumCoordinateSystem : public WirCoreGui::ViewProviderDatum
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderDatumCoordinateSystem);

public:
    /// Constructor
    ViewProviderDatumCoordinateSystem();
    virtual ~ViewProviderDatumCoordinateSystem();

    virtual void attach ( App::DocumentObject *obj );
    virtual void updateData(const App::Property*);

    virtual void setExtents (Base::BoundBox3d bbox);

    bool showInTree() const
    {
      return false;
    }

private:
    SoCoordinate3 *coord;
    SoTranslation *axisLabelXTrans;
    SoTranslation *axisLabelXToYTrans;
    SoTranslation *axisLabelYToZTrans;
    SoFont* font;
};

} // namespace WirCoreGui
