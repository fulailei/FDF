/***************************************************************************
 *   Copyright (c) 2014 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"
#ifndef _PreComp_
# include <algorithm>
# include <sstream>
# include <QListWidgetItem>
# include <QMessageBox>
#endif

#include <App/Application.h>
#include <App/Document.h>
#include <App/DocumentObject.h>
#include <App/GeoFeature.h>

#include "DlgFindRobot.h"
#include <Gui/Application.h>
#include <Gui/ViewProvider.h>
#include "ui_DlgFindRobot.h"

#include <Mod/WirCore/App/RobotObject.h>


using namespace WirCoreGui;



DlgFindRobot::DlgFindRobot(const QStringList& list,  QWidget* parent, Qt::WindowFlags fl)
  : QDialog(parent, fl), link(list), ui(new Ui_DlgFindRobot)
{
    ui->setupUi(this);
    ui->listWidget->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->listWidget->clear();
    findObjects(QString());
}

DlgFindRobot::~DlgFindRobot()
{
    // no need to delete child widgets, Qt does it all for us
    delete ui;
}

void DlgFindRobot::accept()
{
    if (ui->listWidget->selectionMode() == QAbstractItemView::SingleSelection) {
        QList<QListWidgetItem*> items = ui->listWidget->selectedItems();
        if (items.isEmpty()) {
            QMessageBox::warning(this, tr("No selection"), tr("Please select an object from the list"));
            return;
        }
    }

    QDialog::accept();
}

QString DlgFindRobot::propertyLink() const
{
    QList<QListWidgetItem*> items = ui->listWidget->selectedItems();
    if (items.isEmpty()) {
        return QString::fromUtf8("");
    }
    else {
        return items[0]->data(Qt::UserRole).toString();
    }
}

QVariantList DlgFindRobot::propertyLinkList() const
{
    QVariantList varList;
    QList<QListWidgetItem*> items = ui->listWidget->selectedItems();
    if (items.isEmpty()) {
        varList << link;
    }
    else {
        for (QList<QListWidgetItem*>::iterator it = items.begin(); it != items.end(); ++it) {
            QStringList list = link;
            list[1] = (*it)->data(Qt::UserRole).toString();
            list[2] = (*it)->text();
            if (list[1].isEmpty())
                list[2] = QString::fromUtf8("");
            varList << list;
        }
    }

    return varList;
}

void DlgFindRobot::findObjects(const QString& searchText)
{
    QString docName = link[0]; // document name
    QString objType = link[1]; // object Type
    QString listTop = link[2];
    QString listTail = link[3];

    App::Document* doc = App::GetApplication().getDocument((const char*)docName.toLatin1());
    if (doc) {
        Base::Type type = Base::Type::fromName(objType.toStdString().c_str());
        if (!type.isDerivedFrom(App::DocumentObject::getClassTypeId())) {
            std::stringstream str;
            str << "'" << objType.toStdString().c_str() << "' is not a document object type";
            throw Base::TypeError(str.str());
        }

        QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
        item->setText(listTop);
        QByteArray ba("");
        item->setData(Qt::UserRole, ba);

        if (!listTail.isEmpty())
        {
            QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
            item->setText(listTail);
            QByteArray ba("");
            item->setData(Qt::UserRole, ba);
        }

        std::vector<App::DocumentObject*> vecobj = doc->getObjectsOfType(type);
        for (std::vector<App::DocumentObject*>::iterator it = vecobj.begin(); it != vecobj.end(); ++it) {
            Gui::ViewProvider* vp = Gui::Application::Instance->getViewProvider(*it);
            bool nameOk = true;
            if (!searchText.isEmpty()) {
                QString label = QString::fromUtf8((*it)->Label.getValue());
                if (!label.contains(searchText,Qt::CaseInsensitive))
                    nameOk = false;
            }

            if (vp && nameOk ) {
                // filter out the objects
                QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
                item->setIcon(vp->getIcon());
                item->setText(QString::fromUtf8((*it)->Label.getValue()));
                QByteArray ba((*it)->getNameInDocument());
                item->setData(Qt::UserRole, ba);
                item->setSelected(true);
            }
        }
    }
}

void DlgFindRobot::on_checkObjectType_toggled(bool on)
{
    ui->listWidget->clear();
    findObjects(ui->searchBox->text());
}

void DlgFindRobot::on_searchBox_textChanged(const QString& search)
{
    ui->listWidget->clear();
    findObjects(search);
}
#include "moc_DlgFindRobot.cpp"
