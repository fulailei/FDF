#include "PreCompiled.h"

#ifndef _PreComp_
#include <QApplication>
#endif

#include "DlgTrajectoryFromEdge.h"

#include <Base/Console.h>
#include <Base/Exception.h>
#include <Gui/TaskView/TaskSelectLinkProperty.h>
#include <Gui/Application.h>
#include <Gui/Document.h>

#include <TopoDS.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopOpeBRepBuild_Tools.hxx>
#include <BRep_Tool.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <CPnts_AbscissaPoint.hxx>
#include <TopExp.hxx>
#include <GeomAPI_ProjectPointOnSurf.hxx>
#include <BOPTools_AlgoTools3D.hxx>

#include <Mod/Part/App/edgecluster.h>
#include <Mod/Part/App/PartFeature.h>

#include <Mod/WirCore/App/ActiveStationObject.h>


using namespace WirCoreGui;

DlgTrajectoryFromEdge::DlgTrajectoryFromEdge(WirCore::TrajectoryObject* _traj,  WirCore::WorkFrameObject* _wobj)
    : TaskDialog(),traj(_traj), wobj(_wobj)
{
    this->setButtonPosition(TaskDialog::South);
    param = new TrajFromEdgeParameter();
    Content.push_back(param);
}

DlgTrajectoryFromEdge::~DlgTrajectoryFromEdge()
{

}

std::vector<std::string> DlgTrajectoryFromEdge::getSubValuesStartsWith(std::vector<std::string>SubList, const char* starter) const
{
    std::vector<std::string> temp;
    for(std::vector<std::string>::const_iterator it=SubList.begin();it!=SubList.end();++it)
        if(strncmp(starter,it->c_str(),strlen(starter))==0)
            temp.push_back(*it);
    return temp;
}

bool DlgTrajectoryFromEdge::generateTrajectory()
{
    App::DocumentObject* linkEdge = param->m_selEdgeObject;
    App::DocumentObject* linkFace = param->m_selFaceObject;

   // App::Document* doc = App::GetApplication().getActiveDocument();

    if(!linkEdge){
        Base::Console().Error("TrajectoryObjFromEdge: no Edge linked");
        return false;
    }

    if(!linkFace){
        Base::Console().Error("TrajectoryObjFromEdge: no Face+ linked");
        return false;
    }

    if(!linkEdge->getTypeId().isDerivedFrom(Part::Feature::getClassTypeId())
      || !linkFace->getTypeId().isDerivedFrom(Part::Feature::getClassTypeId()))
    {
        Base::Console().Error("TrajectoryObjFromEdge: linked object is not a part object");
        return false;
    }

    Part::Feature *base = static_cast<Part::Feature*>(linkEdge);
    App::DocumentObjectGroup* objGroup = base->getGroup();
    if(objGroup != nullptr) {
        Base::Console().Warning("Edge belongs to group: %s\n", objGroup->name().c_str());
    }
    else {
        Base::Console().Warning("Empty group\n");
    }
    auto edgePlacement = base->Placement.getValue().getPosition();
    Base::Console().Warning("Edge Placement: %f, %f, %f\n", edgePlacement.x, edgePlacement.y, edgePlacement.z);

    auto edgeGlobalPlacement = base->globalPlacement().getPosition();
    Base::Console().Warning("Edge Global Placement: %f, %f, %f\n", edgeGlobalPlacement.x, edgeGlobalPlacement.y, edgeGlobalPlacement.z);
    const Part::TopoShape& TopShape = base->Shape.getShape();
    Base::Console().Warning("TopShape Placement: %f, %f, %f\n", TopShape.getPlacement().getPosition().x,
                                                                TopShape.getPlacemet().getPosition().y,
                                                                TopShape.getPlacemet().getPosition().z);

    const std::vector<std::string>& SubVals = getSubValuesStartsWith(param->edgeSubname,"Edge");

    if(SubVals.size() == 0)
    {
        Base::Console().Error("No Edges specified");
        return false;
    }

    std::vector<TopoDS_Edge> edges;
    for(std::vector<std::string>::const_iterator it = SubVals.begin(); it!=SubVals.end(); ++it){
        TopoDS_Edge edge = TopoDS::Edge(TopShape.getSubShape(it->c_str()));

        edges.push_back(edge);
    }

    Part::Edgecluster acluster(edges);
    Part::tEdgeClusterVector aclusteroutput = acluster.GetClusters();

    if(aclusteroutput.size() == 0)
    {
        Base::Console().Error("No Edges specified");
        return false;
    }
    bool first = true;

    TopTools_IndexedDataMapOfShapeListOfShape anEFsMap;
    TopExp::MapShapesAndAncestors (TopShape.getShape(), TopAbs_EDGE, TopAbs_FACE, anEFsMap);

    auto getRotation = [&](const NCollection_List<TopoDS_Shape>& pfaces,const gp_Pnt& p,
                            const gp_Vec& v,
                            Base::Rotation& rot){
        gp_XYZ zdir;
        for(auto shape : pfaces) {
            TopoDS_Face face = TopoDS::Face(shape);
            Handle_Geom_Surface surface = BRep_Tool::Surface(face);
            GeomAPI_ProjectPointOnSurf proj(p, surface);
            Standard_Real U, V;
            proj.LowerDistanceParameters(U, V);
            gp_Dir tdir;
            BOPTools_AlgoTools3D::GetNormalToSurface(surface, U, V, tdir);
            if(face.Orientation() == TopAbs_Orientation::TopAbs_FORWARD){
                tdir = -tdir;
            }
            gp_XYZ txyz(tdir.X(), tdir.Y(), tdir.Z());
            zdir += txyz;
        }
        zdir.Normalize();
        gp_XYZ xdir(v.X(), v.Y(), v.Z());
        gp_XYZ ydir = zdir.Crossed(xdir);

        Base::Matrix4D mat;
        mat[0][0] = xdir.X();
        mat[1][0] = xdir.Y();
        mat[2][0] = xdir.Z();
        mat[3][0] = 0;

        mat[0][1] = ydir.X();
        mat[1][1] = ydir.Y();
        mat[2][1] = ydir.Z();
        mat[3][1] = 0;

        mat[0][2] = zdir.X();
        mat[1][2] = zdir.Y();
        mat[2][2] = zdir.Z();
        mat[3][2] = 0;

        //Base::Vector3d from1(0, 0, 1);
        //Base::Vector3d to1(dir.X(), dir.Y(), dir.Z());
        //rot.setValue(from1, to1);
        rot.setValue(mat);
    };

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    auto toolObject  = _station->GetActiveToolObject();
    for(std::vector<std::vector<TopoDS_Edge>>::const_iterator it= aclusteroutput.begin(); it!= aclusteroutput.end(); ++it)
    {
        for(std::vector<TopoDS_Edge>::const_iterator it2=it->begin(); it2!=it->end(); ++it2)
        {

            NCollection_List<TopoDS_Shape> pfaces = anEFsMap.FindFromKey(*it2);
            TopoDS_Face face = TopoDS::Face(TopShape.getSubShape(param->faceSubname.c_str()));
            for(auto shape : pfaces) {
                if (shape.IsSame(face))
                {
                    pfaces.Clear();
                    pfaces.Append(face);
                    break;
                }
            }

            Base::Console().Message("Edge has %d faces\n", pfaces.Size());
            BRepAdaptor_Curve adapt(*it2);
            switch(adapt.GetType())
            {
            case GeomAbs_Line:
            {
                adapt.Edge();
                adapt.Edge();
                gp_Pnt P1 = adapt.Value(adapt.FirstParameter());
                gp_Pnt P2 = adapt.Value(adapt.LastParameter());

                gp_Vec V1;
                adapt.D1(adapt.FirstParameter(), P1, V1);

                gp_Vec V2;
                adapt.D1(adapt.LastParameter(), P2, V2);
                Base::Rotation R1;
                Base::Rotation R2;

                getRotation(pfaces, P1, V1, R1);
                getRotation(pfaces, P2, V2, R2);

                if(it2->Orientation() == TopAbs_REVERSED)
                {
                    gp_Pnt tmpP = P1;
                    Base::Rotation tmpR = R1;
                    P1 = P2;
                    R1 = R2;
                    R2 = tmpR;
                    P2 = tmpP;
                }
                if(first) {
                    auto pos = wobj->Placement.getValue().getPosition();
                    Base::Console().Warning("wobj Placement: %f, %f, %f\n", pos.x, pos.y, pos.z);
                    auto grouppos = wobj->placement().getValue().getPosition();
                    Base::Console().Warning("wobj group placement: %f, %f, %f\n", grouppos.x, grouppos.y, grouppos.z);
                    Base::Console().Warning("P1 Placement: %f, %f, %f\n", P1.X(), P1.Y(), P1.Z());
                    Base::Console().Warning("P2 Placement: %f, %f, %f\n", P2.X(), P2.Y(), P2.Z());

                    Base::Placement _placement(wobj->placement().getValue().inverse()*
                                               base->globalPlacement() *
                                               base->Placement.getValue().inverse() * Base::Placement(Base::Vector3d(P1.X(), P1.Y(), P1.Z()), R1));

                    traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                    first = false;
                }

                Base::Placement _placement(wobj->placement().getValue().inverse() *
                                           base->globalPlacement() *
                                           base->Placement.getValue().inverse() * Base::Placement(Base::Vector3d(P2.X(), P2.Y(), P2.Z()), R2));
                traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                break;
            }
            case GeomAbs_BSplineCurve:
            {
                Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
                Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
               // Standard_Real NbrSegments = Round(Length/SegValue.getValue());
                Standard_Real NbrSegments = Round(Length/0.5);
                Standard_Real beg = adapt.FirstParameter();
                Standard_Real end = adapt.LastParameter();
                Standard_Real stp = ParLength/NbrSegments;
                bool reversed = false;
                if(it2->Orientation() == TopAbs_REVERSED) {
                    std::swap(beg, end);
                    stp = -stp;
                    reversed = true;
                }

                if(first)
                    first = false;
                else
                    beg += stp;
                if(reversed)
                {
                    for(;beg > end; beg += stp)
                    {
                        gp_Pnt P = adapt.Value(beg);
                        Base::Rotation R1;
                        gp_Vec V1;
                        adapt.D1(beg, P, V1);

                        getRotation(pfaces, P, V1, R1);
                        Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                        traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                    }
                }
                else {
                    for(;beg < end; beg += stp) {
                        gp_Pnt P = adapt.Value(beg);
                        gp_Vec V;
                        adapt.D1(beg, P, V);
                        Base::Rotation R1;
                        getRotation(pfaces, P, V, R1);

                        Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                        traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                    }
                }
            }
                break;
            case GeomAbs_Circle:
            {
                Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
                Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
                //Standard_Real NbrSegments = Round(Length/SegValue.getValue());
                Standard_Real NbrSegments = Round(Length/0.5);
                Standard_Real SegLength = ParLength/NbrSegments;
                if(it2->Orientation() == TopAbs_REVERSED)
                {
                    double i = adapt.LastParameter();
                    if(first)
                        first = false;
                    else
                        i -= SegLength;
                    for(; i > adapt.FirstParameter(); i-= SegLength){
                        gp_Pnt P = adapt.Value(i);
                        gp_Vec V;
                        adapt.D1(i, P, V);
                        Base::Rotation R1;
                        getRotation(pfaces, P, V, R1);
                        Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                        traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                    }
                }
                else
                {
                    double i = adapt.FirstParameter();
                    if(first)
                        first = false;
                    else
                        i += SegLength;
                    for(; i<adapt.LastParameter(); i+SegLength)
                    {
                        gp_Pnt P = adapt.Value(i);
                        gp_Vec V;
                        adapt.D1(i, P, V);
                        Base::Rotation R1;
                        getRotation(pfaces, P, V, R1);
                        Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                        traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                    }
                }
                break;
            }
            default:
                throw Base::TypeError("Unknown Edge Type in WirOlp::TrajectoryObjFromEdge::execute()");
            }

        }
    }
    return true;
}


bool DlgTrajectoryFromEdge::accept()
{
   return generateTrajectory();
}

bool DlgTrajectoryFromEdge::reject()
{
    return true;
}

void DlgTrajectoryFromEdge::helpRequested()
{

}


void DlgTrajectoryFromEdge::modifyStandardButtons(QDialogButtonBox* button)
{
    param->groupLayout()->addWidget(button);//button->hide();
}



#include "moc_DlgTrajectoryFromEdge.cpp"
