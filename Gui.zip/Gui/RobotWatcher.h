#ifndef WIROLP_ROBOTWATCHER_H
#define WIROLP_ROBOTWATCHER_H


#include <Gui/TaskView/TaskWatcher.h>
#include "RobotOptions.h"

#include <QObject>

namespace WirCoreGui {

class TaskContent;

class RobotWatcher : public Gui::TaskView::TaskWatcher
{
    Q_OBJECT

public:
    RobotWatcher();
    ~RobotWatcher();

    virtual bool shouldShow(void);

protected:
    RobotOptions *rob;
};



}








#endif // TASKWATCHER_H
