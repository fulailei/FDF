#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include "TaskDlgRobotSimulate.h"
#include "Mod/WirCore/Gui/DlgRobotSimulate.h"

using namespace WirCoreGui;
using namespace WirCore;

TaskDlgRobotSimulate::TaskDlgRobotSimulate(WirCore::RobotObject *pcRobotObject, WirCore::TrajectoryObject *pcTrajectoryObject)
    : TaskDialog()
{  
    setButtonPosition(TaskDlgRobotSimulate::South);

    taskBox = nullptr;
    std::vector<WirCore::WaypointObject*> waypoints;
    waypoints = pcTrajectoryObject->getAllPointsInTrajectory();

    if(waypoints.size() < 2)
        return;

    trac = new DlgRobotSimulate(pcRobotObject, pcTrajectoryObject);
    taskBox = new Gui::TaskView::TaskBox(/*QPixmap(), widget->windowTitle(),true,*/ 0);
    taskBox->groupLayout()->addWidget(trac);
    Content.push_back(taskBox);

    //rob = new RobotOptions(_pcRobotObject);
    //QObject::connect(trac ,SIGNAL(axisChanged(float,float,float,float,float,float,const Base::Placement &)),
    //                 rob  ,SLOT  (setAxis(float,float,float,float,float,float,const Base::Placement &)));
    //Content.push_back(rob);

    //rob  = new TaskRobot6Axis(pcRobotObject);
    //ctr  = new TaskRobotControl(pcRobotObject);
    //trac = new TaskTrajectory(pcRobotObject,pcTrajectoryObject);
    //msg  = new TaskRobotMessages(pcRobotObject);
    
    // QObject::connect(trac ,SIGNAL(axisChanged(float,float,float,float,float,float,const Base::Placement &)),
    //                     rob  ,SLOT  (setAxis(float,float,float,float,float,float,const Base::Placement &)));
    // Content.push_back(rob);
    // Content.push_back(ctr);
    // Content.push_back(trac);
    // Content.push_back(msg);
}

TaskDlgRobotSimulate::~TaskDlgRobotSimulate()
{

}

void TaskDlgRobotSimulate::open()
{
    //msg->hideGroupBox();
    // ctr->hideGroupBox();
}

void TaskDlgRobotSimulate::clicked(int)
{
    
}

bool TaskDlgRobotSimulate::accept()
{
    return true;
}

bool TaskDlgRobotSimulate::reject()
{
    return true;
}

void TaskDlgRobotSimulate::helpRequested()
{

}

void TaskDlgRobotSimulate::modifyStandardButtons(QDialogButtonBox* button)
{
    if (taskBox)
    {
         taskBox->groupLayout()->addWidget(button);
    }
}

#include "moc_TaskDlgRobotSimulate.cpp"
