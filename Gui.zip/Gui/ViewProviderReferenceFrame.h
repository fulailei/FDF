#ifndef WIRCORE_VIEWPROVIDERREFERENCEFRAME_H
#define WIRCORE_VIEWPROVIDERREFERENCEFRAME_H

#include <Base/Placement.h>
#include <Gui/ViewProviderGeometryObject.h>
#include <Gui/SoFCSelection.h>
#include <Gui/SoFCCSysDragger.h>
#include <Gui/SoAxisCrossKit.h>
#include <QMenu>

namespace WirCoreGui
{

class ViewProviderReferenceFrame : public Gui::ViewProviderGeometryObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderReferenceFrame);

public:
    ViewProviderReferenceFrame();

    ~ViewProviderReferenceFrame();

   void attach(App::DocumentObject *pcObject);
   void setDisplayMode(const char* ModeName);
   std::vector<std::string> getDisplayModes() const;
   void updateData(const App::Property*);

   virtual void onChanged(const App::Property* prop);
   void setupContextMenu(QMenu* menu, QObject* receiver, const char* member);

   std::vector<App::DocumentObject*> claimChildren(void) const;

   bool showInTree() const
   {
     return false;
   }

   static double s_scaleFactor;

protected:
   Gui::SoFCSelection* refFrameRoot;

   Gui::SoShapeScale* axisCross;
   SoGroup* axisGroup;
   SoTransform* axisTrans;
};

}

#endif
