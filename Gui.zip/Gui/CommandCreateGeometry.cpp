#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
# include <QCoreApplication>

# include <BRepBndLib.hxx>
# include <BRepBuilderAPI_MakeVertex.hxx>
# include <BRepExtrema_DistShapeShape.hxx>
# include <BRepMesh_IncrementalMesh.hxx>
# include <BRep_Tool.hxx>
# include <BRepTools.hxx>
# include <BRepAdaptor_Curve.hxx>
# include <BRepAdaptor_Surface.hxx>
# include <GeomLib.hxx>
# include <GeomAbs_CurveType.hxx>
# include <GeomAbs_SurfaceType.hxx>
# include <Geom_BezierCurve.hxx>
# include <Geom_BSplineCurve.hxx>
# include <Geom_BezierSurface.hxx>
# include <Geom_BSplineSurface.hxx>
# include <GeomAPI_ProjectPointOnSurf.hxx>
# include <GeomLProp_SLProps.hxx>
# include <gp_Trsf.hxx>
# include <Poly_Array1OfTriangle.hxx>
# include <Poly_Triangulation.hxx>
# include <Poly_Connect.hxx>
# include <Standard_Version.hxx>
# include <TColgp_Array1OfPnt.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Edge.hxx>
# include <TopoDS_Wire.hxx>
# include <TopoDS_Face.hxx>
# include <TopoDS_Shape.hxx>
# include <TopoDS_Vertex.hxx>
# include <TopoDS_Iterator.hxx>
# include <TopExp_Explorer.hxx>
# include <TopExp.hxx>
# include <TopTools_IndexedMapOfShape.hxx>
# include <Poly_PolygonOnTriangulation.hxx>
# include <TColStd_Array1OfInteger.hxx>
# include <TColgp_Array1OfDir.hxx>
# include <TColgp_Array1OfPnt2d.hxx>
# include <TopTools_ListOfShape.hxx>
# include <TShort_Array1OfShortReal.hxx>
# include <TShort_HArray1OfShortReal.hxx>
# include <Precision.hxx>

#endif

#include <Gui/Action.h>
#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>
#include <Gui/ViewProvider.h>
#include <Gui/SoFCSelection.h>
#include <Gui/ViewProviderPart.h>
#include <Base/Console.h>
#include <Gui/View3DInventor.h>
#include "Gui/View3DInventorViewer.h"
#include "Gui/MainWindow.h"
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>
#include <Gui/Control.h>
#include <Mod/WirCore/Gui/TaskGeomFillSurface.h>
#include <Mod/WirCore/Gui/TaskCreateGeometry.h>
#include <DlgProjectionOnSurface.h>

// #####################################################################################################
using namespace std;
using namespace Gui;
using namespace WirCoreGui;
//using namespace WirCore;


//===========================================================================
// CmdWirCoreCreateGeometry
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreCreateGeometry);
CmdWirCoreCreateGeometry::CmdWirCoreCreateGeometry()
    :Command("WirCoreCreateGeometry")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("CreateGeometry");
    sToolTipText    = QT_TR_NOOP("CreateGeometry");
    sWhatsThis      = "WirCore_CreateGeometry";
    sStatusTip      = sToolTipText;
    sPixmap         = "WirCore_CreateGeometry";
}

void CmdWirCoreCreateGeometry::activated(int)
{
    Gui::TaskView::TaskDialog* dlg = Gui::Control().activeDialog();
    // start the edit dialog
    if (dlg)
    {
//        TaskGeomFillSurface* tDlg = qobject_cast<TaskGeomFillSurface*>(dlg);
////        if (tDlg)
////            tDlg->setEditedObject(obj);
//        Gui::Control().showDialog(dlg);


        TaskCreateGeometry* tDlg = qobject_cast<TaskCreateGeometry*>(dlg);
        Gui::Control().showDialog(dlg);


    }
    else
        //Gui::Control().showDialog(new TaskGeomFillSurface());
        Gui::Control().showDialog(new TaskCreateGeometry());
}

bool CmdWirCoreCreateGeometry::isActive(void)
{
    return hasActiveDocument();
}

//===========================================================================
// WirCore_projectionOnSurface
//===========================================================================
DEF_STD_CMD_A(CmdWirCoreProjectionOnSurface)

CmdWirCoreProjectionOnSurface::CmdWirCoreProjectionOnSurface()
  :Command("WirCore_projectionOnSurface")
{
  sAppModule = "WirCore";
  sGroup = QT_TR_NOOP("WirCore");
  sMenuText = QT_TR_NOOP("Create projection on surface...");
  sToolTipText = QT_TR_NOOP("Create projection on surface...");
  sWhatsThis = "WirCore_projectionOnSurface";
  sStatusTip = sToolTipText;
  sPixmap = "WirCore_ProjectionOnSurface";
}

void CmdWirCoreProjectionOnSurface::activated(int iMsg)
{
  Q_UNUSED(iMsg);
  WirCoreGui::TaskProjectionOnSurface* dlg = new WirCoreGui::TaskProjectionOnSurface();
  Gui::Control().showDialog(dlg);
}

bool CmdWirCoreProjectionOnSurface::isActive(void)
{
  return (hasActiveDocument() /*&& !Gui::Control().activeDialog()*/);
}

void CreateWirCoreCommandCreateGeometry(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();
    rcCmdMgr.addCommand(new CmdWirCoreCreateGeometry());
    rcCmdMgr.addCommand(new CmdWirCoreProjectionOnSurface());
}
