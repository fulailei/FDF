#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include <Base/Console.h>
#include <Base/UnitsApi.h>
#include <Gui/Control.h>
#include <QString>
#include <qpalette.h>
#include <QSlider>
#include "ui_DlgCollisionMatrix.h"
#include "DlgCollisionMatrix.h"
#include <QStringList>

using namespace WirCoreGui;
using namespace Gui;

DlgCollisionMatrix::DlgCollisionMatrix(WirCore::AllowedCollisionMatrix& acm,
                                 QWidget* parent,
                                 Qt::WindowFlags fl )
    : QDialog(parent, fl), acm(acm)
{ 
    ui = new Ui::Form();
    ui->setupUi(this);

    for (int i = 0; i < acm.getEntryNum(); i++)
        bflipValues.push_back(false);

    connect(ui->tableWidget, SIGNAL(cellDoubleClicked(int,int)), this, SLOT(slotCellDoubleClicked(int,int)));

    ui->fcl->setChecked(this->acm.getCollisionType() != 0);
    ui->openinventor->setChecked(this->acm.getCollisionType() == 0);

    auto c = acm.getCollisionColor();
    QColor color;
    color.setRgbF(c.r, c.g, c.b, c.a);
    ui->colorButton->setColor(color);

    ui->checkBox_CheckHideObject->setChecked(this->acm.getIsCheckHideObject());
    ui->checkBox_MarkCollisionPoint->setChecked(this->acm.getIsCheckCollsionPoint());
    ui->checkBox_CheckInSim->setChecked(this->acm.getIsCheckInSim());

    ui->checkBox_CheckHideObject->setVisible(ui->openinventor->isChecked());
    ui->checkBox_MarkCollisionPoint->setVisible(ui->openinventor->isChecked());

    updateTable();


    // QRect rect=ui->tableWidget->visualItemRect;
    // ui.setupUi(this);
    /*  QMetaObject::connectSlotsByName(this);

        this->groupLayout()->addWidget(proxy);
        QObject::connect(ui->horizontalSlider_2, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA2(int)));
        QObject::connect(ui->horizontalSlider_3, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA3(int)));
        QObject::connect(ui->horizontalSlider_4, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA4(int)));
        QObject::connect(ui->horizontalSlider_5, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA5(int)));
        QObject::connect(ui->horizontalSlider_6, SIGNAL(sliderMoved(int)), this, SLOT(changeSliderA6(int)));
    */
}

void DlgCollisionMatrix::on_colorButton_clicked()
{
    QColor c = ui->colorButton->color();
    App::Color color(c.redF(), c.greenF(), c.blueF(), c.alphaF());
    acm.setCollisionColor(color);
}

void DlgCollisionMatrix::on_checkBox_CheckHideObject_toggled()
{
    acm.setIsCheckHideObject(ui->checkBox_CheckHideObject->checkState());
}

void DlgCollisionMatrix::on_checkBox_MarkCollisionPoint_toggled()
{
    acm.setIsCheckCollsionPoint(ui->checkBox_MarkCollisionPoint->checkState());
}

void DlgCollisionMatrix::on_checkBox_CheckInSim_toggled()
{
    acm.setIsCheckInSim(ui->checkBox_CheckInSim->checkState());
}

void DlgCollisionMatrix::on_fcl_toggled()
{
    acm.setCollisionType(ui->fcl->isChecked());
    ui->checkBox_CheckHideObject->setVisible(ui->fcl->isChecked());
    ui->checkBox_MarkCollisionPoint->setVisible(ui->fcl->isChecked());
}

void DlgCollisionMatrix::on_openinventor_toggled()
{
    acm.setCollisionType(!ui->openinventor->isChecked());
    ui->checkBox_CheckHideObject->setVisible(!ui->openinventor->isChecked());
    ui->checkBox_MarkCollisionPoint->setVisible(!ui->openinventor->isChecked());
}

void DlgCollisionMatrix::updateTable()
{
    if (!ui) return;

    int size = acm.getEntryNum();
    ui->tableWidget->setRowCount(size);
    ui->tableWidget->setColumnCount(size);

    QStringList slists;
    for (int i = 0; i < size; i++)
    {
        slists << QString::fromStdString(acm.getEntryName(i));
    }// << "Helvetica" << "Times" << "Courier";
    ui->tableWidget->setHorizontalHeaderLabels(slists);
    ui->tableWidget->setVerticalHeaderLabels(slists);


    QPixmap xp(QString::fromStdString(":/icons/CollisionMatrix_x.svg"));
    QSize mSize = xp.size();
    xp = xp.scaled(mSize.width() * 0.08, mSize.height() * 0.08);


    QPixmap yp(QString::fromStdString(":/icons/CollisionMatrix_y.svg"));
    mSize = yp.size();
    yp = yp.scaled(mSize.width() * 0.08, mSize.height() * 0.08);


    QPixmap tp(QString::fromStdString(":/icons/CollisionMatrix_t.svg"));
    mSize = tp.size();
    tp = tp.scaled(mSize.width() * 0.08, mSize.height() * 0.08);

    for (int r = 0; r < size; r++)
        for (int c = 0; c < size; c++)
        {
            // Base::Console().Message("value is %d\n",acm.getEntry(c,r));
            if (c == r)
            {
                QLabel *tlabel = new QLabel;
                tlabel->setPixmap(tp);
                tlabel->setAlignment(Qt::AlignCenter);
                ui->tableWidget->setCellWidget(r, c, tlabel);
            }
            else if(acm.getEntry(c,r))
            {
                QLabel *ylabel = new QLabel;
                ylabel->setPixmap(yp);
                ylabel->setAlignment(Qt::AlignCenter);
                ui->tableWidget->setCellWidget(r, c, ylabel);
            }
            else
            {
                QLabel *xlabel = new QLabel;
                xlabel->setPixmap(xp);
                xlabel->setAlignment(Qt::AlignCenter);
                ui->tableWidget->setCellWidget(r, c, xlabel);
            }
        }


    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);

    //set size of the header and its resize mode
    ui->tableWidget->horizontalHeader()->setDefaultSectionSize(20);
    ui->tableWidget->verticalHeader()->setDefaultSectionSize(20);
    // set the resize mode to fixed, so the user cannot change the height/width
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    setTableWidgeSize();
}

void DlgCollisionMatrix::slotCellDoubleClicked(int row, int column)
{
    // Base::Console().Message("The cell (i,j) is double clicked!\n",row,column);
    if (column == row)
    {
        for (int i = 0; i < acm.getEntryNum(); i++)
        {
            if (i != column)
            {
                if (bflipValues[column])
                {
                    acm.setEntry(column, i, 0);
                    acm.setEntry(i, row, 0);
                }
                else
                {
                    acm.setEntry(column, i, 1);
                    acm.setEntry(i, row, 1);
                }
            }
        }
        bflipValues[column] = !bflipValues[column];
    }
    else if (acm.getEntry(column, row) == 1)
        acm.setEntry(column, row, 0);
    else
        acm.setEntry(column, row, 1);

    updateTable();
}

void DlgCollisionMatrix::setTableWidgeSize()
{
    ui->tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    int w = 0; int h = 0;
    w += ui->tableWidget->contentsMargins().left()
            + ui->tableWidget->contentsMargins().right();
    h += ui->tableWidget->contentsMargins().top()
            + ui->tableWidget->contentsMargins().bottom();

    w += ui->tableWidget->verticalHeader()->width();
    h += ui->tableWidget->horizontalHeader()->height();

    for (int i=0; i<ui->tableWidget->columnCount(); ++i)
        w += ui->tableWidget->columnWidth(i);
    for (int i=0; i<ui->tableWidget->rowCount(); ++i)
        h += ui->tableWidget->rowHeight(i);
    /*
    if (w > ui->centralWidget->contentsRect().width())
        w = ui->centralWidget->contentsRect().width();
    if (h > ui->centralWidget->contentsRect().height())
        h = ui->centralWidget->contentsRect().height();*/
    /*
    int w = ui->tableWidget->verticalHeader()->width() + 4; // +4 seems to be needed
    for (int i = 0; i < ui->tableWidget->columnCount(); i++)
       w += ui->tableWidget->columnWidth(i); // seems to include gridline (on my machine)
    int h = ui->tableWidget->horizontalHeader()->height() + 4;
    for (int i = 0; i < ui->tableWidget->rowCount(); i++)
       h += ui->tableWidget->rowHeight(i);
//    ui->tableWidget->setMaximumSize(QSize(w, h));
//    ui->tableWidget->setMinimumSize(ui->tableWidget->maximumSize());
*/
    ui->tableWidget->setMinimumWidth(w);
    ui->tableWidget->setMaximumWidth(w);
    ui->tableWidget->setMinimumHeight(h);
    ui->tableWidget->setMaximumHeight(h);
    ui->tableWidget->setMinimumWidth(1000);
    ui->tableWidget->setMaximumWidth(1000);
    ui->tableWidget->setMinimumHeight(500);
    ui->tableWidget->setMaximumHeight(500);
}


#include "moc_DlgCollisionMatrix.cpp"



