#ifndef WIRCORE_VIEWPROVIDERWAYPOINTOBJECT_H
#define WIRCORE_VIEWPROVIDERWAYPOINTOBJECT_H

#include <Gui/ViewProviderDocumentObject.h>
#include <App/DocumentObject.h>
#include <Gui/SoFCSelection.h>
#include <Mod/WirCore/App/TrajectoryObject.h>

namespace WirCoreGui
{

class ViewProviderWaypointObject : public Gui::ViewProviderDocumentObject
{
    PROPERTY_HEADER(WirCoreGui::ViewProviderWaypointObject);

public:
    ViewProviderWaypointObject();

    ~ViewProviderWaypointObject();

    void attach(App::DocumentObject *pcObject);
    void setDisplayMode(const char* ModeName);
    std::vector<std::string> getDisplayModes() const;

    void updateData(const App::Property*);

    void setupContextMenu(QMenu*, QObject*, const char*);

    bool canDropObjects() const;
    bool canDragObjects() const;
    bool canDropObject(App::DocumentObject* obj) const;

    void dropObject(App::DocumentObject* obj);

    void SetRobotConfig();

    bool showInTree() const
    {
      return false;
    }


    WirCore::TrajectoryObject* findTrajtoryContainPoint(App::DocumentObject* obj);

protected:
   Gui::SoFCSelection* refWaypointRoot;

};

}
#endif // VIEWPROVIDERWAYPOINTOBJECT_H
