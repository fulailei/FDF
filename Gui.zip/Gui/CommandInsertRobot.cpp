/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"
#ifndef _PreComp_
# include <QMessageBox>
#endif

#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/MainWindow.h>
#include <Gui/FileDialog.h>
#include <Gui/Selection.h>
#include <Gui/Document.h>

#include <Mod/WirCore/App/RobotObject.h>


using namespace std;

DEF_STD_CMD_A(CmdWirCoreRobotInsertAbb4600);

CmdWirCoreRobotInsertAbb4600::CmdWirCoreRobotInsertAbb4600()
    :Command("WirCore_InsertAbb4600")
{
    sAppModule      = "WirCore";
    sGroup          = QT_TR_NOOP("WirCore");
    sMenuText       = QT_TR_NOOP("Abb4600");
    sToolTipText    = QT_TR_NOOP("Insert a Abb 4600 into the document.");
    sWhatsThis      = "WirCore_InsertAbb4600";
    sStatusTip      = sToolTipText;
   // sPixmap         = "WirCore_CreateRobot";
}

void CmdWirCoreRobotInsertAbb4600::activated(int)
{
    std::string FeatName = getUniqueObjectName("Abb4600");
    std::string RobotPath = "Mod/WirCore/Lib/Abb/Abb4600_40_205/RobotConfig.zip";
  //  App::Document* doc = App::GetApplication().getActiveDocument();

    openCommand("Place robot");

    doCommand(Doc, "App.activeDocument().addObject(\"WirCore::RobotObject\", \"%s\")", FeatName.c_str());
    doCommand(Doc,"App.activeDocument().%s.RobotXmlFile = App.getResourceDir()+\"%s\"",FeatName.c_str(),RobotPath.c_str());
    doCommand(Doc,"App.activeDocument().%s.Axis1 = 0",FeatName.c_str());
    doCommand(Doc,"App.activeDocument().%s.Axis2 = 0",FeatName.c_str());
    doCommand(Doc,"App.activeDocument().%s.Axis3 = 0",FeatName.c_str());
    doCommand(Doc,"App.activeDocument().%s.Axis4 = 0",FeatName.c_str());
    doCommand(Doc,"App.activeDocument().%s.Axis5 = 30",FeatName.c_str());
    doCommand(Doc,"App.activeDocument().%s.Axis6 = 0",FeatName.c_str());

    std::string stationName = FeatName + "Station";

    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::WorkStationGroup* _obj = new WirCore::WorkStationGroup();
    doc->addObject(_obj, stationName.c_str());
    _obj->Initialization();

    stationName = _obj->Label.getValue();
    doCommand(Doc,"App.activeDocument().%s.robot = App.activeDocument().%s",stationName.c_str(), FeatName.c_str());
    std::string activeName =  "select_active_station";
    doCommand(Doc,"App.activeDocument().%s.Object = App.activeDocument().%s",activeName.c_str(), stationName.c_str());

    updateActive();
    commitCommand();
}

bool CmdWirCoreRobotInsertAbb4600::isActive(void)
{
    if (getActiveGuiDocument())
    {
        App::Document* doc = App::GetApplication().getActiveDocument();

        return ((doc->getObjectsOfType(WirCore::RobotObject::getClassTypeId())).size() < 1);
    }
    else
        return false;


}



// #####################################################################################################
void CreateWirCoreCommandInsertRobot(void)
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();

    rcCmdMgr.addCommand(new CmdWirCoreRobotInsertAbb4600());
}
