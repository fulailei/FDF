#ifndef WIRCOREGUI_TASKGEOMFILLSURFACE_H
#define WIRCOREGUI_TASKGEOMFILLSURFACE_H

#include <QDoubleSpinBox>
#include "Mod/Part/App/PartFeature.h"
#include <Gui/TaskView/TaskDialogSpecial.h>
#include <Gui/TaskView/TaskView.h>
#include <Gui/SelectionFilter.h>
#include <Gui/DocumentObserver.h>
#include <Base/BoundBox.h>
#include "TopoDS_Shape.hxx"
#include "TopoDS_Edge.hxx"
#include "TopoDS_Face.hxx"
#include "TopoDS_Wire.hxx"
#include "gp_Dir.hxx"

class QListWidgetItem;

namespace Gui
{
class View3DInventor;
}

namespace WirCoreGui
{

class ViewProviderProjectCurve;
class ProjectCurve;
class DlgCrossSections;
class Ui_GeomFillSurface;


class GeomFillSurface : public QWidget,
                        public Gui::SelectionObserver,
                        public Gui::DocumentObserver
{
    Q_OBJECT

public:
    GeomFillSurface();
    ~GeomFillSurface();
    void open();
    void checkOpenCommand();
    bool accept();
    bool reject();
    std::vector<Gui::SelectionObject> getSelectFaces() { return m_vFaces; }

protected:
    void changeEvent(QEvent *e);
    virtual void onSelectionChanged(const Gui::SelectionChanges& msg);
    /** Notifies on undo */
    virtual void slotUndoDocument(const Gui::Document& Doc);
    /** Notifies on redo */
    virtual void slotRedoDocument(const Gui::Document& Doc);
    /** Notifies when the object is about to be removed. */
    virtual void slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj);

    class EdgeSelection;
    enum SelectionMode { None, Append, Remove };
    SelectionMode selectionMode;  
    int projectLineType; // project
    bool checkCommand;

private Q_SLOTS:
    void on_pushButton_showline_clicked(bool checked);

    void changePage(int index);
    void on_checkBox_clicked(bool checked);
    void onDeleteFace(void);
    void onDeleteEdge(void);
    void onWidgetEdgeSelectionChanged();

    void clearSelection();

    void on_pushButton_clicked();
    void on_pushButtonGetCurrentCamDir_clicked();
    void set_xyz_dir_spinbox(QDoubleSpinBox* icurrentSpinBox);
    void on_pushButtonDirX_clicked();
    void on_pushButtonDirY_clicked();
    void on_pushButtonDirZ_clicked();
    void create_projection_wire1();
    void show_projected_shapes();

    void on_radioLine_clicked();
    void on_radioSplin_clicked();
    void on_radioPolylin_clicked();

private:
    void get_camera_direction(void);

    Ui_GeomFillSurface* ui;
    std::vector<TopoDS_Shape> m_inputShapeVec; // wireline
    std::vector<TopoDS_Edge> m_wireShapeVec; // wireline
    std::vector<Gui::SelectionObject> m_vFaces;
    Part::Feature* m_geometryObject;
    ViewProviderProjectCurve* vp;
    ProjectCurve* spline;
    Gui::View3DInventor* view = nullptr;
    DlgCrossSections* m_intersectDlg;
};


class TaskGeomFillSurface : public Gui::TaskView::TaskDialogSpecial
{
    Q_OBJECT

public:
    TaskGeomFillSurface();
    ~TaskGeomFillSurface();
    std::vector<Gui::SelectionObject> getSelectFaces() { return widget->getSelectFaces(); }
    void modifyStandardButtons(QDialogButtonBox* button);

public:
    void open();
    bool accept();
    bool reject();

    virtual QDialogButtonBox::StandardButtons getStandardButtons() const
    { return QDialogButtonBox::Ok | QDialogButtonBox::Cancel; }

private:
    GeomFillSurface* widget;
    Gui::TaskView::TaskBox* taskbox;
};

} //namespace WirCoreGui

#endif // WIRCOREGUI_TASKGEOMFILLSURFACE_H
