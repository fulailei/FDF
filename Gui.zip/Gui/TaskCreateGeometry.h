#ifndef WIRCOREGUI_TASKCREATEGEOMETRY_H
#define WIRCOREGUI_TASKCREATEGEOMETRY_H


#include "Mod/Part/App/PartFeature.h"
#include <Gui/TaskView/TaskDialogSpecial.h>
#include <Gui/TaskView/TaskView.h>
#include <Gui/SelectionFilter.h>
#include <Gui/DocumentObserver.h>
#include <Base/BoundBox.h>
#include "TopoDS_Shape.hxx"
#include "TopoDS_Edge.hxx"
#include "TopoDS_Face.hxx"
#include "TopoDS_Wire.hxx"
#include "gp_Dir.hxx"

class QToolButton;
class QListWidgetItem;
class QDoubleSpinBox;

namespace Gui
{
class View3DInventor;
}

namespace WirCore
{
class GeometryObject;
}

namespace WirCoreGui
{
class WorkObjectReferenceFrame;
class ViewProviderProjectCurve;
class ProjectCurve;
class DlgCrossSections;
class Ui_DlgCreateGeometry;
class DlgSpecifyArea;
class DlgSpecifyEdge;
class BaseDialog;
class DlgProjection;
class DlgUVCurve;
class ViewProviderGeometryObject;

class DlgCreateGeometry : public QWidget
        //public Gui::DocumentObserver
{
    Q_OBJECT
public:
    DlgCreateGeometry();
    ~DlgCreateGeometry();

    void open();
    void checkOpenCommand();
    bool accept();
    bool reject();

    void preview();
    //std::vector<Gui::SelectionObject> getSelectFaces() { return m_vFaces; }

protected:
    void changeEvent(QEvent *e);
    //virtual void onSelectionChanged(const Gui::SelectionChanges& msg);
    /** Notifies on undo */
    // virtual void slotUndoDocument(const Gui::Document& Doc);
    /** Notifies on redo */
    //virtual void slotRedoDocument(const Gui::Document& Doc);
    /** Notifies when the object is about to be removed. */
    // virtual void slotDeletedObject(const Gui::ViewProviderDocumentObject& Obj);

    class EdgeSelection;
    enum SelectionMode { None, Append, Remove };
    SelectionMode selectionMode;
    int projectLineType; // project
    bool checkCommand;

Q_SIGNALS:
    void sigSpecifyAreaClicked();
    void sigSpecifyAreaClose();

private Q_SLOTS:
    // 四种类型都需要指定面操作
    void on_toolButtonSpecifyArea_clicked();
    void slotCloseSpecifyAreaPage();
    void on_toolButtonPreViewArea_clicked(bool checked);

    // 1、Edge Curve
    void on_toolButtonSpecifyEdge_clicked();
    void on_toolButtonPreViewEdge_clicked(bool checked);

    // 2、Intersect Geo
    void on_toolButtonSpecifyPlane_clicked();
    void on_toolButtonPreViewPlane_clicked();

    // 3、Projection Geo
    void on_toolButtonSpecifyProCurve_clicked();
    void on_toolButtonSpecifyProVector_clicked();
    void on_toolButtonPreViewProCurve_clicked();
    void on_toolButtonPreViewProVector_clicked();

    // 4、UV Curve
    void on_toolButtonSpecifyUVParam_clicked();

private:
    void addToAssistWidget(BaseDialog* w);


    enum TypeGeo {Edge = 0, Intersect, Project, UV};
    Ui_DlgCreateGeometry* ui;
    QString m_StrGeoName;
    WorkObjectReferenceFrame* selectWorkObjFrame = nullptr;
    TypeGeo m_curType = Edge;
    BaseDialog* m_curDlg = nullptr;

    // EdgeCurve
    DlgSpecifyArea* m_pDlgSpecifyArea = nullptr;
    DlgSpecifyEdge* m_pDlgSpecifyEdge = nullptr;
    
    // Intersect Geo
    DlgCrossSections* m_pDlgIntersectGeo = nullptr;

    // Project Geo
    DlgProjection* m_pDlgProjectionGeo = nullptr;

    // UVCurve
    DlgUVCurve* m_pDlgDlgUVCurve = nullptr;

    // preview res
    ViewProviderGeometryObject* m_pVpGeo = nullptr;
    WirCore::GeometryObject* m_pGeo = nullptr;
    Gui::View3DInventor* view = nullptr;
};



class TaskCreateGeometry : public Gui::TaskView::TaskDialog
{
    Q_OBJECT

public:
    TaskCreateGeometry();
    ~TaskCreateGeometry();
    void modifyStandardButtons(QDialogButtonBox* button) override;

public:
    void open() override;
    bool accept() override;
    bool reject() override;

    QDialogButtonBox::StandardButtons getStandardButtons() const override
    {
        return QDialogButtonBox::Ok | QDialogButtonBox::Cancel;
    }

private:
    DlgCreateGeometry* widget;
    Gui::TaskView::TaskBox* taskbox;

    //QDialogButtonBox* dlgBtnBox;
    QWidget* btnsBox;
    QToolButton* m_btnOK;
    QToolButton* m_btnCancel;
    QToolButton* m_btnPreview;
};

} //namespace WirCoreGui

#endif // WIRCOREGUI_TASKGEOMFILLSURFACE_H
