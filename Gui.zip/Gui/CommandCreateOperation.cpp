#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include <Gui/Action.h>
#include <App/Application.h>
#include <Gui/Application.h>
#include <Gui/Command.h>
#include <Gui/Control.h>
#include <Gui/Document.h>
#include <Mod/WirCore/Gui/TaskMachiningOperations.h>
#include <Mod/WirCore/App/WorkStationGroup.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/ActiveStationObject.h>
// ###################################33
using namespace std;
using namespace Gui;
using namespace WirCoreGui;

//===========================================
// CmdWirCoreCreateOperation
//===========================================
DEF_STD_CMD_A(CmdWirCoreCreateOperation);
CmdWirCoreCreateOperation::CmdWirCoreCreateOperation()
    :Command("WirCoreCreateOperation")
{
    sAppModule = "WirCore";
    sGroup = QT_TR_NOOP("WirCore");
    sMenuText = QT_TR_NOOP("CreateOperation");
    sToolTipText = QT_TR_NOOP("CreateOperation");
    sWhatsThis = "WirCore_CreateOperation";
    sStatusTip = sToolTipText;
    sPixmap = "WirCore_CreateOperation";
}

void CmdWirCoreCreateOperation::activated(int)
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    WirCore::TrajectoryObject* _TrajectoryObject = new WirCore::TrajectoryObject();

    std::string n = "Trajectory";
    _TrajectoryObject->Label.setValue(n);
    doc->addObject(_TrajectoryObject, n.c_str());

    WirCore::WorkStationGroup* _station = dynamic_cast<WirCore::WorkStationGroup*>
                                        ((dynamic_cast<WirCore::ActiveStationObject*>(doc->getObject("select_active_station")))->Object.getValue());

    _station->setInStation(_TrajectoryObject);
    Gui::TaskView::TaskDialog* dlg = Gui::Control().activeDialog();

    if(dlg)
    {
        //TODO: create the TaskMachiningOperation
        Gui::Control().showDialog(dlg);
    }
    else
    {
        Gui::Control().showDialog(new TaskMachiningOperations(_TrajectoryObject));
    }
}

bool CmdWirCoreCreateOperation::isActive()
{
    return hasActiveDocument();
}

void CreateWirCoreCommandCreateOperation()
{
    Gui::CommandManager &rcCmdMgr = Gui::Application::Instance->commandManager();

    rcCmdMgr.addCommand(new CmdWirCoreCreateOperation());
}
