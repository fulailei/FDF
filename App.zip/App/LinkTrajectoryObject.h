#ifndef WIRCORE_LINKTRAJECTORYOBJECT_H
#define WIRCORE_LINKTRAJECTORYOBJECT_H

#include "TrajectoryOperationObject.h"

namespace WirCore
{

class LinkTrajectoryObject : public WirCore::TrajectoryOperationObject
{
    PROPERTY_HEADER(WirCore::LinkTrajectoryObject);
public:
    LinkTrajectoryObject();
    virtual ~LinkTrajectoryObject();


    App::PropertyLink          linkTrajectory;

    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderLinkTrajectory";
    }


};
}
#endif // LINKTRAJECTORYOBJECT_H
