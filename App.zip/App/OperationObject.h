#ifndef WIRCORE_OPERATIONOBJECT_H
#define WIRCORE_OPERATIONOBJECT_H

#include <App/DocumentObject.h>
#include "WaypointObject.h"

namespace WirCore
{

class OperationObject : public App::DocumentObject
{
    PROPERTY_HEADER(WirCore::OperationObject);

public:
    OperationObject();
    virtual ~OperationObject();

    virtual const char * getViewProviderName() const override {
        return "WirCoreGui::ViewProviderOperationObject";
    };

    virtual App::DocumentObjectExecReturn * execute() override {
        return App::DocumentObject::StdReturn;
    }

    virtual short mustExecute() const;

public:
    std::vector<WirCore::WaypointObject*> getAllPointsInGeometry();


    App::PropertyLinkList WayPointList;
    App::PropertyBool updateEvent;

protected:
    virtual void onChanged(const App::Property* prop);


    std::vector<WirCore::WaypointObject*> waypoints_;
};

}

#endif
