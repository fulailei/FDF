#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include "WorkObjectReferenceFrame.h"

using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::WorkObjectReferenceFrame, WirCore::ReferenceFrame)

WorkObjectReferenceFrame::WorkObjectReferenceFrame()
{
    Placement.setStatus(App::Property::Hidden, true);
    Label.setStatus(App::Property::ReadOnly, true);
}

WorkObjectReferenceFrame::~WorkObjectReferenceFrame()
{

}
