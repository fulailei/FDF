#include "Process_Path.h"
using namespace WirCore;
using namespace Base;


TYPESYSTEM_SOURCE(WirCore::Process_Path, Base::Persistence);

Process_Path::Process_Path()
{

}
Process_Path::~Process_Path()
{

}
void Process_Path::Ganerate_Process_Path(WirCore::GeometryObject *geom,WirCore::WorkFrameObject* wobj,WirCore::ToolObjectReferenceFrame* toolObject)
{
    auto getRotation = [&](const TopoDS_Face face,const gp_Pnt& p,
                            const gp_Vec& v,
                            Base::Rotation& rot)
    {
        gp_XYZ zdir;
            Handle_Geom_Surface surface = BRep_Tool::Surface(face);
            GeomAPI_ProjectPointOnSurf proj(p, surface);
            Standard_Real U, V;
            proj.LowerDistanceParameters(U, V);
            gp_Dir tdir;
            BOPTools_AlgoTools3D::GetNormalToSurface(surface, U, V, tdir);
            if(face.Orientation() == TopAbs_Orientation::TopAbs_FORWARD){
                tdir = -tdir;
            }
            gp_XYZ txyz(tdir.X(), tdir.Y(), tdir.Z());
            zdir += txyz;

        zdir.Normalize();
        gp_XYZ xdir(v.X(), v.Y(), v.Z());
        gp_XYZ ydir = zdir.Crossed(xdir);

        Base::Matrix4D mat;
        mat[0][0] = xdir.X();
        mat[1][0] = xdir.Y();
        mat[2][0] = xdir.Z();
        mat[3][0] = 0;

        mat[0][1] = ydir.X();
        mat[1][1] = ydir.Y();
        mat[2][1] = ydir.Z();
        mat[3][1] = 0;

        mat[0][2] = zdir.X();
        mat[1][2] = zdir.Y();
        mat[2][2] = zdir.Z();
        mat[3][2] = 0;

        //Base::Vector3d from1(0, 0, 1);
        //Base::Vector3d to1(dir.X(), dir.Y(), dir.Z());
        //rot.setValue(from1, to1);
        rot.setValue(mat);
    };
    for(auto it:geom->obj_group)
    {
        auto aPart1 = dynamic_cast<Part::Feature*>(it.first);
        auto edge= aPart1->Shape.getShape();
        auto aPart2 = dynamic_cast<Part::Feature*>(it.second);
        auto face= aPart2->Shape.getShape();
        string s="Edges";
        string f="Faces";
      TopoDS_Edge topoedge = TopoDS::Edge(edge.getSubShape(s.c_str()));
      TopoDS_Face topoface = TopoDS::Face(face.getSubShape(f.c_str()));
      BRepAdaptor_Curve adapt(topoedge);
      switch(adapt.GetType())
      {
      case GeomAbs_Line:
      {
          Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
          Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
         // Standard_Real NbrSegments = Round(Length/SegValue.getValue());
          Standard_Real NbrSegments = Round(Length/0.5);
          Standard_Real beg = adapt.FirstParameter();
          Standard_Real end = adapt.LastParameter();
          Standard_Real stp = ParLength/NbrSegments;
          int count_length=0;
          bool reversed = false;
          if(topoedge.Orientation() == TopAbs_REVERSED) {
              std::swap(beg, end);
              stp = -stp;
              reversed = true;
          }
             // beg += stp;
          if(reversed)
          {
              for(;beg > end; beg += stp)
              {
                  gp_Pnt P = adapt.Value(beg);
                  Base::Rotation R1;
                  gp_Vec V1;
                  adapt.D1(beg, P, V1);
                  getRotation(topoface, P, V1, R1);
                  Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                  if(beg==adapt.FirstParameter()||beg==end||count_length*0.5==Save_Parameter->length)
                  {
                  traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                  count_length=0;
                  }
                  count_length++;
              }
          }
          else {
              for(;beg < end; beg += stp) {
                  gp_Pnt P = adapt.Value(beg);
                  gp_Vec V;
                  adapt.D1(beg, P, V);
                  Base::Rotation R1;
                  getRotation(topoface, P, V, R1);
                  Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                  traj->addWaypointToTrajectory(_placement, wobj, toolObject);
              }
          }
      }
          break;

      case GeomAbs_BSplineCurve:
      {
          Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
          Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
         // Standard_Real NbrSegments = Round(Length/SegValue.getValue());
          Standard_Real NbrSegments = Round(Length/0.5);
          Standard_Real beg = adapt.FirstParameter();
          Standard_Real end = adapt.LastParameter();
          Standard_Real stp = ParLength/NbrSegments;
          int count_length=0;
          bool reversed = false;
          if(topoedge.Orientation() == TopAbs_REVERSED) {
              std::swap(beg, end);
              stp = -stp;
              reversed = true;
          }
             // beg += stp;
          if(reversed)
          {
              for(;beg > end; beg += stp)
              {
                  gp_Pnt P = adapt.Value(beg);
                  Base::Rotation R1;
                  gp_Vec V1;
                  adapt.D1(beg, P, V1);
                  getRotation(topoface, P, V1, R1);
                  Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));

                  if(beg==adapt.FirstParameter()||beg==end||count_length*0.5==Save_Parameter->length)
                  {
                  traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                  count_length=0;
                  }
                  count_length++;
              }
          }
          else {
              for(;beg < end; beg += stp) {
                  gp_Pnt P = adapt.Value(beg);
                  gp_Vec V;
                  adapt.D1(beg, P, V);
                  Base::Rotation R1;
                  getRotation(topoface, P, V, R1);
                  Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                  if(beg==adapt.FirstParameter()||beg==end||count_length*0.5==Save_Parameter->length)
                  {
                  traj->addWaypointToTrajectory(_placement, wobj, toolObject);
                  count_length=0;
                  }
                  count_length++;
              }
          }
      }
          break;
      case GeomAbs_Circle:
      {
          Standard_Real Length = CPnts_AbscissaPoint::Length(adapt);
          Standard_Real ParLength = adapt.LastParameter()-adapt.FirstParameter();
          //Standard_Real NbrSegments = Round(Length/SegValue.getValue());
          Standard_Real NbrSegments = Round(Length/0.5);
          Standard_Real SegLength = ParLength/NbrSegments;
          if(topoedge.Orientation() == TopAbs_REVERSED)
          {
              double i = adapt.LastParameter();

                  i -= SegLength;
              for(; i > adapt.FirstParameter(); i-= SegLength){
                  gp_Pnt P = adapt.Value(i);
                  gp_Vec V;
                  adapt.D1(i, P, V);
                  Base::Rotation R1;
                  getRotation(topoface, P, V, R1);
                  Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                  traj->addWaypointToTrajectory(_placement, wobj, toolObject);
              }
          }
          else
          {
              double i = adapt.FirstParameter();
                  i += SegLength;
              for(; i<adapt.LastParameter(); i+SegLength)
              {
                  gp_Pnt P = adapt.Value(i);
                  gp_Vec V;
                  adapt.D1(i, P, V);
                  Base::Rotation R1;
                  getRotation(topoface, P, V, R1);
                  Base::Placement _placement(wobj->placement().getValue().inverse()*Base::Placement(Base::Vector3d(P.X(), P.Y(), P.Z()),R1));
                  traj->addWaypointToTrajectory(_placement, wobj, toolObject);
              }
          }
          break;
      }
      default:
          throw Base::TypeError("Unknown Edge Type in WirOlp::TrajectoryObjFromEdge::execute()");
      }

  }
}

unsigned int Process_Path::getMemSize (void) const
{
    return 0;
}

void Process_Path::Save (Writer &writer) const
{


}

void Process_Path::Restore(XMLReader &reader)
{


}
void Process_Path::Set_Parameter(Process_Parameter input_Parameter)
{
    Save_Parameter->angle=input_Parameter.angle;
    Save_Parameter->length=input_Parameter.length;
    Save_Parameter->tolerance=input_Parameter.tolerance;
}
Process_Parameter* Process_Path::Get_Parameter()
{
    return Save_Parameter;
}
TrajectoryObject * Process_Path::Get_trajectory()
{
    return traj;
}
