#ifndef WIRCORE_TRAJECTORYOPTIMIZATION_H
#define WIRCORE_TRAJECTORYOPTIMIZATION_H


#include "PreCompiled.h"

#ifndef _PreComp_

#endif

#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/WaypointObject.h>

#include <vector>

namespace WirCore
{
//轨迹优化类
class TrajectoryOptimization
{
public:
    TrajectoryOptimization(WirCore::TrajectoryObject *pcTrajectoryObject);

    void StartOptimizationDlg();

    enum PointType {
        Arriveable = 0,
        UnArriveable,
        OutOfLimit,
        SingAWrist
    };

    std::vector<std::vector<PointType>> getTracMap() {return m_TracMap;};
private:
    //内部缓存的轨迹和机器人
    WirCore::TrajectoryObject* m_trac;
    WirCore::RobotObject* m_rob;
    void initTracMap();
    std::vector<std::vector<PointType>> m_TracMap;
    //获取传入的轨迹点机器人运动到该点是FL盘中心在世界坐标系下的位置
    Base::Placement getPointRobotTcpPos(WirCore::WaypointObject* i_obj);
};

}


#endif // TRAJECTORYOPTIMIZATION_H
