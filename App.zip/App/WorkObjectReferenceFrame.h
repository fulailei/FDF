#ifndef WORKOBJECTREFERENCEFRAME_H
#define WORKOBJECTREFERENCEFRAME_H


#include <App/DocumentObject.h>
#include <App/PropertyGeo.h>
#include "ReferenceFrame.h"

namespace WirCore
{

class WorkObjectReferenceFrame : public WirCore::ReferenceFrame
{
   PROPERTY_HEADER(WirCore::WorkObjectReferenceFrame);
public:
    WorkObjectReferenceFrame();

    virtual ~WorkObjectReferenceFrame();


    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderReferenceFrame";
    }

    virtual App::DocumentObjectExecReturn *execute(void) {
        return App::DocumentObject::StdReturn;
    }

};

}
#endif // WORKOBJECTREFERENCEFRAME_H
