#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "ActiveStationObject.h"
#include "WorkStationGroup.h"

using namespace WirCore;
using namespace App;


PROPERTY_SOURCE(WirCore::ActiveStationObject, App::DocumentObject)

ActiveStationObject::ActiveStationObject()
{
    ADD_PROPERTY_TYPE(Object,(0),"",App::Prop_None,"active station group");
    Object.setStatus(App::Property::Hidden, true);
}


ActiveStationObject::~ActiveStationObject()
{
}

void ActiveStationObject::onChanged(const App::Property* prop)
{
    App::DocumentObject::onChanged(prop);
    if(prop == &Object){
        auto obj = dynamic_cast<WirCore::WorkStationGroup*>(Object.getValue()) ;
        obj->UpdateComboEvent.setValue(true);
    }

}


