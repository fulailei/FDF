#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "WorkStationGroup.h"
#include <App/Application.h>
#include <App/Document.h>

using namespace WirCore;
using namespace App;

PROPERTY_SOURCE_WITH_EXTENSIONS(WirCore::WorkStationGroup, App::DocumentObjectGroup);

WorkStationGroup::WorkStationGroup()
{
    Group.setStatus(App::Property::Hidden, true);
    GroupExtension::initExtension(this);

    ADD_PROPERTY_TYPE(activeWobjObjectName,(0),"",App::Prop_ReadOnly,"active station group");
    ADD_PROPERTY_TYPE(activeToolObjectName,(0),"",App::Prop_ReadOnly,"active station group");

    ADD_PROPERTY_TYPE(WobjGroup,(0),"",App::Prop_Hidden,"WobjGroup");
    ADD_PROPERTY_TYPE(ToolGroup,(0),"",App::Prop_Hidden,"ToolGroup");
    ADD_PROPERTY_TYPE(TrajtoryGroup,(0),"",App::Prop_Hidden,"TrajtoryGroup");

    ADD_PROPERTY_TYPE(robot,(0),"",App::Prop_None,"robot in station");
    ADD_PROPERTY_TYPE(UpdateComboEvent,(0),"",App::Prop_Hidden," ");

    robot.setStatus(App::Property::ReadOnly, true);
}


WorkStationGroup::~WorkStationGroup()
{
}


WorkStationGroup* WorkStationGroup::getStationGroupOfObject(const DocumentObject* obj)
{
    WirCore::WorkStationGroup* stationObj = nullptr;
    auto list = obj->getInList();
    for (auto obj : list) {
        if(obj->isDerivedFrom(WirCore::WorkStationGroup::getClassTypeId()))
            return dynamic_cast<WirCore::WorkStationGroup*>(obj);

        if(obj->hasExtension(App::GroupExtension::getExtensionClassTypeId(), false))
        {
            stationObj = getStationGroupOfObject(obj);
            if (stationObj != nullptr)
            {
                return stationObj;
            }
        }
    }

    return nullptr;
}

void WorkStationGroup::updateAllRobotHoldFrame(Base::Placement i_placement)
{
    auto wobjlist = dynamic_cast<App::DocumentObjectGroup*>(WobjGroup.getValue())->getObjects();
    for (auto obj : wobjlist) {
        if (!obj->isDerivedFrom(WirCore::WorkFrameObject::getClassTypeId()))
        {
            continue;
        }
        WirCore::WorkFrameObject* _Wobj = dynamic_cast<WirCore::WorkFrameObject*>(obj);
        if (_Wobj->robotHold.getValue())
        {
            auto _local = _Wobj->wobjPlacement.getValue();
            _Wobj->Placement.setValue(i_placement * _local);
        }
    }

    auto Toollist = dynamic_cast<App::DocumentObjectGroup*>(ToolGroup.getValue())->getObjects();
    for (auto obj : Toollist) {
        if (!obj->isDerivedFrom(WirCore::ToolObjectReferenceFrame::getClassTypeId()))
        {
            continue;
        }

        WirCore::ToolObjectReferenceFrame* _tool = dynamic_cast<WirCore::ToolObjectReferenceFrame*>(obj);
        if (_tool->robotHold.getValue())
        {
            auto _local = _tool->toolPlacement.getValue();
            _tool->Placement.setValue(i_placement * _local);
        }
    }

    return;
}

std::vector<App::DocumentObject*> WorkStationGroup::getAllWobjsInStation()
{
    std::vector<App::DocumentObject*> _group;
    _group.clear();
    auto wobjlist = dynamic_cast<App::DocumentObjectGroup*>(WobjGroup.getValue());
    if (wobjlist)
    {
        _group = wobjlist->getObjectsOfType(WirCore::WorkFrameObject::getClassTypeId());
    }
    return _group;
}

std::vector<App::DocumentObject*> WorkStationGroup::getAllToolsInStation()
{
    std::vector<App::DocumentObject*> _group;
    _group.clear();
    auto Toollist = dynamic_cast<App::DocumentObjectGroup*>(ToolGroup.getValue());
    if (Toollist)
    {
        _group = Toollist->getObjectsOfType(WirCore::ToolObjectReferenceFrame::getClassTypeId());
    }
    return _group;
}


std::vector<WirCore::WaypointObject*> WorkStationGroup::getAllWaypointsInStation()
{
    std::vector<App::DocumentObject*> _tracGroup;
    std::vector<WirCore::WaypointObject*> _group;
    _tracGroup.clear();
    _group.clear();
    auto Traclist = dynamic_cast<App::DocumentObjectGroup*>(TrajtoryGroup.getValue());
    if (Traclist)
    {
        _tracGroup = Traclist->getObjectsOfType(WirCore::TrajectoryObject::getClassTypeId());
    }
    for (auto _obj : _tracGroup)
    {
        auto points = dynamic_cast<WirCore::TrajectoryObject*>(_obj)->getAllPointsInTrajectory();
        _group.insert(_group.end(), points.begin(), points.end());
    }
    return _group;
}

void WorkStationGroup::Initialization()
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    std::string Featname = Label.getValue();

    //insert wobj group
    App::DocumentObjectGroup* wobjlist = new App::DocumentObjectGroup();
    doc->addObject(wobjlist, (Featname+"_WobjGroup").c_str());
    addObject(wobjlist);
    WobjGroup.setValue(wobjlist);

    WirCore::WorkFrameObject* wobj = new WirCore::WorkFrameObject();
    doc->addObject(wobj, "WobjFrame");
    WirCore::WorkObjectReferenceFrame* ref = new WirCore::WorkObjectReferenceFrame();
    wobj->WObjReferenceFrame.setValue(ref);
    doc->addObject(ref);
    wobj->addObject(ref);
    wobjlist->addObject(wobj);
    activeWobjObjectName.setValue(wobj->Label.getValue());

    //insert tool group
    App::DocumentObjectGroup* Toollist = new App::DocumentObjectGroup();
    doc->addObject(Toollist, (Featname+"_ToolGroup").c_str());
    addObject(Toollist);
    ToolGroup.setValue(Toollist);

    WirCore::ToolObjectReferenceFrame* toolObj = new WirCore::ToolObjectReferenceFrame();
    doc->addObject(toolObj, "toolFrame");
    Toollist->addObject(toolObj);
    activeToolObjectName.setValue(toolObj->Label.getValue());

    //insert Trajtory Group
    App::DocumentObjectGroup* Trajtorylist = new App::DocumentObjectGroup();
    doc->addObject(Trajtorylist, (Featname+"_TrajtoryGroup").c_str());
    addObject(Trajtorylist);
    TrajtoryGroup.setValue(Trajtorylist);
}



void WorkStationGroup::setInStation(App::DocumentObject* i_obj)
{
    std::vector<DocumentObject*> _objects = getObjectsOfType(App::DocumentObjectGroup::getClassTypeId());

    if (_objects.empty())
    {
        return;
    }

    if (i_obj->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
    {
        auto _group = dynamic_cast<App::DocumentObjectGroup*>(TrajtoryGroup.getValue());
        _group->addObject(i_obj);
    }
    else if (i_obj->isDerivedFrom(WirCore::WorkFrameObject::getClassTypeId()))
    {
        auto _group = dynamic_cast<App::DocumentObjectGroup*>(WobjGroup.getValue());
        _group->addObject(i_obj);
    }
    else if (i_obj->isDerivedFrom(WirCore::ToolObjectReferenceFrame::getClassTypeId()))
    {
         auto _group = dynamic_cast<App::DocumentObjectGroup*>(ToolGroup.getValue());
        _group->addObject(i_obj);
    }
}

WirCore::WorkFrameObject* WorkStationGroup::GetActiveWobjObject()
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    auto _object = dynamic_cast<WirCore::WorkFrameObject*>(doc->getObject(activeWobjObjectName.getValue()));

    return _object;
}

WirCore::ToolObjectReferenceFrame* WorkStationGroup::GetActiveToolObject()
{
    App::Document* doc = App::GetApplication().getActiveDocument();
    auto _object = dynamic_cast<WirCore::ToolObjectReferenceFrame*>(doc->getObject(activeToolObjectName.getValue()));\

    return _object;
}




