#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "RobotToolObject.h"
#include <App/DocumentObjectPy.h>
#include <Base/Placement.h>
#include <Base/FileInfo.h>


using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::RobotToolObject, App::GeoFeature)


RobotToolObject::RobotToolObject()
{
   ADD_PROPERTY_TYPE(ToolTcp ,( Base::Placement()),"Tool definition",Prop_None,"Defines ToolBase to Robot TCP");
   ADD_PROPERTY_TYPE(ToolShape,(0),"Tool definition",App::Prop_None,"Link to the Shape is used as Tool");

   ToolShape.setStatus(App::Property::Hidden, true);

   GroupExtension::initExtension(this);
}

RobotToolObject::~RobotToolObject()
{
}

short RobotToolObject::mustExecute(void) const
{
    return 0;
}


PyObject *RobotToolObject::getPyObject()
{
    if (PythonObject.is(Py::_None())){
        // ref counter is set to 1
        PythonObject = Py::Object(new App::DocumentObjectPy(this),true);
    }
    return Py::new_reference_to(PythonObject);
}


