#ifndef REFERENCEFRAME_H
#define REFERENCEFRAME_H


#include <App/DocumentObject.h>
#include <App/PropertyGeo.h>
#include <App/GeoFeature.h>

namespace WirCore
{

class ReferenceFrame : public App::GeoFeature
{
    PROPERTY_HEADER(WirCore::ReferenceFrame);

public:
    ReferenceFrame(void);
    virtual ~ReferenceFrame();

    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderReferenceFrame";
    }

    virtual App::DocumentObjectExecReturn *execute(void) {
        return App::DocumentObject::StdReturn;
    }

    virtual short mustExecute(void) const;
    virtual PyObject *getPyObject(void);

    virtual void Save(Base::Writer &/*writer*/) const;
    virtual void Restore(Base::XMLReader &/*reader*/);

public:
    //bool addObject(App::DocumentObject* object);
    //const std::vector<App::DocumentObject*> &getObjects() const;
    //App::PropertyPlacement Frame;
    //App::PropertyLink Object;
    //App::PropertyLinkChild Object;
    App::PropertyLinkList Objects;

protected:
    virtual void onChanged(const App::Property* prop);
    bool block;

    //std::vector<App::DocumentObject*> objects;

};
}


#endif // REFERENCEFRAME_H
