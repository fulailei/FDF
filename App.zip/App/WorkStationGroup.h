#ifndef WIRCORE_WORKSTATIONGROUP_H
#define WIRCORE_WORKSTATIONGROUP_H

#include <App/OriginGroupExtension.h>
#include <App/DocumentObject.h>
#include <App/DocumentObjectGroup.h>

#include "TrajectoryObject.h"
#include "WorkFrameObject.h"
#include "ToolObjectReferenceFrame.h"
#include "WorkObjectReferenceFrame.h"
#include "WaypointObject.h"

namespace WirCore
{
class  WorkStationGroup :  public App::DocumentObjectGroup
{
     PROPERTY_HEADER_WITH_EXTENSIONS(WirCore::WorkStationGroup);
public:
    WorkStationGroup();
    virtual ~WorkStationGroup();


    /// returns the type name of the ViewProvider
    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderWorkStationGroup";
    }

    void setInStation(App::DocumentObject* i_obj);
    App::PropertyLink robot;

    //工作站内所有工件坐标系集合
    App::PropertyLink WobjGroup;
    //工作站内所有工具坐标系集合
    App::PropertyLink ToolGroup;
    //工作站内所有轨迹集合
    App::PropertyLink TrajtoryGroup;

    App::PropertyString activeWobjObjectName;
    App::PropertyString activeToolObjectName;

    App::PropertyBool UpdateComboEvent;

    static WorkStationGroup* getStationGroupOfObject(const DocumentObject* obj);
    //刷新所有被机器人抓着的工件工具坐标系
    void updateAllRobotHoldFrame(Base::Placement i_placement);

    void Initialization();

    WirCore::WorkFrameObject* GetActiveWobjObject();
    WirCore::ToolObjectReferenceFrame* GetActiveToolObject();

    std::vector<App::DocumentObject*> getAllWobjsInStation();
    std::vector<App::DocumentObject*> getAllToolsInStation();
    std::vector<WirCore::WaypointObject*> getAllWaypointsInStation();
};


}
#endif //WIRCORE_WORKSTATIONGROUP_H
