#include "PreCompiled.h"

#ifndef _PreComp_
# include <gp_Pln.hxx>
#endif

#include "PointObject.h"
#include "WaypointObject.h"
#include "TrajectoryObject.h"

using namespace WirCore;

PROPERTY_SOURCE(WirCore::PointObject, WirCore::CoordinateSystem)
PointObject::PointObject()
{
}

PointObject::~PointObject()
{

}


void PointObject::onChanged(const App::Property* prop)
{
     App::GeoFeature::onChanged(prop);
     if(prop == &Label){
        std::vector<App::DocumentObject*> vecObject;
        vecObject = this->getInList();

        for (std::vector<App::DocumentObject*>::iterator it = vecObject.begin(); it != vecObject.end(); ++it)
        {
            Base::Type objType = (*it)->getTypeId();
            if (objType.isDerivedFrom(WirCore::WaypointObject::getClassTypeId()))
            {
               WirCore::WaypointObject *p = dynamic_cast<WirCore::WaypointObject *>(*it);
               p->waypointType.setValue(p->waypointType.getValue());
            }
        }
     }
}

bool PointObject::copyFrom(PointObject* i_object)
{
    if (i_object == nullptr)
    {
        return false;
    }

    std::vector<App::Property*> from_props;
    i_object->getPropertyList(from_props);

    std::vector<App::Property*> to_props;
    this->getPropertyList(to_props);

    for (unsigned int index = 0; index < from_props.size(); index++)
    {
        App::Property* temp = from_props[index]->Copy();
        to_props[index]->Paste(*temp);
    }
    return true;
}
