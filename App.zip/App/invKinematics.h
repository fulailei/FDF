#ifndef WIRCORE_INVKINEMATICS_H
#define WIRCORE_INVKINEMATICS_H

#include "kdl_cp/chain.hpp"
#include "kdl_cp/jntarray.hpp"
#include "kdl_cp/frames_io.hpp"

#ifndef RO_MATH_TOL_DOUBLE
    #define RO_MATH_TOL_DOUBLE 1e-5
#endif


namespace WirCore
{

/// Definition of the Axis properties
struct AxisDefinition {
    double a;        // a of the Denavit-Hartenberg parameters (mm)
    double alpha;    // alpha of the Denavit-Hartenberg parameters (°)
    double d;        // d of the Denavit-Hartenberg parameters (mm)
    double theta;    // a of the Denavit-Hartenberg parameters (°)
    double rotDir;   // rotational direction (1|-1)
    double maxAngle; // soft ends + in °
    double minAngle; // soft ends - in °
    double velocity; // max vlocity of the axle in °/s
};


class invKinematics
{

public:
    invKinematics(std::vector<AxisDefinition> axisDH,const KDL::JntArray& q_min, const KDL::JntArray& q_max);

    virtual ~invKinematics();

    int CartToJnt(const KDL::JntArray& q_init, const KDL::Frame& p_in, KDL::JntArray& q_out, std::vector<bool> LinkConfig);
private:
    std::vector<AxisDefinition> axisDH;
    KDL::JntArray q_min;
    KDL::JntArray q_max;

    double RoATan(long double Y, long double X)
    {
        return atan2(fabs(Y) < RO_MATH_TOL_DOUBLE ? 0.0 : Y, fabs(X) < RO_MATH_TOL_DOUBLE ? 0.0 : X);
    }


};

}

#endif // INVKINEMATICS_H
