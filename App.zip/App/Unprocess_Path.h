#ifndef UNPROCESS_PATH_H
#define UNPROCESS_PATH_H
#include "PreCompiled.h"
#ifndef _PreComp_
#endif
#include "PointObject.h"
#include "WaypointObject.h"
#include "TrajectoryOperationObject.h"
#include "TrajectoryObject.h"
#include <App/DocumentObjectPy.h>
#include <Base/Placement.h>
#include <App/Application.h>
#include <App/Document.h>
#include "LinkTrajectoryObject.h"
#include <App/DocumentObject.h>
#include <App/PropertyFile.h>
#include <App/PropertyGeo.h>
#include <App/GeoFeature.h>

namespace WirCore {
enum Approach_Type
{
    Approach_Linear,Approach_Arc,Approach_None
};

enum Departing_Type
{
    Departing_Linear,Departing_Arc,Departing_None
};
enum Link_Type
{
    Use_Approach_Departing,Lift_Saft_Height,Direct
};
struct Approach_parameter
{
    double Approach_Length;
    double Approach_Rotation_Y;
    double Approach_Rotation_Z;
    double Approach_Radius;
    double Approach_Angle;
};
struct Departing_parameter
{
    double Departing_Length;
    double Departing_Rotation_Y;
    double Departing_Rotation_Z;
    double Departing_Radius;
    double Departing_Angle;
};
struct Other_parameter
{
    double Buffer_Distance;
    double Safe_Height;
};
class Unprocess_Path : public Base::Persistence
{
     TYPESYSTEM_HEADER();
public:
    Unprocess_Path();
    ~Unprocess_Path();
    virtual unsigned int getMemSize (void) const;
    virtual void Save (Base::Writer &/*writer*/) const;
    virtual void Restore(Base::XMLReader &/*reader*/);
    void Ganerate_Approach_Path(WaypointObject *Start_Point,WirCore::WorkFrameObject* wobj);
    void Ganerate_Departing_Path(WaypointObject *End_Point,WirCore::WorkFrameObject* wobj);
    void Ganerate_Link_Path(WaypointObject *Start_Point,WaypointObject *End_Point,WirCore::WorkFrameObject* wobj);
    void Set_Approach_Parameter(Approach_parameter input_approach_para);
    void Set_Departing_Parameter(Departing_parameter input_departing_para);
    void Set_Other_Parameter(Other_parameter input_other_para);
    void Set_Enum_Choose_Type(Approach_Type input_Enum_Approach_Type,Departing_Type input_Enum_Departing_Type,Link_Type input_Enum_Link_Type);
    Approach_parameter * Get_Approach_Parameter();
    Departing_parameter * Get_Departing_Parameter();
    Other_parameter *Get_Other_Parameter();
    void Get_Enum_Choose_Type(Approach_Type &output_Enum_Approach_Type,Departing_Type &output_Enum_Departing_Type,Link_Type &output_Enum_Link_Type);
    TrajectoryObject * Get_Approach_path();
    TrajectoryObject * Get_Departing_path();
    TrajectoryObject * Get_Link_path();
private:
   //parameter//
    Approach_parameter *approach_para;
    Departing_parameter *departing_para;
    Other_parameter *other_para;
    //enum choose type;
    Approach_Type Enum_Approach_Type;
    Departing_Type Enum_Departing_Type;
    Link_Type Enum_Link_Type;
protected:
    TrajectoryObject *Approach_Path;
    TrajectoryObject *Departing_Path;
    TrajectoryObject *Link_Path;
};
}
#endif // UNPROCESS_PATH_H
