#ifndef WIRCORE_TRAJECTORYOBJECT_H
#define WIRCORE_TRAJECTORYOBJECT_H

#include <App/DocumentObject.h>
#include <App/PropertyFile.h>
#include <App/PropertyGeo.h>
#include <App/GeoFeature.h>

#include "WaypointObject.h"
#include "WorkFrameObject.h"
#include "ToolObjectReferenceFrame.h"

namespace WirCore
{

class TrajectoryObject : public App::DocumentObject
{
    PROPERTY_HEADER(WirCore::TrajectoryObject);

public:
    TrajectoryObject();
    virtual ~TrajectoryObject();

    virtual const char* getViewProviderName() const {
        return "WirCoreGui::ViewProviderTrajectory";
    }

    virtual App::DocumentObjectExecReturn *execute(void){
        return App::DocumentObject::StdReturn;
    }

    virtual short mustExecute() const;
    virtual PyObject *getPyObject(void);

    //App::PropertyPlacement Base;
    //轨迹中所有TrajectoryOperationObject集合
    App::PropertyLinkList WayPointList;
    App::PropertyBool updateEvent;

    void addWaypointToTrajectory(Base::Placement i_placement, WirCore::WorkFrameObject* wobj, App::DocumentObject* tool);
    //获取指令或是目标点所被应用的轨迹
    static std::vector<WirCore::TrajectoryObject*>getInlistTrajectory(App::DocumentObject* obj);
    //获取轨迹中所有的waypoint
    std::vector<WirCore::WaypointObject*> getAllPointsInTrajectory();


protected:
    virtual void onChanged(const App::Property* prop);
    //搜索找出轨迹中所有waypoint
    void CompareTrajectory(WirCore::TrajectoryObject* _traj);
    std::vector<WirCore::WaypointObject*> m_waypoints;
};

}

#endif
