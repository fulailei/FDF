#ifndef WIRCORE_WAYPOINTOBJECT_H
#define WIRCORE_WAYPOINTOBJECT_H

#include <App/DocumentObject.h>
#include <App/PropertyStandard.h>
#include <App/PropertyGeo.h>
#include "PointObject.h"
#include "TrajectoryOperationObject.h"

namespace WirCore
{
class WaypointObject : public WirCore::TrajectoryOperationObject
{
    PROPERTY_HEADER(WirCore::WaypointObject);
public:
    WaypointObject();

    virtual ~WaypointObject();

    /// returns the type name of the ViewProvider
    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderWaypointObject";
    }

    virtual App::DocumentObjectExecReturn *execute(void) {
        return App::DocumentObject::StdReturn;
    }



    virtual PyObject *getPyObject(void);

    App::PropertyFloat          Velocity;
    App::PropertyFloat          Accelaration;
    App::PropertyEnumeration    waypointType;
    App::PropertyLink           linkPoint;
    App::PropertyLink           linkTool;
    App::PropertyBool           ConfigFront;
    App::PropertyBool           ConfigUp;
    App::PropertyBool           ConfigFlip;

    //获取所有引用，所传入的目标点的轨迹点的集合
    static std::vector<WaypointObject*> getWayPointInlist(const PointObject* obj);

    bool copyFrom(WaypointObject* i_object);

    //设置运动到该点的机器人轴配置
    bool setLinkConfig(std::vector<bool> i_vec);
    std::vector<bool> getLinkConfig() ;

    void setCurTime(double t) { time = t; }
    double getCurTime() { return time; }


private:
    static const char* WaypointEnums[];

    std::vector<bool> m_LinkConfig;
    double time = 0;
};
}
#endif // WAYPOINTOBJECT_H
