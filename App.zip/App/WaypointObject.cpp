#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "WaypointObject.h"
#include <App/DocumentObjectPy.h>

using namespace WirCore;
using namespace App;

const char* WaypointObject::WaypointEnums[]= {"MoveJ","MoveL"};


PROPERTY_SOURCE(WirCore::WaypointObject, WirCore::TrajectoryOperationObject)
WaypointObject::WaypointObject()
{
    waypointType.setEnums(WaypointEnums);
    ADD_PROPERTY_TYPE(Velocity,(200),"Base",App::Prop_None,"");
    ADD_PROPERTY_TYPE(Accelaration,(100.0),"Base",App::Prop_None,"");
    ADD_PROPERTY_TYPE(waypointType,((long)2),"Type",App::Prop_None,"Waypoint type");

    ADD_PROPERTY_TYPE(linkPoint,(0),"link",App::Prop_None,"Link point");
    ADD_PROPERTY_TYPE(linkTool,(0),"link",App::Prop_None,"Link Tool");

    ADD_PROPERTY_TYPE(ConfigFront,(true),"Config",App::Prop_Hidden,"Link Config");
    ADD_PROPERTY_TYPE(ConfigUp,(false),"Config",App::Prop_Hidden,"Link Config");
    ADD_PROPERTY_TYPE(ConfigFlip,(true),"Config",App::Prop_Hidden,"Link Config");

    linkPoint.setStatus(App::Property::ReadOnly, true);
    Label.setStatus(App::Property::ReadOnly, true);
}


std::vector<bool> WaypointObject::getLinkConfig()
{
    std::vector<bool> LinkConfig;

    LinkConfig.push_back(ConfigFront.getValue());
    LinkConfig.push_back(ConfigUp.getValue());
    LinkConfig.push_back(ConfigFlip.getValue());

    return LinkConfig;
}

WaypointObject::~WaypointObject()
{

}

PyObject *WaypointObject::getPyObject()
{
    if (PythonObject.is(Py::_None())){
        // ref counter is set to 1
        PythonObject = Py::Object(new App::DocumentObjectPy(this),true);
    }
    return Py::new_reference_to(PythonObject);
}

bool WaypointObject::copyFrom(WaypointObject* i_object)
{
    if (i_object == nullptr)
    {
        return false;
    }

    std::vector<App::Property*> from_props;
    i_object->getPropertyList(from_props);

    std::vector<App::Property*> to_props;
    this->getPropertyList(to_props);

    for (unsigned int index = 0; index < from_props.size(); index++)
    {       
        App::Property* temp = from_props[index]->Copy();
        to_props[index]->Paste(*temp);
    }
    return true;
}



bool WaypointObject::setLinkConfig(std::vector<bool> i_vec)
{
    ConfigFront.setValue(i_vec[0]);
    ConfigUp.setValue(i_vec[1]);
    ConfigFlip.setValue(i_vec[2]);
    return true;
}

std::vector<WirCore::WaypointObject*> WaypointObject::getWayPointInlist(const PointObject* obj)
{
    std::vector<WirCore::WaypointObject*> _group;
    auto list = obj->getInList();
    for (auto obj : list) {
        if(obj->isDerivedFrom(WirCore::WaypointObject::getClassTypeId()))
            _group.push_back(dynamic_cast<WirCore::WaypointObject*>(obj));
    }
    return _group;
}

