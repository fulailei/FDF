#include "PreCompiled.h"

#ifndef _PreComp_
#endif


#include "LinkTrajectoryObject.h"

using namespace WirCore;
using namespace App;



PROPERTY_SOURCE(WirCore::LinkTrajectoryObject, WirCore::TrajectoryOperationObject)

LinkTrajectoryObject::LinkTrajectoryObject()
{
    ADD_PROPERTY_TYPE(linkTrajectory,(0),"link",App::Prop_None,"Link Trajectory");
    linkTrajectory.setStatus(App::Property::ReadOnly, true);
}


LinkTrajectoryObject::~LinkTrajectoryObject()
{

}
