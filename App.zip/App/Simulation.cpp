/***************************************************************************
 *   Copyright (c) Jürgen Riegel          (juergen.riegel@web.de) 2002     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"

#ifndef _PreComp_

#endif

#include "kdl_cp/chain.hpp"
#include "kdl_cp/frames_io.hpp"

#include <stdio.h>
#include <iostream>

#include <Base/Console.h>
#include <Base/Placement.h>

#include "kdl_cp/chain.hpp"
#include "kdl_cp/path_line.hpp"
#include "kdl_cp/path_roundedcomposite.hpp"
#include "kdl_cp/trajectory_composite.hpp"
#include "kdl_cp/rotational_interpolation_sa.hpp"
#include "kdl_cp/velocityprofile_trap.hpp"
#include "kdl_cp/trajectory_segment.hpp"
#include "kdl_cp/path_roundedcomposite.hpp"
#include "kdl_cp/utilities/error.h"

#include "Simulation.h"

using namespace WirCore;
using namespace std;
using namespace KDL;



Simulation::Simulation(WirCore::RobotObject *_pcRobotObject,
                       WirCore::TrajectoryObject *_pcTrajectoryObject):
    TimeStep(0.0), m_pcRobotObject(_pcRobotObject),m_pcTrajectoryObject(_pcTrajectoryObject)
{
    pcTrajectory = nullptr;
    Base = m_pcRobotObject->Placement.getValue();

    initTrajectory();
    startAxis[0] = m_pcRobotObject->Axis1.getValue();
    startAxis[1] = m_pcRobotObject->Axis2.getValue();
    startAxis[2] = m_pcRobotObject->Axis3.getValue();
    startAxis[3] = m_pcRobotObject->Axis4.getValue();
    startAxis[4] = m_pcRobotObject->Axis5.getValue();
    startAxis[5] = m_pcRobotObject->Axis6.getValue();

    setToTime(0,0);


}

Simulation::~Simulation()
{
    delete pcTrajectory;
    pcTrajectory = nullptr;
}


void Simulation::initTrajectory()
{
    m_vecWaypoints.clear();
    m_vecWaypoints = m_pcTrajectoryObject->getAllPointsInTrajectory();

  //  std::vector<App::DocumentObject*> waypoints = m_pcTrajectoryObject->WayPointList.getValues();

    if(m_vecWaypoints.size() < 2)
        return;

    if(pcTrajectory != nullptr)
        delete (pcTrajectory);
    pcTrajectory = new KDL::Trajectory_Composite();

    std::unique_ptr<KDL::Trajectory_Segment> trajSegment;
    std::unique_ptr<KDL::VelocityProfile> velProfile;
    std::unique_ptr<KDL::Path_RoundedComposite> pathRoundComp;
    KDL::Frame last;

    try {
        bool first = true;


        double timeAdd = 0;
        for(std::vector<WirCore::WaypointObject*>::const_iterator it = m_vecWaypoints.begin(); it!=m_vecWaypoints.end();++it)
        {
            if ((*it)->linkPoint.getValue() == nullptr || (*it)->linkTool.getValue() == nullptr)
            {
                continue;
            }

            WirCore::PointObject* point = dynamic_cast<WirCore::PointObject*>
                    ((dynamic_cast<WirCore::WaypointObject*>(*it))->linkPoint.getValue());
            Base::Placement EndPos = point->globalPlacement();
            // std::string strPointWorkMod = point->
            WirCore::WorkFrameObject* workframe( nullptr );
            if (point) {
                auto group( App::GeoFeatureGroupExtension::getGroupOfObject(point) );
                if (group) {
                    workframe = group->getExtensionByType< WirCore::WorkFrameObject>();
                }
            }

            WirCore::ToolObjectReferenceFrame* ToolObject = dynamic_cast< WirCore::ToolObjectReferenceFrame*>
                    ((dynamic_cast<WirCore::WaypointObject*>(*it))->linkTool.getValue());

            Tool = ToolObject->Placement.getValue();

            std::string strPointType = dynamic_cast<WirCore::WaypointObject*>(*it)->waypointType.getValueAsString();

            bool bWobjRobHold = workframe->robotHold.getValue();
            if (!bWobjRobHold)
            {
                EndPos = EndPos * ToolObject->toolPlacement.getValue().inverse();
            }
            else
            {
                EndPos = Tool * point->Placement.getValue().inverse();
            }

            float Velocity = dynamic_cast<WirCore::WaypointObject*>(*it)->Velocity.getValue();
            float Accelaration = dynamic_cast<WirCore::WaypointObject*>(*it)->Accelaration.getValue();

            if(first) {
                last = toFrame(EndPos);
                first = false;
            }
            else {
                if (strPointType.compare("MoveJ") == 0 || strPointType.compare("MoveL") == 0)
                {
                    KDL::Frame next = toFrame(EndPos);
                    bool Cont = false && !(it == --m_vecWaypoints.end());
                    if(Cont && !pathRoundComp) {
                        pathRoundComp.reset(new KDL::Path_RoundedComposite(3, 3,
                                                                           new KDL::RotationalInterpolation_SingleAxis()));
                        velProfile.reset(new KDL::VelocityProfile_Trap(Velocity, Accelaration));
                        pathRoundComp->Add(last);
                        pathRoundComp->Add(next);
                    }
                    else if(Cont && pathRoundComp) {
                        pathRoundComp->Add(next);
                    }
                    else if(Cont == false && pathRoundComp) {
                        pathRoundComp->Add(next);
                        pathRoundComp->Finish();
                        velProfile->SetProfile(0, pathRoundComp->PathLength());
                        trajSegment.reset(new KDL::Trajectory_Segment(pathRoundComp.release(), velProfile.release()));
                    }
                    else if(Cont == false && !pathRoundComp) {
                        KDL::Path* path;
                        path = new KDL::Path_Line(last, next,
                                                  new KDL::RotationalInterpolation_SingleAxis(),
                                                  1.0,
                                                  true);
                        velProfile.reset(new KDL::VelocityProfile_Trap(Velocity, Accelaration));
                        velProfile->SetProfile(0, path->PathLength());
                        trajSegment.reset(new KDL::Trajectory_Segment(path, velProfile.release()));
                    }
                    last = next;
                }
                if(!pathRoundComp && trajSegment)
                {
                    auto p = dynamic_cast<WaypointObject*>(*it);
                    auto dur = trajSegment->Duration();
                    timeAdd += dur;
                    p->setCurTime(timeAdd);
                    pcTrajectory->Add(trajSegment.release()); 
                }
            }

        }
    } catch (KDL::Error &e) {
        throw Base::RuntimeError(e.Description());
    }

    m_endtime = getDuration();

}

double Simulation::getLength() const
{
    return pcTrajectory->GetPath()->PathLength();
}

double Simulation::getDuration() const
{
    return pcTrajectory->Duration();
}


double Simulation::getVelocity(double time) const {
    KDL::Vector vec = pcTrajectory->Vel(time).vel;
    Base::Vector3d vec2(vec[0], vec[1], vec[2]);
    return vec2.Length();
}


void Simulation::step(double tick)
{
    TimeStep += tick;
}


void Simulation::setToTime(float t, int index)
{
    TimeStep = static_cast<double>(t);

    if(TimeStep <= m_endtime) {
        Base::Placement neededPos = toPlacement(pcTrajectory->Pos(TimeStep));
        m_pcRobotObject->setTcpWithLinkConfig(neededPos, m_vecWaypoints[index]->getLinkConfig());
    }

    Axis[0] = m_pcRobotObject->Axis1.getValue();
    Axis[1] = m_pcRobotObject->Axis2.getValue();
    Axis[2] = m_pcRobotObject->Axis3.getValue();
    Axis[3] = m_pcRobotObject->Axis4.getValue();
    Axis[4] = m_pcRobotObject->Axis5.getValue();
    Axis[5] = m_pcRobotObject->Axis6.getValue();
}

void Simulation::reset(){

    m_pcRobotObject->Axis1.setValue(startAxis[0]);
    m_pcRobotObject->Axis2.setValue(startAxis[1]);
    m_pcRobotObject->Axis3.setValue(startAxis[2]);
    m_pcRobotObject->Axis4.setValue(startAxis[3]);
    m_pcRobotObject->Axis5.setValue(startAxis[4]);
    m_pcRobotObject->Axis6.setValue(startAxis[5]);

    if(TimeStep <= m_endtime) {
        Base::Placement neededPos = toPlacement(pcTrajectory->Pos(TimeStep));
        m_pcRobotObject->Tcp.setValue(neededPos);
    }

    Axis[0] = m_pcRobotObject->Axis1.getValue();
    Axis[1] = m_pcRobotObject->Axis2.getValue();
    Axis[2] = m_pcRobotObject->Axis3.getValue();
    Axis[3] = m_pcRobotObject->Axis4.getValue();
    Axis[4] = m_pcRobotObject->Axis5.getValue();
    Axis[5] = m_pcRobotObject->Axis6.getValue();
}
