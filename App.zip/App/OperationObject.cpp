#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "OperationObject.h"
#include <App/Document.h>
#include <App/DocumentObjectPy.h>


using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::OperationObject, App::DocumentObject)

OperationObject::OperationObject()
{
    ADD_PROPERTY_TYPE(WayPointList,(0),"",App::Prop_None,"List of Links");
    ADD_PROPERTY_TYPE(updateEvent,(0), "", App::Prop_Hidden,"List of Links");
    WayPointList.setStatus(App::Property::Hidden, true);
}

OperationObject::~OperationObject()
{
}

short OperationObject::mustExecute() const
{
    return 0;
}

void OperationObject::onChanged(const App::Property *prop)
{
    App::DocumentObject::onChanged(prop);
}

std::vector<WirCore::WaypointObject*> OperationObject::getAllPointsInGeometry()
{
    return waypoints_;
}
