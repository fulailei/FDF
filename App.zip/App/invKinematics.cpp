#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#ifndef M_PI
    #define M_PI    3.14159265358979323846 /* pi */
#endif


#include "invKinematics.h"

using namespace WirCore;
using namespace KDL;

invKinematics::invKinematics(std::vector<AxisDefinition> _axisDH,const JntArray& _q_min, const JntArray& _q_max):
    axisDH(_axisDH), q_min(_q_min), q_max(_q_max)
{

}

invKinematics::~invKinematics()
{
}

int invKinematics::CartToJnt(const JntArray& q_in, const Frame& p_in, JntArray& q_out, std::vector<bool> LinkConfig)
{
    if (LinkConfig.size() < 3)
    {
        return -1;
    }

    q_out = q_in;

    // the joint values
    double theta1 = 0, theta11 = 0, theta12 = 0;
    double theta2 = 0, theta21 = 0, theta22 = 0;
    double theta3 = 0;
    double theta4 = 0, theta41 = 0, theta42 = 0;
    double theta5 = 0;
    double theta6 = 0;

    Frame baseToAxis1 = Frame::DH(0  ,0 ,axisDH[0].d ,0);
    Frame Axis6ToEndPos = Frame::DH(0  ,0 ,axisDH[5].d ,0);

    Frame T = baseToAxis1.Inverse() *  p_in * Axis6ToEndPos.Inverse();

    Frame V0, V1, V2, V3, V4, V5;

    // for theta1
    double V014, V024, r, temp;
    V0 = T;

    V014 = V0(0, 3);
    V024 = V0(1, 3);

    r = sqrt(V014 * V014 + V024 * V024);

    temp = axisDH[2].d / r;

    if (fabs(temp) > 1)
    {
        return 0;
    }
    else
    {
        // determine for atan2
        theta11 = RoATan(V024, V014) + asin(axisDH[2].d / r);
        theta12 = RoATan(V024, V014) + M_PI - asin(axisDH[2].d / r);
    }

    theta1 = theta11;
    if (!LinkConfig[0])
    {
        theta1 = theta12;
    }

    // for theta2
    V1 = Frame::DH(axisDH[0].a  ,axisDH[0].alpha * (M_PI/180) ,0 , theta1);

    V1 = V1.Inverse() * V0;

    double V114, V124, phi;

    V114 = V1(0, 3);
    V124 = V1(1, 3);
    r = sqrt(V114 * V114 + V124 * V124);

    // determine for atan2
    phi = RoATan(V124, V114);

    temp = ((((axisDH[1].a * axisDH[1].a) - (axisDH[3].d * axisDH[3].d)) - (axisDH[2].a * axisDH[2].a)) + (r * r)) / (2 * axisDH[1].a * r);

    if (fabs(temp) > 1)
    {
        return 0;
    }
    else
    {
        theta21 = phi + acos(temp);
        theta22 = phi - acos(temp);
    }

    theta2 = theta21;
    if (!LinkConfig[1])
    {
        theta2 = theta22;
    }


    // for theta3
    Frame A2 = Frame::DH(axisDH[1].a  ,axisDH[1].alpha * (M_PI/180) ,axisDH[1].d , theta2);
    V2 = A2;

    V2 = V2.Inverse() * V1;

    double V214, V224;

    V214 = V2(0, 3);
    V224 = V2(1, 3);

    // determine for atan2
    phi = RoATan(axisDH[2].a, axisDH[3].d);

    // determine for atan2
    theta3 = phi - RoATan(V214, V224);

//    if (theta3 > 0)
//    {
//        theta3 = theta3 - 2 * M_PI;
//    }

    // for theta4
    V3 = A2 * Frame::DH(axisDH[2].a  ,axisDH[2].alpha * (M_PI/180) ,axisDH[2].d , theta3);

    V3 = V3.Inverse() * V1;

    double V313, V323;
    V313 = V3(0, 2);
    V323 = V3(1, 2);

    // determine for atan2
    theta41 = RoATan(-V323, -V313);
    theta42 = RoATan(V323, V313);
    theta4 = theta41;
    if (!LinkConfig[2])
    {
        theta4 = theta42;
    }


    // for theta5
    V4 = Frame::DH(axisDH[3].a  ,axisDH[3].alpha * (M_PI/180) ,axisDH[3].d , theta4);
    V4 = V4.Inverse() * V3;

    double V413, V423;
    V413 = V4(0, 2);
    V423 = V4(1, 2);
    // determine for atan2
    theta5 = RoATan(-V413, V423);

    // for theta6
    V5 = Frame::DH(axisDH[4].a  ,axisDH[4].alpha * (M_PI/180) ,axisDH[4].d , theta5);

    V5 = V5.Inverse() * V4;

    double V512, V522;

    V512 = V5(0, 1);
    V522 = V5(1, 1);

    theta6 = RoATan(-V512, V522);

    q_out(0) = theta1;
    q_out(1) = theta2 + M_PI / 2;
    q_out(2) = theta3;
    q_out(3) = theta4;
    q_out(4) = theta5;
    q_out(5) = theta6 - axisDH[5].theta* (M_PI/180);

    for(unsigned int j=0; j<q_min.rows(); j++) {
      if(q_out(j) < q_min(j)){
        q_out(j) = q_out(j) + M_PI *2;
      }
    }

        for(unsigned int j=0; j<q_max.rows(); j++) {
        if(q_out(j) > q_max(j)) {
          q_out(j) = q_out(j) - M_PI *2;
        }
    }
    return 1;
}
