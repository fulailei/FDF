#ifndef WIRCORE_ROBOTTOOLOBJECT_H
#define WIRCORE_ROBOTTOOLOBJECT_H


#include <App/GeoFeature.h>
#include <App/Part.h>
#include <App/PropertyFile.h>
#include <App/PropertyGeo.h>

#include <App/OriginGroupExtension.h>

#include "RobotObject.h"
//该类原设计为机器人工具，目前暂时没有使用
namespace WirCore
{

class RobotToolObject : public App::GeoFeature,
                        public App::OriginGroupExtension
{
     PROPERTY_HEADER(WirCore::RobotToolObject);
public:
    RobotToolObject();

    virtual ~RobotToolObject();

    /// returns the type name of the ViewProvider
    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderRobotToolObject";
    }

    virtual App::DocumentObjectExecReturn *execute(void) {
        return App::DocumentObject::StdReturn;
    }
    virtual short mustExecute(void) const;
    virtual PyObject *getPyObject(void);

    App::PropertyPlacement ToolTcp;
    App::PropertyLink      ToolShape;
protected:
    /// get called by the container when a property has changed



};
}
#endif // ROBOTTOOLOBJECT_H
