#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "WorkFrameObject.h"
#include <App/DocumentObjectPy.h>


using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::WorkFrameObject, App::GeoFeature)

WorkFrameObject::WorkFrameObject()
{
    ADD_PROPERTY_TYPE(WObjReferenceFrame,(0),"",App::Prop_None,"Link to the Frame");
    WObjReferenceFrame.setStatus(App::Property::Hidden, true);
    ADD_PROPERTY_TYPE(robotHold, (1), "operation mode",Prop_None,"");
    ADD_PROPERTY_TYPE(wobjPlacement, (Base::Placement()), "attribute",Prop_None,"");

    GroupExtension::initExtension(this);
}

WorkFrameObject::~WorkFrameObject()
{
}

short WorkFrameObject::mustExecute(void) const
{
    return 0;
}


PyObject *WorkFrameObject::getPyObject()
{
    if (PythonObject.is(Py::_None())){
        // ref counter is set to 1
        PythonObject = Py::Object(new App::DocumentObjectPy(this),true);
    }
    return Py::new_reference_to(PythonObject);
}


WirCore::WorkFrameObject* WorkFrameObject::getWorkFrameInlist(const PointObject* obj)
{
    WirCore::WorkFrameObject* _wobj;
    auto list = obj->getInList();
    for (auto obj : list) {
        if(obj->isDerivedFrom(WirCore::WorkFrameObject::getClassTypeId()))
            _wobj = dynamic_cast<WirCore::WorkFrameObject*>(obj);
    }
    return _wobj;
}



