#pragma once

#include <Mod/Part/App/DatumFeature.h>

namespace WirCore
{

class CoordinateSystem : public Part::Datum
{
    PROPERTY_HEADER(PartDesign::CoordinateSystem);

public:
    CoordinateSystem();
    virtual ~CoordinateSystem();

    const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderDatumCoordinateSystem";
    }

    Base::Vector3d getXAxis();
    Base::Vector3d getYAxis();
    Base::Vector3d getZAxis();
};

} //namespace CoordinateSystem
