#ifndef WIRCORE_PROPERTYTRAJECTORY_H
#define WIRCORE_PROPERTYTRAJECTORY_H

#include <App/Property.h>
#include <Base/BoundBox.h>
#include "kdl_cp/trajectory.hpp"

namespace KDL
{
    class Trajectory_Composite;
}


namespace WirCore {

class PropertyTrajectory : public App::Property
{
    TYPESYSTEM_HEADER();

public:
    PropertyTrajectory();
    ~PropertyTrajectory();

    void setValue(KDL::Trajectory_Composite *pcTrajectory);

    KDL::Trajectory_Composite* getValue() const;

    Base::BoundBox3d getBoundingBox() const;

    void Save(Base::Writer &writer) const;
    void Restore(Base::XMLReader &reader);

    App::Property *Copy(void) const;
    void Paste(const App::Property &from);
    unsigned int getMemSize(void) const;

private:
    KDL::Trajectory_Composite * _Trajectory;

};



}

#endif
