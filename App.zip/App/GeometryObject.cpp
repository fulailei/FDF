#include "PreCompiled.h"
#ifndef _PreComp_
# include <BRepAdaptor_Curve.hxx>
# include <BRepAdaptor_Surface.hxx>
# include <GeomAbs_CurveType.hxx>
# include <GeomAbs_SurfaceType.hxx>
# include <Geom_BezierCurve.hxx>
# include <Geom_BSplineCurve.hxx>
# include <Geom_BezierSurface.hxx>
# include <Geom_BSplineSurface.hxx>
# include <GeomAPI_PointsToBSplineSurface.hxx>
# include <gp_Pnt.hxx>
# include <TopoDS.hxx>
# include <TopoDS_Edge.hxx>
# include <TopoDS_Wire.hxx>
# include <TopoDS_Face.hxx>
# include <TopoDS_Shape.hxx>
# include <TopoDS_Shell.hxx>
# include <TopExp_Explorer.hxx>
# include <GC_MakeSegment.hxx>
# include <BRepBuilderAPI_MakeEdge.hxx>
# include <BRepBuilderAPI_MakeWire.hxx>
# include <Python.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/nodes/SoSwitch.h>
# include <Inventor/SoDB.h>
# include <Inventor/SoInput.h>
# include <Inventor/SbVec3f.h>
# include <Inventor/nodes/SoSeparator.h>
# include <Inventor/nodes/SoTransform.h>
# include <Inventor/nodes/SoSphere.h>
# include <Inventor/nodes/SoRotation.h>
# include <Inventor/actions/SoSearchAction.h>
# include <Inventor/draggers/SoJackDragger.h>
# include <Inventor/VRMLnodes/SoVRMLTransform.h>
# include <Inventor/nodes/SoBaseColor.h>
# include <Inventor/nodes/SoCoordinate3.h>
# include <Inventor/nodes/SoDrawStyle.h>
# include <Inventor/nodes/SoFaceSet.h>
# include <Inventor/nodes/SoLineSet.h>
# include <Inventor/nodes/SoMarkerSet.h>
# include <Inventor/nodes/SoShapeHints.h>
#endif


#include "GeometryObject.h"
#include <App/PropertyStandard.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/Part/App/Geometry.h>
#include <Gui/ActionFunction.h>

using namespace WirCore;


PROPERTY_SOURCE(WirCore::GeometryObject, Part::Feature)

GeometryObject::GeometryObject()
{
    //------------------------------------BSpline----------------------------------
//        TColgp_Array1OfPnt poles(1, 7);
//        double radius = 5;
//        poles(1) = gp_Pnt(radius, 0, 0);
//        poles(2) = gp_Pnt(radius, 2*radius, 0);
//        poles(3) = gp_Pnt(-radius, 2*radius, 0);
//        poles(4) = gp_Pnt(-radius, 0, 0);
//        poles(5) = gp_Pnt(-radius, -2*radius, 0);
//        poles(6) = gp_Pnt(radius, -2*radius, 0);
//        poles(7) = gp_Pnt(radius, 0, 0);

//        TColStd_Array1OfReal weights(1,7);
//        for (int i=1; i<=7; i++) {
//            //poles(i).Rotate(axis, angle);
//            weights(i) = 1;
//        }
//        weights(1) = 3;
//        weights(4) = 3;
//        weights(7) = 3;

//        TColStd_Array1OfInteger mults(1, 3);
//        mults(1) = 4;
//        mults(2) = 3;
//        mults(3) = 4;

//        TColStd_Array1OfReal knots(1, 3);
//        knots(1) = 0;
//        knots(2) = M_PI;
//        knots(3) = 2*M_PI;

//        Handle(Geom_BSplineCurve) spline = new Geom_BSplineCurve(poles, weights, knots, mults, 3,
//            Standard_False, Standard_True);
//        //spline->Segment(0, last-first);






        //auto spline1 = new Part::GeomBSplineCurve(spline);

//        const std::vector<gp_Pnt> p{gp_Pnt(0,0,0), gp_Pnt(5,5,0), gp_Pnt(10,0,0), gp_Pnt(15,5,0), gp_Pnt(20,0,0)};
//        const std::vector<gp_Vec> t{gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0), gp_Vec(1,0,0)};
//        auto spline1 = new Part::GeomBSplineCurve;
//        spline1->interpolate(p,t);
//        //spline1->toShape();
//        this->Shape.setValue(spline1->toShape());
}


