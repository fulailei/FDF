#ifndef WIRCORE_WORKFRAMEOBJECT_H
#define WIRCORE_WORKFRAMEOBJECT_H

#include <App/OriginGroupExtension.h>
#include <App/DocumentObject.h>
#include <App/GeoFeature.h>
#include "PointObject.h"

namespace WirCore
{

class WorkFrameObject : public App::GeoFeature,
                        public App::OriginGroupExtension
{
    PROPERTY_HEADER(WirCore::WorkFrameObject);
public:
    WorkFrameObject();
    virtual ~WorkFrameObject();

    /// returns the type name of the ViewProvider
    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderWorkFrameObject";
    }

    virtual App::DocumentObjectExecReturn *execute(void) {
        return App::DocumentObject::StdReturn;
    }
    virtual short mustExecute(void) const;
    virtual PyObject *getPyObject(void);

    App::PropertyLink       WObjReferenceFrame;
    //是否被机器人抓住，（机器人的在使用该工件坐标系时的工作模式，是否为抓取工件加工工具）
    App::PropertyBool       robotHold;
    App::PropertyPlacement  wobjPlacement;

    //获取所传入的目标点所在的工件坐标系
    static WirCore::WorkFrameObject* getWorkFrameInlist(const PointObject* obj);

};

}

#endif // WORKFRAMEOBJECT_H
