#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include "ReferenceFrame.h"
#include <App/DocumentObjectPy.h>
#include <Base/Placement.h>

#include <Base/Writer.h>
#include <Base/Reader.h>

using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::ReferenceFrame, App::GeoFeature)

ReferenceFrame::ReferenceFrame()
    :block(false)
{
    //ADD_PROPERTY_TYPE(Frame, (Base::Placement()), "Reference Frame", Prop_None, "Reference Frame with respect to");
    ADD_PROPERTY_TYPE(Objects, (0), "",Prop_None,"Link to the Objects used in this Frame");
    Objects.setStatus(App::Property::Hidden, true);
}

ReferenceFrame::~ReferenceFrame()
{
}

short ReferenceFrame::mustExecute(void) const
{
    return 0;
}

PyObject *ReferenceFrame::getPyObject()
{
    if(PythonObject.is(Py::_None())) {
        PythonObject = Py::Object(new DocumentObjectPy(this), true);
    }
    return Py::new_reference_to(PythonObject);
}

void ReferenceFrame::onChanged(const App::Property *prop)
{
    App::GeoFeature::onChanged(prop);
}

void ReferenceFrame::Save(Base::Writer &writer) const
{
    App::GeoFeature::Save(writer);
}

void ReferenceFrame::Restore(Base::XMLReader &reader)
{
    block = true;
    App::GeoFeature::Restore(reader);
    block = false;
}

/*
bool ReferenceFrame::addObject(App::DocumentObject* object) {
    objects.push_back(object);
    return true;
}

const std::vector<App::DocumentObject*> &ReferenceFrame::getObjects() const
{
    return objects;
}*/








