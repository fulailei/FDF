#pragma once

// FCL Headers
#include <fcl/config.h>
#if FCL_MAJOR_VERSION==0 && FCL_MINOR_VERSION<6
#include <fcl/collision.h>
#include <fcl/distance.h>
#include <fcl/collision_node.h>
#include <fcl/traversal/traversal_node_setup.h>
#include <fcl/continuous_collision.h>
#else
#include <fcl/narrowphase/collision.h>
#include <fcl/narrowphase/distance.h>
#include <fcl/narrowphase/continuous_collision.h>
#include <fcl/broadphase/broadphase_collision_manager.h>
#include <fcl/broadphase/broadphase_dynamic_AABB_tree.h>
#include <fcl/broadphase/broadphase_collision_manager.h>
#include <fcl/narrowphase/collision.h>
#include <fcl/narrowphase/distance.h>
#include "fcl/narrowphase/collision.h"
#endif

// STL headers
#include <memory>
#include <utility>
#include <vector>
#include <limits>
#include <cmath>
#include <vector>
#include <QString>

#define OMPL_CLASS_FORWARD(C)                                                                                          \
    class C;                                                                                                           \
    typedef std::shared_ptr<C> C##Ptr


namespace fclwrapper
{

OMPL_CLASS_FORWARD(FCLMethodWrapper);

#if FCL_MAJOR_VERSION==0 && FCL_MINOR_VERSION<6
    using Vector3 = fcl::Vec3f;
    using Quaternion = fcl::Quaternion3f;
    using Transform = fcl::Transform3f;
    using BVType = fcl::OBBRSS;
    using Model = fcl::BVHModel<BVType>;
    using MeshDistanceTraversalNodeOBBRSS = fcl::MeshDistanceTraversalNodeOBBRSS;
    using CollisionRequest = fcl::CollisionRequest;
    using CollisionResult = fcl::CollisionResult;
    using ContinuousCollisionRequest = fcl::ContinuousCollisionRequest;
    using ContinuousCollisionResult = fcl::ContinuousCollisionResult;
    using DistanceRequest = fcl::DistanceRequest;
    using DistanceResult = fcl::DistanceResult;
#else
    using Vector3 = fcl::Vector3d;
    using Quaternion = fcl::Quaterniond;
    using Transform = fcl::Transform3d;
    using BVType = fcl::OBBRSS<double>;
    using Model = fcl::BVHModel<BVType>;
    using MeshDistanceTraversalNodeOBBRSS = fcl::detail::MeshDistanceTraversalNodeOBBRSS<double>;
    using CollisionRequest = fcl::CollisionRequest<double>;
    using CollisionResult = fcl::CollisionResult<double>;
    using ContinuousCollisionRequest = fcl::ContinuousCollisionRequest<double>;
    using ContinuousCollisionResult = fcl::ContinuousCollisionResult<double>;
    using DistanceRequest = fcl::DistanceRequest<double>;
    using DistanceResult = fcl::DistanceResult<double>;
#endif

typedef std::shared_ptr<fcl::CollisionObjectd> FCLCollisionObjectPtr;
typedef std::shared_ptr<const fcl::CollisionObjectd> FCLCollisionObjectConstPtr;

/** \brief A general high-level object which consists of multiple \e FCLCollisionObjects. It is the top level data
 *  structure which is used in the collision checking process. */
struct FCLObject
{
  void registerTo(fcl::BroadPhaseCollisionManagerd* manager);
  void unregisterFrom(fcl::BroadPhaseCollisionManagerd* manager);
  void clear();

  std::vector<FCLCollisionObjectPtr> collision_objects_;

  /** \brief Geometry data corresponding to \e collision_objects_. */
  //std::vector<FCLGeometryConstPtr> collision_geometry_;
};

/** \brief Bundles an \e FCLObject and a broadphase FCL collision manager. */
struct FCLManager
{
  FCLObject object_;
  std::shared_ptr<fcl::BroadPhaseCollisionManagerd> manager_;
};


typedef struct SceneObject
{
    std::string name;
    std::vector<fcl::Vector3d> vertices;
    std::vector<fcl::Triangle> triangles;
} FclSceneObject;
typedef  std::vector<FclSceneObject> FclSceneObjects;

struct CollisionData
{
  CollisionData() : req_(nullptr), /*active_components_only_(nullptr),*/ res_(nullptr), /*acm_(nullptr),*/ done_(false)
  {
  }

  CollisionData(const CollisionRequest* req, CollisionResult* res/*, const AllowedCollisionMatrix* acm*/)
    : req_(req), /*active_components_only_(nullptr),*/ res_(res)/*, acm_(acm)*/, done_(false)
  {
  }

  ~CollisionData()
  {
  }

  /** \brief Compute \e active_components_only_ based on the joint group specified in \e req_ */
  //void enableGroup(const moveit::core::RobotModelConstPtr& robot_model);

  /** \brief The collision request passed by the user */
  const CollisionRequest* req_;

  /** \brief  If the collision request includes a group name, this set contains the pointers to the link models that
   *  are considered for collision.
   *
   *  If the pointer is NULL, all collisions are considered. */
  //const std::set<const moveit::core::LinkModel*>* active_components_only_;

  /** \brief The user-specified response location. */
  CollisionResult* res_;

  /** \brief The user-specified collision matrix (may be NULL). */
  //const AllowedCollisionMatrix* acm_;

  /** \brief Flag indicating whether collision checking is complete. */
  bool done_;
};




/// \brief Wrapper for FCL discrete and continuous collision checking and distance queries
class FCLMethodWrapper
{

public:
    FCLMethodWrapper(bool selfCollision, FclSceneObjects env, FclSceneObjects robot)
        : selfCollision_(selfCollision)
    {
        auto m = new fcl::DynamicAABBTreeCollisionManagerd();
        managerEnv_.reset(m);

        auto m1 = new fcl::DynamicAABBTreeCollisionManagerd();
        managerRob_.reset(m1);
        configure(env, robot);
    }

    static bool collisionCallback1(fcl::CollisionObjectd* o1, fcl::CollisionObjectd* o2, void* data)
    {
      CollisionData* cdata = reinterpret_cast<CollisionData*>(data);
      if (cdata->done_)
        return true;
      return false;
    //  const CollisionGeometryData* cd1 = static_cast<const CollisionGeometryData*>(o1->collisionGeometry()->getUserData());
    //  const CollisionGeometryData* cd2 = static_cast<const CollisionGeometryData*>(o2->collisionGeometry()->getUserData());

    //   do not collision check geoms part of the same object / link / attached body
    //  if (cd1->sameObject(*cd2))
    //    return false;
    }

    void registerTo(fcl::BroadPhaseCollisionManagerd* manager)
    {
      std::vector<fcl::CollisionObjectd*> collision_objects(robotParts_.size() + envs_.size());
      for (std::size_t i = 0; i < robotParts_.size(); ++i)
        collision_objects[i] = new fcl::CollisionObjectd(robotParts_[i]);
      if (!collision_objects.empty())
        manager->registerObjects(collision_objects);
    }

    void checkSelfCollisionHelper(const CollisionRequest& req, CollisionResult& res) const
    {
      //FCLManager manager;
      //allocSelfCollisionBroadPhase(state, manager);
//      CollisionData cd(&req, &res/*, acm*/);
//      //cd.enableGroup(getRobotModel());
//      managerEnv_->collide(&cd, &collisionCallback1);
//      if (req.distance)
//      {
//        DistanceRequest dreq;
//        DistanceResult dres;

//        dreq.group_name = req.group_name;
//        dreq.acm = acm;
//        dreq.enableGroup(getRobotModel());
//        distanceSelf(dreq, dres, state);
//        res.distance = dres.minimum_distance.distance;
//      }
    }

    virtual ~FCLMethodWrapper()
    {
    }

    /// \brief Checks whether the given robot state collides with the
    /// environment or itself.
    ///
     //bool allowedCollision(std::string name1, std::string name2)
     //std::function<bool (std::string name1, std::string name2)> func;

    virtual bool isValid(/*std::function<bool(std::string name1, std::string name2)> func*//*const base::State *state*/)
    {
        CollisionRequest req;
        CollisionResult res;
        CollisionData cd(&req, &res/*, acm*/);
        //cd.enableGroup(getRobotModel());
        managerEnv_->setup();
        managerEnv_->collide(&cd, &collisionCallback1);
        auto a = cd.req_;

//#if FCL_MAJOR_VERSION==0 && FCL_MINOR_VERSION<6
//        static Transform identity;
//#else
//        static Transform identity(Transform::Identity());
//#endif
//        CollisionRequest collisionRequest;
//        CollisionResult collisionResult;
//        Transform transform;

//        if (environment_.num_tris > 0)
//        {
//            // Performing collision checking with environment.
//            for (std::size_t i = 0; i < robotParts_.size(); ++i)
//            {
//                //poseFromStateCallback_(transform, extractState_(state, i));
//                auto envName = ((QString*)environment_.getUserData())->toStdString();
//                auto robName = ((QString*)robotParts_[i]->getUserData())->toStdString();
////                if (/*func(envName, robName) && */fcl::collide(robotParts_[i], transform, &environment_,
////                                 identity, collisionRequest, collisionResult) > 0)
//                    return false;
//            }
//        }

//        // Checking for self collision
//        if (selfCollision_)
//        {
//            Transform trans_i, trans_j;
//            for (std::size_t i = 0 ; i < robotParts_.size(); ++i)
//            {
//                // poseFromStateCallback_(trans_i, extractState_(state, i));

//                for (std::size_t j  = i + 1 ; j < robotParts_.size(); ++j)
//                {
//                    // poseFromStateCallback_(trans_j, extractState_(state, j));
////                    if (fcl::collide(robotParts_[i], trans_i, robotParts_[j], trans_j,
////                                     collisionRequest, collisionResult) > 0)
//                        return false;
//                }
//            }
//        }

//        return true;
    }

    /// \brief Check the continuous motion between s1 and s2.  If there is a collision
    /// collisionTime will contain the parameterized time to collision in the range [0,1).
//    virtual bool isValid(/*const base::State *s1, const base::State *s2,*/ double &collisionTime) const
//    {
//        Transform transi_beg, transi_end, trans;
//        ContinuousCollisionRequest collisionRequest(10, 0.0001, fcl::CCDM_SCREW,
//                                                    fcl::GST_LIBCCD, fcl::CCDC_CONSERVATIVE_ADVANCEMENT);
//        ContinuousCollisionResult collisionResult;

////        // Checking for collision with environment
////        if (environment_.num_tris > 0)
////        {
////            for (size_t i = 0; i < robotParts_.size(); ++i)
////            {
////                // Getting the translation and rotation from s1 and s2
////                //poseFromStateCallback_(transi_beg, extractState_(s1, i));
////                //poseFromStateCallback_(transi_end, extractState_(s2, i));

////                // Checking for collision
////                fcl::continuousCollide(robotParts_[i], transi_beg, transi_end,
////                                       &environment_, trans, trans,
////                                       collisionRequest, collisionResult);
////                if (collisionResult.is_collide)
////                {
////                    collisionTime = collisionResult.time_of_contact;
////                    return false;
////                }
////            }
////        }

//        // Checking for collision with environment
//        if (environment_.num_tris > 0)
//        {
//            for (size_t i = 0; i < robotParts_.size(); ++i)
//            {
//                // Getting the translation and rotation from s1 and s2
//                //poseFromStateCallback_(transi_beg, extractState_(s1, i));
//                //poseFromStateCallback_(transi_end, extractState_(s2, i));

//                // Checking for collision
//                fcl::continuousCollide(robotParts_[i], transi_beg, transi_end,
//                                       &environment_, trans, trans,
//                                       collisionRequest, collisionResult);
//                if (collisionResult.is_collide)
//                {
//                    collisionTime = collisionResult.time_of_contact;
//                    return false;
//                }
//            }
//        }

//        // Checking for self collision
//        if (selfCollision_)
//        {
//            Transform transj_beg, transj_end;
//            for (std::size_t i = 0 ; i < robotParts_.size(); ++i)
//            {
//                //poseFromStateCallback_(transi_beg, extractState_(s1, i));
//                //poseFromStateCallback_(transi_end, extractState_(s2, i));

//                for (std::size_t j = i+1; j < robotParts_.size(); ++j)
//                {
//                    //poseFromStateCallback_(transj_beg, extractState_(s1, j));
//                    //poseFromStateCallback_(transj_end, extractState_(s2, j));

//                    // Checking for collision
//                    fcl::continuousCollide(robotParts_[i], transi_beg, transi_end,
//                                           robotParts_[j], transj_beg, transj_end,
//                                           collisionRequest, collisionResult);
//                    if (collisionResult.is_collide)
//                    {
//                        collisionTime = collisionResult.time_of_contact;
//                        return false;
//                    }
//                }
//            }
//        }
//        return true;
//    }

    /// \brief Returns the minimum distance from the given robot state and the environment
    virtual double clearance(/*const base::State *state*/) const
    {
#if FCL_MAJOR_VERSION==0 && FCL_MINOR_VERSION<6
        static Transform identity;
#else
        static Transform identity(Transform::Identity());
#endif
        double minDist = std::numeric_limits<double>::infinity ();
        if (environment_.num_tris > 0)
        {
            DistanceRequest distanceRequest(true);
            DistanceResult distanceResult;
            Transform trans;
            for (size_t i = 0; i < robotParts_.size (); ++i)
            {
                //poseFromStateCallback_(trans, extractState_(state, i));
                //fcl::distance(robotParts_[i], trans, &environment_, identity, distanceRequest, distanceResult);
                if (distanceResult.min_distance < minDist)
                    minDist = distanceResult.min_distance;
            }
        }

        return minDist;
    }

public:

    /// \brief Configures the geometry of the robot and the environment
    /// to setup validity checking.
    void configure(FclSceneObjects env, FclSceneObjects robot)
    {
        //environment_.beginModel ();
        //QString* name = new QString(QString::fromStdString(env.at(0).name));
        //environment_.setUserData(name);
        //environment_.beginModel ();
        //environment_.addSubModel(env.at(0).vertices, env.at(0).triangles);
        //environment_.endModel ();
        //environment_.computeLocalAABB();

        managerEnv_->clear();
        for (size_t en = 0; en < env.size(); ++en)
        {
            auto model = std::make_shared<Model>();
            model->beginModel();
            model->addSubModel(env.at(en).vertices, env.at(en).triangles);
            model->endModel();
            model->computeLocalAABB();
            envs_.push_back(model);

            auto collisionObj = new fcl::CollisionObjectd(model);
            managerEnv_->registerObject(collisionObj);
        }


        managerRob_->clear();
        for (size_t rbt = 0; rbt < robot.size(); ++rbt)
        {
            auto model = std::make_shared<Model>();
            model->beginModel();
            QString* name = new QString(QString::fromStdString(robot.at(rbt).name));
            model->setUserData(name);
            model->addSubModel(robot.at(rbt).vertices, robot.at(rbt).triangles);
            model->endModel();
            model->computeLocalAABB();
            robotParts_.push_back(model);

            auto collisionObj = new fcl::CollisionObjectd(model);
            managerRob_->registerObject(collisionObj);
        }
    }

    //    /// \brief Convert a mesh to a FCL BVH model
    //    std::pair<std::vector <Vector3>, std::vector<fcl::Triangle>> getFCLModelFromScene(const aiScene *scene, const aiVector3D &center) const
    //    {
    //        std::vector<const aiScene*> scenes(1, scene);
    //        std::vector<aiVector3D>     centers(1, center);
    //        return getFCLModelFromScene(scenes, centers);
    //    }

    //    /// \brief Convert a mesh to a FCL BVH model
    //    std::pair<std::vector<Vector3>, std::vector<fcl::Triangle>> getFCLModelFromScene(const std::vector<const aiScene*> &scenes, const std::vector<aiVector3D> &center) const
    //    {
    //        // Model consists of a set of points, and a set of triangles
    //        // that connect those points
    //        std::vector<fcl::Triangle> triangles;
    //        std::vector<Vector3> pts;

    //        for (unsigned int i = 0; i < scenes.size(); ++i)
    //        {
    //            if (scenes[i] != nullptr)
    //            {
    //                std::vector<aiVector3D> t;
    //                // extractTriangles is a misleading name.  this extracts the set of points,
    //                // where each set of three contiguous points consists of a triangle
    //                scene::extractTriangles(scenes[i], t);

    //                if (center.size() > i)
    //                    for (auto & j : t)
    //                        j -= center[i];

    //                assert(t.size() % 3 == 0);

    //                for (auto & p : t)
    //                {
    //                    pts.emplace_back(p[0], p[1], p[2]);
    //                }
    //            }
    //        }

    //        for (unsigned int i = 0; i < pts.size(); i+=3)
    //            triangles.emplace_back(i, i+1, i+2);

    //        return std::make_pair(pts, triangles);
    //    }

    void clear()
    {
        robotParts_.clear();
        envs_.clear();
    }

    /// \brief Geometric model used for the environment
    Model environment_;

    /// \brief List of components for the geometric model of the robot


    mutable std::vector<std::shared_ptr<Model>> robotParts_;
    mutable std::vector<std::shared_ptr<Model>> envs_;

    /// \brief Callback to get the geometric portion of a specific state
    //GeometricStateExtractor     extractState_;

    /// \brief Flag indicating whether the geometry is checked for self collisions
    bool                        selfCollision_;

    /// \brief Callback to extract translation and rotation from a state
    //FCLPoseFromStateCallback    poseFromStateCallback_;

    std::unique_ptr<fcl::BroadPhaseCollisionManagerd> managerEnv_;
    std::unique_ptr<fcl::BroadPhaseCollisionManagerd> managerRob_;
};

}
