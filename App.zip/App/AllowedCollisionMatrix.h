#pragma once

#include <App/DocumentObject.h>
#include <Base/Type.h>
#include <string>
#include <vector>

//#include <App/DocumentObserver.h>
//#include <Base/BaseClass.h>

namespace App
{
class Document;
class DocumentObject;
}

namespace WirCore
{

class AllowedCollisionMatrix  : public App::DocumentObject
{
    // PROPERTY_HEADER(WirOlp::AllowedCollisionMatrix);
    TYPESYSTEM_HEADER();

public:  
    /// returns the type name of the ViewProvider
    virtual const char* getViewProviderName(void) const
    {
        return "WirCoreGui::ViewProviderACM";
    }

    virtual App::DocumentObjectExecReturn *execute(void)
    {
        return App::DocumentObject::StdReturn;
    }

    virtual short mustExecute(void) const;
    virtual PyObject *getPyObject(void);

    virtual void Save (Base::Writer & writer) const;
    virtual void Restore(Base::XMLReader & reader);

    ~AllowedCollisionMatrix();
    AllowedCollisionMatrix();
    AllowedCollisionMatrix(std::string p);
    void clear();
    int getEntryNum();
    bool hasEntry(std::string val);
    bool subEntries(AllowedCollisionMatrix& acm);
    void deleteColumn(int index);
    std::string getEntryName(int index);
    std::string toString();
    AllowedCollisionMatrix subMatrix(std::vector<int> indices);

    //    void slotSaveDocument(const Base::Writer   & writer);
    //    void slotRestoreDocumen(const Base::XMLReader& reader);

    void updateByEntryNames(AllowedCollisionMatrix& acm);
    void setEntryNames(std::vector<std::string>& names);
    bool setEntryValues(std::vector<int>& entry_values);
    bool resetEntryNames(std::vector<std::string>& names);
    int getEntry(int column,int row);
    int getEntry(std::string columnName,std::string rowName);
    void setEntry(int column,int row,int value);
    void setEntry(std::string columnName,std::string rowName,int value);
    std::vector<std::string> getEntryNames();
    std::vector<int> getValues();
    void setEntryPrefix(std::string pf);
    void copy(AllowedCollisionMatrix& acm);

    void operator += (AllowedCollisionMatrix& acm);
    void operator = (AllowedCollisionMatrix& acm);
    void addEntry(std::string entryName);

    static std::string uniqueName;
    static bool bUnique;

    bool getIsCheckInSim() const { return isCheckInSim; }
    void setIsCheckInSim(bool ok) { isCheckInSim = ok; }
    bool getIsCheckHideObject() const { return isCheckHideObject; }
    void setIsCheckHideObject(bool ok) { isCheckHideObject = ok; }
    bool getIsCheckCollsionPoint() const { return isCheckCollsionPoint; }
    void setIsCheckCollsionPoint(bool ok) { isCheckCollsionPoint = ok; }
    int getCollisionType() const { return collisionType; }
    void setCollisionType(int type) { collisionType = type; }
    App::Color getCollisionColor() const { return collisionColor; }
    void setCollisionColor(App::Color c) { collisionColor = c; }

protected:
    std::vector<std::string> entry_names;
    std::vector<int> entry_values;
    int entry_num;
    std::string prefix;

    bool isCheckInSim = true;
    bool isCheckHideObject = true;
    bool isCheckCollsionPoint = false;
    int collisionType = 0; // 0: openinventor 1: fcl
    App::Color collisionColor;

};

} //namespace WirCore
