/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/
#include "RobotObject.h"
#include "RobotToolObject.h"
#include <App/DocumentObjectPy.h>
#include <App/Application.h>
#include <Base/Placement.h>
#include <App/Document.h>
#include <App/Part.h>
#include <App/DocumentObjectGroup.h>

#include <Base/Writer.h>
#include <Base/Reader.h>
#include <Mod/Part/App/PartFeature.h>
#include <Mod/WirCore/App/TrajectoryObject.h>
#include <App/VRMLObject.h>

#include <QString>
#include <QProcess>

using namespace WirCore;

PROPERTY_SOURCE(WirCore::RobotObject, App::GeoFeature)

template<typename T, size_t N>
T * end(T (&ra)[N]) {
    return ra + N;
}


RobotObject::RobotObject()
:block(false)
{
    ADD_PROPERTY_TYPE(RobotXmlFile,(0),""    ,App::Prop_None,"Included file with the xml and model");
    ADD_PROPERTY_TYPE(LinkList,(0),"",App::Prop_None,"List of Links");
    LinkList.setSize(0);

    ADD_PROPERTY_TYPE(Axis1,(0.0),"Robot kinematic",App::Prop_None,"Axis 1 angle of the robot in degre");
    ADD_PROPERTY_TYPE(Axis2,(0.0),"Robot kinematic",App::Prop_None,"Axis 2 angle of the robot in degre");
    ADD_PROPERTY_TYPE(Axis3,(0.0),"Robot kinematic",App::Prop_None,"Axis 3 angle of the robot in degre");
    ADD_PROPERTY_TYPE(Axis4,(0.0),"Robot kinematic",App::Prop_None,"Axis 4 angle of the robot in degre");
    ADD_PROPERTY_TYPE(Axis5,(0.0),"Robot kinematic",App::Prop_None,"Axis 5 angle of the robot in degre");
    ADD_PROPERTY_TYPE(Axis6,(0.0),"Robot kinematic",App::Prop_None,"Axis 6 angle of the robot in degre");

    ADD_PROPERTY_TYPE(Tcp,(Base::Placement()),"Robot kinematic",App::Prop_None,"Tcp of the robot");

    ADD_PROPERTY_TYPE(ToolShape,(0),"Robot kinematic",App::Prop_None,"Link to the Shape is used as Tool");

    ADD_PROPERTY_TYPE(ConfigFront,(true),"Config",App::Prop_Hidden,"Link Config");
    ADD_PROPERTY_TYPE(ConfigUp,(false),"Config",App::Prop_Hidden,"Link Config");
    ADD_PROPERTY_TYPE(ConfigFlip,(true),"Config",App::Prop_Hidden,"Link Config");


    RobotXmlFile.setStatus(App::Property::Hidden, true);
    LinkList.setStatus(App::Property::Hidden, true);
    ToolShape.setStatus(App::Property::Hidden, true);

    vecJointsTransForm.clear();
    GroupExtension::initExtension(this);
}

RobotObject::~RobotObject()
{
}

short RobotObject::mustExecute(void) const
{
    return 0;
}

PyObject *RobotObject::getPyObject()
{
    if (PythonObject.is(Py::_None())){
        // ref counter is set to 1
        PythonObject = Py::Object(new App::DocumentObjectPy(this),true);
    }
    return Py::new_reference_to(PythonObject); 
}


void RobotObject::onChanged(const App::Property* prop)
{
    App::GeoFeature::onChanged(prop);
    auto updateToolBase = [&](){
        if(ToolShape.getValue())
        {
            App::GeoFeature* o = ToolShape.getValue<App::GeoFeature*>();
            if(o)
            {
                o->Placement.setValue(Tcp.getValue());
            }
        }

    };

    if(prop == &RobotXmlFile){

    }

    if(prop == &Axis1 && !block){
        robot.setAxis(0,Axis1.getValue());
        block = true;
        Tcp.setValue(globalPlacement()*robot.getTcp());
        block = false;
    }
    if(prop == &Axis2 && !block){
        robot.setAxis(1,Axis2.getValue());
        block = true;
        Tcp.setValue(globalPlacement()*robot.getTcp());
        block = false;
    }
    if(prop == &Axis3 && !block){
        robot.setAxis(2,Axis3.getValue());
        block = true;
        Tcp.setValue(globalPlacement()*robot.getTcp());
        block = false;
    }
    if(prop == &Axis4 && !block){
        robot.setAxis(3,Axis4.getValue());
        block = true;
        Tcp.setValue(globalPlacement()*robot.getTcp());
        block = false;
    }
    if(prop == &Axis5 && !block){
        robot.setAxis(4,Axis5.getValue());
        block = true;
        Tcp.setValue(globalPlacement()*robot.getTcp());
        block = false;
    }
    if(prop == &Axis6 && !block){
        robot.setAxis(5,Axis6.getValue());
        block = true;
        Tcp.setValue(globalPlacement()*robot.getTcp());
        block = false;
    }
    if(prop == &Tcp && !block){
        isLimitPos = robot.setTo(globalPlacement().inverse()*Tcp.getValue(), m_LinkConfig);
        block = true;
        if (isLimitPos)
        {
            Axis1.setValue(robot.getAxis(0));
            Axis2.setValue(robot.getAxis(1));
            Axis3.setValue(robot.getAxis(2));
            Axis4.setValue(robot.getAxis(3));
            Axis5.setValue(robot.getAxis(4));
            Axis6.setValue(robot.getAxis(5));
        }
        else
        {
            Tcp.setValue(globalPlacement()*robot.getTcp());
        }
        block = false;
    }
    if(prop == &Placement && !block){
        Tcp.setValue(globalPlacement()*robot.getTcp());
    }

    WirCore::WorkStationGroup* workObj = WirCore::WorkStationGroup::getStationGroupOfObject(this);
    if (workObj != nullptr)
    {
        workObj->updateAllRobotHoldFrame(globalPlacement()*robot.getTcp());
    }

    updateAllJointsTcp();
    updateToolBase();
}

int RobotObject::setTcpWithLinkConfig(Base::Placement i_Pla, std::vector<bool> i_Vec,bool i_UpdateModel)
{
    isLimitPos = robot.setTo(globalPlacement().inverse()*i_Pla, i_Vec);
    block = false;
    if (i_UpdateModel && isLimitPos)
    {
        Axis1.setValue(robot.getAxis(0));
        Axis2.setValue(robot.getAxis(1));
        Axis3.setValue(robot.getAxis(2));
        Axis4.setValue(robot.getAxis(3));
        Axis5.setValue(robot.getAxis(4));
        Axis6.setValue(robot.getAxis(5));
    }
    return isLimitPos;
  //  block = false;
}


bool RobotObject::setLinkConfig(std::vector<bool> i_vec)
{
    ConfigFront.setValue(i_vec[0]);
    ConfigUp.setValue(i_vec[1]);
    ConfigFlip.setValue(i_vec[2]);
    return true;
}


std::vector<bool> RobotObject::getLinkConfig()
{
    std::vector<bool> LinkConfig;

    LinkConfig.push_back(ConfigFront.getValue());
    LinkConfig.push_back(ConfigUp.getValue());
    LinkConfig.push_back(ConfigFlip.getValue());

    return LinkConfig;
}


void RobotObject::Save (Base::Writer &writer) const
{
    for(unsigned int i = 0;i < vecJointsTransForm.size(); i++)
    {
        writer.Stream() << writer.ind() << "<JointsTransForm "
                        << "Px=\""          <<  vecJointsTransForm[i].getPosition().x  << "\" "
                        << "Py=\""          <<  vecJointsTransForm[i].getPosition().y  << "\" "
                        << "Pz=\""          <<  vecJointsTransForm[i].getPosition().z  << "\" "
                        << "Q0=\""          <<  vecJointsTransForm[i].getRotation()[0] << "\" "
                        << "Q1=\""          <<  vecJointsTransForm[i].getRotation()[1] << "\" "
                        << "Q2=\""          <<  vecJointsTransForm[i].getRotation()[2] << "\" "
                        << "Q3=\""          <<  vecJointsTransForm[i].getRotation()[3] << "\"/>"
                        << std::endl;
    }

    App::GeoFeature::Save(writer);
    robot.Save(writer);

}

void RobotObject::Restore(Base::XMLReader &reader)
{
    block = true;
    Base::Placement Tip;
    vecJointsTransForm.clear();

    for(unsigned int i = 0; i < 5; i++){
        reader.readElement("JointsTransForm");
        // get the value of the placement
        Tip =    Base::Placement(Base::Vector3d(reader.getAttributeAsFloat("Px"),
                                                reader.getAttributeAsFloat("Py"),
                                                reader.getAttributeAsFloat("Pz")),
                                 Base::Rotation(reader.getAttributeAsFloat("Q0"),
                                                reader.getAttributeAsFloat("Q1"),
                                                reader.getAttributeAsFloat("Q2"),
                                                reader.getAttributeAsFloat("Q3")));
        vecJointsTransForm.push_back(Tip);
    }

    App::GeoFeature::Restore(reader);
    robot.Restore(reader);

//    // set up the robot with the loaded axis position
    robot.setAxis(0,Axis1.getValue());
    robot.setAxis(1,Axis2.getValue());
    robot.setAxis(2,Axis3.getValue());
    robot.setAxis(3,Axis4.getValue());
    robot.setAxis(4,Axis5.getValue());
    robot.setAxis(5,Axis6.getValue());
    robot.setTo(Tcp.getValue(), m_LinkConfig);
    Tcp.setValue(globalPlacement()*robot.getTcp());
    block = false;
}


void RobotObject::analyzeConfigZip(const char * FileName)
{
    SpecifyJointTcp.clear();

    QString sFileName = QString::fromUtf8(FileName);

    QString tmp = QString::fromUtf8("/");
    int num = sFileName.lastIndexOf(tmp);
    QString sFilepath= sFileName.mid(0, num );


    unzipConfigfile(sFileName, sFilepath);

    LoadRobotXml(sFilepath);

    if (DHparam.size() > 5)
    {
        robot.readKinematic(DHparam);
    }
    updateAllJointsTcp();
}

void RobotObject::updateAllJointsTcp()
{
    SpecifyJointTcp.clear();
    for (int i = 0; i < DHparam.size(); i ++)
    {
        SpecifyJointTcp.push_back(robot.getSpecifyJointTcp(i));
    }
}

void RobotObject::LoadRobotXml(QString FilePath)
{
    DHparam.clear();
    vecJointModFile.clear();

    QDomDocument doc(QString::fromUtf8("SvgDoc"));
    QFile file(FilePath + QString::fromUtf8("/RobotConfig.xml"));
    if (!file.open(QIODevice::ReadOnly)) {
        Base::Console().Message("open robot config error\n");
        return;
    }

    if (!doc.setContent(&file)) {
        Base::Console().Message("open robot config error\n");
        file.close();
        return;
    }
    file.close();

    QDomElement xmlroot=doc.documentElement(); //返回根节点
    QDomNode node=xmlroot.firstChild(); //获得

    QDomElement e;
    while(!node.isNull()) {
        e = node.toElement();                          // try to convert the node to an element.
        if(!e.isNull()) {
           QString str = e.tagName();
           if (str == QString::fromUtf8("RobotJoint"))
           {
              QDomNodeList list=e.childNodes();

              for(int i = 0;i < list.count();i++)   //base里没有关节信息
              {
                  QDomNode n = list.at(i);
                  QDomNodeList Jointlist = n.childNodes();
                  AxisDefinition tDHpara;
                  for(int j = 0; j < Jointlist.count(); j++)
                  {
                     QDomNode t_node = Jointlist.at(j);
                     if(t_node.isElement())
                     {
                         if (t_node.nodeName() == QString::fromUtf8("ModelPath"))
                         {
                            vecJointModFile.push_back(FilePath + t_node.toElement().text());
                         }
                         if (t_node.nodeName() == QString::fromUtf8("Theta"))
                         {
                            tDHpara.theta = t_node.toElement().text().toDouble();
                         }

                         if (t_node.nodeName() == QString::fromUtf8("d"))
                         {
                            tDHpara.d = t_node.toElement().text().toDouble();
                         }

                         if (t_node.nodeName() == QString::fromUtf8("Alpha"))
                         {
                            tDHpara.alpha = t_node.toElement().text().toDouble();
                         }

                         if (t_node.nodeName() == QString::fromUtf8("a"))
                         {
                            tDHpara.a = t_node.toElement().text().toDouble();
                         }

                         if (t_node.nodeName() == QString::fromUtf8("JointDirection"))
                         {
                            tDHpara.rotDir = t_node.toElement().text().toDouble();
                         }

                         if (t_node.nodeName() == QString::fromUtf8("MaxAngle"))
                         {
                            tDHpara.maxAngle = t_node.toElement().text().toDouble();
                         }

                         if (t_node.nodeName() == QString::fromUtf8("MinAngle"))
                         {
                            tDHpara.minAngle = t_node.toElement().text().toDouble();
                         }

                         tDHpara.velocity = 200;
                     }
                  }

                 if (i > 0)
                 {
                     DHparam.push_back(tDHpara);
                 }
              }
           }
        }
        node=node.nextSibling();
    }

}


void RobotObject::unzipConfigfile(QString FileName,  QString FilePath)
{
    QFile zip_file(FileName);
    if (!zip_file.open(QIODevice::ReadOnly)) {
        Base::Console().Message("open robot config error\n");
        return;
    }
    QProcess *terminal;
    terminal = new QProcess;   //初始化

    terminal->setWorkingDirectory(FilePath);

    QString program = QString::fromUtf8("unzip");
    QStringList arguments;
    arguments << QString::fromUtf8("./RobotConfig.zip");
    terminal->start(program, arguments);

    terminal->waitForFinished();//等待完成

    terminal->close();
    delete terminal;
    terminal = 0;

}
