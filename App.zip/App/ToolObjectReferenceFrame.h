#ifndef TOOLOBJECTREFERENCEFRAME_H
#define TOOLOBJECTREFERENCEFRAME_H

#include <App/DocumentObject.h>
#include <App/PropertyGeo.h>
#include <Mod/WirCore/App/DatumCS.h>

namespace WirCore
{


class ToolObjectReferenceFrame : public WirCore::CoordinateSystem
{
    PROPERTY_HEADER(WirCore::ToolObjectReferenceFrame);

public:
    ToolObjectReferenceFrame();
    virtual ~ToolObjectReferenceFrame();

    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderDatumCoordinateSystem";
    }
    //是否被机器人抓住，（机器人的在使用该工具坐标系时的工作模式，是否为抓取工具加工工件）
    App::PropertyBool robotHold;

    App::PropertyFloat mass;
    App::PropertyVector toolFocus;
    App::PropertyVector toolInertia;
    App::PropertyPlacement  toolPlacement;
};

}
#endif // TOOLOBJECTREFERENCEFRAME_H
