#include "Unprocess_Path.h"

using namespace WirCore;
using namespace Base;


TYPESYSTEM_SOURCE(WirCore::Unprocess_Path , Base::Persistence);


Unprocess_Path::Unprocess_Path()
{

}
Unprocess_Path::~Unprocess_Path()
{

}
void Unprocess_Path::Ganerate_Approach_Path(WaypointObject *Start_Point,WirCore::WorkFrameObject* wobj)
{  
    double r_x,r_y,r_z;
    Base::Placement point_pos;
    Base::Placement delta_pos;
    Base::Placement approach_matrix;
    WirCore::PointObject* approach_object=new WirCore::PointObject;
    App::DocumentObject* point;
    WirCore::PointObject*  point_object;
    Base::Rotation  rotation;
    WirCore::ToolObjectReferenceFrame* tool_object;
    Vector3d pos;
    Rotation rot;
    Matrix4D trans_Matrix4D;
    switch (Enum_Approach_Type) {
    case (Approach_Linear):
        point=Start_Point->linkPoint.getValue();
        point_object=dynamic_cast< WirCore::PointObject*>(point);
        point_pos=point_object->Placement.getValue();
        //获取加工初始点位姿，求进刀点//
        rotation=point_pos.getRotation();
        rotation.getYawPitchRoll(r_x,r_y,r_z);
        r_y=r_y+approach_para->Approach_Rotation_Y;
        r_z=r_z+approach_para->Approach_Rotation_Z;
        rotation.setYawPitchRoll(r_x,r_y,r_z);
        point_pos.setRotation(rotation);
        pos.x=-approach_para->Approach_Length;
        pos.y=0;
        pos.z=0;
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        approach_matrix=point_pos*delta_pos;
        rotation=point_pos.getRotation();
        approach_matrix.setRotation(point_object->Placement.getValue().getRotation());
        Approach_Path->addWaypointToTrajectory(approach_matrix,wobj,Start_Point->linkTool.getValue());
        // 求缓冲距离点 //
        pos.x=-other_para->Buffer_Distance;
        pos.y=0;
        pos.z=0;
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        approach_matrix=point_pos*delta_pos;
        approach_matrix.setRotation(point_object->Placement.getValue().getRotation());
        Approach_Path->addWaypointToTrajectory(approach_matrix,wobj,Start_Point->linkTool.getValue());
        break;
    case (Approach_Arc):
        point=Start_Point->linkPoint.getValue();
        point_object=dynamic_cast< WirCore::PointObject*>(point);
        tool_object=dynamic_cast<WirCore::ToolObjectReferenceFrame*>(Start_Point->linkPoint.getValue());
        point_pos=point_object->Placement.getValue();
        rotation=point_pos.getRotation();
       //求圆弧进刀点   //
        pos.x=-approach_para->Approach_Radius*cos(approach_para->Approach_Angle/180*3.14);
        pos.y=0;
        pos.z=approach_para->Approach_Radius*(1-sin(approach_para->Approach_Angle/180*3.14));
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        approach_matrix=point_pos*delta_pos;
        Approach_Path->addWaypointToTrajectory(approach_matrix,wobj,Start_Point->linkTool.getValue());
        //圆弧中间点取角度一半的中间点   //
        pos.x=-approach_para->Approach_Radius*cos(approach_para->Approach_Angle/2/180*3.14);
        pos.y=0;
        pos.z=approach_para->Approach_Radius*(1-sin(approach_para->Approach_Angle/2/180*3.14));
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        approach_matrix=point_pos*delta_pos;
        approach_object->disPlacement.setValue(approach_matrix);
        Approach_Path->addWaypointToTrajectory(approach_matrix,wobj,Start_Point->linkTool.getValue());
        //缓冲点//
        pos.x=-approach_para->Approach_Radius*cos(other_para->Buffer_Distance/approach_para->Approach_Radius);
        pos.y=0;
        pos.z=approach_para->Approach_Radius*(1-sin(other_para->Buffer_Distance/approach_para->Approach_Radius));
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        approach_matrix=point_pos*delta_pos;
        approach_object->disPlacement.setValue(approach_matrix);
        Approach_Path->addWaypointToTrajectory(approach_matrix,wobj,Start_Point->linkTool.getValue());
        break;
        ;
    case (Approach_None):
       Approach_Path->WayPointList.setValue(Start_Point);
        ;
    }
}
void Unprocess_Path::Ganerate_Departing_Path(WaypointObject *End_Point,WirCore::WorkFrameObject* wobj)
{
    double r_x,r_y,r_z;
    Base::Placement point_pos;
    Base::Placement delta_pos;
    Base::Placement Departing_matrix;
    WirCore::PointObject* Departing_object=new WirCore::PointObject;
    App::DocumentObject* point;
    WirCore::PointObject*  point_object;
    Base::Rotation  rotation;
    WirCore::ToolObjectReferenceFrame* tool_object;
    Vector3d pos;
    Rotation rot;
    Matrix4D trans_Matrix4D;
    switch (Enum_Departing_Type) {
    case (Departing_Linear):
        point=End_Point->linkPoint.getValue();
        point_object=dynamic_cast< WirCore::PointObject*>(point);
        point_pos=point_object->Placement.getValue();
        //获取加工初始点位姿，求退刀点//
        rotation=point_pos.getRotation();
        rotation.getYawPitchRoll(r_x,r_y,r_z);
        r_y=r_y-departing_para->Departing_Rotation_Y;
        r_z=r_z-departing_para->Departing_Rotation_Z;
        rotation.setYawPitchRoll(r_x,r_y,r_z);
        point_pos.setRotation(rotation);
        // 求缓冲距离点  //
        pos.x=other_para->Buffer_Distance;
        pos.y=0;
        pos.z=0;
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        Departing_matrix=point_pos*delta_pos;
        Departing_matrix.setRotation(point_object->Placement.getValue().getRotation());
        Departing_Path->addWaypointToTrajectory(Departing_matrix,wobj,End_Point->linkTool.getValue());
        // 退刀点  //
        pos.x=departing_para->Departing_Length;
        pos.y=0;
        pos.z=0;
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        Departing_matrix=point_pos*delta_pos;
        rotation=point_pos.getRotation();
        Departing_matrix.setRotation(point_object->Placement.getValue().getRotation());
        Departing_Path->addWaypointToTrajectory(Departing_matrix,wobj,End_Point->linkTool.getValue());
        break;
    case (Departing_Arc):
        point=End_Point->linkPoint.getValue();
        point_object=dynamic_cast< WirCore::PointObject*>(point);
        tool_object=dynamic_cast<WirCore::ToolObjectReferenceFrame*>(End_Point->linkPoint.getValue());
        point_pos=point_object->Placement.getValue();
        rotation=point_pos.getRotation();
        //求缓冲点//
        pos.x=departing_para->Departing_Radius*cos(other_para->Buffer_Distance/departing_para->Departing_Radius);
        pos.y=0;
        pos.z=departing_para->Departing_Radius*(1-sin(other_para->Buffer_Distance/departing_para->Departing_Radius));
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        Departing_matrix=point_pos*delta_pos;
        Departing_object->disPlacement.setValue(Departing_matrix);
        Departing_Path->addWaypointToTrajectory(Departing_matrix,wobj,End_Point->linkTool.getValue());
        //圆弧中间点取角度一半的中间点   //
        pos.x=departing_para->Departing_Radius*cos(departing_para->Departing_Angle/2/180*3.14);
        pos.y=0;
        pos.z=departing_para->Departing_Radius*(1-sin(departing_para->Departing_Angle/2/180*3.14));
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        Departing_matrix=point_pos*delta_pos;
        Departing_object->disPlacement.setValue(Departing_matrix);
        Departing_Path->addWaypointToTrajectory(Departing_matrix,wobj,End_Point->linkTool.getValue());
       //求圆弧退刀点   //
        pos.x=departing_para->Departing_Radius*cos(departing_para->Departing_Angle/180*3.14);
        pos.y=0;
        pos.z=departing_para->Departing_Radius*(1-sin(departing_para->Departing_Angle/180*3.14));
        delta_pos.setPosition(pos);
        rot.setYawPitchRoll(0,0,0);
        delta_pos.setRotation(rot);
        Departing_matrix=point_pos*delta_pos;
        Departing_Path->addWaypointToTrajectory(Departing_matrix,wobj,End_Point->linkTool.getValue());
        break;
        ;
    case (Departing_None):
       Departing_Path->WayPointList.setValue(End_Point);
        ;
    }
}
void Unprocess_Path::Ganerate_Link_Path(WaypointObject *Start_Point,WaypointObject *End_Point,WirCore::WorkFrameObject* wobj)
{
    vector<App::DocumentObject*> pointgroup;
    vector<App::DocumentObject*> pointgroup_Approach;
    vector<App::DocumentObject*> pointgroup_Departing;
    WirCore::PointObject* Link_object=new WirCore::PointObject;

    App::DocumentObject* point;
    Base::Placement point_matrix;
    Vector3d pos;
    pointgroup=Link_Path->WayPointList.getValues();
    pointgroup.clear();
    Link_Path->WayPointList.setValues(pointgroup);
    switch (Enum_Link_Type) {
    case (Use_Approach_Departing):
        //进刀路径加退刀路径 //
           Ganerate_Departing_Path(Start_Point,wobj);
           Ganerate_Approach_Path(End_Point,wobj);
           pointgroup_Departing=Departing_Path->WayPointList.getValues();
           pointgroup_Approach=Approach_Path->WayPointList.getValues();
           pointgroup.insert(pointgroup.end(),pointgroup_Departing.begin(),pointgroup_Departing.end());
           pointgroup.insert(pointgroup.end(),pointgroup_Approach.begin(),pointgroup_Approach.end());
           Link_Path->WayPointList.setValues(pointgroup);
        ;
    case (Lift_Saft_Height):
        point=Start_Point->linkPoint.getValue();
        Link_object=dynamic_cast< WirCore::PointObject*>(point);
        point_matrix=Link_object->Placement.getValue();
        pos=point_matrix.getPosition();
        pos.z=pos.z+other_para->Safe_Height;
        point_matrix.setPosition(pos);
        Link_Path->addWaypointToTrajectory(point_matrix,wobj,Start_Point->linkTool.getValue());
        //第一段结束点//
        point=End_Point->linkPoint.getValue();
        Link_object=dynamic_cast< WirCore::PointObject*>(point);
        point_matrix=Link_object->disPlacement.getValue();
        pos=point_matrix.getPosition();
        pos.z=pos.z+other_para->Safe_Height;
        point_matrix.setPosition(pos);
        Link_Path->addWaypointToTrajectory(point_matrix,wobj,End_Point->linkTool.getValue());
        //第二段开始点//
        ;
    case (Direct):
         pointgroup.push_back(Start_Point);
         pointgroup.push_back(End_Point);
         Link_Path->WayPointList.setValues(pointgroup);
        ;
    }



}
void Unprocess_Path::Set_Approach_Parameter(Approach_parameter input_approach_para)
{
    approach_para->Approach_Angle=input_approach_para.Approach_Angle;
    approach_para->Approach_Length=input_approach_para.Approach_Length;
    approach_para->Approach_Radius=input_approach_para.Approach_Radius;
    approach_para->Approach_Rotation_Y=input_approach_para.Approach_Rotation_Y;
    approach_para->Approach_Rotation_Z=input_approach_para.Approach_Rotation_Z;
}
void Unprocess_Path::Set_Departing_Parameter(Departing_parameter input_departing_para)
{
    departing_para->Departing_Angle=input_departing_para.Departing_Angle;
    departing_para->Departing_Length=input_departing_para.Departing_Length;
    departing_para->Departing_Radius=input_departing_para.Departing_Radius;
    departing_para->Departing_Rotation_Y=input_departing_para.Departing_Rotation_Y;
    departing_para->Departing_Rotation_Z=input_departing_para.Departing_Rotation_Z;
}
void Unprocess_Path::Set_Other_Parameter(Other_parameter input_other_para)
{
    other_para->Safe_Height=input_other_para.Safe_Height;
    other_para->Buffer_Distance=input_other_para.Buffer_Distance;
}
void Unprocess_Path::Set_Enum_Choose_Type(Approach_Type input_Enum_Approach_Type,Departing_Type input_Enum_Departing_Type,Link_Type input_Enum_Link_Type)
{
      Enum_Approach_Type=input_Enum_Approach_Type;
      Enum_Link_Type=input_Enum_Link_Type;
      Enum_Departing_Type=input_Enum_Departing_Type;
}
Approach_parameter *  Unprocess_Path::Get_Approach_Parameter()
{
    return approach_para;
}
Departing_parameter * Unprocess_Path::Get_Departing_Parameter()
{
    return departing_para;
}
Other_parameter * Unprocess_Path::Get_Other_Parameter()
{
    return other_para;
}
void Unprocess_Path::Get_Enum_Choose_Type(Approach_Type &output_Enum_Approach_Type,Departing_Type &output_Enum_Departing_Type,Link_Type &output_Enum_Link_Type)
{
    output_Enum_Approach_Type=Enum_Approach_Type;
    output_Enum_Link_Type=Enum_Link_Type;
    output_Enum_Departing_Type=Enum_Departing_Type;
}
TrajectoryObject * Unprocess_Path::Get_Approach_path()
{
    return Approach_Path;
}
TrajectoryObject * Unprocess_Path::Get_Departing_path()
{
    return Departing_Path;
}
TrajectoryObject * Unprocess_Path::Get_Link_path()
{
    return Link_Path;
}
unsigned int Unprocess_Path::getMemSize (void) const
{
    return 0;
}

void Unprocess_Path::Save (Writer &writer) const
{


}

void Unprocess_Path::Restore(XMLReader &reader)
{


}
