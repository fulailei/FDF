﻿#include "TrajectoryOptimization.h"

using namespace WirCore;
using namespace std;

TrajectoryOptimization::TrajectoryOptimization(WirCore::TrajectoryObject *_pcTrajectoryObject):
    m_trac(_pcTrajectoryObject)
{
    auto* _stationObj = WirCore::WorkStationGroup::getStationGroupOfObject(m_trac);
    m_rob = dynamic_cast<WirCore::RobotObject*>(_stationObj->robot.getValue());
    initTracMap();
}

void TrajectoryOptimization::StartOptimizationDlg()
{
    initTracMap();
}



Base::Placement TrajectoryOptimization::getPointRobotTcpPos(WirCore::WaypointObject* i_obj)
{
    auto _point = dynamic_cast<WirCore::PointObject*>(i_obj->linkPoint.getValue());
    if (_point == nullptr || i_obj->linkTool.getValue() == nullptr)
    {
        return Base::Placement();
    }

    Base::Placement EndPos = _point->globalPlacement();
    WirCore::WorkFrameObject* workframe( nullptr );

    auto group( App::GeoFeatureGroupExtension::getGroupOfObject(_point) );
    if (group) {
        workframe = group->getExtensionByType< WirCore::WorkFrameObject>();
    }

    auto ToolObject = dynamic_cast< WirCore::ToolObjectReferenceFrame*>(i_obj->linkTool.getValue());
    Base::Placement Tool = ToolObject->Placement.getValue();

    bool bWobjRobHold = workframe->robotHold.getValue();
    if (!bWobjRobHold)
    {
        EndPos = EndPos * ToolObject->toolPlacement.getValue().inverse();
    }
    else
    {
        EndPos = Tool * _point->Placement.getValue().inverse();
    }
    return  EndPos;
}

void TrajectoryOptimization::initTracMap()
{
    std::vector<WirCore::WaypointObject*> vecWaypoints;
    vecWaypoints.clear();
    vecWaypoints = m_trac->getAllPointsInTrajectory();
    m_TracMap.clear();
    for (auto obj: vecWaypoints)
    {
        Base::Placement EndPos = getPointRobotTcpPos(obj);

        std::vector<bool> _vec = obj->getLinkConfig();
        std::vector<PointType> _vecType;

        for (int Increment = -180; Increment <= 180;  Increment += 10)
        {
            Base::Rotation rot(Base::Vector3d(0,0,1), Increment);
            Base::Placement transform(Base::Vector3d(0,0,0), rot);

            Base::Placement _newEndPos = EndPos * transform;

            int result = m_rob->setTcpWithLinkConfig(_newEndPos, _vec, false);
            if (result == 1)
            {
                _vecType.push_back(Arriveable);
            }
            else if (result == 0)
            {
                _vecType.push_back(UnArriveable);
            }
            else if (result == 2)
            {
                _vecType.push_back(OutOfLimit);
            }

        }
        m_TracMap.push_back(_vecType);
    }
}
