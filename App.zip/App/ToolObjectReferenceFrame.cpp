#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include "ToolObjectReferenceFrame.h"

using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::ToolObjectReferenceFrame, WirCore::CoordinateSystem)


ToolObjectReferenceFrame::ToolObjectReferenceFrame()
{
    ADD_PROPERTY_TYPE(robotHold, (0), "operation mode",Prop_None,"");
    ADD_PROPERTY_TYPE(toolFocus, (0,0,0), "attribute",Prop_None,"");
    ADD_PROPERTY_TYPE(mass,(1.0),"attribute",Prop_None,"");
    ADD_PROPERTY_TYPE(toolInertia, (0,0,0), "attribute",Prop_None,"");
    ADD_PROPERTY_TYPE(toolPlacement, (Base::Placement()), "attribute",Prop_None,"");
}

ToolObjectReferenceFrame::~ToolObjectReferenceFrame()
{

}
