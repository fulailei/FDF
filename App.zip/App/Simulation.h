/***************************************************************************
 *   Copyright (c) Jürgen Riegel          (juergen.riegel@web.de) 2009     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/
#pragma once
#include <Base/Vector3D.h>
#include <Base/Placement.h>
#include <string>
#include <App/GeoFeatureGroupExtension.h>
#include "kdl_cp/trajectory.hpp"

#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/RobotObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/PointObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/ToolObjectReferenceFrame.h>
#include <Mod/WirCore/App/LinkTrajectoryObject.h>

#include <vector>

namespace KDL
{
    class Trajectory_Composite;
}


namespace WirCore
{

/** Algo class for projecting shapes and creating SVG output of it
 */


class Simulation
{

public:
	/// Constructor
        ///
    //仿真类在构造时需传入所需仿真的机器人和轨迹。初始化时会将轨迹通过KDL拟合成一段时序匀速机器人运动路径，存放在pcTrajectory中
    Simulation(WirCore::RobotObject *pcRobotObject,
               WirCore::TrajectoryObject *pcTrajectoryObject);
	virtual ~Simulation();

    double getLength(void) const;
    double getDuration(void) const;

    //Base::Placement getPosition(void) const;
    double getVelocity(double time) const;

    void step(double tick);
    void setToTime(float t, int index);
    // apply the start axis angles and set to time 0. Restores the exact start position
    void reset(void);

    double TimeStep;
    double Axis[6];
    double startAxis[6];

    double m_endtime = 0.0;

    Base::Placement Tool;
    Base::Placement Base;


private:
    void initTrajectory();
    inline  KDL::Frame toFrame(const Base::Placement &To){
        return KDL::Frame(KDL::Rotation::Quaternion(To.getRotation()[0],To.getRotation()[1],To.getRotation()[2],To.getRotation()[3]),KDL::Vector(To.getPosition()[0],To.getPosition()[1],To.getPosition()[2]));
    }
    inline  Base::Placement toPlacement(const KDL::Frame &To){
            double x,y,z,w;
            To.M.GetQuaternion(x,y,z,w);
            return Base::Placement(Base::Vector3d(To.p[0],To.p[1],To.p[2]),Base::Rotation(x,y,z,w));
    }


private:
    WirCore::RobotObject * m_pcRobotObject;
    WirCore::TrajectoryObject *m_pcTrajectoryObject;
    std::vector<WirCore::WaypointObject*> m_vecWaypoints;
protected:
    KDL::Trajectory_Composite *pcTrajectory;
};



} //namespace Robot



//#endif
