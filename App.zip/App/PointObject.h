#ifndef WIRCORE_POINTOBJECT_H
#define WIRCORE_POINTOBJECT_H

#include <Mod/WirCore/App/DatumCS.h>


namespace WirCore
{

class PointObject : public WirCore::CoordinateSystem
{
    PROPERTY_HEADER(WirCore::PointObject);
public:
    PointObject();
    virtual ~PointObject();

    const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderCSPoint";
    }

    App::PropertyPlacement disPlacement;

    bool copyFrom(PointObject* i_object);



protected:
    /// get called by the container when a property has changed
    virtual void onChanged (const App::Property* prop);

};

}
#endif // POINTOBJECT_H
