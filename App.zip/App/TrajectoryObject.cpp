#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "TrajectoryObject.h"
#include <App/DocumentObjectPy.h>
#include <Base/Placement.h>
#include <App/Application.h>
#include <App/Document.h>
#include "LinkTrajectoryObject.h"

using namespace WirCore;
using namespace App;

PROPERTY_SOURCE(WirCore::TrajectoryObject, App::DocumentObject)


TrajectoryObject::TrajectoryObject()
{
    //ADD_PROPERTY_TYPE( Base,      (Base::Placement())  , "Trajectory",Prop_None,"Actuall base frame of the trajectory");
    ADD_PROPERTY_TYPE(WayPointList,(0),"",App::Prop_None,"List of Links");
    ADD_PROPERTY_TYPE(updateEvent,(0),"",App::Prop_Hidden,"List of Links");
    WayPointList.setStatus(App::Property::Hidden, true);
}

TrajectoryObject::~TrajectoryObject()
{
}

short TrajectoryObject::mustExecute() const
{
    return 0;
}

PyObject *TrajectoryObject::getPyObject()
{
    if(PythonObject.is(Py::_None())) {
        PythonObject = Py::Object(new DocumentObjectPy(this), true);
    }
    return Py::new_reference_to(PythonObject);
}

void TrajectoryObject::onChanged(const App::Property *prop)
{
    App::DocumentObject::onChanged(prop);
}

std::vector<WirCore::TrajectoryObject*>TrajectoryObject::getInlistTrajectory(App::DocumentObject* obj)
{
    std::vector<WirCore::TrajectoryObject*> Trajs;
    if (obj->isDerivedFrom(WirCore::PointObject::getClassTypeId()))
    {
        auto group = WaypointObject::getWayPointInlist(dynamic_cast<PointObject*>(obj));
        for (auto obj : group) {
            auto list = obj->getInList();
            for (auto tObj : list) {
                if(tObj->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
                {
                    Trajs.push_back(dynamic_cast<WirCore::TrajectoryObject*>(tObj));
                }
            }
        }
    }
    else if (obj->isDerivedFrom(WirCore::TrajectoryOperationObject::getClassTypeId()))
    {
        auto list = obj->getInList();
        for (auto obj : list) {
            if(obj->isDerivedFrom(WirCore::TrajectoryObject::getClassTypeId()))
            {
                Trajs.push_back(dynamic_cast<WirCore::TrajectoryObject*>(obj));
            }
        }
    }

    return Trajs;
}

void TrajectoryObject::CompareTrajectory(WirCore::TrajectoryObject* _traj)
{
    std::vector<App::DocumentObject*> pointGroup;
    pointGroup = _traj->WayPointList.getValues();

    for(unsigned int i = 0; i < pointGroup.size(); ++i) {
        if (pointGroup[i]->isDerivedFrom(WirCore::LinkTrajectoryObject::getClassTypeId()))
        {
            auto t_traj = dynamic_cast<WirCore::TrajectoryObject*>
                    ((dynamic_cast<WirCore::LinkTrajectoryObject*>(pointGroup[i]))->linkTrajectory.getValue());
            if (!t_traj)
            {
                continue;
            }
            CompareTrajectory(t_traj);
        }
        else if (pointGroup[i]->isDerivedFrom(WirCore::WaypointObject::getClassTypeId()))
        {
            m_waypoints.push_back(dynamic_cast<WirCore::WaypointObject*>(pointGroup[i]));
        }
    }

}

std::vector<WirCore::WaypointObject*> TrajectoryObject::getAllPointsInTrajectory()
{
    m_waypoints.clear();
    CompareTrajectory(this);
    return m_waypoints;
}

void TrajectoryObject::addWaypointToTrajectory(Base::Placement i_placement,  WirCore::WorkFrameObject* wobj, App::DocumentObject* tool)
{
    App::Document* doc = App::GetApplication().getActiveDocument();

    WirCore::PointObject* _PointObject = new WirCore::PointObject();
    std::string n = "Target";
    _PointObject->Label.setValue(n);
    doc->addObject(_PointObject, n.c_str());
    _PointObject->Placement.setValue(i_placement);
    wobj->addObject(_PointObject);

    std::vector<App::DocumentObject*> pointGroup;
    pointGroup = WayPointList.getValues();

    WirCore::WaypointObject*  waypoint = new  WirCore::WaypointObject();
    waypoint->linkPoint.setValue(_PointObject);
    waypoint->waypointType.setValue("MoveL");
    waypoint->linkTool.setValue(tool);

    n = "MoveL_" + std::string(_PointObject->Label.getValue()) + "_";
    waypoint->Label.setValue(n);
    doc->addObject(waypoint, n.c_str());
    pointGroup.push_back(waypoint);

    WayPointList.setValues(pointGroup);
}


