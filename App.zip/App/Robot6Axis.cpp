/***************************************************************************
 *   Copyright (c) Jürgen Riegel          (juergen.riegel@web.de) 2002     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include <Base/Writer.h>
#include <Base/Reader.h>

#include "kdl_cp/chain.hpp"
#include "kdl_cp/chainfksolver.hpp"
#include "kdl_cp/chainfksolverpos_recursive.hpp"
#include "kdl_cp/frames_io.hpp"
#include "kdl_cp/chainiksolver.hpp"
#include "kdl_cp/chainiksolvervel_pinv.hpp"
#include "kdl_cp/chainjnttojacsolver.hpp"
#include "kdl_cp/chainiksolverpos_nr.hpp"
#include "kdl_cp/chainiksolverpos_nr_jl.hpp"
#include "kdl_cp/chainiksolverpos_si_jl.hpp"

#include "Robot6Axis.h"
#include "RobotAlgos.h"

#ifndef M_PI
    #define M_PI    3.14159265358979323846 /* pi */
#endif

#ifndef M_PI_2
    #define M_PI_2  1.57079632679489661923 /* pi/2 */
#endif

using namespace WirCore;
using namespace Base;
using namespace KDL;

// some default roboter

AxisDefinition UR10[6] = {
//   a    ,alpha ,d    ,theta ,rotDir ,maxAngle ,minAngle ,AxisVelocity
    {0    ,0     ,128  ,0     , 1     ,+185     ,-185     ,156         }, // Axis 1
    {0    ,90    ,0.0  ,180   , 1     ,+35      ,-155     ,156         }, // Axis 2
    {612.7,0.0   ,0.0  ,0.0   , 1     ,+154     ,-130     ,156         }, // Axis 3
    {571.6,0.0   ,163.9,0.0   , 1     ,+350     ,-350     ,330         }, // Axis 4
    {0    ,-90   ,115.7,0.0   , 1     ,+130     ,-130     ,330         }, // Axis 5
    {0    ,+90   ,92.2 ,180   , 1     ,+350     ,-350     ,615         }  // Axis 6
};

AxisDefinition ABB4600[6] = {
    {175  ,-90   ,495  ,0.0    ,1    ,+180     ,-180     ,175         },
    {900  ,0.0   ,0.0  ,-90.0  ,1    ,+150     ,-90      ,175         },
    {175  ,-90   ,0.0  ,0.0    ,1    ,+75      ,-180     ,175},
    {0    ,90    ,960  ,0.0    ,1    ,+400     ,-400     ,250},
    {0    ,-90   ,0.0  ,0.0    ,1    ,+120     ,-125     ,250},
    {0    ,0     ,135  ,180.0  ,1    ,+400     ,-400     ,360},
};

TYPESYSTEM_SOURCE(WirCore::Robot6Axis , Base::Persistence);

Robot6Axis::Robot6Axis()
{
    // create joint array for the min and max angle values of each joint
    Min = JntArray(6);
    Max = JntArray(6);

	// Create joint array
    Actuall = JntArray(6);

    // set to default kuka 500
    setKinematic(ABB4600);

    JointTcp.clear();
}

Robot6Axis::~Robot6Axis()
{
}


void Robot6Axis::setKinematic(const AxisDefinition KinDef[6])
{
	Chain temp;

    axisDH.clear();

    for(int i=0 ; i<6 ;i++){
        axisDH.push_back(KinDef[i]);
        temp.addSegment(Segment(Joint(Joint::RotZ),Frame::DH(KinDef[i].a  ,KinDef[i].alpha * (M_PI/180) ,KinDef[i].d ,KinDef[i].theta * (M_PI/180))));
        RotDir  [i] = KinDef[i].rotDir;
        Max(i) = KinDef[i].maxAngle * (M_PI/180);
        Min(i) = KinDef[i].minAngle * (M_PI/180);
        Velocity[i] = KinDef[i].velocity;

        Actuall(i) = 0;
    }

	// for now and testing
    Kinematic = temp;

	// get the actual TCP out of the axis
	calcTcp();
}

double Robot6Axis::getMaxAngle(int Axis)
{
    return Max(Axis) * (180.0/M_PI);
}

double Robot6Axis::getMinAngle(int Axis)
{
    return Min(Axis) * (180.0/M_PI);
}

void split(std::string const& string, const char delimiter, std::vector<std::string>& destination)
{
    std::string::size_type  last_position(0);
    std::string::size_type  position(0);
         
    for (std::string::const_iterator it(string.begin()); it != string.end(); ++it, ++position)
    {
        if (*it == delimiter )
        {
            destination.push_back(string.substr(last_position, position - last_position ));
            last_position = position + 1;
        }
    }
    destination.push_back(string.substr(last_position, position - last_position ));
}

void Robot6Axis::readKinematic(std::vector<AxisDefinition> i_DHpara)
{
    AxisDefinition temp[6];
    for( int i = 0; i < i_DHpara.size() ; i++){
       temp[i] = i_DHpara[i];
       std::cout << "a: " << temp[i].a
                  << "alpha: " << temp[i].alpha
                  << "d: " << temp[i].d
                  << "theta: " << temp[i].theta
                  << "rotDir: " << temp[i].rotDir
                  << "maxAngle: " << temp[i].maxAngle
                  << "minAngle: " << temp[i].minAngle
                  << "velocity: " << temp[i].velocity << std::endl;
    }

    setKinematic(temp);
}

unsigned int Robot6Axis::getMemSize (void) const
{
	return 0;
}

void Robot6Axis::Save (Writer &writer) const
{
    for(unsigned int i=0;i<6;i++){
        Base::Placement Tip = toPlacement(Kinematic.getSegment(i).getFrameToTip());
	    writer.Stream() << writer.ind() << "<Axis "
                        << "Px=\""          <<  Tip.getPosition().x  << "\" " 
                        << "Py=\""          <<  Tip.getPosition().y  << "\" "
                        << "Pz=\""          <<  Tip.getPosition().z  << "\" "
					    << "Q0=\""          <<  Tip.getRotation()[0] << "\" "
                        << "Q1=\""          <<  Tip.getRotation()[1] << "\" "
                        << "Q2=\""          <<  Tip.getRotation()[2] << "\" "
                        << "Q3=\""          <<  Tip.getRotation()[3] << "\" "
                        << "rotDir=\""      <<  RotDir[i]		     << "\" "
                        << "maxAngle=\""    <<  Max(i)               << "\" "
                        << "minAngle=\""    <<  Min(i)               << "\" "
                        << "AxisVelocity=\""<<  Velocity[i]          << "\" "
                        << "a=\""           <<  axisDH[i].a          << "\" "
                        << "alpha=\""       <<  axisDH[i].alpha      << "\" "
                        << "d=\""           <<  axisDH[i].d          << "\" "
                        << "theta=\""       <<  axisDH[i].theta      << "\" "
                        << "Pos=\""         <<  Actuall(i)           << "\"/>"
					                      
                        << std::endl;
    }

}

void Robot6Axis::Restore(XMLReader &reader)
{
    Chain Temp;
    Base::Placement Tip;
    axisDH.clear();

    for(unsigned int i=0;i<6;i++){
        // read my Element
        reader.readElement("Axis");
        // get the value of the placement
        Tip =    Base::Placement(Base::Vector3d(reader.getAttributeAsFloat("Px"),
                                                reader.getAttributeAsFloat("Py"),
                                                reader.getAttributeAsFloat("Pz")),
                                 Base::Rotation(reader.getAttributeAsFloat("Q0"),
                                                reader.getAttributeAsFloat("Q1"),
                                                reader.getAttributeAsFloat("Q2"),
                                                reader.getAttributeAsFloat("Q3")));
        Temp.addSegment(Segment(Joint(Joint::RotZ),toFrame(Tip)));


        if(reader.hasAttribute("rotDir"))
            Velocity[i] = reader.getAttributeAsFloat("rotDir");
        else
            Velocity[i] = 1.0;
        // read the axis constraints
        Min(i)  = reader.getAttributeAsFloat("minAngle");
        Max(i)  = reader.getAttributeAsFloat("maxAngle");
        if(reader.hasAttribute("AxisVelocity"))
            Velocity[i] = reader.getAttributeAsFloat("AxisVelocity");
        else
            Velocity[i] = 156.0;

        AxisDefinition t_axis;
        t_axis.a = reader.getAttributeAsFloat("a");
        t_axis.alpha = reader.getAttributeAsFloat("alpha");
        t_axis.d = reader.getAttributeAsFloat("d");
        t_axis.theta = reader.getAttributeAsFloat("theta");

        Actuall(i) = reader.getAttributeAsFloat("Pos");

        axisDH.push_back(t_axis);
    }
    Kinematic = Temp;

    calcTcp();

}



int Robot6Axis::setTo(const Placement &To, std::vector<bool> LinkConfig)
{
	//Creation of the solvers:
	ChainFkSolverPos_recursive fksolver1(Kinematic);//Forward position solver
	ChainIkSolverVel_pinv iksolver1v(Kinematic);//Inverse velocity solver
    //ChainIkSolverPos_NR_JL iksolver1(Kinematic,Min,Max,fksolver1,iksolver1v,100,1e-6);//Maximum 100 iterations, stop at accuracy 1e-6
  //  ChainIkSolverPos_SI_JL iksolver1(Kinematic,Min,Max,fksolver1,iksolver1v,100,1e-6);
    invKinematics iksolver1(axisDH, Min, Max);
	//Creation of jntarrays:
	JntArray result(Kinematic.getNrOfJoints());
	 
	//Set destination frame
	Frame F_dest = Frame(KDL::Rotation::Quaternion(To.getRotation()[0],To.getRotation()[1],To.getRotation()[2],To.getRotation()[3]),KDL::Vector(To.getPosition()[0],To.getPosition()[1],To.getPosition()[2]));
	 
	// solve
    if(!iksolver1.CartToJnt(Actuall,F_dest,result, LinkConfig))
        return 0;
	else{
		Actuall = result;
		Tcp = F_dest;
        int iResult = 1;
        for (int i = 0; i < 6; i ++)
        {
            double axis = RotDir[i] * (Actuall(i)/(M_PI/180));
            if (axis < Min(i) || axis > Max(i))
            {
                iResult = 2;
            }
        }
        return iResult;
	}
}

Base::Placement Robot6Axis::getTcp(void)
{
	double x,y,z,w;
	Tcp.M.GetQuaternion(x,y,z,w);
	return Base::Placement(Base::Vector3d(Tcp.p[0],Tcp.p[1],Tcp.p[2]),Base::Rotation(x,y,z,w));
}


Base::Placement Robot6Axis::getSpecifyJointTcp(int i_jointNum)
{
   double x,y,z,w;
   JointTcp[i_jointNum].M.GetQuaternion(x,y,z,w);
   return Base::Placement(Base::Vector3d(JointTcp[i_jointNum].p[0],JointTcp[i_jointNum].p[1],JointTcp[i_jointNum].p[2]),Base::Rotation(x,y,z,w));
}

bool Robot6Axis::calcTcp(void)
{
    // Create solver based on kinematic chain
    ChainFkSolverPos_recursive fksolver = ChainFkSolverPos_recursive(Kinematic);
 
     // Create the frame that will contain the results
   // KDL::Frame cartpos;
 
    // Calculate forward position kinematics
    int kinematics_status;

    JointTcp.clear();
   // kinematics_status = fksolver.JntToCart(Actuall,cartpos);
    kinematics_status = fksolver.JntToCart(Actuall,JointTcp);

    if(kinematics_status>=0){
        if (JointTcp.size() == 0)
        {
            Tcp = Frame::Identity();
        }
        else
        {
           Tcp = JointTcp[JointTcp.size() - 1];
        }
		return true;
    }else{
        JointTcp.clear();
        return false;
    }
}

bool Robot6Axis::setAxis(int Axis,double Value)
{
	Actuall(Axis) = RotDir[Axis] * Value * (M_PI/180); // degree to radiants

	return calcTcp();
}

double Robot6Axis::getAxis(int Axis)
{
	return RotDir[Axis] * (Actuall(Axis)/(M_PI/180)); // radian to degree
}


