#include "../PreCompiled.h"

#ifndef _PreComp_
#endif

#include "ABBProgGenerator.h"
#include "RobotInstruction.h"



using namespace  std;
using namespace  Eigen;

namespace WirCore {
std::ostream& operator<< (std::ostream& oss,  const Eigen::Quaterniond& quad){
    oss<<"["<<quad.w()<<", "<<quad.x()<<", "<<quad.y()<<", "<<quad.z()<<"]";
    return oss;
}
std::ostream& operator<< (std::ostream& oss, const Eigen::Vector3d& vec){
    oss<<"["<<vec.x()<<", "<<vec.y()<<", "<<vec.z()<<"]";
    return oss;
}
std::ostream& operator<< (std::ostream& oss, const Robot6D& r6d){
    oss<<r6d.getPosition()<<", "<<r6d.getOrientation();
    return oss;
}

std::ostream& operator<< (std::ostream &oss, const RobotAxis& ra){
    oss<<"[";
    for (int i=0;i<ra.getNum();i++){
        oss<<ra.getAxisValues()[i];
        if(i!=ra.getNum()-1)
             oss<<",";
    }
    oss<<"]";
    return oss;
}

// modification required here
std::ostream& operator<< (std::ostream &oss, const RobotToolLoad& rtl){
    oss<<"["<<rtl.mass<<", "<<rtl.getPosition()<<", "
      <<rtl.getPrincipalInertiaAxis()<<", "<<rtl.getPrincipalInertia()<<"]";
    return oss;
}

}

using namespace WirCore;


ABBProgGenerator::ABBProgGenerator(std::string name)
    :ABBProgGenerator()
{
    progName=name;
}
ABBProgGenerator::ABBProgGenerator(){

//    Base::Console().Message("Enter Here 32!!\n");
    m_traj = nullptr;


    defaultSpeeddataName="wirSpeed";
    defaultZonedataName="wirZone";
    defaultExtaxName="wirExtax";


    defaultContext();
}

ABBProgGenerator::~ABBProgGenerator(){
//    Base::Console().Message("Enter Here 33!!\n");

}



void ABBProgGenerator::generateMoveJ(WirCore::WaypointObject* cmd,ProgStringWriter& writer){
    WirCore::WorkFrameObject* wobj;
    auto point = dynamic_cast<WirCore::PointObject*>(cmd->linkPoint.getValue());
    if (point) {
        auto group(App::GeoFeatureGroupExtension::getGroupOfObject(point));
        if (group) {
            wobj = group->getExtensionByType< WirCore::WorkFrameObject>();
        }
    }
    else
    {
        return;
    }

    Robot6D target(point->Placement.getValue());
    writer.Stream()<<writer.ind()<<"MoveJ "<<"["<<target<<","
                  <<"[-1,0,-1,0],"<<defaultExtaxName<<"], "
                 <<defaultSpeeddataName<<", "
                <<defaultZonedataName<<", "
               <<(cmd->linkTool.getValue())->Label.getValue()<<", "
              <<"\\WObj:="<<wobj->Label.getValue()<<";"<<endl;
}


void ABBProgGenerator::generateMoveL(WirCore::WaypointObject* cmd,ProgStringWriter& writer){
    WirCore::WorkFrameObject* wobj;
    auto point = dynamic_cast<WirCore::PointObject*>(cmd->linkPoint.getValue());
    if (point) {
        auto group( App::GeoFeatureGroupExtension::getGroupOfObject(point) );
        if (group) {
            wobj = group->getExtensionByType< WirCore::WorkFrameObject>();
        }
    }
    else
    {
        return;
    }
    Robot6D target(point->Placement.getValue());
    writer.Stream()<<writer.ind()<<"MoveL "<<"["<<target<<","
                  <<"[-1,0,-1,0],"<<defaultExtaxName<<"], "
                 <<defaultSpeeddataName<<", "
                <<defaultZonedataName<<", "
               <<(cmd->linkTool.getValue())->Label.getValue()<<", "
              <<"\\WObj:="<<wobj->Label.getValue()<<";"<<endl;
}


void ABBProgGenerator::generateExtaxDef(ProgStringWriter& writer){
    writer.Stream()<<"VAR extjoint  "<<defaultExtaxName<<" := ["
                  <<"9E9,9E9,9E9,9E9,9E9,9E9];"<<endl;
}


void ABBProgGenerator::generateWobjdataDef(ProgStringWriter& writer){

    for (auto _obj : vecWojs)
    {
        string s1=_obj->robotHold.getValue()? "TRUE, ":"FALSE, ";
        string s2= "TRUE, ";

        Base::Placement UfPla;
        Base::Placement OfPla = _obj->wobjPlacement.getValue();

        if (!_obj->robotHold.getValue())
        {
            OfPla = _obj->Placement.getValue();
        }

        Robot6D uframe(UfPla);
        Robot6D oframe(OfPla);


        writer.Stream()<<"PERS wobjdata "<<_obj->Label.getValue()<<" := ["
                      <<s1<<s2<<"\"\", ";
                     writer.Stream()<<"["<<UfPla<<"]";
                     writer.Stream()<<",";
                     writer.Stream()<<"["<<OfPla<<"]"
                      <<"];"<<endl;
    }
}

void ABBProgGenerator::generateTooldataDef(ProgStringWriter& writer){
    for (auto _obj : vecTools)
    {
        Base::Placement tfPla = _obj->toolPlacement.getValue();
        Base::Vector3d _vec = _obj->toolFocus.getValue();
        Eigen::Vector3d pos(_vec.x, _vec.y, _vec.z);
        Eigen::Quaternionf Axis = Quaternionf::Identity();
        _vec = _obj->toolInertia.getValue();
        Eigen::Vector3d Inertia(_vec.x, _vec.y, _vec.z);

        RobotToolLoad tload(_obj->mass.getValue(), pos, Axis, Inertia);

        string s=_obj->robotHold.getValue() ? "TRUE, ":"FALSE, ";

        if (!_obj->robotHold.getValue())
        {
            tfPla = _obj->Placement.getValue() * _obj->toolPlacement.getValue();
        }

        Robot6D tframe(tfPla);

        writer.Stream()<<"PERS tooldata "<<_obj->Label.getValue()<<" := [ "
                      <<s<<"["<< tframe <<"],"
                     <<tload.toString()<<"];"<<endl;
    }
}



void ABBProgGenerator::generateZonedataDef(RobotZonedata& obj, ProgStringWriter& writer){

    if (obj.usePredefined){
        writer.Stream()<<"VAR zonedata "<<obj.getName()<<" :=   "
                      <<obj.predefined<<";"<<endl;
    }
    else{
        string s=obj.finep ? "TRUE, ":"FALSE, ";
        writer.Stream()<<"VAR zonedata "<<obj.getName()<<" := [ "
                      <<s<<", "<<obj.pzone_tcp<<", "<<obj.pzone_ori<<", "<<obj.pzone_eax<<", "
                     <<obj.zone_ori<<", "<<obj.zone_leax<<", "<<obj.zone_reax
                    <<"];"<<endl;
    }
}

void ABBProgGenerator::generateSpeeddataDef(RobotSpeeddata& obj,ProgStringWriter& writer)
{
    if (obj.usePredefined){
        writer.Stream()<<"VAR speeddata  "<<obj.getName()<<" :=   "
                      <<obj.predefined<<";";
    }
    else{
        writer.Stream()<<"VAR speeddata  "<<obj.getName()<<" := [ "
                      <<obj.v_tcp<<", "<<obj.v_orientation<<", "<<obj.v_leax<<", "
                     <<obj.v_reax<<"];"<<endl;
    }
}

void ABBProgGenerator::generateSpeeddata(RobotSpeeddata& obj, ProgStringWriter& writer)
{
    writer.Stream() << "speeddata " << obj.getName() << " := [ "
                    << obj.v_tcp<< ", " << obj.v_orientation<< ", "<< obj.v_leax<<", "
                    << obj.v_reax << "];" << endl;
}




void ABBProgGenerator::initContext( ProgStringWriter& writer){
    generateWobjdataDef(writer);
    generateTooldataDef(writer);
    if (defaultSpeeddata)
        generateSpeeddataDef(*defaultSpeeddata,writer);
    if (defaultZonedata)
        generateZonedataDef(*defaultZonedata,writer);
    generateExtaxDef(writer);
    writer.Stream()<<endl;
}
void ABBProgGenerator::defaultContext(){
    defaultSpeeddata=new RobotSpeeddata(500,500,defaultSpeeddataName);
    defaultZonedata=new RobotZonedata(defaultZonedataName,"z1");
}

void ABBProgGenerator::generateMainHeader(ProgStringWriter& writer)
{
    writer.Stream()<<writer.ind()<<"ConfJ \\On;"<<endl;
    writer.Stream()<<writer.ind()<<"ConfL \\Off;"<<endl;
    writer.Stream()<<writer.ind()<<"SingArea\\Wrist;"<<endl;
}

void  ABBProgGenerator::FindWobjandTool(std::vector<WirCore::WaypointObject*> vec)
{
    std::vector<WirCore::WaypointObject*> waypoints = vec;
    vecWojs.clear();
    vecTools.clear();
    for (auto obj : waypoints)
    {
        bool flag = true;
        WirCore::WorkFrameObject* wobj( nullptr );
        auto point = obj->linkPoint.getValue();
        if (point) {
            auto group( App::GeoFeatureGroupExtension::getGroupOfObject(point) );
            if (group) {
                wobj = group->getExtensionByType< WirCore::WorkFrameObject>();
            }
        }

        for (auto _wobj : vecWojs)
        {
            if (_wobj->Label.getValue() == wobj->Label.getValue())
            {
                flag = false;
                break;
            }
        }

        if (flag)
        {
            vecWojs.push_back(wobj);
        }

        flag = true;

        auto Tool = dynamic_cast<WirCore::ToolObjectReferenceFrame*>(obj->linkTool.getValue());

        for (auto _Tool : vecTools)
        {
            if (_Tool->Label.getValue() == Tool->Label.getValue())
            {
                flag = false;
                break;
            }
        }

        if (flag)
        {
            vecTools.push_back(Tool);
        }

    }
}
string ABBProgGenerator::generateProg(WirCore::TrajectoryObject* traj) {
    string name = progName + "program";
    ProgStringWriter writer;
    m_traj = traj;
    std::vector<WirCore::WaypointObject*> waypoints = m_traj->getAllPointsInTrajectory();
    FindWobjandTool(waypoints);

    writer.Stream() << "MODULE MOD_wirProg" << endl << endl;

    initContext(writer);
    writer.Stream() << "PROC main_Wir()" << endl;
    writer.incInd();
    writer.Stream() << writer.ind() << name << ";" << endl
                    << writer.ind() << "EXIT;" << endl;
    writer.decInd();
    writer.Stream() << "ENDPROC" << endl << endl;

    writer.Stream() << "PROC " << name << "()" << endl;
    writer.incInd();
    generateMainHeader(writer);

    for(auto _obj : waypoints ) {
        if(_obj->waypointType.getEnum() == "MoveJ"){
            generateMoveJ(_obj, writer);
        }
        else if(_obj->waypointType.getEnum() == "MoveL"){
            generateMoveL(_obj, writer);
        }
    }
    writer.decInd();
    writer.Stream() << "ENDPROC" << endl << endl;
    writer.Stream() << "ENDMODULE" << endl << endl;
    return writer.getString();
}


