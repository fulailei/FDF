
#ifndef WIROLP_PROG_STRINGWRITER_H
#define WIROLP_PROG_STRINGWRITER_H


#include <sstream>

namespace WirCore
{

class Persistence;


class  ProgStringWriter
{
private:
  //  std::string getUniqueFileName(const char *Name);

    short indent;
    char indBuf[1024];

    std::ostringstream strStream;

public:
    ProgStringWriter(void);
    ~ProgStringWriter();
    std::ostringstream &Stream(void){return strStream;}

    std::string getString(void) const {return strStream.str();}
    /** @name Error handling */
    //@{
 //   void addError(const std::string&);
 //   bool hasErrors() const;
  //  void clearErrors();
 //   std::vector<std::string> getErrors() const;
    //@}

    /** @name pretty formatting for XML */
    //@{
    /// get the current indentation
    const char* ind(void) const {return indBuf;}
    /// increase indentation by one tab
    void incInd(void);
    /// decrease indentation by one tab
    void decInd(void);
    //@}

//    virtual std::ostream &Stream(void)=0;




};


}  //namespace WirOlp


#endif // WIROLP_PROG_STRINGWRITER_H
