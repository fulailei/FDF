#include "../PreCompiled.h"

#ifndef _PreComp_
#endif
#include "ProgStringWriter.h"

using namespace WirCore;
using namespace  std;


ProgStringWriter::ProgStringWriter(void)
    :indent(0)
{
    indBuf[0] = '\0';
}



ProgStringWriter::~ProgStringWriter(){

}


void ProgStringWriter::incInd(void)
{
    if (indent < 1020) {
        indBuf[indent  ] = ' ';
        indBuf[indent+1] = ' ';
        indBuf[indent+2] = ' ';
        indBuf[indent+3] = ' ';
        indBuf[indent+4] = '\0';
        indent += 4;
    }
}

void ProgStringWriter::decInd(void)
{
    if (indent >= 4) {
        indent -= 4;
    }
    else {
        indent = 0;
    }
    indBuf[indent] = '\0';
}
