
#ifndef WIRCORE_ROBOT_INSTRUCTION_H
#define WIRCORE_ROBOT_INSTRUCTION_H



#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <string>
#include <vector>
#include <Base/Placement.h>


namespace WirCore
{


class RobotInstruction
{
public:
    std::string getName();
    RobotInstruction(std::string name);
    virtual ~RobotInstruction();
//    virtual ~RobotInstruction()=0;
//    virtual void setName(std::string name);
protected:
    RobotInstruction();
    std::string name;

};

class RobotParameter:public RobotInstruction
{
public:
    RobotParameter();
    RobotParameter(std::string name);
    bool isPredefined();
//private:
//    std::string name;
public:
    std::string predefined;
    bool usePredefined;
};

////////////////////////////////////////////////////
/// \brief The Robot6D class
///
class Robot6D : public RobotParameter
{
public:
    Robot6D(std::string name="");
    Robot6D(float x,float y,float z,float w,float wx,float wy,float wz,std::string name="");
    Robot6D(Eigen::Vector3d position,Eigen::Quaterniond orientation=Eigen::Quaterniond::Identity(),std::string name="");
    Robot6D(const Base::Placement pla, std::string name="" );
//    Robot6D(float x,float y,float z,float w,float wx,float wy,float wz);
//    Robot6D(Eigen::Vector3d& position,Eigen::Quaterniond& orientation);
    double x();
    double y();
    double z();
    double w();
    double wx();
    double wy();
    double wz();
    void operator=(Robot6D& r6d);
    const Eigen::Vector3d& getPosition() const {return position;}
    const Eigen::Quaterniond& getOrientation() const{return orientation;}
    std::string toString();

   // inline Eigen::Vector3d& getPosition()  {return position;}

   // inline Eigen::Quaterniond& getOrientation() {return orientation;}
private:
    Eigen::Vector3d position;
    Eigen::Quaterniond orientation;
};


class RobotToolLoad : public RobotParameter
{

public:
    RobotToolLoad(double m,Eigen::Vector3d& pos,Eigen::Quaternionf& pia,Eigen::Vector3d& pi);
    void operator=(RobotToolLoad& data);
    const Eigen::Vector3d& getPosition() const {return position;}
    const Eigen::Quaterniond& getPrincipalInertiaAxis() const {return principalInertiaAxis;}
    const Eigen::Vector3d& getPrincipalInertia() const {return principalInertia;}
    std::string toString();
public:
    double mass; //kg
    Eigen::Vector3d position; //mass center
    Eigen::Quaterniond principalInertiaAxis;
    Eigen::Vector3d principalInertia;
};

class RobotAxis : public RobotParameter
{
public:
    RobotAxis(int num,std::vector<double> values);
    int getNum() const {return axisNum;}
    const std::vector<double>& getAxisValues() const {return axisValues;}
private:
    int axisNum;
    std::vector<double> axisValues;
};

class RobotSpeeddata : public RobotParameter
{
public:
    RobotSpeeddata(int v_tcp,int v_orietation,std::string name="");
    RobotSpeeddata(std::string predefinedSpeed,std::string name="");
    ~RobotSpeeddata();
public:
    int v_leax;
    int v_reax;
    int v_tcp;
    int v_orientation;
    int overwrite_v_tcp; //overwritten by \V: in Move Instruction for ABB robot, default value:-1
    int overwrite_t; //overwritten by \T: in Move Instruction for ABB robot, default value:-1
    void operator=(RobotSpeeddata& robotSpeed);
};


class RobotZonedata : public RobotParameter
{
public:
    RobotZonedata(std::string name,int pzone_tcp,int pzone_ori,int zone_ori);
    RobotZonedata(std::string name,std::string predefinedZone);
public:
    bool finep;

    int pzone_tcp;
    int pzone_ori;
    int zone_ori;
    float pzone_eax;
    float zone_leax;
    float zone_reax;
    int overwrite_zon_tcp; //overwritten by \Z: in Move Instruction for ABB robot, default value:-1
    int overwrite_t; //overwritten by \T: in Move Instruction for ABB robot, default value:-1

};


} //namespace WirOlp


#endif // WIROLP_ROBOT_INSTRUCTION_H
