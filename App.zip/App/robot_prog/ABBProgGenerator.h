
#ifndef WIRCORE_ABB_PROG_GENERATOR_H
#define WIRCORE_ABB_PROG_GENERATOR_H

#include "RobotInstruction.h"
#include "ProgStringWriter.h"

#include <sstream>
#include <string>
#include <Eigen/Dense>
#include <memory>

#include <Mod/WirCore/App/TrajectoryObject.h>
#include <Mod/WirCore/App/WaypointObject.h>
#include <Mod/WirCore/App/WorkFrameObject.h>
#include <Mod/WirCore/App/PointObject.h>
#include <Mod/WirCore/App/ToolObjectReferenceFrame.h>

#include <Base/Console.h>

namespace WirCore
{


class ABBProgGenerator
{
public:
    ABBProgGenerator();
    ABBProgGenerator(std::string name);
    ~ABBProgGenerator();
    std::string generateProg(WirCore::TrajectoryObject* traj);

    void generateMoveJ(WirCore::WaypointObject* cmd,ProgStringWriter& writer);
    void generateMoveL(WirCore::WaypointObject* cmd,ProgStringWriter& writer);
    void generateSpeeddata(RobotSpeeddata& obj, ProgStringWriter& writer);

    void defaultContext();

private:
    void initContext(ProgStringWriter& oss);
    void generateWobjdataDef(ProgStringWriter& writer);
    void generateZonedataDef(RobotZonedata& obj,ProgStringWriter& writer);
    void generateSpeeddataDef(RobotSpeeddata& obj,ProgStringWriter& writer);
    void generateTooldataDef(ProgStringWriter& writer);
    void generateExtaxDef(ProgStringWriter& writer);
    void generateMainHeader(ProgStringWriter& writer);

    void FindWobjandTool(std::vector<WirCore::WaypointObject*> vec);

    WirCore::TrajectoryObject* m_traj;
    std::vector<WirCore::WorkFrameObject*> vecWojs;
    std::vector<WirCore::ToolObjectReferenceFrame*> vecTools;
    std::string progName;
    std::string defaultSpeeddataName;
    std::string defaultZonedataName;
    std::string defaultExtaxName;

    RobotSpeeddata* defaultSpeeddata;
    RobotZonedata* defaultZonedata;
};



} //namespace WirOlp


#endif // WIROLP_ABB_PROG_GENERATOR_H
