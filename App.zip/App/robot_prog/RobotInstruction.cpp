#include "../PreCompiled.h"

#ifndef _PreComp_
#endif

#include "RobotInstruction.h"
#include <Base/Console.h>
using namespace WirCore;
using namespace std;

string RobotInstruction::getName(){
    return name;
}


RobotInstruction::RobotInstruction(string n)
    :name(n)
{

}

RobotInstruction::RobotInstruction(){

}


RobotInstruction::~RobotInstruction(){

}

RobotAxis::RobotAxis(int num,vector<double> values)
    :axisNum(num), axisValues(values)
{

}


RobotParameter::RobotParameter(string n)
    :RobotInstruction (n)
{

}



RobotParameter::RobotParameter()
    :RobotInstruction ("")
{

}

bool RobotParameter::isPredefined(){
    return usePredefined;
}




RobotZonedata::RobotZonedata(string name,int pzone_tcp,int pzone_ori,int zone_ori)
    :RobotParameter (name)
{
    this->pzone_tcp=pzone_tcp;
    this->pzone_ori=pzone_ori;
    this->zone_ori=zone_ori;
    usePredefined=false;
}


RobotSpeeddata::RobotSpeeddata(int tcp,int orietation,string name)
    :RobotParameter(name),v_tcp(tcp),v_orientation(orietation)
{
    overwrite_v_tcp=-1; //overwritten by \V: in Move Instruction for ABB robot, default value:-1
    overwrite_t=-1;
    v_leax=50.0;
    v_reax=500.0;
    usePredefined=false;
}



RobotSpeeddata::RobotSpeeddata(std::string predefinedSpeed,string name)
    :RobotParameter (name)
{
    usePredefined=true;
    this->predefined=predefinedSpeed;
}

void RobotSpeeddata::operator=(RobotSpeeddata& robotSpeed){
    this->v_tcp=robotSpeed.v_tcp;
    this->v_orientation=robotSpeed.v_orientation;
    this->overwrite_t=robotSpeed.overwrite_t;
    this->overwrite_v_tcp=robotSpeed.overwrite_v_tcp;
}


RobotSpeeddata::~RobotSpeeddata(){

}

RobotZonedata::RobotZonedata(string name,string predefinedZone)
    :RobotParameter (name)
{
    usePredefined=true;
    this->predefined=predefinedZone;
}


Robot6D::Robot6D(float x,float y,float z,float w,float wx,float wy,float wz,string name)
    :RobotParameter(name), position(Eigen::Vector3d(x,y,z)),orientation(Eigen::Quaterniond(w,wx,wy,wz)){

}



Robot6D::Robot6D(string name)
    :RobotParameter(name){
    position=Eigen::Vector3d(0,0,0);
    orientation=Eigen::Quaterniond::Identity();

}


void Robot6D::operator=(Robot6D& r6d){
    this->position=r6d.position;
    this->orientation=r6d.orientation;
}

Robot6D::Robot6D(Eigen::Vector3d position,Eigen::Quaterniond orientation,string name)
    :RobotParameter (name){
    this->position=position;
    this->orientation=orientation;
}

Robot6D::Robot6D(const Base::Placement pla,string name)
    :RobotParameter (name){
    double q0, q1, q2, q3;
    pla.getRotation().getValue(q0, q1, q2, q3);
    Eigen::Vector3d pos(pla.getPosition().x, pla.getPosition().y, pla.getPosition().z);
    Eigen::Quaterniond orient(q3, q0, q1 ,q2);

    this->position=pos;
    this->orientation=orient;
}

double Robot6D::x(){
    return position.x();
}
double Robot6D::y(){
    return position.y();
}
double Robot6D::z(){
    return position.z();
}
double Robot6D::w(){
    return orientation.w();
}
double Robot6D::wx(){
    return orientation.x();
}
double Robot6D::wy(){
    return orientation.y();
}
double Robot6D::wz(){
    return orientation.z();
}

string Robot6D::toString(){

    ostringstream oss;
    oss<<"["<<position.x()<<","<<position.y()<<","<<position.z()<<"],["
            <<orientation.w()<<","<<orientation.x()<<","<<orientation.y()<<","
            <<orientation.z()<<"]";
    return oss.str();
}


RobotToolLoad::RobotToolLoad(double m,Eigen::Vector3d& pos,Eigen::Quaternionf& pia,Eigen::Vector3d& pi)
    :mass(m),position(pos),principalInertiaAxis(pia),principalInertia(pi)
{

}


void RobotToolLoad::operator=(RobotToolLoad& data){
    mass=data.mass;
    position=data.position;
    principalInertia=data.principalInertia;
    principalInertiaAxis=data.principalInertiaAxis;
}

string RobotToolLoad::toString() {
    ostringstream oss;
    oss << "[" << mass << ", [" << position.x() << ", " << position.y() << ", " << position.z() << "], ["
        << principalInertiaAxis.w() << ", " << principalInertiaAxis.x() << ", " << principalInertiaAxis.y() << ", " << principalInertiaAxis.z() << "], "
        << principalInertia.x() << ", " << principalInertia.y() << ", " << principalInertia.z() << "]";
    return oss.str();
}
