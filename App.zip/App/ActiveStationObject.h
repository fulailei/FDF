#ifndef WIRCORE_ACTIVESTATIONOBJECT_H
#define WIRCORE_ACTIVESTATIONOBJECT_H

#include <App/DocumentObject.h>


namespace WirCore
{
class ActiveStationObject : public App::DocumentObject
{
     PROPERTY_HEADER(WirCore::ActiveStationObject);
public:
    ActiveStationObject();
    virtual ~ActiveStationObject();

     App::PropertyLink Object;

protected:
     virtual void onChanged (const App::Property* prop);

};
}
#endif // ACTIVESTATIONOBJECT_H
