#include "log.h"

#include "spdlog/sinks/stdout_color_sinks.h"
#include "spdlog/sinks/basic_file_sink.h"

namespace WirCore
{
    std::shared_ptr<spdlog::logger> Log::logger_;

    void Log::Init()
    {
      std::vector<spdlog::sink_ptr> sinks;
      sinks.push_back(std::make_shared<spdlog::sinks::stdout_color_sink_mt>());
      sinks.push_back(std::make_shared<spdlog::sinks::basic_file_sink_mt>("wircore.log",true));

      sinks[0]->set_pattern("%^[%T] %n: %v%$");
      sinks[1]->set_pattern("[%T] [%l] %n: %v");

      logger_ = std::make_shared<spdlog::logger>("WirCore", begin(sinks), end(sinks));
      spdlog::register_logger(logger_);
      logger_->set_level(spdlog::level::trace);
      logger_->flush_on(spdlog::level::trace);

    }

}
