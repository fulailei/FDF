#pragma once
#include <memory>
#include "spdlog/spdlog.h"

namespace WirCore
{

class Log
{
public:
    static void Init();

    inline static std::shared_ptr<spdlog::logger>& GetLogger() { return logger_; }

private:
    static std::shared_ptr<spdlog::logger> logger_;
};

}

#define WIR_TRACE(...)      WirCore::Log::GetLogger()->trace(__VA_ARGS__)
#define WIR_DEBUG(...)      WirCore::Log::GetLogger()->debug(__VA_ARGS__)
#define WIR_INFO(...)       WirCore::Log::GetLogger()->info(__VA_ARGS__)
#define WIR_WARN(...)       WirCore::Log::GetLogger()->warn(__VA_ARGS__)
#define WIR_ERROR(...)      WirCore::Log::GetLogger()->error(__VA_ARGS__)
#define WIR_CRITICAL(...)   WirCore::Log::GetLogger()->critical(__VA_ARGS__)
