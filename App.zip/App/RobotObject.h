/***************************************************************************
 *   Copyright (c) 2008 Jürgen Riegel (juergen.riegel@web.de)              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#ifndef WIRCORE_ROBOTOBJECT_H
#define WIRCORE_ROBOTOBJECT_H


#include "PreCompiled.h"

#ifndef _PreComp_
    # include <QDomDocument>
    # include <QFile>
#endif

#include <App/GeoFeature.h>
#include <App/PropertyFile.h>
#include <App/PropertyGeo.h>
#include <App/PropertyLinks.h>
#include <App/Part.h>
#include <Mod/Part/App/PartFeature.h>

#include <App/OriginGroupExtension.h>

#include "Robot6Axis.h"
#include "WorkStationGroup.h"

namespace WirCore
{

class RobotObject : public App::GeoFeature,
                    public App::OriginGroupExtension
{
    PROPERTY_HEADER(WirCore::RobotObject);

public:
    /// Constructor
    RobotObject(void);
    virtual ~RobotObject();

    /// returns the type name of the ViewProvider
    virtual const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderRobotObject";
    }
    virtual App::DocumentObjectExecReturn *execute(void) {
        return App::DocumentObject::StdReturn;
    }
    virtual short mustExecute(void) const;
    virtual PyObject *getPyObject(void);

	virtual void Save (Base::Writer &/*writer*/) const;
    virtual void Restore(Base::XMLReader &/*reader*/);

    Robot6Axis &getRobot(void){return robot;}
    //机器人的xml文件所在的位置
    App::PropertyFileIncluded RobotXmlFile;

    App::PropertyFloat Axis1,Axis2,Axis3,Axis4,Axis5,Axis6;
    //各个关节的模型数据
    App::PropertyLinkList LinkList;

	App::PropertyPlacement Tool;
    App::PropertyLink  ToolShape;
	App::PropertyPlacement Tcp;
    App::PropertyPlacement ToolBase;
    //机器人轴配置
    App::PropertyBool           ConfigFront;
    App::PropertyBool           ConfigUp;
    App::PropertyBool           ConfigFlip;

    static std::vector<std::string> defaultLinkNames;
    static std::vector<std::string> defaultAxisNames;
    static int defaultAxisNum;

    std::vector<bool> m_LinkConfig;
    //机器人DH参数
    std::vector<AxisDefinition> DHparam;
    //机器人xml文件中各个关节模型所在的路径位置
    std::vector<QString> vecJointModFile;
    //解析机器人的xml配置文件
    void analyzeConfigZip(const char * FileName);

    //导入各个关节模型时用以调整模型旋转中心所在位置的中间矩阵
    std::vector<Base::Placement> SpecifyJointTcp;
    //每个关节模型的旋转矩阵
    std::vector<Base::Placement> vecJointsTransForm;

    int isLimitPos = true;
    //外部调用机器人求逆解接口，第一个参数为机器人FL末端位置，第二个参数为一个长度为3的机器人轴配置参数，第三个参数为是否将计算的得到的位置刷新到当前机器人
    int setTcpWithLinkConfig(Base::Placement i_Pla, std::vector<bool> i_Vec, bool i_UpdateModel = true);
    //设置机器人轴配置
    bool setLinkConfig(std::vector<bool> i_vec);
    //获取机器人轴配置
    std::vector<bool> getLinkConfig() ;

protected:
    /// get called by the container when a property has changed
    virtual void onChanged (const App::Property* prop);

    Robot6Axis robot;

    void unzipConfigfile(QString FileName,  QString FilePath);
    void LoadRobotXml(QString FilePath);

    bool block;

    void updateAllJointsTcp();

};

} //namespace Robot


#endif // ROBOT_ROBOTOBJECT_H
