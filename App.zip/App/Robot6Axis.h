/***************************************************************************
 *   Copyright (c) Jürgen Riegel          (juergen.riegel@web.de) 2002     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/


#ifndef WIRCORE_ROBOT6AXLE_H
#define WIRCORE_ROBOT6AXLE_H

#include "kdl_cp/chain.hpp"
#include "kdl_cp/jntarray.hpp"

#include <Base/Persistence.h>
#include <Base/Placement.h>

#include "invKinematics.h"

namespace WirCore
{

/** The representation for a 6-Axis industry grade robot
 */
class Robot6Axis : public Base::Persistence
{
    TYPESYSTEM_HEADER();

public:
    Robot6Axis();
    virtual ~Robot6Axis();

	// from base class
    virtual unsigned int getMemSize (void) const;
	virtual void Save (Base::Writer &/*writer*/) const;
    virtual void Restore(Base::XMLReader &/*reader*/);

	// interface
    /// set the kinematic parameters of the robot
    void setKinematic(const AxisDefinition KinDef[6]);
    /// read the kinematic parameters of the robot from a file
    void readKinematic(std::vector<AxisDefinition> i_DHpara);
    
    /// set the robot to that position, calculates the Axis
    int  setTo(const Base::Placement &To, std::vector<bool> LinkConfig);
	bool setAxis(int Axis,double Value);
	double getAxis(int Axis);
    double getMaxAngle(int Axis);
    double getMinAngle(int Axis);
	/// calculate the new Tcp out of the Axis
	bool calcTcp(void);
	Base::Placement getTcp(void);

    Base::Placement getSpecifyJointTcp(int i_jointNum);

    //void setKinematik(const std::vector<std::vector<float> > &KinTable);


protected:
	KDL::Chain Kinematic;
	KDL::JntArray Actuall;
	KDL::JntArray Min;
	KDL::JntArray Max;
	KDL::Frame Tcp;

    std::vector<KDL::Frame> JointTcp;

	double Velocity[6];
	double RotDir  [6];

    std::vector<AxisDefinition> axisDH;

};

} //namespace Part


#endif // PART_TOPOSHAPE_H
