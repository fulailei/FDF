#include "PreCompiled.h"

#ifndef _PreComp_
#include <sstream>
#endif

#include <Base/Console.h>
#include <Base/Writer.h>
#include <Base/Reader.h>
#include <Base/Exception.h>
#include <Base/FileInfo.h>
#include <Base/Stream.h>

#include "PropertyTrajectory.h"
#include "TrajectoryPy.h"

using namespace WirCore;

TYPESYSTEM_SOURCE(WirCore::PropertyTrajectory, App::Property);

PropertyTrajectory::PropertyTrajectory()
{

}

PropertyTrajectory::~PropertyTrajectory()
{
}

void PropertyTrajectory::setValue(KDL::Trajectory_Composite* traj)
{
    aboutToSetValue();
    _Trajectory = traj;
    hasSetValue();
}

KDL::Trajectory_Composite* PropertyTrajectory::getValue() const
{
    return _Trajectory;
}

Base::BoundBox3d PropertyTrajectory::getBoundingBox() const
{
    Base::BoundBox3d box;
    return box;
}

App::Property *PropertyTrajectory::Copy(void) const
{
    PropertyTrajectory *prop = new PropertyTrajectory();
    prop->_Trajectory = this->_Trajectory;
    return prop;
}

void PropertyTrajectory::Paste(const App::Property &from)
{
    aboutToSetValue();
    _Trajectory = dynamic_cast<const PropertyTrajectory&>(from)._Trajectory;
    hasSetValue();
}

unsigned int PropertyTrajectory::getMemSize() const
{
    return 0;
}

void PropertyTrajectory::Save(Base::Writer &writer) const
{
    _Trajectory.Save(writer);
}

void PropertyTrajectory::Restore(Base::XMLReader &reader)
{
    WirCore::Trajectory temp;
    temp.Restore(reader);
    setValue(temp);
}




















