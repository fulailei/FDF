#include "PreCompiled.h"

#ifndef _PreComp_
#endif


#include "TrajectoryOperationObject.h"

using namespace WirCore;
using namespace App;


PROPERTY_SOURCE(WirCore::TrajectoryOperationObject, App::DocumentObject)

TrajectoryOperationObject::TrajectoryOperationObject()
{

}

TrajectoryOperationObject::~TrajectoryOperationObject()
{

}
