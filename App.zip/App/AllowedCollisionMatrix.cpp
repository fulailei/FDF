#include "PreCompiled.h"
#ifndef _PreComp_
#endif

#include <algorithm>
#include <Base/Console.h>
#include "AllowedCollisionMatrix.h"
#include <App/Document.h>
#include <App/DocumentObjectPy.h>
#include <string>       // std::string
#include <iostream>     // std::cout
#include <sstream>      // std::ostringstream

using namespace WirCore;
using namespace App;

TYPESYSTEM_SOURCE(WirCore::AllowedCollisionMatrix , App::DocumentObject);
//PROPERTY_SOURCE(WirOlp::AllowedCollisionMatrix , App::DocumentObject);

std::string AllowedCollisionMatrix::uniqueName = "WIRCOREUNIQUEACMWIRCORE";
bool AllowedCollisionMatrix::bUnique = false;
short AllowedCollisionMatrix::mustExecute(void) const
{
    return 0;
}

PyObject *AllowedCollisionMatrix::getPyObject()
{
    if (PythonObject.is(Py::_None()))
    {
        // ref counter is set to 1
        PythonObject = Py::Object(new DocumentObjectPy(this),true);
    }
    return
            Py::new_reference_to(PythonObject);
}

AllowedCollisionMatrix::~AllowedCollisionMatrix()
{
}

AllowedCollisionMatrix::AllowedCollisionMatrix()
{
    prefix="";
    entry_num=0;
}

//0-index
int AllowedCollisionMatrix::getEntry(int column, int row)
{
    if (column >= entry_num || row >= entry_num)
        return -1;
    else
    {
        return entry_values[row*entry_num + column];
    }
}

void AllowedCollisionMatrix::setEntry(std::string columnName, std::string rowName, int value)
{
    std::vector<std::string>::iterator it=std::find(entry_names.begin(), entry_names.end(), columnName);
    if (it == entry_names.end())
        return ;

    int col = it-entry_names.begin();

    it = std::find(entry_names.begin(), entry_names.end(), rowName);
    if (it == entry_names.end())
        return ;

    int row = it - entry_names.begin();
    //    entry_values.
    setEntry(col, row, value);
    setEntry(row, col, value);
}

int AllowedCollisionMatrix::getEntry(std::string columnName,std::string rowName)
{
    std::vector<std::string>::iterator it = std::find(entry_names.begin(), entry_names.end(), columnName);
    if (it == entry_names.end())
        return -1;
    int col = it - entry_names.begin();

    it = std::find(entry_names.begin(), entry_names.end(), rowName);
    if (it == entry_names.end())
        return -1;

    int row = it-entry_names.begin();
    //    entry_values.
    return getEntry(col, row);
}

void AllowedCollisionMatrix::setEntry(int column,int row,int value)
{
    if (column >= entry_num || row >= entry_num)
        return;
    else
    {
        entry_values[row * entry_num + column] = value;
        entry_values[column * entry_num + row] = value;
    }
}

AllowedCollisionMatrix::AllowedCollisionMatrix(std::string p)
    :prefix(p)
{
}

void AllowedCollisionMatrix::setEntryPrefix(std::string pf)
{
    for (int i = 0; i < entry_names.size(); i++)
    {
        entry_names[i] = pf + "_" + entry_names[i];
    }
}

bool AllowedCollisionMatrix::resetEntryNames(std::vector<std::string>& names)
{
    if (names.size() != entry_names.size())
    {
        return false;
    }
    else
    {
        setEntryNames(names);
        return true;
    }
}

void AllowedCollisionMatrix::setEntryNames(std::vector<std::string>& names)
{
    entry_num = names.size();
    entry_names.resize(entry_num);
    entry_names = names;
    entry_values.resize(entry_num*entry_num);
}

std::string AllowedCollisionMatrix::getEntryName(int index)
{
    if (index < entry_num)
        return entry_names[index];
    else
        return std::string();
}

bool AllowedCollisionMatrix::setEntryValues(std::vector<int>& values)
{
    if (entry_values.size() == 0 || entry_values.size() != values.size())
        return false;
    entry_values = values;
    return true;
}

void AllowedCollisionMatrix::operator=(AllowedCollisionMatrix& acm)
{
    copy(acm);
}

void AllowedCollisionMatrix::copy(AllowedCollisionMatrix& acm)
{
    entry_names.resize(acm.getEntryNum());
    entry_values.resize(acm.getEntryNum()*acm.getEntryNum());
    entry_names = acm.entry_names;
    entry_values = acm.entry_values;
    entry_num = entry_names.size();
}

std::vector<std::string> AllowedCollisionMatrix::getEntryNames()
{
    return entry_names;
}

std::vector<int> AllowedCollisionMatrix::getValues()
{
    return entry_values;
}

void AllowedCollisionMatrix::deleteColumn(int index)
{
    std::vector<std::string>::iterator it;
    int old_entry_num = entry_num;

    entry_num -= 1;
    std::vector<int> newEntryValues,oldEntryValues;
    oldEntryValues.reserve(old_entry_num*old_entry_num);
    oldEntryValues = entry_values;

    entry_values.resize(entry_num*entry_num);
    entry_names.erase(entry_names.begin() + index);

    for (int i = 0; i < entry_num; i++)
    {
        int oldRow;
        oldRow = (i >= index) ? i + 1 : i;
        for (int j = 0; j < entry_num; j++)
        {
            int oldColumn;
            oldColumn = (j >= index) ? j + 1 : j;
            entry_values[i * entry_num + j] = oldEntryValues[oldRow * old_entry_num + oldColumn];
        }
    }
}

void AllowedCollisionMatrix::updateByEntryNames(AllowedCollisionMatrix& acm)
{
    std::vector<std::string> entriesToDelete;
    std::vector<int> entryIndicesToAdd;

    std::vector<std::string>::iterator it;

    int ind = 0;
    for (it = acm.entry_names.begin(); it < acm.entry_names.end(); it++)
    {
        if (!hasEntry(*it))
            entryIndicesToAdd.push_back(ind);
        ind++;
    }

    for (it = entry_names.begin(); it < entry_names.end(); it++)
    {
        if (!acm.hasEntry(*it))
            entriesToDelete.push_back(*it);
    }

    //    Base::Console().Message("Enter Here 89!\n");

    std::vector<std::string>::iterator it2;
    for (it = entriesToDelete.begin(); it < entriesToDelete.end(); it++)
    {
        it2 = std::find(entry_names.begin(), entry_names.end(), (*it));
        int column = it2 - entry_names.begin();
        deleteColumn(column);
    }

    if (entryIndicesToAdd.size() > 0)
    {
        AllowedCollisionMatrix a;
        a.entry_num = entryIndicesToAdd.size();
        for (int i = 0; i < entryIndicesToAdd.size(); i++)
            a.entry_names.push_back(acm.entry_names[entryIndicesToAdd[i]]);
        a.entry_values.resize(a.entry_num*a.entry_num);

        for (int i = 0; i < entryIndicesToAdd.size(); i++)
        {
            for (int j = 0; j < entryIndicesToAdd.size(); j++)
            {
                a.entry_values[i * a.entry_num + j] = acm.entry_values[entryIndicesToAdd[i] *
                        acm.entry_num + entryIndicesToAdd[j]];

                // Base::Console().Message("Entry value is %d!\n",acm.entry_values[entryIndicesToAdd[i]*acm.entry_num+entryIndicesToAdd[j]]);
            }
        }
        // Base::Console().Message("Enter Here 91!\n");
        (*this) += a;
    }
}

std::string AllowedCollisionMatrix::toString()
{
    std::ostringstream os;
    os << "the entry names is ";

    for (int i = 0; i < entry_num; i++)
        os << entry_names[i] << ", ";
    os << std::endl;

    for (int i = 0; i < entry_num; i++)
    {
        for (int j = 0; j < entry_num; j++)
            os << entry_values[i * entry_num + j] << ", ";
        os << std::endl;
    }
    return os.str();
}

void AllowedCollisionMatrix::operator += (AllowedCollisionMatrix& acm)
{
    std::vector<std::string>::iterator it;
    int old_entry_num = entry_num;
    for (it = acm.entry_names.begin(); it < acm.entry_names.end(); it++)
    {
        entry_names.push_back(*it);
    }

    entry_num = entry_names.size();
    std::vector<int> newEntryValues, oldEntryValues;
    oldEntryValues.reserve(old_entry_num * old_entry_num);
    oldEntryValues = entry_values;

    entry_values.resize(entry_num*entry_num);
    for (int i = 0; i < old_entry_num; i++)
    {
        for (int j = 0; j < old_entry_num; j++)
            entry_values[i * entry_num + j] = oldEntryValues[i * old_entry_num + j];
    }
    for (int i = old_entry_num; i < entry_num; i++)
    {
        for (int j = old_entry_num; j < entry_num; j++)
            entry_values[i * entry_num + j] = acm.getEntry(i - old_entry_num,
                                                           j - old_entry_num);//[i*old_entry_num+j];
    }

    for (int i = 0; i < old_entry_num; i++)
    {
        for (int j = old_entry_num; j < entry_num; j++)
        {
            entry_values[i * entry_num + j] = 0;
            entry_values[j * entry_num + i] = 0;
            //            Base::Console().Message("Setting Value (%d,%d) is %d\n",i,j,newEntryValues[i*entry_num+j]);
            //            Base::Console().Message("Setting Value (%d,%d) is %d\n",j,i,newEntryValues[j*entry_num+i]);
            //newEntryValues[(entry_num-1)*entry_num+i]=0;
        }
    }
    /*    Base::Console().Message("the value of old_entry_num is %d\n",old_entry_num);
    Base::Console().Message("the value of entry_num is %d\n",entry_num);
    for (int i=0;i<entry_num;i++){
        for (int j=0;j<entry_num;j++)
            Base::Console().Message("the value of (%d,%d) is %d\n",i,j,entry_values[i*entry_num+j]);
    }*/
}

void AllowedCollisionMatrix::Save(Base::Writer& writer) const
{
    writer.Stream() << writer.ind() << "<ACM size=\""<< entry_num <<"\">" <<std::endl;
    writer.incInd();
    for (int i = 0; i < entry_num; i++)
    {
        std::string name = "e" + i;
        writer.Stream() << writer.ind()
                        << "<Entry name=\"" << name<<"\" value=\"" << entry_names[i] << "\" />"
                        << std::endl;
    }

    for (int i = 0; i < entry_num; i++)
    {
        std::string rowName="r" + i;
        writer.Stream() << writer.ind()<<"<Row name=\""<<rowName+"\" ";
        for (int j = 0; j < entry_num; j++)
        {
            std::string name = "c" + j;
            writer.Stream() << name << "=\"" << entry_values[i * entry_num + j] << "\" ";
        }
        writer.Stream() << "/>" << std::endl;
    }

    writer.decInd(); // indentation for 'ACM'
    writer.Stream() << writer.ind() << "</ACM>" << std::endl;
}

void AllowedCollisionMatrix::Restore(Base::XMLReader & reader)
{
    int count;
    // Column info
    reader.readElement("ACM");
    count = reader.hasAttribute("size") ? reader.getAttributeAsInteger("size") : 0;
    if (count == 0)
        return;

    entry_num = count;
    entry_names.resize(count);
    entry_values.resize(count*count);
    //get entry values
    for (int i = 0; i < count; i++)
    {
        reader.readElement("Entry");
        const char* name = reader.hasAttribute("name") ? reader.getAttribute("name") : nullptr;
        const char* value = reader.hasAttribute("value") ? reader.getAttribute("value") : nullptr;

        try
        {
            if (name && name[0] == 'e' && value)
            {
                int loc = name[1] - '0';
                entry_names[loc] = std::string(value);
            }
        }
        catch (...)
        {
            // Something is wrong, skip this column
        }

    }

    for (int i = 0; i < count; i++)
    {
        reader.readElement("Row");
        const char* name = reader.hasAttribute("name") ? reader.getAttribute("name") : nullptr;

        if (name && name[0] == 'r')
        {
            int row = name[1] - '0';
            try
            {
                for (int j = 0; j < count; j++)
                {
                    std::string colName = "c" + j;
                    int value = reader.hasAttribute(colName.c_str()) ?
                                reader.getAttributeAsInteger(colName.c_str()) : 0;
                    setEntry(j, row, value);
                }
            }
            catch (...)
            {
                // Something is wrong, skip this column
            }
        }
    }
    reader.readEndElement("ACM");
}

void AllowedCollisionMatrix::clear()
{
    entry_names.clear();
    entry_num = 0;
    entry_values.clear();
}

int AllowedCollisionMatrix::getEntryNum()
{
    return entry_num;
}

bool AllowedCollisionMatrix::subEntries(AllowedCollisionMatrix& acm)
{
    std::vector<std::string>::iterator it;
    for (it = acm.entry_names.begin(); it < acm.entry_names.end(); it++)
    {
        if (!hasEntry(*it))
            return false;
    }
    return true;
}

bool AllowedCollisionMatrix::hasEntry(std::string val)
{
    std::vector<std::string>::iterator it = std::find(entry_names.begin(), entry_names.end(), val);
    if (it == entry_names.end())
        return false;
    else
        return true;
}

void AllowedCollisionMatrix::addEntry(std::string entryName)
{
    entry_names.push_back(std::string(entryName.data()));
    entry_num = entry_names.size();
    std::vector<int> newEntryValues,oldEntryValues;

    oldEntryValues.reserve((entry_num - 1) * (entry_num - 1));
    oldEntryValues = entry_values;
    entry_values.resize(entry_num * entry_num);
    for (int i = 0; i < entry_num - 1; i++)
    {
        for (int j = 0; j < entry_num - 1; j++)
            entry_values[i * entry_num + j] = oldEntryValues[i * (entry_num - 1) + j];
    }

    for (int i = 0; i < entry_num - 1; i++)
    {
        entry_values[(i + 1) * entry_num - 1] = 0;
        entry_values[(entry_num - 1) * entry_num + i] = 0;
    }

    entry_values[entry_num * entry_num - 1] = 1;
}
