#ifndef PROCESS_PATH_H
#define PROCESS_PATH_H
#include "PreCompiled.h"
#ifndef _PreComp_
#endif
#include "PointObject.h"
#include "WaypointObject.h"
#include "TrajectoryOperationObject.h"
#include "TrajectoryObject.h"
#include <App/DocumentObjectPy.h>
#include <Base/Placement.h>
#include <App/Application.h>
#include <App/Document.h>
#include "LinkTrajectoryObject.h"
#include <App/DocumentObject.h>
#include <App/PropertyFile.h>
#include <App/PropertyGeo.h>
#include <App/GeoFeature.h>
#include "GeometryObject.h"
#include <TopoDS.hxx>
#include <TopoDS_Edge.hxx>
#include <BRep_Tool.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <CPnts_AbscissaPoint.hxx>
#include <TopExp.hxx>
#include <GeomAPI_ProjectPointOnSurf.hxx>
#include <BOPTools_AlgoTools3D.hxx>
namespace WirCore {
struct  Process_Parameter
{
    double length;
    double tolerance;
    double angle;
};
class Process_Path: public Base::Persistence
{
     TYPESYSTEM_HEADER();
public:
    Process_Path();
    ~Process_Path();
    virtual unsigned int getMemSize (void) const;
    virtual void Save (Base::Writer &/*writer*/) const;
    virtual void Restore(Base::XMLReader &/*reader*/);
    void Ganerate_Process_Path(WirCore::GeometryObject *geom,WirCore::WorkFrameObject* wobj,WirCore::ToolObjectReferenceFrame* toolObject);
    void Set_Parameter(Process_Parameter input_Parameter);
    Process_Parameter *Get_Parameter();
    TrajectoryObject *Get_trajectory();
private:
    Process_Parameter *Save_Parameter;
protected:
    TrajectoryObject *traj;
};
}
#endif // PROCESS_PATH_H
