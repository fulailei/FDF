#ifndef WIRCORE_GEOMETRYOBJECT_H
#define WIRCORE_GEOMETRYOBJECT_H

#include "Mod/Part/App/PartFeature.h"

namespace WirCore
{

class GeometryObject : public Part::Feature
{
    PROPERTY_HEADER(WirCore::GeometryObject);

public:
    GeometryObject();
    /// returns the type name of the ViewProvider
    const char* getViewProviderName(void) const {
        return "WirCoreGui::ViewProviderGeometryObject";
    }
    typedef std::pair<App::DocumentObject*, App::DocumentObject*> edges_faces;
    std::vector<edges_faces> obj_group;
};

} //namespace WirCore


#endif // WIRCORE_GEOMETRY_H

