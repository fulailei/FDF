#ifndef WIRCORE_TRAJECTORYOPERATIONOBJECT_H
#define WIRCORE_TRAJECTORYOPERATIONOBJECT_H


#include <App/DocumentObject.h>
namespace WirCore
{
class TrajectoryOperationObject : public App::DocumentObject
{
    PROPERTY_HEADER(WirCore::TrajectoryOperationObject);
public:
    TrajectoryOperationObject();

    virtual ~TrajectoryOperationObject();
};
}
#endif // TRAJECTORYOPERATIONOBJECT_H
